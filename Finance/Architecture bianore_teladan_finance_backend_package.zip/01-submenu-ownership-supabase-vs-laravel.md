# Bianore Teladan — Finance Sub Menu Ownership
_Last updated: 2026-05-25_

## Prinsip Pembagian Supabase vs Laravel

**Supabase dipakai untuk data core, query cepat, tenant isolation, RPC transaksi, dashboard metric, dan report base query.**  
**Laravel dipakai untuk workflow bisnis yang butuh orchestration, approval flow kompleks, file upload validation, payment batch process, export, notification, integration ke payroll/accounting/bank, dan audit service yang lebih fleksibel.**

> Kesimpulan praktis: UI boleh ambil data list/summary dari Supabase RPC via Laravel wrapper. Untuk action penting seperti approve, reject, pay, sync payroll, export, upload receipt, lebih aman lewat Laravel.

---

## 1. Finance Overview

**Sub menu:** Finance / Overview  
**Primary backend:** Supabase RPC + Laravel wrapper  
**Kenapa:** summary dashboard harus cepat, tapi alerts/action butuh orchestration.

### Supabase
- `finance_overview_summary(p_tenant_id, p_period_month)`
- `finance_alerts_today(p_tenant_id)`
- View aggregations:
  - `finance_reimbursement_summary_v`
  - `finance_cash_advance_summary_v`
  - `finance_payroll_cost_preview_v`

### Laravel
- Endpoint wrapper:
  - `GET /api/finance/overview`
  - `GET /api/finance/alerts`
- Resolve user tenant dari JWT Laravel.
- Normalize response supaya UI stabil.
- Bisa cache 30–60 detik untuk dashboard.

### UI needs
- Summary cards
- Finance alerts
- Pending approval list
- Recent activity
- Quick actions

---

## 2. Reimbursement

**Sub menu:** Finance / Reimbursement  
**Primary backend:** Laravel untuk action, Supabase untuk data + RPC transaction

### Supabase
- Tables:
  - `finance_reimbursements`
  - `finance_reimbursement_items`
  - `finance_reimbursement_categories`
  - `finance_reimbursement_policies`
  - `finance_receipts`
- RPC:
  - `finance_reimbursement_list`
  - `finance_reimbursement_detail`
  - `finance_create_reimbursement`
  - `finance_submit_reimbursement`
  - `finance_mark_reimbursement_paid`
  - `finance_sync_reimbursement_to_payroll`

### Laravel
- Upload receipt/photo proof.
- Validate file type, file size, virus-safe basic check.
- Approval action:
  - approve
  - reject
  - request revision
- Notification to employee/manager/finance.
- Export reimbursement report.
- Sync approved reimbursement to payroll component.

### Why Laravel action?
Karena action approval butuh:
- role checking
- multi-step approval
- notification
- attachment validation
- audit log
- possible payroll integration

---

## 3. Cash Advance

**Sub menu:** Finance / Cash Advance  
**Primary backend:** Laravel for workflow + Supabase for ledger/RPC

### Supabase
- Tables:
  - `finance_cash_advances`
  - `finance_cash_advance_settlements`
  - `finance_cash_advance_settlement_items`
- RPC:
  - `finance_cash_advance_list`
  - `finance_cash_advance_detail`
  - `finance_create_cash_advance`
  - `finance_disburse_cash_advance`
  - `finance_settle_cash_advance`
  - `finance_overdue_cash_advances`

### Laravel
- Approve/reject request.
- Disbursement flow with reference number.
- Settlement upload receipt.
- Generate payroll deduction if advance is overdue/unsettled.
- Send reminder before/after due date.

### UI needs
- All advances
- Request approval
- Disbursement
- Settlement
- Overdue advance

---

## 4. Employee Allowance

**Sub menu:** Finance / Employee Allowance  
**Primary backend:** Supabase for rules/data + Laravel for payroll sync

### Supabase
- Tables:
  - `finance_allowance_types`
  - `finance_employee_allowances`
  - `finance_allowance_rules`
- RPC:
  - `finance_allowance_list`
  - `finance_assign_allowance`
  - `finance_calculate_attendance_allowance`

### Laravel
- Sync recurring/non-recurring allowance to Payroll.
- Recalculate allowance when attendance changes.
- Validate taxable/non-taxable rules.
- Approval workflow if allowance assignment requires approval.

### UI needs
- Allowance list
- Employee assignment
- Effective date
- Recurring/non-recurring
- Include in payroll
- Taxable/non-taxable

---

## 5. Deductions

**Sub menu:** Finance / Deductions  
**Primary backend:** Supabase for calculation + Laravel for rule management and payroll sync

### Supabase
- Tables:
  - `finance_deduction_types`
  - `finance_employee_deductions`
  - `finance_deduction_rules`
- RPC:
  - `finance_deduction_list`
  - `finance_create_manual_deduction`
  - `finance_calculate_attendance_deduction`
  - `finance_recurring_deductions_due`

### Laravel
- Manage deduction rules UI API.
- Run scheduled job:
  - attendance-based deduction
  - recurring deduction
  - overdue cash advance deduction
  - loan installment deduction
- Sync to payroll.

### UI needs
- All deductions
- Attendance-based deduction
- Manual deduction
- Recurring deduction
- Deduction rules

---

## 6. Employee Loans

**Sub menu:** Finance / Employee Loans  
**Primary backend:** Laravel for approval/installment generation + Supabase for records

### Supabase
- Tables:
  - `finance_employee_loans`
  - `finance_loan_installments`
  - `finance_loan_payments`
- RPC:
  - `finance_loan_list`
  - `finance_loan_detail`
  - `finance_create_loan_request`
  - `finance_generate_loan_installments`
  - `finance_record_loan_payment`

### Laravel
- Approve/reject loan.
- Generate installment schedule.
- Scheduler to push installment to payroll each period.
- Notification if installment due.
- Export loan history.

### UI needs
- Loan request
- Loan approval
- Installment amount
- Remaining balance
- Payment history
- Status

---

## 7. Payroll Cost Preview

**Sub menu:** Finance / Payroll Cost Preview  
**Primary backend:** Supabase view/RPC + Laravel sync action

### Supabase
- View/RPC combines:
  - attendance salary impact
  - allowance
  - deduction
  - reimbursement to be paid
  - loan deduction
  - cash advance deduction
- RPC:
  - `finance_payroll_cost_preview`
  - `finance_payroll_cost_by_department`
  - `finance_payroll_cost_by_branch`

### Laravel
- `POST /api/finance/payroll-preview/send-to-payroll`
- Lock selected period before final payroll.
- Compare previous month.
- Export preview.

### UI needs
- Filter by month/branch/department/employee
- Estimated gross salary
- Estimated allowance
- Estimated deduction
- Reimbursement to be paid
- Estimated net pay

---

## 8. Payment Batch

**Sub menu:** Finance / Payment Batch  
**Primary backend:** Laravel primary + Supabase ledger

### Supabase
- Tables:
  - `finance_payment_batches`
  - `finance_payment_batch_items`
  - `finance_payment_methods`
- RPC:
  - `finance_payment_batch_list`
  - `finance_create_payment_batch`
  - `finance_add_items_to_payment_batch`
  - `finance_mark_batch_paid`

### Laravel
- Select approved items.
- Validate payable status.
- Generate payment reference.
- Export bank transfer file.
- Mark paid/failed/cancelled.
- Notify employees.
- Sync payment status back to reimbursement/cash advance/payroll.

### UI needs
- Create payment batch
- Select approved items
- Total amount
- Payment method
- Bank account
- Payment date
- Reference number
- Mark as paid
- Export payment file

---

## 9. Finance Reports

**Sub menu:** Finance / Reports  
**Primary backend:** Supabase for query + Laravel for export

### Supabase
- Report RPC:
  - `finance_report_reimbursement`
  - `finance_report_cash_advance`
  - `finance_report_loan`
  - `finance_report_deduction`
  - `finance_report_allowance`
  - `finance_report_payroll_cost`
  - `finance_report_employee_summary`
  - `finance_report_outstanding_balance`

### Laravel
- PDF/Excel/CSV export.
- Report download history.
- Email scheduled report later if needed.
- Permission control for sensitive report.

### UI needs
- Report filter
- Export PDF/Excel/CSV
- Summary by department/branch/employee
- Outstanding balances

---

## 10. Finance Settings

**Sub menu:** Finance / Settings  
**Primary backend:** Laravel + Supabase config tables

### Supabase
- Tables:
  - `finance_settings`
  - `finance_approval_workflows`
  - `finance_approval_steps`
  - `finance_payment_methods`
  - `finance_categories`

### Laravel
- Settings CRUD.
- Validate workflow consistency.
- Enforce settings in all action endpoints.
- Approval flow engine.
- Payment method management.

### UI needs
- Reimbursement settings
- Cash advance settings
- Loan settings
- Deduction settings
- Approval workflow
- Payment settings
