# Bianore Teladan — Finance Backend Architecture

## Finance Module Goal

Finance di Bianore Teladan bukan accounting penuh. Finance module ini fokus pada **employee-related finance**:

- Reimbursement
- Cash advance / kasbon operasional
- Allowance
- Deduction
- Employee loan
- Payroll cost preview
- Payment batch
- Finance report
- Finance settings

Accounting full seperti jurnal umum, chart of accounts, invoice, AP/AR, dan tax accounting bisa jadi produk terpisah: **Bianore Tuntas**. Finance Teladan cukup menyediakan data yang rapi untuk payroll dan accounting integration.

---

## Core Design

### 1. Tenant Isolation

Semua table wajib punya:

```sql
tenant_id uuid not null
created_at timestamptz default now()
updated_at timestamptz default now()
deleted_at timestamptz null
```

Query wajib filter `tenant_id`.

### 2. Employee Linking

Finance data harus connect ke:

- `employees.id`
- `branches.id`
- `departments.id`
- `positions.id`
- `attendance_records.id` jika allowance/deduction dari absensi
- `payroll_periods.id` jika sudah masuk payroll
- `field_visits.id` atau `tasks.id` jika reimbursement dari visit/task

### 3. Status Separation

Jangan campur approval status dan payment status.

Example Reimbursement:
- `status`: draft, submitted, pending_approval, approved, rejected, need_revision, cancelled
- `payment_status`: unpaid, queued, paid, failed, cancelled
- `payroll_sync_status`: not_synced, queued, synced, failed

### 4. Money Handling

Gunakan integer untuk rupiah:

```sql
amount_cents bigint not null default 0
currency varchar(3) default 'IDR'
```

Untuk Indonesia bisa anggap `amount_cents` = amount in rupiah minor unit, atau lebih simple gunakan `amount_amount bigint`. Pilih satu standar. Rekomendasi untuk UI lokal: `amount bigint` dalam rupiah.

### 5. Audit Trail

Semua action penting wajib masuk:

- `finance_activity_logs`
- `audit_logs`

Action examples:
- reimbursement_submitted
- reimbursement_approved
- reimbursement_rejected
- reimbursement_revision_requested
- reimbursement_paid
- cash_advance_disbursed
- cash_advance_settled
- loan_approved
- payment_batch_paid
- payroll_preview_synced

---

## API Flow High Level

### UI -> Laravel -> Supabase

Dipakai untuk action yang sensitif:
- create/update with file upload
- approve/reject
- mark as paid
- payment batch
- export
- sync payroll
- scheduler

### UI -> Supabase RPC directly?

Boleh untuk prototype, tapi production lebih aman lewat Laravel wrapper karena auth kamu pakai Laravel JWT, bukan Supabase Auth. Kalau langsung ke Supabase RPC, kamu harus punya custom JWT mapping yang rapi.

### Recommended Production Pattern

```text
React UI
  ↓ Authorization: Bearer Laravel JWT
Laravel API
  ↓ Resolve user_id, tenant_id, role
  ↓ Validate permission
  ↓ Call Supabase RPC / query
Supabase Postgres
  ↓ Return data
Laravel API
  ↓ Normalize response
React UI
```

---

## Roles & Permissions

### Roles
- `super_admin`
- `tenant_owner`
- `admin`
- `hr_manager`
- `finance_manager`
- `finance_staff`
- `manager`
- `employee`

### Permission Matrix Summary

| Action | Employee | Manager | HR | Finance Staff | Finance Manager | Admin |
|---|---:|---:|---:|---:|---:|---:|
| Submit reimbursement | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Approve own team reimbursement | ❌ | ✅ | ✅ | ❌ | ✅ | ✅ |
| Finance approve | ❌ | ❌ | optional | ✅/limited | ✅ | ✅ |
| Mark paid | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Create cash advance | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Disburse cash advance | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Create manual deduction | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ |
| Approve loan | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ |
| Export finance report | ❌ | ❌ | ✅/limited | ✅ | ✅ | ✅ |
| Change finance settings | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |

---

## Scheduler Jobs Laravel

### Daily
- `finance:detect-overdue-advances`
- `finance:remind-pending-reimbursements`
- `finance:calculate-attendance-deductions`
- `finance:calculate-attendance-allowances`

### Weekly
- `finance:remind-loan-installments`
- `finance:cleanup-draft-payment-batches`

### Monthly / Payroll Period
- `finance:generate-recurring-deductions`
- `finance:generate-loan-installments-due`
- `finance:prepare-payroll-cost-preview`
- `finance:sync-payroll-components`

---

## Module Dependencies

```text
Attendance
  → late/absence/no checkout
  → allowance/deduction calculation

Employee
  → employee master data
  → branch/department/position/manager

Payroll
  ← allowance
  ← deduction
  ← reimbursement to be paid
  ← loan installment
  ← cash advance deduction

Finance
  → payment status
  → settlement status
  → report/export

Accounting Integration Later
  ← payment batch
  ← payroll cost
  ← reimbursement expense
  ← cash advance settlement
```
