# Notion Task Checklist — Finance Backend Bianore Teladan

## Phase 0 — Finalize Scope

- [ ] Confirm Finance Teladan is employee-finance, not full accounting.
- [ ] Confirm Finance menus:
  - [ ] Overview
  - [ ] Reimbursement
  - [ ] Cash Advance
  - [ ] Employee Allowance
  - [ ] Deductions
  - [ ] Employee Loans
  - [ ] Payroll Cost Preview
  - [ ] Payment Batch
  - [ ] Finance Reports
  - [ ] Finance Settings
- [ ] Confirm auth source is Laravel JWT.
- [ ] Confirm Supabase is used as Postgres/RPC database.
- [ ] Confirm Laravel is used as API gateway and workflow engine.

---

## Phase 1 — Database Foundation Supabase

- [ ] Create finance enums.
- [ ] Create `finance_settings`.
- [ ] Create `finance_payment_methods`.
- [ ] Create `finance_reimbursement_categories`.
- [ ] Create `finance_reimbursements`.
- [ ] Create `finance_reimbursement_items`.
- [ ] Create `finance_receipts`.
- [ ] Create `finance_cash_advances`.
- [ ] Create `finance_cash_advance_settlements`.
- [ ] Create `finance_cash_advance_settlement_items`.
- [ ] Create `finance_allowance_types`.
- [ ] Create `finance_employee_allowances`.
- [ ] Create `finance_deduction_types`.
- [ ] Create `finance_employee_deductions`.
- [ ] Create `finance_deduction_rules`.
- [ ] Create `finance_employee_loans`.
- [ ] Create `finance_loan_installments`.
- [ ] Create `finance_payment_batches`.
- [ ] Create `finance_payment_batch_items`.
- [ ] Create `finance_activity_logs`.
- [ ] Add indexes for tenant/status/date/employee.
- [ ] Add soft delete support.
- [ ] Add updated_at trigger if already available in project.

---

## Phase 2 — Supabase RPC

- [ ] Create `finance_overview_summary`.
- [ ] Create `finance_alerts_today`.
- [ ] Create `finance_reimbursement_list`.
- [ ] Create `finance_reimbursement_detail`.
- [ ] Create `finance_create_reimbursement`.
- [ ] Create `finance_submit_reimbursement`.
- [ ] Create `finance_mark_reimbursement_paid`.
- [ ] Create `finance_cash_advance_list`.
- [ ] Create `finance_cash_advance_detail`.
- [ ] Create `finance_disburse_cash_advance`.
- [ ] Create `finance_settle_cash_advance`.
- [ ] Create `finance_detect_overdue_cash_advances`.
- [ ] Create `finance_allowance_list`.
- [ ] Create `finance_deduction_list`.
- [ ] Create `finance_payroll_cost_preview`.
- [ ] Create `finance_payment_batch_list`.
- [ ] Create report RPCs.
- [ ] Test all RPCs with 1 tenant and 50 dummy employees.
- [ ] Test tenant isolation.

---

## Phase 3 — Laravel Finance Module

- [ ] Create `app/Modules/Finance`.
- [ ] Create controllers.
- [ ] Create services.
- [ ] Create request validators.
- [ ] Create route file `routes/finance.php`.
- [ ] Register finance routes in `routes/api.php`.
- [ ] Create `SupabaseFinanceService`.
- [ ] Create `FinancePermissionService`.
- [ ] Create `FinanceAuditService`.
- [ ] Create file upload handler for receipts.
- [ ] Create reimbursement workflow.
- [ ] Create cash advance workflow.
- [ ] Create loan workflow.
- [ ] Create payment batch workflow.
- [ ] Create payroll sync service.
- [ ] Create export service.

---

## Phase 4 — Reimbursement

- [ ] Build API list all reimbursements.
- [ ] Build API pending approval.
- [ ] Build API approved.
- [ ] Build API paid.
- [ ] Build create reimbursement.
- [ ] Build upload receipt.
- [ ] Build submit reimbursement.
- [ ] Build approve reimbursement.
- [ ] Build reject reimbursement.
- [ ] Build request revision.
- [ ] Build mark as paid.
- [ ] Build sync to payroll.
- [ ] Build category settings.
- [ ] Build reimbursement policy settings.
- [ ] Add audit logs for every action.

---

## Phase 5 — Cash Advance

- [ ] Build all advances API.
- [ ] Build request approval API.
- [ ] Build approve/reject API.
- [ ] Build disbursement API.
- [ ] Build settlement API.
- [ ] Build overdue advance query.
- [ ] Build overdue detection scheduler.
- [ ] Build payroll deduction conversion for overdue remaining balance.
- [ ] Add audit logs.
- [ ] Add finance alerts.

---

## Phase 6 — Allowance & Deduction

- [ ] Build allowance type CRUD.
- [ ] Build employee allowance assignment.
- [ ] Build recurring allowance logic.
- [ ] Build attendance-based allowance calculation.
- [ ] Build deduction type CRUD.
- [ ] Build manual deduction.
- [ ] Build recurring deduction.
- [ ] Build attendance-based deduction.
- [ ] Build deduction rules.
- [ ] Sync allowance/deduction to payroll.

---

## Phase 7 — Employee Loans

- [ ] Build loan request API.
- [ ] Build loan approval API.
- [ ] Build installment generator.
- [ ] Build loan installment list.
- [ ] Build monthly deduction sync to payroll.
- [ ] Build payment history.
- [ ] Build completed status when remaining balance is zero.
- [ ] Add audit logs.

---

## Phase 8 — Payroll Cost Preview

- [ ] Build payroll cost preview RPC.
- [ ] Build Laravel wrapper.
- [ ] Add filters: month, branch, department, employee.
- [ ] Add comparison with previous month.
- [ ] Add send-to-payroll action.
- [ ] Add period lock validation.
- [ ] Add export preview.

---

## Phase 9 — Payment Batch

- [ ] Build create payment batch.
- [ ] Build select approved items.
- [ ] Build calculate total amount.
- [ ] Build mark ready to pay.
- [ ] Build mark paid.
- [ ] Build mark failed.
- [ ] Build cancel batch.
- [ ] Build export payment file.
- [ ] Update child payment statuses.
- [ ] Notify employees.
- [ ] Add audit logs.

---

## Phase 10 — Finance Reports

- [ ] Reimbursement report.
- [ ] Cash advance report.
- [ ] Loan report.
- [ ] Deduction report.
- [ ] Allowance report.
- [ ] Payroll cost report.
- [ ] Department cost report.
- [ ] Branch cost report.
- [ ] Employee finance summary.
- [ ] Outstanding balance report.
- [ ] Export PDF.
- [ ] Export Excel.
- [ ] Export CSV.

---

## Phase 11 — Finance Settings

- [ ] Reimbursement settings.
- [ ] Cash advance settings.
- [ ] Loan settings.
- [ ] Deduction settings.
- [ ] Approval workflow settings.
- [ ] Payment settings.
- [ ] Validate settings do not break existing workflow.
- [ ] Add audit logs for settings changes.

---

## Phase 12 — QA

- [ ] Test employee submit reimbursement.
- [ ] Test manager approval.
- [ ] Test finance approval.
- [ ] Test mark paid.
- [ ] Test cash advance settlement with remaining balance.
- [ ] Test cash advance settlement with extra reimbursement.
- [ ] Test overdue advance.
- [ ] Test loan installment generation.
- [ ] Test payroll cost preview.
- [ ] Test payment batch.
- [ ] Test report export.
- [ ] Test permission matrix.
- [ ] Test tenant isolation.
- [ ] Test 1000+ employees performance.
