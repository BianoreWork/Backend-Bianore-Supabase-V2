# Laravel API Task — Finance Module

## Folder Structure Recommendation

```text
app/
  Modules/
    Finance/
      Controllers/
        FinanceOverviewController.php
        ReimbursementController.php
        CashAdvanceController.php
        AllowanceController.php
        DeductionController.php
        LoanController.php
        PayrollCostPreviewController.php
        PaymentBatchController.php
        FinanceReportController.php
        FinanceSettingsController.php
      Services/
        FinancePermissionService.php
        FinanceAuditService.php
        SupabaseFinanceService.php
        ReimbursementService.php
        CashAdvanceService.php
        LoanService.php
        PaymentBatchService.php
        PayrollSyncService.php
        FinanceExportService.php
      Requests/
        StoreReimbursementRequest.php
        ApproveReimbursementRequest.php
        RejectReimbursementRequest.php
        StoreCashAdvanceRequest.php
        DisburseCashAdvanceRequest.php
        SettleCashAdvanceRequest.php
        StoreLoanRequest.php
        CreatePaymentBatchRequest.php
      Jobs/
        DetectOverdueAdvancesJob.php
        GenerateRecurringDeductionsJob.php
        SyncFinanceToPayrollJob.php
        SendFinanceReminderJob.php
      DTO/
        FinancePeriodDTO.php
        PaymentBatchItemDTO.php
      Routes/
        finance.php
```

---

# API Routes

```php
Route::middleware(['auth:api'])->prefix('finance')->group(function () {
    Route::get('/overview', [FinanceOverviewController::class, 'index']);
    Route::get('/alerts', [FinanceOverviewController::class, 'alerts']);

    Route::get('/reimbursements', [ReimbursementController::class, 'index']);
    Route::post('/reimbursements', [ReimbursementController::class, 'store']);
    Route::get('/reimbursements/{id}', [ReimbursementController::class, 'show']);
    Route::post('/reimbursements/{id}/submit', [ReimbursementController::class, 'submit']);
    Route::post('/reimbursements/{id}/approve', [ReimbursementController::class, 'approve']);
    Route::post('/reimbursements/{id}/reject', [ReimbursementController::class, 'reject']);
    Route::post('/reimbursements/{id}/request-revision', [ReimbursementController::class, 'requestRevision']);
    Route::post('/reimbursements/{id}/mark-paid', [ReimbursementController::class, 'markPaid']);
    Route::post('/reimbursements/{id}/sync-payroll', [ReimbursementController::class, 'syncPayroll']);

    Route::get('/cash-advances', [CashAdvanceController::class, 'index']);
    Route::post('/cash-advances', [CashAdvanceController::class, 'store']);
    Route::post('/cash-advances/{id}/approve', [CashAdvanceController::class, 'approve']);
    Route::post('/cash-advances/{id}/reject', [CashAdvanceController::class, 'reject']);
    Route::post('/cash-advances/{id}/disburse', [CashAdvanceController::class, 'disburse']);
    Route::post('/cash-advances/{id}/settle', [CashAdvanceController::class, 'settle']);

    Route::get('/allowances', [AllowanceController::class, 'index']);
    Route::post('/allowances/assign', [AllowanceController::class, 'assign']);
    Route::post('/allowances/{id}/sync-payroll', [AllowanceController::class, 'syncPayroll']);

    Route::get('/deductions', [DeductionController::class, 'index']);
    Route::post('/deductions/manual', [DeductionController::class, 'storeManual']);
    Route::post('/deductions/calculate-attendance', [DeductionController::class, 'calculateAttendanceBased']);

    Route::get('/loans', [LoanController::class, 'index']);
    Route::post('/loans', [LoanController::class, 'store']);
    Route::post('/loans/{id}/approve', [LoanController::class, 'approve']);
    Route::post('/loans/{id}/reject', [LoanController::class, 'reject']);
    Route::get('/loans/{id}/installments', [LoanController::class, 'installments']);

    Route::get('/payroll-cost-preview', [PayrollCostPreviewController::class, 'index']);
    Route::post('/payroll-cost-preview/send-to-payroll', [PayrollCostPreviewController::class, 'sendToPayroll']);

    Route::get('/payment-batches', [PaymentBatchController::class, 'index']);
    Route::post('/payment-batches', [PaymentBatchController::class, 'store']);
    Route::post('/payment-batches/{id}/mark-ready', [PaymentBatchController::class, 'markReady']);
    Route::post('/payment-batches/{id}/mark-paid', [PaymentBatchController::class, 'markPaid']);
    Route::post('/payment-batches/{id}/cancel', [PaymentBatchController::class, 'cancel']);

    Route::get('/reports/{type}', [FinanceReportController::class, 'show']);
    Route::post('/reports/{type}/export', [FinanceReportController::class, 'export']);

    Route::get('/settings', [FinanceSettingsController::class, 'show']);
    Route::put('/settings', [FinanceSettingsController::class, 'update']);
});
```

---

# Controller Logic Pattern

## Example: Approve Reimbursement

- [ ] Read Laravel authenticated user.
- [ ] Resolve `tenant_id`, `user_id`, `employee_id`, role.
- [ ] Validate permission: `finance.reimbursement.approve`.
- [ ] Validate reimbursement exists in same tenant.
- [ ] Validate reimbursement status is `submitted` or `pending_approval`.
- [ ] Check policy:
  - [ ] amount over limit?
  - [ ] receipt required?
  - [ ] category active?
  - [ ] manager approval required?
  - [ ] finance approval required?
- [ ] Update status via Supabase query/RPC.
- [ ] Write `finance_activity_logs`.
- [ ] Notify employee.
- [ ] Return normalized response.

## Example: Mark Paid

- [ ] Validate permission: `finance.payment.mark_paid`.
- [ ] Reimbursement/cash advance/payment item must be approved/ready.
- [ ] Validate payment method exists.
- [ ] Attach reference number.
- [ ] Update payment status.
- [ ] If item belongs to payment batch, update item status.
- [ ] Recalculate payment batch total/status.
- [ ] Notify employee if enabled.
- [ ] Return payment result.

---

# SupabaseFinanceService Example

```php
class SupabaseFinanceService
{
    public function rpc(string $function, array $payload): array
    {
        // Use Supabase REST RPC endpoint:
        // POST {SUPABASE_URL}/rest/v1/rpc/{function}
        // Headers:
        // apikey: service_role_key
        // Authorization: Bearer service_role_key
        // Content-Type: application/json

        // Always inject tenant_id from Laravel authenticated context.
        // Never trust tenant_id from frontend body.
    }
}
```

---

# Important Validation Rules

## Reimbursement
- [ ] Cannot submit draft without amount.
- [ ] Cannot approve own reimbursement unless admin override permission exists.
- [ ] Cannot mark as paid unless status approved.
- [ ] Cannot sync to payroll if already paid directly.
- [ ] Cannot delete paid reimbursement.
- [ ] If category requires receipt, proof must exist.

## Cash Advance
- [ ] Cannot disburse before approved.
- [ ] Cannot settle before disbursed.
- [ ] Settlement can produce:
  - [ ] returned balance
  - [ ] extra reimbursement
  - [ ] zero balance
- [ ] Overdue advance can become payroll deduction if setting enabled.

## Loan
- [ ] Cannot approve loan without installment count.
- [ ] Installment amount must match total loan.
- [ ] Active loan generates monthly deduction.
- [ ] Completed when remaining balance = 0.

## Payment Batch
- [ ] Only approved/unpaid items can be selected.
- [ ] Draft can be edited.
- [ ] Ready to pay cannot be edited except cancel.
- [ ] Paid cannot be cancelled.
- [ ] Mark paid updates all child item statuses.
