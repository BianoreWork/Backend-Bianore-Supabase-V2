-- Bianore Teladan Finance RPC Drafts
-- These are starter RPCs for Supabase. Harden permission checks through Laravel wrapper.

-- 1. Finance Overview Summary
create or replace function finance_overview_summary(
  p_tenant_id uuid,
  p_start_date date,
  p_end_date date
)
returns jsonb
language plpgsql
stable
as $$
declare
  v_result jsonb;
begin
  select jsonb_build_object(
    'period', jsonb_build_object('start_date', p_start_date, 'end_date', p_end_date),
    'total_payroll_cost_this_month', 0,
    'pending_reimbursement', coalesce(sum(amount) filter (where status in ('submitted','pending_approval')),0),
    'approved_reimbursement', coalesce(sum(amount) filter (where status='approved' and payment_status <> 'paid'),0),
    'rejected_reimbursement', coalesce(sum(amount) filter (where status='rejected'),0),
    'paid_reimbursement', coalesce(sum(amount) filter (where payment_status='paid'),0),
    'need_approval', count(*) filter (where status in ('submitted','pending_approval')),
    'finance_alerts_count', 0
  )
  into v_result
  from finance_reimbursements
  where tenant_id = p_tenant_id
    and deleted_at is null
    and claim_date between p_start_date and p_end_date;

  v_result := v_result || jsonb_build_object(
    'outstanding_cash_advance',
    coalesce((
      select sum(remaining_balance)
      from finance_cash_advances
      where tenant_id = p_tenant_id
        and deleted_at is null
        and status in ('disbursed','partially_settled','overdue')
    ),0),
    'total_allowance',
    coalesce((
      select sum(amount)
      from finance_employee_allowances
      where tenant_id = p_tenant_id
        and deleted_at is null
        and effective_start <= p_end_date
        and (effective_end is null or effective_end >= p_start_date)
        and status='approved'
    ),0),
    'total_deductions',
    coalesce((
      select sum(amount)
      from finance_employee_deductions
      where tenant_id = p_tenant_id
        and deleted_at is null
        and deduction_date between p_start_date and p_end_date
        and status='approved'
    ),0)
  );

  return v_result;
end;
$$;

-- 2. Reimbursement List
create or replace function finance_reimbursement_list(
  p_tenant_id uuid,
  p_status text default null,
  p_payment_status text default null,
  p_employee_id uuid default null,
  p_start_date date default null,
  p_end_date date default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0
)
returns table (
  reimbursement_id uuid,
  employee_id uuid,
  category_id uuid,
  title text,
  claim_date date,
  amount bigint,
  status finance_approval_status,
  payment_status finance_payment_status,
  payroll_sync_status finance_sync_status,
  submitted_at timestamptz,
  paid_at timestamptz,
  total_count bigint
)
language sql
stable
as $$
  with filtered as (
    select r.*
    from finance_reimbursements r
    where r.tenant_id = p_tenant_id
      and r.deleted_at is null
      and (p_status is null or r.status::text = p_status)
      and (p_payment_status is null or r.payment_status::text = p_payment_status)
      and (p_employee_id is null or r.employee_id = p_employee_id)
      and (p_start_date is null or r.claim_date >= p_start_date)
      and (p_end_date is null or r.claim_date <= p_end_date)
      and (p_search is null or r.title ilike '%' || p_search || '%')
  )
  select
    f.id,
    f.employee_id,
    f.category_id,
    f.title,
    f.claim_date,
    f.amount,
    f.status,
    f.payment_status,
    f.payroll_sync_status,
    f.submitted_at,
    f.paid_at,
    count(*) over() as total_count
  from filtered f
  order by f.created_at desc
  limit p_limit offset p_offset;
$$;

-- 3. Submit Reimbursement
create or replace function finance_submit_reimbursement(
  p_tenant_id uuid,
  p_reimbursement_id uuid,
  p_actor_id uuid
)
returns jsonb
language plpgsql
volatile
as $$
declare
  v_row finance_reimbursements%rowtype;
begin
  select * into v_row
  from finance_reimbursements
  where id = p_reimbursement_id and tenant_id = p_tenant_id and deleted_at is null
  for update;

  if not found then
    raise exception 'REIMBURSEMENT_NOT_FOUND';
  end if;

  if v_row.status not in ('draft','need_revision') then
    raise exception 'INVALID_STATUS_TO_SUBMIT';
  end if;

  update finance_reimbursements
  set status = 'pending_approval',
      submitted_at = now(),
      updated_by = p_actor_id,
      updated_at = now()
  where id = p_reimbursement_id;

  insert into finance_activity_logs(tenant_id, actor_id, entity_type, entity_id, action, new_values)
  values (p_tenant_id, p_actor_id, 'reimbursement', p_reimbursement_id, 'reimbursement_submitted',
          jsonb_build_object('status','pending_approval'));

  return jsonb_build_object('success', true, 'reimbursement_id', p_reimbursement_id, 'status', 'pending_approval');
end;
$$;

-- 4. Mark Reimbursement Paid
create or replace function finance_mark_reimbursement_paid(
  p_tenant_id uuid,
  p_reimbursement_id uuid,
  p_actor_id uuid,
  p_payment_method_id uuid,
  p_payment_reference text
)
returns jsonb
language plpgsql
volatile
as $$
declare
  v_row finance_reimbursements%rowtype;
begin
  select * into v_row
  from finance_reimbursements
  where id = p_reimbursement_id and tenant_id = p_tenant_id and deleted_at is null
  for update;

  if not found then
    raise exception 'REIMBURSEMENT_NOT_FOUND';
  end if;

  if v_row.status <> 'approved' then
    raise exception 'ONLY_APPROVED_REIMBURSEMENT_CAN_BE_PAID';
  end if;

  update finance_reimbursements
  set payment_status = 'paid',
      paid_at = now(),
      paid_by = p_actor_id,
      payment_method_id = p_payment_method_id,
      payment_reference = p_payment_reference,
      updated_by = p_actor_id,
      updated_at = now()
  where id = p_reimbursement_id;

  insert into finance_activity_logs(tenant_id, actor_id, entity_type, entity_id, action, new_values)
  values (p_tenant_id, p_actor_id, 'reimbursement', p_reimbursement_id, 'reimbursement_paid',
          jsonb_build_object('payment_status','paid','payment_reference',p_payment_reference));

  return jsonb_build_object('success', true, 'reimbursement_id', p_reimbursement_id, 'payment_status', 'paid');
end;
$$;

-- 5. Cash Advance List
create or replace function finance_cash_advance_list(
  p_tenant_id uuid,
  p_status text default null,
  p_employee_id uuid default null,
  p_limit int default 20,
  p_offset int default 0
)
returns table (
  cash_advance_id uuid,
  employee_id uuid,
  amount_requested bigint,
  amount_approved bigint,
  amount_disbursed bigint,
  amount_settled bigint,
  remaining_balance bigint,
  purpose text,
  request_date date,
  due_date date,
  status cash_advance_status,
  settlement_status text,
  total_count bigint
)
language sql
stable
as $$
  with filtered as (
    select *
    from finance_cash_advances
    where tenant_id = p_tenant_id
      and deleted_at is null
      and (p_status is null or status::text = p_status)
      and (p_employee_id is null or employee_id = p_employee_id)
  )
  select
    id,
    employee_id,
    amount_requested,
    amount_approved,
    amount_disbursed,
    amount_settled,
    remaining_balance,
    purpose,
    request_date,
    due_date,
    status,
    settlement_status,
    count(*) over() as total_count
  from filtered
  order by created_at desc
  limit p_limit offset p_offset;
$$;

-- 6. Detect Overdue Advances
create or replace function finance_detect_overdue_cash_advances(
  p_tenant_id uuid,
  p_today date default current_date
)
returns jsonb
language plpgsql
volatile
as $$
declare
  v_count int;
begin
  update finance_cash_advances
  set status = 'overdue',
      updated_at = now()
  where tenant_id = p_tenant_id
    and deleted_at is null
    and status in ('disbursed','partially_settled')
    and due_date is not null
    and due_date < p_today
    and remaining_balance > 0;

  get diagnostics v_count = row_count;

  return jsonb_build_object('success', true, 'updated_count', v_count);
end;
$$;

-- 7. Payroll Cost Preview
create or replace function finance_payroll_cost_preview(
  p_tenant_id uuid,
  p_start_date date,
  p_end_date date,
  p_branch_id uuid default null,
  p_department_id uuid default null,
  p_employee_id uuid default null
)
returns table (
  employee_id uuid,
  allowance_total bigint,
  deduction_total bigint,
  reimbursement_to_pay bigint,
  loan_deduction bigint,
  cash_advance_deduction bigint,
  estimated_finance_adjustment bigint
)
language sql
stable
as $$
  with employees_scope as (
    select distinct employee_id
    from (
      select employee_id from finance_employee_allowances where tenant_id=p_tenant_id and deleted_at is null
      union
      select employee_id from finance_employee_deductions where tenant_id=p_tenant_id and deleted_at is null
      union
      select employee_id from finance_reimbursements where tenant_id=p_tenant_id and deleted_at is null
      union
      select employee_id from finance_employee_loans where tenant_id=p_tenant_id and deleted_at is null
      union
      select employee_id from finance_cash_advances where tenant_id=p_tenant_id and deleted_at is null
    ) x
    where (p_employee_id is null or employee_id = p_employee_id)
  )
  select
    e.employee_id,
    coalesce((select sum(amount) from finance_employee_allowances a
      where a.tenant_id=p_tenant_id and a.employee_id=e.employee_id and a.deleted_at is null
      and a.status='approved'
      and a.effective_start <= p_end_date
      and (a.effective_end is null or a.effective_end >= p_start_date)
    ),0) as allowance_total,
    coalesce((select sum(amount) from finance_employee_deductions d
      where d.tenant_id=p_tenant_id and d.employee_id=e.employee_id and d.deleted_at is null
      and d.status='approved'
      and d.deduction_date between p_start_date and p_end_date
    ),0) as deduction_total,
    coalesce((select sum(amount) from finance_reimbursements r
      where r.tenant_id=p_tenant_id and r.employee_id=e.employee_id and r.deleted_at is null
      and r.status='approved' and r.payment_status='unpaid' and r.claim_date between p_start_date and p_end_date
    ),0) as reimbursement_to_pay,
    coalesce((select sum(amount) from finance_loan_installments li
      where li.tenant_id=p_tenant_id and li.employee_id=e.employee_id
      and li.status='pending' and li.due_date between p_start_date and p_end_date
    ),0) as loan_deduction,
    coalesce((select sum(remaining_balance) from finance_cash_advances ca
      where ca.tenant_id=p_tenant_id and ca.employee_id=e.employee_id and ca.deleted_at is null
      and ca.status='overdue'
    ),0) as cash_advance_deduction,
    0::bigint as estimated_finance_adjustment
  from employees_scope e;
$$;
