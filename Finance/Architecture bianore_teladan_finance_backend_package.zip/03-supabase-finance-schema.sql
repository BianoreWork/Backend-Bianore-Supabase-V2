-- Bianore Teladan Finance Core Schema
-- PostgreSQL / Supabase
-- Adjust referenced table names if your existing schema uses bigint employee IDs.

create extension if not exists pgcrypto;

-- =========================
-- ENUMS
-- =========================

do $$ begin
  create type finance_approval_status as enum (
    'draft','submitted','pending_approval','approved','rejected','need_revision','cancelled'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type finance_payment_status as enum (
    'unpaid','queued','paid','failed','cancelled'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type finance_sync_status as enum (
    'not_synced','queued','synced','failed'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type cash_advance_status as enum (
    'requested','approved','rejected','disbursed','partially_settled','settled','overdue','cancelled'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type loan_status as enum (
    'requested','approved','rejected','active','completed','cancelled'
  );
exception when duplicate_object then null; end $$;

-- =========================
-- SETTINGS
-- =========================

create table if not exists finance_settings (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  reimbursement_enabled boolean not null default true,
  cash_advance_enabled boolean not null default true,
  loan_enabled boolean not null default true,
  default_currency varchar(3) not null default 'IDR',
  reimbursement_payroll_payout_enabled boolean not null default true,
  cash_advance_payroll_deduction_enabled boolean not null default true,
  require_receipt_default boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_payment_methods (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null,
  method_type text not null check (method_type in ('bank_transfer','cash','e_wallet','payroll_payout','manual')),
  bank_name text null,
  account_number text null,
  account_name text null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

-- =========================
-- REIMBURSEMENT
-- =========================

create table if not exists finance_reimbursement_categories (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null,
  code text not null,
  max_amount_per_claim bigint null,
  max_amount_per_month bigint null,
  require_receipt boolean not null default true,
  require_manager_approval boolean not null default true,
  require_finance_approval boolean not null default true,
  allow_payroll_payout boolean not null default true,
  allow_direct_payout boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null,
  unique (tenant_id, code)
);

create table if not exists finance_reimbursements (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  employee_id uuid not null,
  branch_id uuid null,
  department_id uuid null,
  category_id uuid references finance_reimbursement_categories(id),
  title text not null,
  description text null,
  claim_date date not null,
  submitted_at timestamptz null,
  amount bigint not null default 0,
  currency varchar(3) not null default 'IDR',
  status finance_approval_status not null default 'draft',
  payment_status finance_payment_status not null default 'unpaid',
  payroll_sync_status finance_sync_status not null default 'not_synced',
  approver_id uuid null,
  approved_at timestamptz null,
  rejected_at timestamptz null,
  rejection_reason text null,
  revision_reason text null,
  paid_at timestamptz null,
  paid_by uuid null,
  payment_method_id uuid null references finance_payment_methods(id),
  payment_reference text null,
  payroll_period_id uuid null,
  related_attendance_id uuid null,
  related_task_id uuid null,
  related_visit_id uuid null,
  created_by uuid null,
  updated_by uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_reimbursement_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  reimbursement_id uuid not null references finance_reimbursements(id) on delete cascade,
  item_name text not null,
  item_date date null,
  amount bigint not null default 0,
  notes text null,
  created_at timestamptz not null default now()
);

create table if not exists finance_receipts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  owner_type text not null check (owner_type in ('reimbursement','cash_advance_settlement','payment_batch','other')),
  owner_id uuid not null,
  file_url text not null,
  file_name text null,
  mime_type text null,
  file_size_bytes bigint null,
  uploaded_by uuid null,
  created_at timestamptz not null default now()
);

-- =========================
-- CASH ADVANCE
-- =========================

create table if not exists finance_cash_advances (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  employee_id uuid not null,
  branch_id uuid null,
  department_id uuid null,
  amount_requested bigint not null default 0,
  amount_approved bigint not null default 0,
  amount_disbursed bigint not null default 0,
  amount_settled bigint not null default 0,
  remaining_balance bigint not null default 0,
  purpose text not null,
  request_date date not null default current_date,
  due_date date null,
  status cash_advance_status not null default 'requested',
  settlement_status text not null default 'not_settled',
  approved_by uuid null,
  approved_at timestamptz null,
  disbursed_by uuid null,
  disbursed_at timestamptz null,
  payment_method_id uuid null references finance_payment_methods(id),
  payment_reference text null,
  payroll_deduction_status finance_sync_status not null default 'not_synced',
  created_by uuid null,
  updated_by uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_cash_advance_settlements (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  cash_advance_id uuid not null references finance_cash_advances(id) on delete cascade,
  submitted_by uuid null,
  submitted_at timestamptz not null default now(),
  total_spent bigint not null default 0,
  returned_amount bigint not null default 0,
  extra_reimbursement_amount bigint not null default 0,
  status finance_approval_status not null default 'submitted',
  approved_by uuid null,
  approved_at timestamptz null,
  notes text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists finance_cash_advance_settlement_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  settlement_id uuid not null references finance_cash_advance_settlements(id) on delete cascade,
  item_name text not null,
  item_date date null,
  amount bigint not null default 0,
  notes text null,
  created_at timestamptz not null default now()
);

-- =========================
-- ALLOWANCE & DEDUCTION
-- =========================

create table if not exists finance_allowance_types (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null,
  code text not null,
  allowance_source text not null default 'manual',
  taxable boolean not null default true,
  include_in_payroll boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null,
  unique (tenant_id, code)
);

create table if not exists finance_employee_allowances (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  employee_id uuid not null,
  allowance_type_id uuid not null references finance_allowance_types(id),
  amount bigint not null default 0,
  effective_start date not null,
  effective_end date null,
  recurring boolean not null default true,
  status finance_approval_status not null default 'approved',
  payroll_sync_status finance_sync_status not null default 'not_synced',
  notes text null,
  created_by uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_deduction_types (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null,
  code text not null,
  deduction_source text not null default 'manual',
  include_in_payroll boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null,
  unique (tenant_id, code)
);

create table if not exists finance_employee_deductions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  employee_id uuid not null,
  deduction_type_id uuid not null references finance_deduction_types(id),
  amount bigint not null default 0,
  deduction_date date not null default current_date,
  recurring boolean not null default false,
  status finance_approval_status not null default 'approved',
  payroll_sync_status finance_sync_status not null default 'not_synced',
  related_attendance_id uuid null,
  related_cash_advance_id uuid null,
  related_loan_installment_id uuid null,
  notes text null,
  created_by uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_deduction_rules (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  rule_name text not null,
  rule_type text not null check (rule_type in ('late','absence','unpaid_leave','no_checkout','manual','cash_advance','loan')),
  calculation_type text not null check (calculation_type in ('fixed','per_minute','per_day','percentage')),
  amount bigint not null default 0,
  min_minutes int null,
  max_minutes int null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

-- =========================
-- LOANS
-- =========================

create table if not exists finance_employee_loans (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  employee_id uuid not null,
  loan_amount bigint not null default 0,
  installment_amount bigint not null default 0,
  installment_count int not null default 1,
  remaining_balance bigint not null default 0,
  start_payroll_period_id uuid null,
  purpose text null,
  status loan_status not null default 'requested',
  approved_by uuid null,
  approved_at timestamptz null,
  rejected_reason text null,
  created_by uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists finance_loan_installments (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  loan_id uuid not null references finance_employee_loans(id) on delete cascade,
  employee_id uuid not null,
  installment_no int not null,
  due_date date not null,
  payroll_period_id uuid null,
  amount bigint not null default 0,
  paid_amount bigint not null default 0,
  status text not null default 'pending',
  payroll_sync_status finance_sync_status not null default 'not_synced',
  paid_at timestamptz null,
  created_at timestamptz not null default now()
);

-- =========================
-- PAYMENT BATCH
-- =========================

create table if not exists finance_payment_batches (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  batch_number text not null,
  title text not null,
  payment_date date null,
  total_amount bigint not null default 0,
  item_count int not null default 0,
  status text not null default 'draft' check (status in ('draft','ready_to_pay','paid','failed','cancelled')),
  payment_method_id uuid null references finance_payment_methods(id),
  reference_number text null,
  created_by uuid null,
  paid_by uuid null,
  paid_at timestamptz null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null,
  unique (tenant_id, batch_number)
);

create table if not exists finance_payment_batch_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  payment_batch_id uuid not null references finance_payment_batches(id) on delete cascade,
  payable_type text not null check (payable_type in ('reimbursement','cash_advance','payroll','bonus','allowance_manual')),
  payable_id uuid not null,
  employee_id uuid null,
  amount bigint not null default 0,
  status text not null default 'queued',
  created_at timestamptz not null default now()
);

-- =========================
-- ACTIVITY LOGS
-- =========================

create table if not exists finance_activity_logs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  actor_id uuid null,
  entity_type text not null,
  entity_id uuid not null,
  action text not null,
  old_values jsonb null,
  new_values jsonb null,
  metadata jsonb null,
  created_at timestamptz not null default now()
);

-- =========================
-- INDEXES
-- =========================

create index if not exists idx_fin_reimb_tenant_employee_date on finance_reimbursements(tenant_id, employee_id, claim_date);
create index if not exists idx_fin_reimb_tenant_status on finance_reimbursements(tenant_id, status, payment_status);
create index if not exists idx_fin_reimb_payroll_sync on finance_reimbursements(tenant_id, payroll_sync_status);

create index if not exists idx_fin_cash_adv_tenant_status on finance_cash_advances(tenant_id, status, due_date);
create index if not exists idx_fin_cash_adv_employee on finance_cash_advances(tenant_id, employee_id);

create index if not exists idx_fin_allowance_employee on finance_employee_allowances(tenant_id, employee_id, effective_start, effective_end);
create index if not exists idx_fin_deduction_employee on finance_employee_deductions(tenant_id, employee_id, deduction_date);

create index if not exists idx_fin_loans_employee on finance_employee_loans(tenant_id, employee_id, status);
create index if not exists idx_fin_loan_installments_due on finance_loan_installments(tenant_id, due_date, status);

create index if not exists idx_fin_payment_batches_status on finance_payment_batches(tenant_id, status, payment_date);
create index if not exists idx_fin_payment_items_payable on finance_payment_batch_items(tenant_id, payable_type, payable_id);

create index if not exists idx_fin_activity_entity on finance_activity_logs(tenant_id, entity_type, entity_id, created_at desc);
