# UI Build Spec — Finance Module

This file is for frontend/UI build guidance.

## Sidebar Structure

```text
Finance
  ├─ Overview
  ├─ Reimbursement
  │   ├─ All Reimbursements
  │   ├─ Pending Approval
  │   ├─ Approved
  │   ├─ Paid
  │   ├─ Categories
  │   └─ Policy
  ├─ Cash Advance
  │   ├─ All Advances
  │   ├─ Request Approval
  │   ├─ Disbursement
  │   ├─ Settlement
  │   └─ Overdue Advance
  ├─ Employee Allowance
  ├─ Deductions
  │   ├─ All Deductions
  │   ├─ Attendance-based Deduction
  │   ├─ Manual Deduction
  │   ├─ Recurring Deduction
  │   └─ Deduction Rules
  ├─ Employee Loans
  ├─ Payroll Cost Preview
  ├─ Payment Batch
  ├─ Finance Reports
  └─ Finance Settings
```

---

## Overview Page

### Cards
- Total Payroll Cost This Month
- Pending Reimbursement
- Approved Reimbursement
- Rejected Reimbursement
- Outstanding Cash Advance
- Total Deductions
- Total Allowance
- Payroll Ready Amount
- Need Approval
- Finance Alerts

### Components
- Summary card grid
- Finance alert list
- Pending approval table
- Recent activity timeline
- Quick action buttons:
  - Add Reimbursement
  - Add Cash Advance
  - Add Deduction
  - Export Finance Report
  - Sync to Payroll

### API
`GET /api/finance/overview?month=2026-05`

---

## Reimbursement Page

### Table columns
- Employee name
- Department
- Branch
- Claim category
- Amount
- Claim date
- Submitted date
- Status
- Receipt/proof
- Approver
- Payment status
- Action

### Actions
- View detail
- Approve
- Reject
- Request revision
- Mark as paid
- Export
- Sync to payroll

### Detail Drawer
- Employee info
- Claim info
- Items
- Receipt preview
- Policy check result
- Approval timeline
- Payment information
- Audit log

---

## Cash Advance Page

### Table columns
- Employee
- Amount requested
- Amount approved
- Purpose
- Request date
- Due date
- Status
- Settlement status
- Remaining balance

### Actions
- View detail
- Approve
- Reject
- Disburse
- Submit settlement
- Mark overdue
- Convert remaining to payroll deduction

### Settlement UX
Input:
- Total spent
- Returned amount
- Extra reimbursement amount
- Receipt upload
- Notes

System display:
- Advance amount
- Used amount
- Remaining balance
- Difference result:
  - employee returns money
  - company reimburses extra
  - balanced

---

## Payroll Cost Preview

### Filters
- Month
- Branch
- Department
- Employee
- Payroll period

### Columns
- Employee
- Base payroll estimate
- Estimated allowance
- Estimated deduction
- Reimbursement to be paid
- Loan deduction
- Cash advance deduction
- Estimated net pay
- Status

### Actions
- Export preview
- Send to payroll
- Compare previous month

---

## Payment Batch

### Create Batch Flow
1. Click Create Payment Batch
2. Select item types:
   - Reimbursement
   - Cash Advance
   - Payroll
   - Bonus
   - Manual allowance
3. Select approved items
4. Choose payment method
5. Set payment date
6. Review total amount
7. Mark Ready to Pay
8. Mark Paid / Failed

### Batch statuses
- Draft
- Ready to Pay
- Paid
- Failed
- Cancelled

---

## Empty States

### Reimbursement
"Belum ada reimbursement. Tambahkan klaim pertama atau tunggu karyawan submit klaim."

### Cash Advance
"Belum ada cash advance aktif. Buat request uang muka untuk operasional karyawan."

### Payroll Cost Preview
"Pilih periode payroll untuk melihat estimasi biaya."

---

## Status Badge Colors

Frontend can define:
- Draft: gray
- Submitted: blue
- Pending Approval: amber
- Approved: green
- Rejected: red
- Need Revision: purple
- Paid: green
- Overdue: red
- Cancelled: gray

No backend dependency on color.
