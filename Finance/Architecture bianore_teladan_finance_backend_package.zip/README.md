# Bianore Teladan — Finance Backend Package

Paket ini dibuat dari finance info user dan disusun untuk kebutuhan:
1. Pembagian sub-menu Finance: mana Supabase, mana Laravel.
2. Struktur backend Finance yang lengkap.
3. SQL starter schema Supabase.
4. RPC starter.
5. Laravel API task.
6. UI build spec agar frontend bisa mulai build tampilan Finance.

## Isi ZIP

- `01-submenu-ownership-supabase-vs-laravel.md`
- `02-finance-backend-architecture.md`
- `03-supabase-finance-schema.sql`
- `04-supabase-finance-rpc-drafts.sql`
- `05-laravel-finance-api-task.md`
- `06-ui-build-spec-finance.md`
- `07-notion-task-checklist-finance.md`
- `08-finance-api-contract.json`
- `source-finance-info.txt`

## Quick Recommendation

- Supabase: database, tenant isolation, summary RPC, list/detail RPC, report base query, payroll cost preview.
- Laravel: auth wrapper, approval workflow, receipt upload, payment batch, scheduler, export, notification, payroll sync.

## Important

SQL ini adalah starter schema. Sesuaikan FK `employee_id`, `tenant_id`, `branch_id`, dan `department_id` dengan schema Bianore Teladan yang sudah ada.
