
  # Design HRIS Dashboard ver 2

  This is a code bundle for Design HRIS Dashboard ver 2. The original project is available at https://www.figma.com/design/yzsmArFMKlm2T1LlMPHlIR/Design-HRIS-Dashboard-ver-2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  