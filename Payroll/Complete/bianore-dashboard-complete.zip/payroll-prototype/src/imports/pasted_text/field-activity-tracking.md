Please update the Sales Calling / Client Visits feature into a Field Employee Activity Tracking feature.

IMPORTANT CONTEXT:
This feature is not only for sales visits. It is used to track and monitor employee activities when they are working outside the office area, such as:
- Sales meeting clients
- Client visits
- Field work
- Business trips
- Employee assignments outside the office
- Operational visits

The main goal is:
Managers can assign employees to field activities and monitor their real-time activity/location while they are outside the office.

Do not remove the existing dashboard style, sidebar, layout, cards, tables, and overall visual direction. Continue from the current design and improve it.

Rename / adjust the feature meaning:
From:
Sales Calling & Client Visits

To:
Field Activity & Client Visits
or
Field Employee Tracking

The feature should support:
1. Manager assigns field activity/task to employee
2. Employee goes outside office for client visit or field work
3. System tracks employee activity and GPS location
4. Manager can see employee status in dashboard
5. Manager can monitor real-time map while employee is on duty
6. Each activity can show detail, notes, photos, location, timeline, and proof

Dashboard improvements:

1. Add Real-Time Field Map section
Create a real-time map area in the dashboard where manager can see employees who are currently outside / on field duty.

The map should show:
- Employee marker/avatar
- Employee name
- Current GPS location
- Activity status
- Assigned client/location
- Last updated time
- Movement path or route preview
- Online / offline / GPS lost indicator

Employee status on map:
- On the way
- Arrived
- In progress
- Completed
- Delayed
- GPS inactive
- Need attention

Map interaction:
- Clicking employee marker opens a right-side detail panel
- Detail panel shows employee activity information
- Manager can see current location, destination, assigned task, check-in time, visit progress, and proof

2. Add Assignment / Task Flow
Manager must be able to assign the field activity to an employee.

Add button:
+ Assign Field Activity
or
+ New Field Assignment

Assignment form should include:
- Select employee
- Activity type
  - Client visit
  - Sales meeting
  - Field work
  - Delivery / pickup
  - Site inspection
  - Business trip
  - Other
- Client / company name
- Contact person
- Phone number
- Destination / visit location
- Full address
- District / area
- Scheduled date
- Scheduled start time
- Estimated end time
- Priority
  - Low
  - Medium
  - High
  - Urgent
- Required proof
  - GPS check-in
  - Photo proof
  - Notes
  - Client signature optional
- Activity objective / instruction
- Tags
- Save assignment

3. Overview Tab Updates
The Overview tab should show both summary and real-time monitoring.

Add / update cards:
- Employees on field today
- Active field activities
- Completed activities
- Delayed activities
- GPS inactive alerts
- Pending assignments
- Completion rate
- Average visit duration

Add sections:
- Real-Time Field Map
- Active Field Activities
- Today’s Field Assignments
- Alerts & Reminders
- Top Field Performers
- Activity Completion Trend

4. Visit Log / Activity Log Tab Updates
Keep the existing table style, but rename it as Activity Log or Field Activity Log.

Table columns should include:
- Employee
- Activity type
- Client / destination
- Location
- Assigned by
- Date / time
- Check-in time
- Check-out time
- Current status
- GPS status
- Photo proof
- Notes
- Outcome
- Action / detail

Filters should include:
- Search by employee, client, location, activity type
- Status filter
- Employee filter
- Activity type filter
- Date range filter
- Branch filter
- Department filter

Status should include:
- Assigned
- On the way
- Arrived
- In progress
- Completed
- Missed
- Cancelled
- Delayed
- GPS inactive

5. Timeline Tab Update
The Timeline tab must be interactive.

Each timeline card must be clickable.

When a manager clicks a timeline card, show a right-side detail panel / drawer.

Timeline card should show:
- Employee avatar
- Employee name
- Activity type
- Client / destination
- Location
- Status badge
- Time
- Duration
- Short notes
- Outcome badge
- GPS indicator
- Photo proof count

Right-side detail panel should show:
- Employee profile
- Assignment information
- Activity type
- Assigned by manager
- Client / destination detail
- Full address
- Current GPS location
- Map preview
- Route / movement history
- Check-in time
- Check-out time
- Duration
- Status history
- Activity notes
- Photo proof
- Outcome
- Manager action buttons

Manager action buttons:
- View full map
- Message employee
- Call employee
- Mark as reviewed
- Request update
- Reassign task
- Cancel activity

6. Real-Time Detail Drawer
Create a right-side drawer for field activity detail.

The drawer should appear when:
- Clicking a map marker
- Clicking a timeline card
- Clicking a row in the activity log

Drawer content:
- Header with employee name, role, and status
- Activity progress stepper
  - Assigned
  - On the way
  - Arrived
  - In progress
  - Completed
- Live location card
- Mini map
- Assignment detail
- Client / destination detail
- Time tracking
- GPS accuracy
- Last location update
- Proof section
  - Photos
  - Notes
  - Signature if available
- Activity timeline
- Manager notes
- Action buttons

7. Log New Visit / Activity Modal Update
The current “Log New Visit” modal should be updated because manager is assigning field activity, not only logging visit.

Rename:
Log New Visit
to
Assign Field Activity

Form steps should be:

Step 1 — Employee & Activity
- Select employee / sales rep
- Activity type
- Client / destination name
- Company / client
- Contact phone
- Tags

Step 2 — Location & Schedule
- Destination location
- Full address
- District / area
- Scheduled date
- Scheduled time
- Estimated duration
- GPS tracking required toggle
- Allow employee to update location toggle

Step 3 — Instruction & Proof
- Activity objective / instruction
- Expected outcome
- Required proof:
  - Photo proof
  - GPS check-in
  - Notes
  - Client signature
- Priority
- Submit / Assign Activity button

Button label should be:
Assign Activity
not Log Visit.

8. Employee Mobile App Requirement
This dashboard should connect logically with the employee mobile app.

Employee mobile app should support:
- View assigned field activity
- Start trip / start activity
- GPS tracking while on field duty
- Check-in at location
- Upload photo proof
- Add notes
- Select outcome
- Check-out / complete activity
- Send update to manager
- Emergency / need help button if needed

Dashboard should show these mobile activity updates in real time.

9. Alerts & Monitoring
Add alert system for manager.

Alerts include:
- Employee has not started assigned activity
- Employee is late to destination
- GPS tracking inactive
- Employee outside expected route
- Employee has arrived but not checked in
- Activity completed without photo proof
- Visit overdue
- Employee requested help
- Missed visit

10. Keep Design Style
Keep the current clean HRIS dashboard style:
- White background
- Soft cards
- Blue primary color
- Rounded components
- Clean table
- Light badges
- Sidebar layout
- Top search bar
- Right-side drawer
- Professional SaaS dashboard style

Do not redesign from scratch.
Continue from the existing design and add the missing field employee tracking logic, real-time map, assignment system, and clickable timeline detail drawer.