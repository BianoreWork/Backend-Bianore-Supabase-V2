Continue the existing Bianore design. Do not redesign anything from scratch. Keep the current visual style, sidebar, layout, colors, typography, cards, tables, and right-side drawer style consistent with the existing Bianore screens.

The Time module already exists. Do not create a new Time module again.

Your task is to complete and improve the parts that are still missing in the existing design.

IMPORTANT:
- Do not remove any existing screen or feature.
- Do not simplify the current design.
- Do not only add labels or descriptions.
- Actually add the missing forms, working-looking filters, table columns, settings sections, and detail drawers.
- Keep everything in English.
- Continue the existing design exactly as it is.

==================================================
1. COMPLETE THE EXISTING TIME MODULE
==================================================

The existing Time module is already present, but it is still incomplete.

Please complete it by adding the missing request forms, filters, tables, and detail views for:

- Time Off / Leave Request
- Sick Leave Request
- Permission Request
- Attendance Correction Request
- Overtime Request

------------------------------------------
A. COMPLETE ALL FILTERS IN TIME
------------------------------------------

Make the filters visible and complete in the Time module.

Add functional-looking filters for:
- Request Type
- Status
- Employee
- Department
- Branch / Work Location
- Date Range
- Approver
- Leave Type
- Overtime Type

These filters should appear on the relevant Time pages and should not be decorative only.

------------------------------------------
B. ADD COMPLETE REQUEST FORMS
------------------------------------------

Add complete admin forms for creating requests.

1. Time Off / Leave / Permission Request Form

Fields:
- Employee
- Request Type:
  - Annual Leave
  - Permission
  - Sick Leave
  - Special Leave
- Start Date
- End Date
- Full Day / Half Day
- If Half Day:
  - First Half
  - Second Half
- Total Requested Days
- Reason
- Branch / Work Location
- Approver
- Attachment Upload
- Additional Note
- Created by Admin
- Reason for Manual Creation
- Approval Action:
  - Submit for Approval
  - Approve Directly
- Attendance Impact Preview:
  - Example: “Employee will be marked as On Leave from 12 May to 13 May after approval.”

2. Sick Leave Specific Fields

When Request Type is Sick Leave, also show:
- Doctor’s Note / Medical Certificate Upload
- Doctor / Clinic Information
- Whether attachment is required
- Admin Note

3. Attendance Correction Request Form

Fields:
- Employee
- Attendance Date
- Correction Type:
  - Forgot Check-in
  - Forgot Check-out
  - Incorrect Check-in Time
  - Incorrect Check-out Time
  - Wrong Attendance Status
  - Location Issue
  - Other
- Current Attendance Record
- Requested Check-in Time
- Requested Check-out Time
- Requested Attendance Status
- Reason
- Attachment Upload
- Approver
- Additional Note

4. Overtime Request Form

Fields:
- Employee
- Overtime Date
- Overtime Type:
  - Before Shift
  - After Shift
  - Rest Day / Holiday
- Scheduled Shift
- Overtime Start Time
- Overtime End Time
- Total Overtime Duration
- Reason
- Project / Task
- Branch / Work Location
- Approver
- Attachment Upload
- Additional Note

------------------------------------------
C. ADD DETAIL DRAWERS FOR REQUESTS
------------------------------------------

When clicking a request row, open a right-side detail drawer.

For Leave / Permission / Sick Leave requests, show:
- Employee information
- Request details
- Approval status
- Approval history
- Attachment
- Admin note
- Attendance impact
- Approve / Reject actions

For Attendance Correction requests, show:
- Original attendance record
- Requested corrected record
- Difference between old and new values
- Related attendance flags
- Supporting attachment
- Reviewer note
- Audit trail
- Approve / Reject actions

For Overtime requests, show:
- Scheduled working hours
- Requested overtime hours
- Actual attendance record, if available
- Whether overtime overlaps with shift hours
- Approval note
- Audit trail
- Approve / Reject actions

==================================================
2. ADD BRANCH / WORK LOCATION SUPPORT
==================================================

Branch / Work Location is still missing in several places. Add it consistently across the existing design.

Add Branch / Work Location to:
- Employee form
- Employee table
- Attendance table
- Attendance filters
- Attendance detail drawer
- Time request tables
- Time request forms
- Reports filters

In Employee forms, add:
- Branch / Work Location
- Allowed Check-in Location
- Assigned Geofence Location
- Work Arrangement:
  - On-site
  - Remote
  - Hybrid

==================================================
3. COMPLETE SETTINGS FOR BRANCH AND CHECK-IN LOCATIONS
==================================================

The Settings module already exists. Add the missing settings pages and forms inside it.

------------------------------------------
A. BRANCH / WORK LOCATION SETTINGS
------------------------------------------

Add a Branches / Work Locations settings section.

Create:
- Branch list table
- Add Branch button
- Branch detail drawer
- Add / Edit Branch form

Branch table columns:
- Branch Name
- Branch Code
- Address
- City
- Assigned Employees
- Allowed Check-in Locations
- Status

Add / Edit Branch form fields:
- Branch Name
- Branch Code
- Address
- City
- Branch Manager
- Time Zone
- Status
- Default Working Schedule
- Notes

------------------------------------------
B. CHECK-IN LOCATION / GEOFENCE SETTINGS
------------------------------------------

Add a Check-in Locations / Geofence settings section.

This section must allow admin to configure:
- How many check-in locations are allowed
- The allowed radius / distance for check-in
- What happens if employees check in outside the allowed radius

Add top-level settings:
- Maximum Allowed Check-in Locations per Branch
- Employees can check in from:
  - Assigned Branch Only
  - Any Company Branch
  - Selected Approved Locations
- Outside Geofence Behavior:
  - Block Check-in
  - Allow but Flag
  - Allow with Required Reason
- Remote Employees Exempt from Geofence:
  - Yes / No

Create:
- Check-in location table
- Add Check-in Location button
- Add / Edit Check-in Location form
- Check-in Location detail drawer

Check-in location table columns:
- Location Name
- Linked Branch
- Address
- Latitude
- Longitude
- Radius Distance
- Allowed Employees
- Status

Add / Edit Check-in Location form fields:
- Location Name
- Linked Branch
- Address
- Latitude
- Longitude
- Geofence Radius Distance:
  - 50 m
  - 100 m
  - 200 m
  - Custom
- Status:
  - Active
  - Inactive
- Allowed For:
  - All Employees
  - Selected Employees
  - Selected Departments
- Require Selfie / Biometric Verification:
  - Yes / No
- Notes

==================================================
4. UPDATE EXISTING FILTERS
==================================================

Complete all filters across the existing modules. Filters should look active and complete, not only visual placeholders.

Add or complete filters for:

Attendance:
- Date
- Status
- Employee
- Department
- Branch / Work Location
- Flag Type

Time:
- Request Type
- Status
- Employee
- Department
- Branch / Work Location
- Date Range
- Approver
- Leave Type
- Overtime Type

Reports:
- Date Range
- Employee
- Department
- Branch / Work Location
- Attendance Status
- Request Type
- Leave Type
- Overtime Status

==================================================
5. FINAL INSTRUCTION
==================================================

Do not create a new design direction.
Do not create the Time module again.
Continue the existing Bianore screens and only complete what is still missing:

- Missing request forms
- Missing detail drawers
- Missing filters
- Missing Branch / Work Location fields
- Missing Branch settings
- Missing Check-in Location / Geofence settings
- Missing radius / distance configuration for check-in locations

Make sure all new screens and components visually match the current Bianore design.