import { AlertTriangle, ShieldAlert, MapPin, FileWarning, ChevronRight } from "lucide-react";
import { alerts } from "./mockData";

const alertConfig = {
  danger: {
    bg: "bg-red-50",
    border: "border-red-200",
    iconBg: "bg-red-100",
    iconColor: "text-red-600",
    badge: "bg-red-100 text-red-700 border-red-200",
    dot: "bg-red-500",
  },
  warning: {
    bg: "bg-amber-50",
    border: "border-amber-200",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
    badge: "bg-amber-100 text-amber-700 border-amber-200",
    dot: "bg-amber-500",
  },
};

const iconMap: Record<number, React.ReactNode> = {
  1: <ShieldAlert size={16} />,
  2: <ShieldAlert size={16} />,
  3: <MapPin size={16} />,
  4: <FileWarning size={16} />,
};

export function AlertsSection() {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-red-50 rounded-lg flex items-center justify-center">
            <AlertTriangle size={15} className="text-red-500" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-800">Alerts & Issues</h3>
          </div>
          <span className="ml-1 bg-red-500 text-white text-[10px] font-semibold px-1.5 py-0.5 rounded-full">
            {alerts.length}
          </span>
        </div>
        <button className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-0.5 transition-colors cursor-pointer">
          View all <ChevronRight size={12} />
        </button>
      </div>

      {/* Alert Items */}
      <div className="divide-y divide-gray-50">
        {alerts.map((alert) => {
          const config = alertConfig[alert.type];
          return (
            <div
              key={alert.id}
              className={`flex items-start gap-3 px-5 py-3.5 hover:bg-gray-50 transition-colors cursor-pointer group`}
            >
              <div className={`w-7 h-7 rounded-lg ${config.iconBg} ${config.iconColor} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                {iconMap[alert.id]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-md border ${config.badge}`}>
                    {alert.type === "danger" ? "High" : "Warning"}
                  </span>
                  <p className="font-semibold text-gray-800 text-[12px]">{alert.title}</p>
                </div>
                <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{alert.description}</p>
              </div>
              <div className="flex-shrink-0 text-right">
                <p className="text-[10px] text-gray-400">{alert.time}</p>
                <ChevronRight size={12} className="text-gray-300 group-hover:text-gray-500 mt-1 ml-auto transition-colors" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
