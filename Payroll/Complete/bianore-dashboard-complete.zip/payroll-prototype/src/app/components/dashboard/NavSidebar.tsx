import { useState } from "react";
import { motion } from "motion/react";
import {
  LayoutDashboard,
  ClipboardList,
  Timer,
  DollarSign,
  Users,
  BarChart2,
  Landmark,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Navigation,
} from "lucide-react";
import type { PageId } from "./mockData";

interface NavSidebarProps {
  activePage: PageId;
  onPageChange: (page: PageId) => void;
  onLogout?: () => void;
}

const navItems: { id: PageId; label: string; Icon: React.ElementType; badge?: number }[] = [
  { id: "dashboard",  label: "Dashboard",           Icon: LayoutDashboard },
  { id: "attendance", label: "Attendance",           Icon: ClipboardList, badge: 3 },
  { id: "time",       label: "Time",                Icon: Timer,         badge: 23 },
  { id: "payroll",    label: "Payroll",             Icon: DollarSign,    badge: 11 },
  { id: "employees",  label: "Employees",           Icon: Users },
  { id: "reports",    label: "Reports & Analytics", Icon: BarChart2 },
  { id: "sales",      label: "Field Activity",     Icon: Navigation,    badge: 5 },
  { id: "finance",    label: "Finance",             Icon: Landmark },
];

export function NavSidebar({ activePage, onPageChange, onLogout }: NavSidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <motion.aside
      initial={{ x: -24, opacity: 0 }}
      animate={{ x: 0,   opacity: 1 }}
      transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
      className={`relative flex flex-col bg-white border-r border-gray-100 flex-shrink-0 transition-[width] duration-300 ease-in-out ${
        collapsed ? "w-[60px]" : "w-[208px]"
      }`}
      style={{ minHeight: "100vh", zIndex: 10 }}
    >
      {/* Logo */}
      <div
        className={`flex items-center gap-2.5 border-b border-gray-100 h-[53px] px-3 flex-shrink-0 overflow-hidden`}
      >
        <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
          <LayoutDashboard size={15} className="text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <p className="text-sm font-bold text-gray-900 whitespace-nowrap">WorkForce</p>
            <p className="text-[10px] text-gray-400 whitespace-nowrap">HRIS Platform</p>
          </div>
        )}
      </div>

      {/* Nav Items */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-hidden">
        {navItems.map(({ id, label, Icon, badge }) => {
          const isActive = activePage === id;
          return (
            <button
              key={id}
              onClick={() => onPageChange(id)}
              title={collapsed ? label : undefined}
              className={`
                w-full flex items-center gap-3 rounded-xl transition-all duration-150 cursor-pointer group
                ${collapsed ? "justify-center px-0 py-2.5" : "px-3 py-2.5"}
                ${isActive
                  ? "bg-blue-50 text-blue-700"
                  : "text-gray-500 hover:bg-gray-50 hover:text-gray-700"
                }
              `}
            >
              <Icon
                size={18}
                className={`flex-shrink-0 ${isActive ? "text-blue-600" : "text-gray-400 group-hover:text-gray-600"}`}
              />
              {!collapsed && (
                <>
                  <span
                    className={`text-sm font-medium whitespace-nowrap flex-1 text-left ${
                      isActive ? "text-blue-700" : ""
                    }`}
                  >
                    {label}
                  </span>
                  {badge && (
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                        isActive
                          ? "bg-blue-100 text-blue-700"
                          : "bg-gray-100 text-gray-500"
                      }`}
                    >
                      {badge}
                    </span>
                  )}
                  {!badge && isActive && (
                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full flex-shrink-0" />
                  )}
                </>
              )}
            </button>
          );
        })}
      </nav>

      {/* Divider */}
      <div className="mx-3 h-px bg-gray-100" />

      {/* Bottom Actions */}
      <div className="px-2 py-3 space-y-0.5">
        <button
          onClick={() => onPageChange("settings")}
          title={collapsed ? "Settings" : undefined}
          className={`w-full flex items-center gap-3 rounded-xl transition-colors cursor-pointer ${
            collapsed ? "justify-center px-0 py-2.5" : "px-3 py-2.5"
          } ${
            activePage === "settings"
              ? "bg-blue-50 text-blue-700"
              : "text-gray-400 hover:bg-gray-50 hover:text-gray-600"
          }`}
        >
          <Settings size={17} className={`flex-shrink-0 ${activePage === "settings" ? "text-blue-600" : ""}`} />
          {!collapsed && <span className={`text-sm whitespace-nowrap ${activePage === "settings" ? "font-semibold text-blue-700" : ""}`}>Settings</span>}
        </button>
        <button
          title={collapsed ? "Logout" : undefined}
          onClick={onLogout}
          className={`w-full flex items-center gap-3 rounded-xl text-gray-400 hover:bg-red-50 hover:text-red-500 transition-colors cursor-pointer ${
            collapsed ? "justify-center px-0 py-2.5" : "px-3 py-2.5"
          }`}
        >
          <LogOut size={17} className="flex-shrink-0" />
          {!collapsed && <span className="text-sm whitespace-nowrap">Logout</span>}
        </button>

        {/* Collapse Toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          title={collapsed ? "Expand sidebar" : undefined}
          className={`w-full flex items-center gap-2 rounded-xl text-gray-300 hover:bg-gray-50 hover:text-gray-500 transition-colors cursor-pointer ${
            collapsed ? "justify-center px-0 py-2" : "px-3 py-2"
          }`}
        >
          {collapsed ? (
            <ChevronRight size={15} />
          ) : (
            <>
              <ChevronLeft size={15} />
              <span className="text-xs whitespace-nowrap">Collapse</span>
            </>
          )}
        </button>
      </div>
    </motion.aside>
  );
}