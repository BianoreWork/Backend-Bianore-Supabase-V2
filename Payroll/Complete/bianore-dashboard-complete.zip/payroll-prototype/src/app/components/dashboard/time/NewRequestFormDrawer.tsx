import { useState, useEffect } from "react";
import { X, Paperclip, ChevronDown, AlertCircle, CheckCircle2, Calendar, User } from "lucide-react";

type RequestCategory = "leave" | "correction" | "overtime";
type LeaveSubType = "Annual Leave" | "Permission" | "Sick Leave" | "Special Leave";
type CorrectionSubType =
  | "Forgot Check-in" | "Forgot Check-out" | "Incorrect Check-in Time"
  | "Incorrect Check-out Time" | "Wrong Attendance Status" | "Location Issue" | "App Issue" | "Other";
type OvertimeSubType = "Before Shift" | "After Shift" | "Rest Day / Holiday";

const employees = [
  "Sarah Johnson", "Michael Chen", "Amy Rodriguez", "David Park", "Emma Wilson",
  "James Kim", "Lisa Thompson", "Robert Davis", "Patricia Moore", "Kevin Lee",
  "Alex Kumar", "Maria Santos", "John Smith", "Jennifer Brown", "Mark Johnson",
];
const departments = ["Engineering", "Marketing", "HR", "Finance", "Operations", "Sales", "Customer Support", "Executive"];
const branches    = ["HQ – Jakarta", "Branch – Surabaya", "Branch – Bandung", "Branch – Bali"];
const approvers   = ["David Park", "Alex Kumar", "Sarah Johnson", "Board Office"];

interface NewRequestFormDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

// ── Shared field components ──────────────────────────────────────────────────
const inp  = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400";
const sel  = `${inp} cursor-pointer appearance-none`;
const lbl  = "block text-[11px] font-semibold text-gray-600 mb-1.5";

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className={lbl}>{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
      {children}
    </div>
  );
}

function Grid2({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3">{children}</div>;
}

// ── Attendance impact preview ────────────────────────────────────────────────
function ImpactPreview({ text }: { text: string }) {
  if (!text) return null;
  return (
    <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
      <div className="flex items-start gap-2">
        <AlertCircle size={13} className="text-blue-600 mt-0.5 flex-shrink-0"/>
        <div>
          <p className="text-[10px] font-bold text-blue-700 uppercase tracking-wide mb-0.5">Attendance Impact</p>
          <p className="text-xs text-blue-800">{text}</p>
        </div>
      </div>
    </div>
  );
}

// ── Leave / Sick / Permission form ──────────────────────────────────────────
function LeaveForm() {
  const [leaveType, setLeaveType] = useState<LeaveSubType>("Annual Leave");
  const [employee, setEmployee]   = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate]     = useState("");
  const [halfDay, setHalfDay]     = useState(false);
  const [halfPart, setHalfPart]   = useState<"first"|"second">("first");
  const [reason, setReason]       = useState("");
  const [approver, setApprover]   = useState(approvers[0]);
  const [branch, setBranch]       = useState(branches[0]);
  const [approveDirectly, setApproveDirectly] = useState(false);
  const [adminNote, setAdminNote] = useState("");

  const calcDays = () => {
    if (!startDate || !endDate) return 0;
    const d = Math.max(0, Math.round((new Date(endDate).getTime() - new Date(startDate).getTime()) / 86400000) + 1);
    return halfDay ? 0.5 : d;
  };
  const days = calcDays();

  const impact = employee && startDate
    ? `${employee} will be marked as ${leaveType === "Annual Leave" ? "On Leave" : leaveType} from ${startDate}${endDate && endDate !== startDate ? ` to ${endDate}` : ""} after ${approveDirectly ? "direct approval" : "approval"}.`
    : "";

  return (
    <div className="space-y-3.5">
      {/* Request type */}
      <Field label="Request Type" required>
        <div className="grid grid-cols-2 gap-2">
          {(["Annual Leave","Permission","Sick Leave","Special Leave"] as LeaveSubType[]).map(t => (
            <button key={t} onClick={() => setLeaveType(t)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all text-left ${
                leaveType === t ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-blue-300"
              }`}>
              {t}
            </button>
          ))}
        </div>
      </Field>

      {/* Employee */}
      <Field label="Employee" required>
        <div className="relative">
          <select value={employee} onChange={e => setEmployee(e.target.value)} className={sel}>
            <option value="">— Select employee —</option>
            {employees.map(e => <option key={e}>{e}</option>)}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
        </div>
      </Field>

      {/* Dates */}
      <Grid2>
        <Field label="Start Date" required>
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className={inp}/>
        </Field>
        <Field label="End Date" required>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className={inp}/>
        </Field>
      </Grid2>

      {/* Duration + Half day */}
      <Grid2>
        <Field label="Total Requested Days">
          <div className="text-xs text-gray-800 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-semibold">
            {days > 0 ? `${days} day${days !== 1 ? "s" : ""}` : "—"}
          </div>
        </Field>
        <Field label="Day Type">
          <div className="flex items-center gap-2 mt-1">
            <button onClick={() => setHalfDay(!halfDay)}
              className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer flex-shrink-0 ${halfDay ? "bg-blue-600" : "bg-gray-200"}`}>
              <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${halfDay ? "translate-x-4" : "translate-x-0.5"}`}/>
            </button>
            <span className="text-xs text-gray-600">Half day</span>
          </div>
        </Field>
      </Grid2>

      {halfDay && (
        <Field label="Half Day Part" required>
          <div className="flex gap-2">
            {(["first","second"] as const).map(p => (
              <button key={p} onClick={() => setHalfPart(p)}
                className={`flex-1 text-xs font-semibold py-2 rounded-xl border cursor-pointer transition-all ${
                  halfPart === p ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-blue-300"
                }`}>
                {p === "first" ? "First half (AM)" : "Second half (PM)"}
              </button>
            ))}
          </div>
        </Field>
      )}

      {/* Branch + Approver */}
      <Grid2>
        <Field label="Branch / Work Location" required>
          <div className="relative">
            <select value={branch} onChange={e => setBranch(e.target.value)} className={sel}>
              {branches.map(b => <option key={b}>{b}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>
        <Field label="Approver" required>
          <div className="relative">
            <select value={approver} onChange={e => setApprover(e.target.value)} className={sel}>
              {approvers.map(a => <option key={a}>{a}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>
      </Grid2>

      {/* Reason */}
      <Field label="Reason" required>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3}
          placeholder="Explain the reason for this request…"
          className={`${inp} resize-none`}/>
      </Field>

      {/* Sick leave specific */}
      {leaveType === "Sick Leave" && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 space-y-3">
          <p className="text-[10px] font-bold text-red-700 uppercase tracking-wide">Sick Leave Details</p>
          <Field label="Doctor / Clinic Name">
            <input type="text" placeholder="e.g. Dr. Ahmad – RS Medistra" className={inp}/>
          </Field>
          <Field label="Doctor's Note / Medical Certificate">
            <label className="flex items-center gap-2 px-3 py-2.5 bg-white border border-dashed border-red-300 rounded-xl cursor-pointer hover:bg-red-50 transition-colors group">
              <Paperclip size={12} className="text-red-400"/>
              <span className="text-xs text-gray-500 group-hover:text-red-600">Click to upload medical certificate</span>
            </label>
          </Field>
          <Field label="Attachment Required">
            <div className="text-xs text-gray-600 bg-white border border-gray-200 rounded-xl px-3 py-2.5">
              Policy: Required for sick leave ≥ 2 days
            </div>
          </Field>
          <Field label="Admin Note">
            <textarea rows={2} placeholder="Internal note (not shown to employee)…" className={`${inp} resize-none`}/>
          </Field>
        </div>
      )}

      {/* Attachment */}
      <Field label="Supporting Attachment">
        <label className="flex items-center gap-2 px-3 py-2.5 bg-white border border-dashed border-gray-300 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors group">
          <Paperclip size={12} className="text-gray-400"/>
          <span className="text-xs text-gray-500 group-hover:text-gray-700">Click to upload attachment</span>
        </label>
      </Field>

      {/* Admin note */}
      <Field label="Additional Note">
        <textarea value={adminNote} onChange={e => setAdminNote(e.target.value)} rows={2}
          placeholder="Optional note for internal reference…"
          className={`${inp} resize-none`}/>
      </Field>

      {/* Admin meta */}
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-3.5 space-y-3">
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Admin Action</p>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-700">Approve Directly</p>
            <p className="text-[10px] text-gray-400">Skip approval flow and mark as approved immediately</p>
          </div>
          <button onClick={() => setApproveDirectly(!approveDirectly)}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer flex-shrink-0 ${approveDirectly ? "bg-blue-600" : "bg-gray-200"}`}>
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${approveDirectly ? "translate-x-4" : "translate-x-0.5"}`}/>
          </button>
        </div>
        <Field label="Reason for Manual Creation">
          <input type="text" placeholder="e.g. Employee unable to submit from app" className={inp}/>
        </Field>
      </div>

      {/* Impact preview */}
      <ImpactPreview text={impact}/>
    </div>
  );
}

// ── Attendance Correction form ───────────────────────────────────────────────
function CorrectionForm() {
  const [corrType, setCorrType] = useState<CorrectionSubType>("Forgot Check-in");
  const [employee, setEmployee] = useState("");
  const [date, setDate]         = useState("");
  const [origCI, setOrigCI]     = useState("");
  const [origCO, setOrigCO]     = useState("");
  const [reqCI, setReqCI]       = useState("");
  const [reqCO, setReqCO]       = useState("");
  const [reqStatus, setReqStatus] = useState("");
  const [reason, setReason]     = useState("");
  const [approver, setApprover] = useState(approvers[0]);

  const corrTypes: CorrectionSubType[] = [
    "Forgot Check-in","Forgot Check-out","Incorrect Check-in Time",
    "Incorrect Check-out Time","Wrong Attendance Status","Location Issue","App Issue","Other",
  ];

  return (
    <div className="space-y-3.5">
      <Field label="Employee" required>
        <div className="relative">
          <select value={employee} onChange={e => setEmployee(e.target.value)} className={sel}>
            <option value="">— Select employee —</option>
            {employees.map(e => <option key={e}>{e}</option>)}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
        </div>
      </Field>

      <Field label="Attendance Date" required>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} className={inp}/>
      </Field>

      <Field label="Correction Type" required>
        <div className="grid grid-cols-2 gap-2">
          {corrTypes.map(t => (
            <button key={t} onClick={() => setCorrType(t)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all text-left ${
                corrType === t ? "bg-teal-600 text-white border-teal-600" : "bg-white text-gray-600 border-gray-200 hover:border-teal-300"
              }`}>
              {t}
            </button>
          ))}
        </div>
      </Field>

      {/* Current record */}
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-3.5 space-y-3">
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Current Attendance Record</p>
        <Grid2>
          <Field label="Original Check-in">
            <input type="time" value={origCI} onChange={e => setOrigCI(e.target.value)} className={inp}/>
          </Field>
          <Field label="Original Check-out">
            <input type="time" value={origCO} onChange={e => setOrigCO(e.target.value)} className={inp}/>
          </Field>
        </Grid2>
      </div>

      {/* Requested */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 space-y-3">
        <p className="text-[10px] font-bold text-blue-700 uppercase tracking-wide">Requested Correction</p>
        <Grid2>
          <Field label="Corrected Check-in">
            <input type="time" value={reqCI} onChange={e => setReqCI(e.target.value)} className={inp}/>
          </Field>
          <Field label="Corrected Check-out">
            <input type="time" value={reqCO} onChange={e => setReqCO(e.target.value)} className={inp}/>
          </Field>
        </Grid2>
        <Field label="Requested Attendance Status">
          <div className="relative">
            <select value={reqStatus} onChange={e => setReqStatus(e.target.value)} className={sel}>
              <option value="">— No status change —</option>
              {["Present","Late","Absent","On Leave","Sick Leave","Permission"].map(s => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>

        {/* Diff preview */}
        {(origCI || origCO || reqCI || reqCO) && (
          <div className="bg-white border border-blue-200 rounded-lg p-2.5 space-y-1">
            <p className="text-[10px] font-bold text-blue-600 mb-1.5">Change Summary</p>
            {(origCI || reqCI) && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-gray-400 line-through">{origCI || "—"}</span>
                <span className="text-gray-400">→</span>
                <span className="text-blue-700 font-bold">{reqCI || "—"}</span>
                <span className="text-gray-400 text-[10px]">(Check-in)</span>
              </div>
            )}
            {(origCO || reqCO) && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-gray-400 line-through">{origCO || "—"}</span>
                <span className="text-gray-400">→</span>
                <span className="text-blue-700 font-bold">{reqCO || "—"}</span>
                <span className="text-gray-400 text-[10px]">(Check-out)</span>
              </div>
            )}
          </div>
        )}
      </div>

      <Field label="Reason" required>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3}
          placeholder="Explain why this correction is needed…" className={`${inp} resize-none`}/>
      </Field>

      <Field label="Supporting Attachment">
        <label className="flex items-center gap-2 px-3 py-2.5 bg-white border border-dashed border-gray-300 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors group">
          <Paperclip size={12} className="text-gray-400"/>
          <span className="text-xs text-gray-500 group-hover:text-gray-700">Upload screenshot, photo, or document</span>
        </label>
      </Field>

      <Field label="Approver" required>
        <div className="relative">
          <select value={approver} onChange={e => setApprover(e.target.value)} className={sel}>
            {approvers.map(a => <option key={a}>{a}</option>)}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
        </div>
      </Field>

      <Field label="Additional Note">
        <textarea rows={2} placeholder="Optional internal note…" className={`${inp} resize-none`}/>
      </Field>

      {employee && date && (
        <ImpactPreview text={`After approval, the attendance record for ${employee} on ${date} will be updated to reflect the corrected values. Original record will be preserved in the audit trail.`}/>
      )}
    </div>
  );
}

// ── Overtime form ─────────────────────────────────────────────────────────────
function OvertimeForm() {
  const [otType, setOtType]     = useState<OvertimeSubType>("After Shift");
  const [employee, setEmployee] = useState("");
  const [otDate, setOtDate]     = useState("");
  const [shift, setShift]       = useState("08:00 – 17:00");
  const [otStart, setOtStart]   = useState("");
  const [otEnd, setOtEnd]       = useState("");
  const [reason, setReason]     = useState("");
  const [project, setProject]   = useState("");
  const [branch, setBranch]     = useState(branches[0]);
  const [approver, setApprover] = useState(approvers[0]);

  const calcDuration = () => {
    if (!otStart || !otEnd) return null;
    const [sh, sm] = otStart.split(":").map(Number);
    const [eh, em] = otEnd.split(":").map(Number);
    const mins = (eh * 60 + em) - (sh * 60 + sm);
    if (mins <= 0) return null;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h > 0 ? `${h}h ` : ""}${m > 0 ? `${m}m` : ""}`.trim();
  };
  const duration = calcDuration();

  return (
    <div className="space-y-3.5">
      <Field label="Overtime Type" required>
        <div className="flex flex-col gap-2">
          {(["Before Shift","After Shift","Rest Day / Holiday"] as OvertimeSubType[]).map(t => (
            <button key={t} onClick={() => setOtType(t)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all text-left ${
                otType === t ? "bg-purple-600 text-white border-purple-600" : "bg-white text-gray-600 border-gray-200 hover:border-purple-300"
              }`}>
              {t}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Employee" required>
        <div className="relative">
          <select value={employee} onChange={e => setEmployee(e.target.value)} className={sel}>
            <option value="">— Select employee —</option>
            {employees.map(e => <option key={e}>{e}</option>)}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
        </div>
      </Field>

      <Grid2>
        <Field label="Overtime Date" required>
          <input type="date" value={otDate} onChange={e => setOtDate(e.target.value)} className={inp}/>
        </Field>
        <Field label="Scheduled Shift">
          <div className="relative">
            <select value={shift} onChange={e => setShift(e.target.value)} className={sel}>
              {["08:00 – 17:00","09:00 – 18:00","07:00 – 16:00","22:00 – 06:00 (Night)"].map(s => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>
      </Grid2>

      <div className="bg-purple-50 border border-purple-200 rounded-xl p-3.5 space-y-3">
        <p className="text-[10px] font-bold text-purple-700 uppercase tracking-wide">Overtime Period</p>
        <Grid2>
          <Field label="OT Start Time" required>
            <input type="time" value={otStart} onChange={e => setOtStart(e.target.value)} className={inp}/>
          </Field>
          <Field label="OT End Time" required>
            <input type="time" value={otEnd} onChange={e => setOtEnd(e.target.value)} className={inp}/>
          </Field>
        </Grid2>
        <Field label="Total Duration">
          <div className={`text-xs font-bold border rounded-xl px-3 py-2.5 ${duration ? "bg-white text-purple-700 border-purple-200" : "bg-gray-50 text-gray-400 border-gray-200"}`}>
            {duration ?? "Enter start and end time"}
          </div>
        </Field>
      </div>

      <Grid2>
        <Field label="Branch / Work Location" required>
          <div className="relative">
            <select value={branch} onChange={e => setBranch(e.target.value)} className={sel}>
              {branches.map(b => <option key={b}>{b}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>
        <Field label="Approver" required>
          <div className="relative">
            <select value={approver} onChange={e => setApprover(e.target.value)} className={sel}>
              {approvers.map(a => <option key={a}>{a}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          </div>
        </Field>
      </Grid2>

      <Field label="Project / Task">
        <input type="text" value={project} onChange={e => setProject(e.target.value)}
          placeholder="e.g. Client Portal v2.1" className={inp}/>
      </Field>

      <Field label="Reason" required>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3}
          placeholder="Explain why overtime is required…" className={`${inp} resize-none`}/>
      </Field>

      <Field label="Supporting Attachment">
        <label className="flex items-center gap-2 px-3 py-2.5 bg-white border border-dashed border-gray-300 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors group">
          <Paperclip size={12} className="text-gray-400"/>
          <span className="text-xs text-gray-500 group-hover:text-gray-700">Upload supporting document (optional)</span>
        </label>
      </Field>

      <Field label="Additional Note">
        <textarea rows={2} placeholder="Optional internal note…" className={`${inp} resize-none`}/>
      </Field>

      {employee && otDate && duration && (
        <ImpactPreview text={`${employee}'s overtime of ${duration} on ${otDate} (${otType}) will be recorded in attendance and visible in the overtime report after approval.`}/>
      )}
    </div>
  );
}

// ── Main drawer ──────────────────────────────────────────────────────────────
export function NewRequestFormDrawer({ isOpen, onClose }: NewRequestFormDrawerProps) {
  const [category, setCategory] = useState<RequestCategory>("leave");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(() => { setSubmitted(false); onClose(); }, 1800);
  };

  const categoryConfig: Record<RequestCategory, { label: string; color: string; active: string }> = {
    leave:      { label: "Leave / Permission / Sick", color: "text-blue-700",   active: "bg-blue-600 text-white border-blue-600" },
    correction: { label: "Attendance Correction",      color: "text-teal-700",   active: "bg-teal-600 text-white border-teal-600" },
    overtime:   { label: "Overtime",                   color: "text-purple-700", active: "bg-purple-600 text-white border-purple-600" },
  };

  return (
    <>
      {isOpen && <div className="fixed inset-0 bg-black/20 backdrop-blur-[2px] z-30" onClick={onClose}/>}

      <aside className={`fixed right-0 top-0 h-full w-[460px] max-w-[96vw] bg-gray-50 z-40 shadow-2xl border-l border-gray-200 flex flex-col transition-transform duration-300 ease-in-out ${isOpen ? "translate-x-0" : "translate-x-full"}`}>

        {/* Header */}
        <div className="flex items-start justify-between gap-3 px-5 py-4 bg-white border-b border-gray-100 flex-shrink-0">
          <div>
            <p className="text-sm font-bold text-gray-900">New Request</p>
            <p className="text-xs text-gray-400 mt-0.5">Create a request on behalf of an employee</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
            <X size={16} className="text-gray-500"/>
          </button>
        </div>

        {/* Category selector */}
        <div className="px-4 py-3 bg-white border-b border-gray-100 flex-shrink-0">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide mb-2">Request Category</p>
          <div className="grid grid-cols-3 gap-2">
            {(Object.entries(categoryConfig) as [RequestCategory, typeof categoryConfig[RequestCategory]][]).map(([cat, cfg]) => (
              <button key={cat} onClick={() => setCategory(cat)}
                className={`text-xs font-semibold px-2 py-2 rounded-xl border cursor-pointer transition-all text-center leading-tight ${
                  category === cat ? cfg.active : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"
                }`}>
                {cfg.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form body */}
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {category === "leave"      && <LeaveForm />}
          {category === "correction" && <CorrectionForm />}
          {category === "overtime"   && <OvertimeForm />}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-2.5 px-4 py-3.5 bg-white border-t border-gray-100 flex-shrink-0">
          <button onClick={onClose}
            className="flex-1 text-xs font-semibold py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer transition-colors">
            Cancel
          </button>
          <button onClick={handleSubmit}
            className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-all ${
              submitted ? "bg-green-600 text-white" : category === "correction" ? "bg-teal-600 hover:bg-teal-700 text-white" : category === "overtime" ? "bg-purple-600 hover:bg-purple-700 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"
            }`}>
            {submitted ? <><CheckCircle2 size={13}/> Submitted!</> : "Submit Request"}
          </button>
        </div>
      </aside>
    </>
  );
}
