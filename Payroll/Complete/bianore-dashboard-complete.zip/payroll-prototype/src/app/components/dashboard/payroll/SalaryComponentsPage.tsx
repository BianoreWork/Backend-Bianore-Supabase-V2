import { useState } from "react";
import {
  Plus, Search, SlidersHorizontal, Layers,
  MoreHorizontal, X, ChevronDown, AlertTriangle,
  CheckCircle, Toggle3Right,
} from "lucide-react";
import {
  salaryComponents,
  type SalaryComponent, type ComponentType, type CalculationType,
} from "./payrollMockData";

const typeConfig: Record<ComponentType, { label: string; bg: string; text: string }> = {
  earning:       { label: "Pendapatan",   bg: "bg-green-50",  text: "text-green-700"  },
  deduction:     { label: "Potongan",     bg: "bg-red-50",    text: "text-red-600"    },
  benefit:       { label: "Benefit",      bg: "bg-blue-50",   text: "text-blue-700"   },
  reimbursement: { label: "Reimbursement",bg: "bg-amber-50",  text: "text-amber-700"  },
};

const calcTypeLabel: Record<CalculationType, string> = {
  fixed:            "Nominal Tetap",
  percentage:       "Persentase",
  formula:          "Formula",
  attendance_based: "Berbasis Absensi",
  overtime_based:   "Berbasis Lembur",
};

const filterTabs: { key: string; label: string }[] = [
  { key: "all", label: "Semua" },
  { key: "earning", label: "Pendapatan" },
  { key: "deduction", label: "Potongan" },
  { key: "benefit", label: "Benefit" },
  { key: "reimbursement", label: "Reimbursement" },
];

function FormModal({ component, onClose }: { component?: SalaryComponent; onClose: () => void }) {
  const [form, setForm] = useState({
    componentCode: component?.componentCode || "",
    componentName: component?.componentName || "",
    componentType: component?.componentType || "earning" as ComponentType,
    calculationType: component?.calculationType || "fixed" as CalculationType,
    defaultAmount: component?.defaultAmount || 0,
    defaultPercentage: component?.defaultPercentage || 0,
    formula: component?.formula || "",
    isTaxable: component?.isTaxable ?? true,
    isBpjsBase: component?.isBpjsBase ?? false,
    isRecurring: component?.isRecurring ?? true,
    isProrated: component?.isProrated ?? false,
    isVisibleOnPayslip: component?.isVisibleOnPayslip ?? true,
  });

  return (
    <>
      <div className="fixed inset-0 bg-black/30 backdrop-blur-[2px] z-40" onClick={onClose} />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 sticky top-0 bg-white">
            <div>
              <h3 className="text-sm font-bold text-gray-900">
                {component ? "Edit Komponen Gaji" : "Tambah Komponen Gaji"}
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">Konfigurasi komponen gaji karyawan</p>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><X size={16} /></button>
          </div>

          {/* Body */}
          <div className="px-5 py-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Kode Komponen *</label>
                <input
                  value={form.componentCode}
                  onChange={(e) => setForm({ ...form, componentCode: e.target.value.toUpperCase() })}
                  placeholder="GAJI_POKOK"
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all font-mono placeholder:text-gray-400"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nama Komponen *</label>
                <input
                  value={form.componentName}
                  onChange={(e) => setForm({ ...form, componentName: e.target.value })}
                  placeholder="Gaji Pokok"
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tipe *</label>
                <select
                  value={form.componentType}
                  onChange={(e) => setForm({ ...form, componentType: e.target.value as ComponentType })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="earning">Pendapatan</option>
                  <option value="deduction">Potongan</option>
                  <option value="benefit">Benefit</option>
                  <option value="reimbursement">Reimbursement</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Cara Hitung *</label>
                <select
                  value={form.calculationType}
                  onChange={(e) => setForm({ ...form, calculationType: e.target.value as CalculationType })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="fixed">Nominal Tetap</option>
                  <option value="percentage">Persentase</option>
                  <option value="formula">Formula</option>
                  <option value="attendance_based">Berbasis Absensi</option>
                  <option value="overtime_based">Berbasis Lembur</option>
                </select>
              </div>
            </div>

            {form.calculationType === "fixed" && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nominal Default (Rp)</label>
                <input
                  type="number"
                  value={form.defaultAmount}
                  onChange={(e) => setForm({ ...form, defaultAmount: Number(e.target.value) })}
                  placeholder="0"
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all"
                />
              </div>
            )}
            {form.calculationType === "percentage" && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Persentase Default (%)</label>
                <input
                  type="number"
                  value={form.defaultPercentage}
                  onChange={(e) => setForm({ ...form, defaultPercentage: Number(e.target.value) })}
                  placeholder="0"
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all"
                />
              </div>
            )}
            {form.calculationType === "formula" && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Formula</label>
                <textarea
                  value={form.formula}
                  onChange={(e) => setForm({ ...form, formula: e.target.value })}
                  placeholder="Contoh: (gaji_pokok / 173) * 1.5 * jam_lembur"
                  rows={3}
                  className="w-full text-xs font-mono bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all resize-none placeholder:text-gray-400"
                />
              </div>
            )}

            {/* Toggles */}
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-xs font-semibold text-gray-700 mb-3">Konfigurasi</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { key: "isTaxable",          label: "Dikenakan Pajak",    desc: "Masuk komponen PKP PPh21" },
                  { key: "isBpjsBase",         label: "Dasar BPJS",         desc: "Termasuk dalam dasar iuran BPJS" },
                  { key: "isRecurring",         label: "Berulang",           desc: "Diberikan setiap bulan" },
                  { key: "isProrated",          label: "Diprorasi",          desc: "Dihitung berdasarkan hari kerja" },
                  { key: "isVisibleOnPayslip",  label: "Tampil di Payslip",  desc: "Muncul di slip gaji karyawan" },
                ].map(({ key, label, desc }) => {
                  const val = form[key as keyof typeof form] as boolean;
                  return (
                    <div key={key} className="flex items-start gap-2.5">
                      <button
                        onClick={() => setForm({ ...form, [key]: !val })}
                        className={`mt-0.5 w-8 h-4 rounded-full transition-colors flex items-center px-0.5 flex-shrink-0 cursor-pointer ${val ? "bg-blue-600" : "bg-gray-300"}`}
                      >
                        <div className={`w-3 h-3 bg-white rounded-full shadow transition-transform ${val ? "translate-x-4" : "translate-x-0"}`} />
                      </button>
                      <div>
                        <p className="text-xs font-medium text-gray-700">{label}</p>
                        <p className="text-[10px] text-gray-400">{desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="px-5 py-4 border-t border-gray-100 flex items-center justify-end gap-2 sticky bottom-0 bg-white">
            <button onClick={onClose} className="text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-4 py-2 rounded-lg cursor-pointer">Batal</button>
            <button onClick={onClose} className="text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer flex items-center gap-1.5">
              <CheckCircle size={12} /> {component ? "Simpan Perubahan" : "Tambah Komponen"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export function SalaryComponentsPage() {
  const [search, setSearch]         = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showForm, setShowForm]     = useState(false);
  const [editTarget, setEditTarget] = useState<SalaryComponent | undefined>();
  const [components, setComponents] = useState(salaryComponents);

  const filtered = components.filter((c) => {
    const matchSearch = c.componentName.toLowerCase().includes(search.toLowerCase()) ||
                        c.componentCode.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || c.componentType === typeFilter;
    return matchSearch && matchType;
  });

  const typeCounts: Record<string, number> = {
    all: components.length,
    earning: components.filter((c) => c.componentType === "earning").length,
    deduction: components.filter((c) => c.componentType === "deduction").length,
    benefit: components.filter((c) => c.componentType === "benefit").length,
    reimbursement: components.filter((c) => c.componentType === "reimbursement").length,
  };

  const toggleActive = (id: string) => {
    setComponents((prev) => prev.map((c) => c.id === id ? { ...c, isActive: !c.isActive } : c));
  };

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Komponen Gaji</h1>
          <p className="text-sm text-gray-500 mt-0.5">Kelola semua komponen pendapatan, potongan, benefit, dan reimbursement</p>
        </div>
        <button
          onClick={() => { setEditTarget(undefined); setShowForm(true); }}
          className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer"
        >
          <Plus size={13} /> Tambah Komponen
        </button>
      </div>

      {/* Summary chips */}
      <div className="flex items-center gap-3 flex-wrap">
        {[
          { label: "Aktif", value: components.filter((c) => c.isActive).length, color: "bg-green-50 text-green-700" },
          { label: "Nonaktif", value: components.filter((c) => !c.isActive).length, color: "bg-gray-100 text-gray-600" },
          { label: "Kena Pajak", value: components.filter((c) => c.isTaxable).length, color: "bg-amber-50 text-amber-700" },
          { label: "Dasar BPJS", value: components.filter((c) => c.isBpjsBase).length, color: "bg-blue-50 text-blue-700" },
        ].map((c) => (
          <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
            <span className="opacity-60">{c.label}: </span>{c.value}
          </div>
        ))}
      </div>

      {/* Table card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
          <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
            {filterTabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setTypeFilter(tab.key)}
                className={`text-xs px-3 py-1.5 rounded-md transition-all cursor-pointer font-medium whitespace-nowrap ${
                  typeFilter === tab.key ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab.label} <span className="opacity-50">{typeCounts[tab.key]}</span>
              </button>
            ))}
          </div>
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Cari komponen..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-48 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                {["Kode", "Nama Komponen", "Tipe", "Cara Hitung", "Nominal/Rate", "Pajak", "BPJS", "Berulang", "Prorate", "Status", ""].map((col) => (
                  <th key={col} className="text-left px-4 py-3">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((comp, idx) => {
                const tc = typeConfig[comp.componentType];
                return (
                  <tr key={comp.id} className={`border-b border-gray-50 transition-colors hover:bg-blue-50/20 ${idx % 2 !== 0 ? "bg-gray-50/20" : ""} ${!comp.isActive ? "opacity-50" : ""}`}>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-mono font-semibold text-gray-700">{comp.componentCode}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{comp.componentName}</p>
                        {comp.formula && (
                          <p className="text-[10px] text-gray-400 font-mono truncate max-w-[200px]">{comp.formula}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${tc.bg} ${tc.text}`}>{tc.label}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-600">{calcTypeLabel[comp.calculationType]}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-700 tabular-nums">
                        {comp.calculationType === "fixed" && comp.defaultAmount > 0
                          ? `Rp ${comp.defaultAmount.toLocaleString("id-ID")}`
                          : comp.calculationType === "percentage" && comp.defaultPercentage > 0
                          ? `${comp.defaultPercentage}%`
                          : "Per record"}
                      </span>
                    </td>
                    {[comp.isTaxable, comp.isBpjsBase, comp.isRecurring, comp.isProrated].map((val, i) => (
                      <td key={i} className="px-4 py-3.5">
                        {val
                          ? <CheckCircle size={14} className="text-green-500" />
                          : <span className="text-gray-200 text-sm">—</span>}
                      </td>
                    ))}
                    <td className="px-4 py-3.5">
                      <button
                        onClick={() => toggleActive(comp.id)}
                        className={`w-9 h-5 rounded-full transition-colors flex items-center px-0.5 cursor-pointer ${comp.isActive ? "bg-blue-600" : "bg-gray-300"}`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full shadow transition-transform ${comp.isActive ? "translate-x-4" : "translate-x-0"}`} />
                      </button>
                    </td>
                    <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => { setEditTarget(comp); setShowForm(true); }}
                        className="p-1.5 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors"
                      >
                        <MoreHorizontal size={14} />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={11} className="py-16 text-center text-sm text-gray-400">Tidak ada komponen ditemukan</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">
            {filtered.length} dari {components.length} komponen
          </p>
          <div className="flex items-center gap-2 text-[10px] text-gray-400">
            <Layers size={11} />
            Urutan ditentukan oleh Sort Order
          </div>
        </div>
      </div>

      <div className="h-4" />

      {showForm && (
        <FormModal
          component={editTarget}
          onClose={() => { setShowForm(false); setEditTarget(undefined); }}
        />
      )}
    </main>
  );
}
