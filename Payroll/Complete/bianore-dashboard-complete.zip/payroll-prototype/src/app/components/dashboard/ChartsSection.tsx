import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  Legend,
} from "recharts";
import { MoreHorizontal } from "lucide-react";
import {
  attendanceByDept,
  attendanceTrend,
  payrollBreakdown,
  overtimeTrend,
} from "./mockData";

const cardClass =
  "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";

function CardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="flex items-start justify-between mb-5">
      <div>
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <button className="p-1 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer text-gray-400">
        <MoreHorizontal size={16} />
      </button>
    </div>
  );
}

const tooltipStyle = {
  contentStyle: {
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
    fontSize: "12px",
    padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
  itemStyle: { color: "#6b7280" },
};

// Attendance by Department Bar Chart
export function AttendanceByDeptChart() {
  return (
    <div className={cardClass}>
      <CardHeader title="Attendance by Department" subtitle="Today's breakdown" />
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={attendanceByDept} barSize={14} barGap={4}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
          <XAxis
            dataKey="dept"
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
            width={28}
          />
          <Tooltip {...tooltipStyle} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: "11px", paddingTop: "12px" }}
          />
          <Bar dataKey="present" name="Present" fill="#3b82f6" radius={[4, 4, 0, 0]} id="bar-dept-present" />
          <Bar dataKey="late" name="Late" fill="#f59e0b" radius={[4, 4, 0, 0]} id="bar-dept-late" />
          <Bar dataKey="absent" name="Absent" fill="#ef4444" radius={[4, 4, 0, 0]} id="bar-dept-absent" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// Attendance Trend Line Chart
export function AttendanceTrendChart() {
  return (
    <div className={cardClass}>
      <CardHeader title="Attendance Trend" subtitle="Last 7 days" />
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={attendanceTrend}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
          <XAxis
            dataKey="day"
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
            width={28}
          />
          <Tooltip {...tooltipStyle} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: "11px", paddingTop: "12px" }}
          />
          <Line
            type="monotone"
            dataKey="present"
            name="Present"
            stroke="#3b82f6"
            strokeWidth={2.5}
            dot={{ fill: "#3b82f6", r: 4, strokeWidth: 0 }}
            activeDot={{ r: 5 }}
            id="line-trend-present"
          />
          <Line
            type="monotone"
            dataKey="late"
            name="Late"
            stroke="#f59e0b"
            strokeWidth={2}
            dot={{ fill: "#f59e0b", r: 3, strokeWidth: 0 }}
            activeDot={{ r: 4 }}
            strokeDasharray="4 2"
            id="line-trend-late"
          />
          <Line
            type="monotone"
            dataKey="absent"
            name="Absent"
            stroke="#ef4444"
            strokeWidth={2}
            dot={{ fill: "#ef4444", r: 3, strokeWidth: 0 }}
            activeDot={{ r: 4 }}
            strokeDasharray="4 2"
            id="line-trend-absent"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Payroll Pie Chart
const RADIAN = Math.PI / 180;
const renderCustomLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
}: any) => {
  if (percent < 0.06) return null;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor="middle"
      dominantBaseline="central"
      style={{ fontSize: 10, fontWeight: 600 }}
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

export function PayrollBreakdownChart() {
  return (
    <div className={cardClass}>
      <CardHeader title="Payroll Cost Breakdown" subtitle="By department — this month" />
      <div className="flex items-center gap-4">
        <ResponsiveContainer width="50%" height={200}>
          <PieChart>
            <Pie
              data={payrollBreakdown}
              cx="50%"
              cy="50%"
              outerRadius={90}
              dataKey="value"
              labelLine={false}
              label={renderCustomLabel}
            >
              {payrollBreakdown.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              {...tooltipStyle}
              formatter={(value: number) =>
                `$${(value / 1000).toFixed(1)}k`
              }
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="flex-1 space-y-2">
          {payrollBreakdown.map((item) => (
            <div key={item.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-xs text-gray-600">{item.name}</span>
              </div>
              <span className="text-xs font-semibold text-gray-800">
                ${(item.value / 1000).toFixed(0)}k
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Overtime Area Chart
export function OvertimeTrendChart() {
  return (
    <div className={cardClass}>
      <CardHeader title="Overtime Trends" subtitle="Weekly overtime hours & cost" />
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={overtimeTrend}>
          <defs>
            <linearGradient id="overtimeGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2} />
              <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="costGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
          <XAxis
            dataKey="week"
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            axisLine={false}
            tickLine={false}
            width={36}
          />
          <Tooltip {...tooltipStyle} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: "11px", paddingTop: "12px" }}
          />
          <Area
            type="monotone"
            dataKey="hours"
            name="OT Hours"
            stroke="#8b5cf6"
            strokeWidth={2.5}
            fill="url(#overtimeGrad)"
            dot={{ fill: "#8b5cf6", r: 3, strokeWidth: 0 }}
            id="area-ot-hours"
          />
          <Area
            type="monotone"
            dataKey="cost"
            name="OT Cost ($)"
            stroke="#3b82f6"
            strokeWidth={2}
            fill="url(#costGrad)"
            dot={{ fill: "#3b82f6", r: 3, strokeWidth: 0 }}
            id="area-ot-cost"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}