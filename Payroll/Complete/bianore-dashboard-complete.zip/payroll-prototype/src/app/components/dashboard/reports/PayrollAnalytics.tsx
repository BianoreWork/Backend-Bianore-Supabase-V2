import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  PieChart, Pie, Cell,
} from "recharts";
import { MoreHorizontal, DollarSign, TrendingUp } from "lucide-react";
import { monthlyPayrollTrend, salaryDistribution, payrollByDept } from "./reportsData";

const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";

const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

const fmtK = (n: number) => `$${(n / 1000).toFixed(0)}k`;

function CardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="flex items-start justify-between mb-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
        <MoreHorizontal size={15} />
      </button>
    </div>
  );
}

const RADIAN = Math.PI / 180;
function PieLabel({ cx, cy, midAngle, innerRadius, outerRadius, name, value }: any) {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  const pct = ((value / payrollByDept.reduce((s, d) => s + d.value, 0)) * 100).toFixed(0);
  if (parseInt(pct) < 5) return null;
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={10} fontWeight={700}>
      {pct}%
    </text>
  );
}

export function PayrollAnalytics() {
  const totalPayroll = payrollByDept.reduce((s, d) => s + d.value, 0);
  const latest = monthlyPayrollTrend[monthlyPayrollTrend.length - 1];
  const prev = monthlyPayrollTrend[monthlyPayrollTrend.length - 2];
  const growthPct = (((latest.total - prev.total) / prev.total) * 100).toFixed(1);

  return (
    <div className="space-y-5">
      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Payroll (Apr)", value: fmt(latest.total), sub: `+${growthPct}% vs last month`, color: "bg-blue-50 text-blue-600" },
          { label: "Total Deductions",    value: fmt(latest.deductions), sub: "Tax + BPJS + penalties", color: "bg-red-50 text-red-500" },
          { label: "Overtime Cost",       value: fmt(latest.overtime), sub: "+16.4% vs March",         color: "bg-purple-50 text-purple-600" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${s.color}`}>
              <DollarSign size={15} />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-900">{s.value}</p>
              <p className="text-[10px] text-gray-400">{s.label}</p>
              <p className="text-[9px] text-gray-400">{s.sub}</p>
            </div>
          </div>
        ))}
      </div>

      {/* 12-Month Payroll Trend */}
      <div className={cardClass}>
        <CardHeader title="12-Month Payroll Trend" subtitle="Total payroll · deductions · overtime — May 2025 → Apr 2026" />
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={monthlyPayrollTrend}>
            <defs>
              <linearGradient id="payGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="otGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.12} />
                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} interval={1} />
            <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={fmtK} width={36} />
            <Tooltip {...tooltipStyle} formatter={(v: number) => [fmt(v), ""]} />
            <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
            <Area id="pay-total" type="monotone" dataKey="total" name="Total Payroll" stroke="#3b82f6" strokeWidth={2} fill="url(#payGrad)" dot={{ r: 3, fill: "#3b82f6" }} />
            <Area id="pay-deductions" type="monotone" dataKey="deductions" name="Deductions" stroke="#ef4444" strokeWidth={1.5} fill="transparent" strokeDasharray="4 2" />
            <Area id="pay-overtime" type="monotone" dataKey="overtime" name="Overtime" stroke="#8b5cf6" strokeWidth={1.5} fill="url(#otGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Salary Distribution + Dept Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Salary Distribution */}
        <div className={cardClass}>
          <CardHeader title="Salary Distribution" subtitle="Net salary ranges · April 2026" />
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={salaryDistribution} barSize={32}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={24} allowDecimals={false} />
              <Tooltip {...tooltipStyle} formatter={(v) => [v, "Employees"]} />
              <Bar id="sal-dist" dataKey="count" name="Employees" radius={[4, 4, 0, 0]}>
                {salaryDistribution.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Cost by Department */}
        <div className={cardClass}>
          <CardHeader title="Cost by Department" subtitle={`Total ${fmt(totalPayroll)} · April 2026`} />
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={payrollByDept} cx="50%" cy="50%" innerRadius={42} outerRadius={72}
                  dataKey="value" labelLine={false} label={PieLabel}>
                  {payrollByDept.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-1.5">
              {payrollByDept.map((d) => (
                <div key={d.name} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: d.fill }} />
                  <span className="text-[10px] text-gray-600 flex-1">{d.name}</span>
                  <span className="text-[10px] font-bold text-gray-800">{fmtK(d.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Payroll Cost Growth Insight */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl px-5 py-4 flex items-center gap-4">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
          <TrendingUp size={18} className="text-white" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-bold text-blue-900">Payroll grew {growthPct}% this month</p>
          <p className="text-xs text-blue-700 mt-0.5">
            April total of {fmt(latest.total)} is up from March's {fmt(prev.total)}.
            Overtime spend (+16.4%) is the primary driver — Engineering and Operations account for 66% of overtime hours.
          </p>
        </div>
      </div>
    </div>
  );
}
