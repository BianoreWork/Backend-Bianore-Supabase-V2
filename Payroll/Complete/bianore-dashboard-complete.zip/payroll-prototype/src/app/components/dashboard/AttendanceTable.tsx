import { useState } from "react";
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Download,
  Filter,
  Search,
} from "lucide-react";
import { employeeLogs } from "./mockData";

type SortField = "name" | "dept" | "checkIn" | "checkOut" | "status" | "hours";
type SortDir = "asc" | "desc" | null;

const statusConfig: Record<string, { bg: string; text: string; dot: string }> = {
  Present: { bg: "bg-green-50", text: "text-green-700", dot: "bg-green-500" },
  Late: { bg: "bg-yellow-50", text: "text-yellow-700", dot: "bg-yellow-500" },
  Absent: { bg: "bg-red-50", text: "text-red-600", dot: "bg-red-500" },
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",
  HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700",
  Sales: "bg-green-50 text-green-700",
};

function SortIcon({ field, sortField, sortDir }: { field: SortField; sortField: SortField | null; sortDir: SortDir }) {
  if (sortField !== field) return <ChevronsUpDown size={12} className="text-gray-300" />;
  if (sortDir === "asc") return <ChevronUp size={12} className="text-blue-600" />;
  return <ChevronDown size={12} className="text-blue-600" />;
}

export function AttendanceTable({ previewMode }: { previewMode?: boolean }) {
  const [sortField, setSortField] = useState<SortField | null>(null);
  const [sortDir, setSortDir] = useState<SortDir>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === "asc" ? "desc" : sortDir === "desc" ? null : "asc");
      if (sortDir === "desc") setSortField(null);
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  const allFiltered = employeeLogs
    .filter((e) => {
      const matchSearch =
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.dept.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "All" || e.status === statusFilter;
      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      if (!sortField || !sortDir) return 0;
      const aVal = a[sortField];
      const bVal = b[sortField];
      const dir = sortDir === "asc" ? 1 : -1;
      return aVal > bVal ? dir : aVal < bVal ? -dir : 0;
    });

  const filtered = previewMode ? allFiltered.slice(0, 5) : allFiltered;

  const columns: { key: SortField; label: string }[] = [
    { key: "name", label: "Employee" },
    { key: "dept", label: "Department" },
    { key: "checkIn", label: "Check-in" },
    { key: "checkOut", label: "Check-out" },
    { key: "status", label: "Status" },
    { key: "hours", label: "Work Hours" },
  ];

  return (
    <div className={previewMode ? "overflow-hidden" : "bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"}>
      {/* Table Header */}
      {!previewMode && (
      <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
        <div>
          <h3 className="text-sm font-semibold text-gray-800">Employee Attendance Logs</h3>
          <p className="text-xs text-gray-400 mt-0.5">{filtered.length} records · Today, Apr 30</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Status Filter */}
          <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
            {["All", "Present", "Late", "Absent"].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`text-xs px-3 py-1.5 rounded-md transition-all cursor-pointer font-medium ${
                  statusFilter === s
                    ? "bg-white text-gray-800 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-40 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
            />
          </div>

          {/* Export */}
          <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer">
            <Download size={13} />
            Export
          </button>
        </div>
      </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[700px]">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/50">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className="text-left px-5 py-3 cursor-pointer group select-none"
                  onClick={() => handleSort(col.key)}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors">
                      {col.label}
                    </span>
                    <SortIcon field={col.key} sortField={sortField} sortDir={sortDir} />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((employee, idx) => {
              const sc = statusConfig[employee.status];
              const dc = deptColors[employee.dept] || "bg-gray-50 text-gray-600";
              return (
                <tr
                  key={employee.id}
                  className={`border-b border-gray-50 hover:bg-blue-50/30 transition-colors cursor-pointer group ${
                    idx % 2 === 0 ? "" : "bg-gray-50/30"
                  }`}
                >
                  {/* Employee */}
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
                        {employee.avatar}
                      </div>
                      <p className="text-xs font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">
                        {employee.name}
                      </p>
                    </div>
                  </td>

                  {/* Department */}
                  <td className="px-5 py-3.5">
                    <span className={`text-xs font-medium px-2 py-1 rounded-md ${dc}`}>
                      {employee.dept}
                    </span>
                  </td>

                  {/* Check-in */}
                  <td className="px-5 py-3.5">
                    <span className={`text-xs font-medium ${employee.checkIn === "—" ? "text-gray-300" : "text-gray-700"}`}>
                      {employee.checkIn}
                    </span>
                  </td>

                  {/* Check-out */}
                  <td className="px-5 py-3.5">
                    <span className={`text-xs font-medium ${employee.checkOut === "—" ? "text-gray-300" : "text-gray-700"}`}>
                      {employee.checkOut}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="px-5 py-3.5">
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}
                    >
                      <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                      {employee.status}
                    </span>
                  </td>

                  {/* Hours */}
                  <td className="px-5 py-3.5">
                    <span className={`text-xs font-medium ${employee.hours === "0h" ? "text-gray-300" : "text-gray-700"}`}>
                      {employee.hours}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <p className="text-sm text-gray-400">No records match your filters.</p>
          </div>
        )}
      </div>

      {/* Footer */}
      {!previewMode && (
      <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
        <p className="text-xs text-gray-400">Showing {filtered.length} of {employeeLogs.length} employees</p>
        <div className="flex items-center gap-1">
          {[1, 2, 3, "...", 14].map((p, i) => (
            <button
              key={i}
              className={`w-7 h-7 rounded-lg text-xs transition-colors cursor-pointer ${
                p === 1
                  ? "bg-blue-600 text-white font-semibold"
                  : "text-gray-500 hover:bg-gray-100"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
      )}
    </div>
  );
}