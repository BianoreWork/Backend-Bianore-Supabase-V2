import { useState } from "react";
import { Receipt, Download, BarChart2, FileText, Edit3, CheckCircle } from "lucide-react";
import { ptkpSettings, terSettings, fmtIDR } from "./payrollMockData";

type TaxTab = "ptkp" | "ter" | "calculations" | "reports";

const terCategoryColors: Record<string, string> = {
  A: "bg-blue-50 text-blue-700",
  B: "bg-green-50 text-green-700",
  C: "bg-violet-50 text-violet-700",
};

const mockTaxCalcs = [
  { emp: "Budi Santoso", avatar: "BS", dept: "Engineering", ptkpStatus: "K1", taxMethod: "gross", grossIncome: 21_350_000, taxableIncome: 15_600_000, terRate: 5, pph21: 780_000 },
  { emp: "Dewi Rahayu",  avatar: "DR", dept: "Marketing",   ptkpStatus: "K0", taxMethod: "gross", grossIncome: 15_350_000, taxableIncome: 10_475_000, terRate: 5, pph21: 523_750 },
  { emp: "Ahmad Fauzi",  avatar: "AF", dept: "Finance",     ptkpStatus: "K2", taxMethod: "gross", grossIncome: 18_450_000, taxableIncome: 12_075_000, terRate: 5, pph21: 603_750 },
  { emp: "Sari Putri",   avatar: "SP", dept: "HR",          ptkpStatus: "TK0", taxMethod: "gross", grossIncome: 11_350_000, taxableIncome: 6_850_000,  terRate: 2, pph21: 137_000 },
  { emp: "Eko Prasetyo", avatar: "EP", dept: "Operations",  ptkpStatus: "K1", taxMethod: "nett",  grossIncome: 14_350_000, taxableIncome: 8_975_000,  terRate: 5, pph21: 448_750 },
];

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600", "from-amber-500 to-orange-600",
];

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700", Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",     HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700",
};

export function TaxPage() {
  const [activeTab, setActiveTab] = useState<TaxTab>("ptkp");

  const terCategories = [...new Set(terSettings.map((t) => t.terCategory))];

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Pajak / PPh21</h1>
          <p className="text-sm text-gray-500 mt-0.5">Pengaturan PTKP, TER, kalkulasi PPh21, dan laporan pajak</p>
        </div>
        <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
          <Download size={13} className="text-gray-400" /> Export Laporan Pajak
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {([
          { id: "ptkp"         as TaxTab, label: "PTKP",          icon: <Receipt size={13} /> },
          { id: "ter"          as TaxTab, label: "TER (Tarif)",    icon: <BarChart2 size={13} /> },
          { id: "calculations" as TaxTab, label: "Kalkulasi PPh21", icon: <FileText size={13} /> },
          { id: "reports"      as TaxTab, label: "Laporan",         icon: <Download size={13} /> },
        ]).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* ── PTKP TAB ── */}
      {activeTab === "ptkp" && (
        <div className="space-y-4">
          <div className="flex items-start gap-2 text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2.5">
            <Receipt size={12} className="text-blue-600 flex-shrink-0 mt-0.5" />
            PTKP (Penghasilan Tidak Kena Pajak) adalah batas penghasilan yang dikecualikan dari penghitungan PPh21 tahunan.
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Tabel PTKP</h3>
                <p className="text-xs text-gray-400 mt-0.5">PMK No. 168/PMK.03/2023 · Berlaku 2024</p>
              </div>
              <button className="text-xs text-blue-600 font-medium hover:text-blue-800 cursor-pointer flex items-center gap-1">
                <Edit3 size={12} /> Update PTKP
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50/60">
                    {["Kode", "Status", "PTKP / Tahun", "PTKP / Bulan", "Berlaku Sejak", "Status"].map((col) => (
                      <th key={col} className="text-left px-5 py-3">
                        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ptkpSettings.map((p, idx) => (
                    <tr key={p.id} className={`border-b border-gray-50 hover:bg-blue-50/20 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{p.ptkpCode}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs text-gray-700">{p.ptkpName}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(p.amount)}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs text-gray-600 tabular-nums">{fmtIDR(Math.round(p.amount / 12))}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs text-gray-500">{p.effectiveStartDate}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        {p.isActive
                          ? <span className="inline-flex items-center gap-1 text-[10px] text-green-700 bg-green-50 px-2 py-0.5 rounded-full font-semibold"><CheckCircle size={9} /> Aktif</span>
                          : <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">Nonaktif</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── TER TAB ── */}
      {activeTab === "ter" && (
        <div className="space-y-4">
          <div className="flex items-start gap-2 text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2.5">
            <BarChart2 size={12} className="text-blue-600 flex-shrink-0 mt-0.5" />
            TER (Tarif Efektif Rata-rata) adalah metode perhitungan PPh21 berdasarkan PMK No. 168/2023 yang berlaku mulai Januari 2024.
          </div>

          {terCategories.map((cat) => {
            const catRates = terSettings.filter((t) => t.terCategory === cat);
            const cc = terCategoryColors[cat] || "bg-gray-100 text-gray-600";
            return (
              <div key={cat} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-lg ${cc}`}>Kategori {cat}</span>
                  <div>
                    <p className="text-sm font-semibold text-gray-800">TER Kategori {cat}</p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {cat === "A" ? "Status TK/0, K/0" : cat === "B" ? "Status TK/1, TK/2, K/1" : "Status TK/3, K/2, K/3"}
                    </p>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100 bg-gray-50/60">
                        {["Penghasilan Bruto Min", "Penghasilan Bruto Maks", "Tarif (%)", "Status"].map((col) => (
                          <th key={col} className="text-left px-5 py-2.5">
                            <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {catRates.map((t, idx) => (
                        <tr key={t.id} className={`border-b border-gray-50 hover:bg-blue-50/20 ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                          <td className="px-5 py-2.5"><span className="text-xs text-gray-700 tabular-nums">{fmtIDR(t.incomeMin)}</span></td>
                          <td className="px-5 py-2.5"><span className="text-xs text-gray-700 tabular-nums">{t.incomeMax ? fmtIDR(t.incomeMax) : "Tak terbatas"}</span></td>
                          <td className="px-5 py-2.5">
                            <span className="text-xs font-bold text-blue-700 tabular-nums">{t.rate}%</span>
                          </td>
                          <td className="px-5 py-2.5">
                            {t.isActive
                              ? <CheckCircle size={13} className="text-green-500" />
                              : <span className="text-gray-300 text-sm">—</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── CALCULATIONS TAB ── */}
      {activeTab === "calculations" && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            {[
              { label: "Total PPh21 Mei 2025", value: fmtIDR(mockTaxCalcs.reduce((s, c) => s + c.pph21, 0)), color: "bg-red-50 text-red-700" },
              { label: "Rata-rata PPh21", value: fmtIDR(Math.round(mockTaxCalcs.reduce((s, c) => s + c.pph21, 0) / mockTaxCalcs.length)), color: "bg-amber-50 text-amber-700" },
              { label: "Gross Up", value: "1 karyawan", color: "bg-violet-50 text-violet-700" },
              { label: "Nett (Ditanggung)", value: "1 karyawan", color: "bg-blue-50 text-blue-700" },
            ].map((c) => (
              <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
                <span className="opacity-60">{c.label}: </span>{c.value}
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Kalkulasi PPh21 — Mei 2025</h3>
                <p className="text-xs text-gray-400 mt-0.5">Per karyawan berdasarkan TER 2024</p>
              </div>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <Download size={12} /> Export
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px]">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50/60">
                    {["Karyawan", "Dept", "Status PTKP", "Metode Pajak", "Penghasilan Bruto", "Penghasilan Kena Pajak", "TER", "PPh21"].map((col) => (
                      <th key={col} className="text-left px-4 py-3">
                        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {mockTaxCalcs.map((c, idx) => {
                    const dc   = deptColors[c.dept] || "bg-gray-100 text-gray-600";
                    const grad = avatarGradients[idx % avatarGradients.length];
                    return (
                      <tr key={c.emp} className={`border-b border-gray-50 hover:bg-blue-50/20 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                              {c.avatar}
                            </div>
                            <span className="text-xs font-semibold text-gray-800">{c.emp}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3.5"><span className={`text-xs font-medium px-2 py-0.5 rounded-md ${dc}`}>{c.dept}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{c.ptkpStatus}</span></td>
                        <td className="px-4 py-3.5">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${
                            c.taxMethod === "nett" ? "bg-green-50 text-green-700" :
                            c.taxMethod === "gross_up" ? "bg-violet-50 text-violet-700" :
                            "bg-gray-100 text-gray-600"
                          }`}>
                            {c.taxMethod === "gross" ? "Gross" : c.taxMethod === "nett" ? "Nett" : "Gross Up"}
                          </span>
                        </td>
                        <td className="px-4 py-3.5"><span className="text-xs text-gray-700 tabular-nums">{fmtIDR(c.grossIncome)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-gray-700 tabular-nums">{fmtIDR(c.taxableIncome)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs font-semibold text-blue-700">{c.terRate}%</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs font-bold text-red-600 tabular-nums">{fmtIDR(c.pph21)}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── REPORTS TAB ── */}
      {activeTab === "reports" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[
            { title: "Laporan Bulanan PPh21", desc: "Rekap potongan pajak semua karyawan per periode", icon: FileText, color: "bg-red-50", iconColor: "text-red-600" },
            { title: "SPT 1721-A1", desc: "Form bukti potong tahunan per karyawan", icon: Receipt, color: "bg-amber-50", iconColor: "text-amber-600" },
            { title: "e-SPT PPh21 (CSV)", desc: "Format untuk upload ke DJP Online", icon: Download, color: "bg-blue-50", iconColor: "text-blue-600" },
            { title: "Laporan Tahunan PPh21", desc: "Rekapitulasi pajak selama setahun per departemen", icon: BarChart2, color: "bg-violet-50", iconColor: "text-violet-600" },
          ].map((item) => (
            <div key={item.title} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl ${item.color} flex items-center justify-center flex-shrink-0`}>
                  <item.icon size={18} className={item.iconColor} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">{item.title}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
                </div>
                <Download size={15} className="text-gray-300 group-hover:text-blue-500 transition-colors flex-shrink-0 mt-1" />
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="h-4" />
    </main>
  );
}
