import { useState } from "react";
import { ChevronDown, ChevronUp, Users } from "lucide-react";
import type { FullEmployee } from "./employeeData";

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600",
  "from-amber-500 to-orange-600", "from-cyan-500 to-blue-600",
];

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing:   "bg-pink-50 text-pink-700",
  Finance:     "bg-cyan-50 text-cyan-700",
  HR:          "bg-purple-50 text-purple-700",
  Operations:  "bg-orange-50 text-orange-700",
  Sales:       "bg-green-50 text-green-700",
  Executive:   "bg-gray-100 text-gray-700",
};

interface OrgNodeCardProps {
  emp: FullEmployee;
  onSelect: (emp: FullEmployee) => void;
  size?: "large" | "normal" | "small";
}

function OrgNodeCard({ emp, onSelect, size = "normal" }: OrgNodeCardProps) {
  const grad = avatarGradients[emp.id % avatarGradients.length];
  const dc = deptColors[emp.dept] || "bg-gray-50 text-gray-600";
  const isLarge = size === "large";
  const isSmall = size === "small";

  return (
    <button
      onClick={() => onSelect(emp)}
      className={`bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all cursor-pointer group text-left flex-shrink-0 ${
        isLarge ? "w-52 p-4" : isSmall ? "w-36 p-3" : "w-44 p-3.5"
      }`}
    >
      <div className={`rounded-full bg-gradient-to-br ${grad} text-white flex items-center justify-center font-bold mx-auto mb-2 ${
        isLarge ? "w-12 h-12 text-base" : isSmall ? "w-8 h-8 text-xs" : "w-10 h-10 text-sm"
      }`}>
        {emp.avatar}
      </div>
      <p className={`font-semibold text-gray-800 text-center truncate group-hover:text-blue-700 transition-colors ${isLarge ? "text-sm" : "text-xs"}`}>
        {emp.name}
      </p>
      <p className={`text-gray-500 text-center truncate mt-0.5 ${isSmall ? "text-[9px]" : "text-[10px]"}`}>
        {emp.role}
      </p>
      <div className="flex justify-center mt-1.5">
        <span className={`font-medium px-1.5 py-0.5 rounded text-center ${dc} ${isSmall ? "text-[8px]" : "text-[9px]"}`}>
          {emp.dept}
        </span>
      </div>
    </button>
  );
}

interface OrgNodeProps {
  emp: FullEmployee;
  allEmps: FullEmployee[];
  onSelect: (emp: FullEmployee) => void;
  level?: number;
}

function OrgNode({ emp, allEmps, onSelect, level = 0 }: OrgNodeProps) {
  const [expanded, setExpanded] = useState(true);
  const children = allEmps.filter((e) => e.managerId === emp.id);
  const isRoot = level === 0;

  return (
    <div className="flex flex-col items-center flex-shrink-0">
      {/* Card */}
      <div className="relative">
        <OrgNodeCard emp={emp} onSelect={onSelect} size={isRoot ? "large" : level === 1 ? "normal" : "small"} />
        {children.length > 0 && (
          <button
            onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
            className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-5 h-5 bg-white border border-gray-200 rounded-full flex items-center justify-center shadow-sm hover:bg-blue-50 hover:border-blue-300 transition-colors cursor-pointer z-10"
          >
            {expanded ? <ChevronUp size={10} className="text-gray-500" /> : <ChevronDown size={10} className="text-blue-600" />}
          </button>
        )}
      </div>

      {/* Children */}
      {children.length > 0 && expanded && (
        <div className="flex flex-col items-center">
          {/* Vertical line down */}
          <div className="w-px h-7 bg-gray-200" />

          {/* Horizontal + children */}
          <div className="relative flex items-start">
            {/* Horizontal connecting bar */}
            {children.length > 1 && (
              <div
                className="absolute top-0 bg-gray-200 pointer-events-none"
                style={{
                  height: "1px",
                  left: `calc(100% / ${2 * children.length})`,
                  right: `calc(100% / ${2 * children.length})`,
                }}
              />
            )}
            <div className="flex items-start gap-5">
              {children.map((child) => (
                <div key={child.id} className="flex flex-col items-center">
                  {/* Vertical line up from child to horizontal bar */}
                  <div className="w-px h-6 bg-gray-200" />
                  <OrgNode emp={child} allEmps={allEmps} onSelect={onSelect} level={level + 1} />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface OrgChartProps {
  employees: FullEmployee[];
  onSelect: (emp: FullEmployee) => void;
}

export function OrgChart({ employees, onSelect }: OrgChartProps) {
  const root = employees.find((e) => e.managerId === null);
  const totalCount = employees.length;
  const deptCounts = employees.reduce<Record<string, number>>((acc, e) => {
    acc[e.dept] = (acc[e.dept] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      {/* Org Chart Legend */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 text-xs text-gray-500">
          <Users size={12} />
          <span className="font-medium">{totalCount} employees</span>
        </div>
        <div className="w-px h-3 bg-gray-200" />
        {Object.entries(deptCounts).map(([dept, count]) => {
          const dc = deptColors[dept] || "bg-gray-50 text-gray-600";
          return (
            <span key={dept} className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${dc}`}>
              {dept}: {count}
            </span>
          );
        })}
      </div>

      {/* Chart Area */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 overflow-auto">
        {root ? (
          <div className="min-w-max flex flex-col items-center">
            <OrgNode emp={root} allEmps={employees} onSelect={onSelect} level={0} />
          </div>
        ) : (
          <div className="py-16 text-center text-gray-400 text-sm">
            No organizational data found.
          </div>
        )}
      </div>

      <p className="text-[10px] text-gray-400 text-center">
        Click any card to view employee profile · Click ↑↓ to expand/collapse
      </p>
    </div>
  );
}
