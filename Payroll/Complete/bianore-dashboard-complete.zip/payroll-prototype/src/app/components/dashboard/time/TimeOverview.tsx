import { motion } from "motion/react";
import {
  Clock, CheckCircle2, AlertCircle, CalendarDays,
  TrendingUp, Users, ArrowRight, Activity,
} from "lucide-react";
import { timeSummary, statusConfig, leaveTypeConfig, leaveRequests, correctionRequests, overtimeRequests } from "./timeMockData";

const EASE = [0.22, 1, 0.36, 1] as const;

function FadeUp({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay, ease: EASE }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const kpiCards = [
  { label: "Total Pending",      value: 23, icon: <Clock size={18}/>,         bg: "bg-amber-50",  icon2: "text-amber-600",  sub: "Across all request types" },
  { label: "Pending Leave",      value:  9, icon: <CalendarDays size={18}/>,  bg: "bg-blue-50",   icon2: "text-blue-600",   sub: "Annual, permission, special" },
  { label: "Pending Sick Leave", value:  4, icon: <AlertCircle size={18}/>,   bg: "bg-red-50",    icon2: "text-red-500",    sub: "Awaiting review" },
  { label: "Pending Corrections",value:  7, icon: <Activity size={18}/>,      bg: "bg-teal-50",   icon2: "text-teal-600",   sub: "Attendance fix requests" },
  { label: "Pending Overtime",   value:  3, icon: <TrendingUp size={18}/>,    bg: "bg-purple-50", icon2: "text-purple-600", sub: "Awaiting approval" },
  { label: "Approved Today",     value: 11, icon: <CheckCircle2 size={18}/>,  bg: "bg-green-50",  icon2: "text-green-600",  sub: "Processed so far today" },
];

const activityColor: Record<string, string> = {
  approved: "bg-green-500",
  rejected: "bg-red-500",
  submitted: "bg-blue-500",
  flagged: "bg-amber-500",
};

// Combine pending items from all request types for the queue table
const pendingQueue = [
  ...leaveRequests.filter(r => r.status === "pending").slice(0, 4).map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept,
    type: r.type, category: "Leave", submitted: r.submittedAt.split(" ")[0],
    approver: r.approver, urgent: false,
  })),
  ...correctionRequests.filter(r => r.status === "pending").slice(0, 3).map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept,
    type: r.correctionType, category: "Correction", submitted: r.submittedAt.split(" ")[0],
    approver: r.approver, urgent: true,
  })),
  ...overtimeRequests.filter(r => r.status === "pending").slice(0, 3).map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept,
    type: r.overtimeType, category: "Overtime", submitted: r.submittedAt.split(" ")[0],
    approver: r.approver, urgent: false,
  })),
].slice(0, 8);

const categoryPill: Record<string, string> = {
  Leave:      "bg-blue-50 text-blue-700 border border-blue-200",
  Correction: "bg-teal-50 text-teal-700 border border-teal-200",
  Overtime:   "bg-purple-50 text-purple-700 border border-purple-200",
};

export function TimeOverview() {
  return (
    <div className="space-y-5">

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {kpiCards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 18, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.42, delay: 0.10 + i * 0.06, ease: EASE }}
            className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className={`w-9 h-9 rounded-xl ${card.bg} ${card.icon2} flex items-center justify-center mb-3`}>
              {card.icon}
            </div>
            <p className="text-2xl font-bold text-gray-900 tracking-tight">{card.value}</p>
            <p className="text-xs font-semibold text-gray-700 mt-0.5">{card.label}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{card.sub}</p>
          </motion.div>
        ))}
      </div>

      {/* Main body: Pending Queue + On Leave Today + Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

        {/* Pending Approval Queue */}
        <FadeUp delay={0.52} className="xl:col-span-2">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Pending Approval Queue</h3>
                <p className="text-xs text-gray-400 mt-0.5">Requests waiting for admin action</p>
              </div>
              <span className="text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-1 rounded-lg">
                {pendingQueue.length} pending
              </span>
            </div>
            <div className="divide-y divide-gray-50">
              {pendingQueue.map((req) => (
                <div key={req.id} className="flex items-center gap-3 px-5 py-3 hover:bg-gray-50 transition-colors cursor-pointer group">
                  {/* Avatar */}
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {req.avatar}
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-semibold text-gray-800 truncate">{req.employee}</p>
                      {req.urgent && (
                        <span className="text-[9px] font-bold bg-red-50 text-red-600 border border-red-200 px-1.5 py-0.5 rounded-md flex-shrink-0">URGENT</span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-400 truncate">{req.type} · {req.dept}</p>
                  </div>
                  {/* Category */}
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex-shrink-0 ${categoryPill[req.category]}`}>
                    {req.category}
                  </span>
                  {/* Date + ID */}
                  <div className="text-right flex-shrink-0 hidden sm:block">
                    <p className="text-[11px] text-gray-500">{req.submitted}</p>
                    <p className="text-[10px] text-gray-400">{req.id}</p>
                  </div>
                  {/* Actions */}
                  <div className="flex items-center gap-1.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="text-[10px] font-bold px-2.5 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 cursor-pointer transition-colors">Approve</button>
                    <button className="text-[10px] font-bold px-2.5 py-1 bg-white border border-gray-200 text-gray-600 rounded-lg hover:bg-red-50 hover:text-red-600 hover:border-red-200 cursor-pointer transition-colors">Reject</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </FadeUp>

        {/* On Leave Today + Recent Activity */}
        <FadeUp delay={0.58} className="space-y-5">
          {/* On Leave Today */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">On Leave Today</h3>
                <p className="text-xs text-gray-400 mt-0.5">{timeSummary.onLeaveToday.length} employees</p>
              </div>
              <Users size={14} className="text-gray-400"/>
            </div>
            <div className="divide-y divide-gray-50">
              {timeSummary.onLeaveToday.map((emp, i) => {
                const lc = leaveTypeConfig[emp.type as keyof typeof leaveTypeConfig] ?? { pill: "bg-gray-100 text-gray-500 border border-gray-200", icon: "📅" };
                return (
                  <div key={i} className="flex items-center gap-2.5 px-4 py-2.5">
                    <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-400 to-blue-500 flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
                      {emp.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-800 truncate">{emp.name}</p>
                      <p className="text-[10px] text-gray-400 truncate">{emp.dept}</p>
                    </div>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${lc.pill} flex-shrink-0`}>
                      {lc.icon} {emp.type}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-4 py-3.5 border-b border-gray-100">
              <h3 className="text-sm font-semibold text-gray-800">Recent Activity</h3>
            </div>
            <div className="px-4 py-3 space-y-3">
              {timeSummary.recentActivity.map((act, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${activityColor[act.action] ?? "bg-gray-400"}`}/>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] text-gray-700 leading-snug">
                      <span className="font-semibold">{act.actor}</span>{" "}
                      <span className={act.action === "approved" ? "text-green-600" : act.action === "rejected" ? "text-red-600" : "text-gray-600"}>
                        {act.action}
                      </span>{" "}
                      {act.target}
                    </p>
                    <p className="text-[10px] text-gray-400 mt-0.5">{act.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </FadeUp>
      </div>

      {/* Upcoming Approved Leave */}
      <FadeUp delay={0.65}>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div>
              <h3 className="text-sm font-semibold text-gray-800">Upcoming Approved Leave</h3>
              <p className="text-xs text-gray-400 mt-0.5">Next 14 days</p>
            </div>
            <button className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
              View all <ArrowRight size={11}/>
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  {["Employee", "Type", "From", "To", "Duration", "Branch", "Approver"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-[11px] font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {leaveRequests.filter(r => r.status === "approved").map(r => {
                  const lc = leaveTypeConfig[r.type];
                  return (
                    <tr key={r.id} className="hover:bg-gray-50 transition-colors cursor-pointer">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0">
                            {r.avatar}
                          </div>
                          <span className="font-medium text-gray-800">{r.employee}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${lc.pill}`}>{lc.icon} {r.type}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-600">{r.startDate}</td>
                      <td className="px-4 py-3 text-gray-600">{r.endDate}</td>
                      <td className="px-4 py-3 text-gray-600">{r.duration} day{r.duration > 1 ? "s" : ""}</td>
                      <td className="px-4 py-3 text-gray-500">{r.branch}</td>
                      <td className="px-4 py-3 text-gray-500">{r.approver}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </FadeUp>
    </div>
  );
}
