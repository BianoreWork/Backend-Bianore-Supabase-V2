import { useState } from "react";
import {
  FileText, Download, Send, Search,
  CheckCircle, Clock, SlidersHorizontal,
  X, ChevronLeft, ChevronRight, Eye,
  RefreshCw, AlertTriangle,
} from "lucide-react";
import { payslips, fmtIDR, fmtIDRShort, type Payslip } from "./payrollMockData";

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600", "from-amber-500 to-orange-600",
];

const statusConfig = {
  draft:     { label: "Draft",        bg: "bg-gray-100",  text: "text-gray-600",  dot: "bg-gray-400",  icon: <Clock size={10} /> },
  generated: { label: "Dibuat",       bg: "bg-blue-50",   text: "text-blue-700",  dot: "bg-blue-500",  icon: <FileText size={10} /> },
  sent:      { label: "Terkirim",     bg: "bg-green-50",  text: "text-green-700", dot: "bg-green-500", icon: <CheckCircle size={10} /> },
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing:   "bg-pink-50 text-pink-700",
  Finance:     "bg-cyan-50 text-cyan-700",
  HR:          "bg-purple-50 text-purple-700",
  Operations:  "bg-orange-50 text-orange-700",
  Sales:       "bg-green-50 text-green-700",
};

const monthNames = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];

// ── Payslip Preview Modal ─────────────────────────────────────────────────────
function PayslipPreviewModal({ ps, onClose }: { ps: Payslip; onClose: () => void }) {
  return (
    <>
      <div className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-40" onClick={onClose} />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
          {/* Modal header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Preview Slip Gaji</h3>
              <p className="text-xs text-gray-400 mt-0.5">{ps.payslipNumber}</p>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg cursor-pointer">
                <Download size={12} /> Download PDF
              </button>
              <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><X size={16} /></button>
            </div>
          </div>

          {/* Payslip body */}
          <div className="px-5 py-4 space-y-4">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-blue-200">BIANORE</p>
                  <p className="text-sm font-bold text-white mt-0.5">Slip Gaji Karyawan</p>
                  <p className="text-xs text-blue-200 mt-0.5">
                    {monthNames[ps.periodMonth - 1]} {ps.periodYear}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-blue-200">No. Slip</p>
                  <p className="text-xs font-mono font-bold text-white">{ps.payslipNumber}</p>
                </div>
              </div>
            </div>

            {/* Employee info */}
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "Nama", value: ps.employeeName },
                  { label: "ID Karyawan", value: ps.employeeId },
                  { label: "Departemen", value: ps.dept },
                  { label: "Periode", value: `${monthNames[ps.periodMonth - 1]} ${ps.periodYear}` },
                ].map(({ label, value }) => (
                  <div key={label}>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">{label}</p>
                    <p className="text-xs font-semibold text-gray-800 mt-0.5">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Earnings & Deductions */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Pendapatan</p>
                {[
                  { label: "Gaji Pokok",       value: ps.grossSalary * 0.7 },
                  { label: "Tunjangan Jabatan", value: ps.grossSalary * 0.07 },
                  { label: "Tunjangan Transport", value: ps.grossSalary * 0.03 },
                  { label: "Tunjangan Makan",   value: ps.grossSalary * 0.02 },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-center justify-between py-0.5">
                    <span className="text-[10px] text-gray-600">{label}</span>
                    <span className="text-[10px] font-medium text-gray-800 tabular-nums">{fmtIDR(Math.round(value))}</span>
                  </div>
                ))}
                <div className="pt-1.5 border-t border-gray-200 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-green-700">Total Pendapatan</span>
                  <span className="text-[10px] font-bold text-green-700 tabular-nums">{fmtIDR(ps.grossSalary)}</span>
                </div>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Potongan</p>
                {[
                  { label: "PPh21",            value: ps.totalDeduction * 0.55 },
                  { label: "BPJS Kesehatan",   value: ps.totalDeduction * 0.25 },
                  { label: "BPJS Ketenagakerjaan", value: ps.totalDeduction * 0.2 },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-center justify-between py-0.5">
                    <span className="text-[10px] text-gray-600">{label}</span>
                    <span className="text-[10px] font-medium text-red-600 tabular-nums">({fmtIDR(Math.round(value))})</span>
                  </div>
                ))}
                <div className="pt-1.5 border-t border-gray-200 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-red-600">Total Potongan</span>
                  <span className="text-[10px] font-bold text-red-600 tabular-nums">({fmtIDR(ps.totalDeduction)})</span>
                </div>
              </div>
            </div>

            {/* Net salary */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 flex items-center justify-between">
              <p className="text-sm font-bold text-blue-800">GAJI BERSIH</p>
              <p className="text-xl font-bold text-blue-800 tabular-nums">{fmtIDR(ps.netSalary)}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export function PayslipsPage() {
  const [search, setSearch]         = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [periodFilter, setPeriodFilter] = useState("all");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [preview, setPreview]       = useState<Payslip | null>(null);

  const filtered = payslips.filter((ps) => {
    const matchSearch = ps.employeeName.toLowerCase().includes(search.toLowerCase()) ||
                        ps.payslipNumber.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || ps.status === statusFilter;
    const matchPeriod = periodFilter === "all" || `${ps.periodMonth}-${ps.periodYear}` === periodFilter;
    return matchSearch && matchStatus && matchPeriod;
  });

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelectedIds(next);
  };
  const toggleAll = () => {
    setSelectedIds(selectedIds.size === filtered.length ? new Set() : new Set(filtered.map((ps) => ps.id)));
  };

  const counts = {
    all:       payslips.length,
    draft:     payslips.filter((ps) => ps.status === "draft").length,
    generated: payslips.filter((ps) => ps.status === "generated").length,
    sent:      payslips.filter((ps) => ps.status === "sent").length,
  };

  const periods = [...new Set(payslips.map((ps) => `${ps.periodMonth}-${ps.periodYear}`))];

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Payslip</h1>
          <p className="text-sm text-gray-500 mt-0.5">Generate, kirim, dan unduh slip gaji karyawan</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
            <Download size={13} className="text-gray-400" /> Export Semua
          </button>
          <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
            <RefreshCw size={13} /> Generate Semua
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="flex items-center gap-3 flex-wrap">
        {[
          { label: "Total Payslip", value: counts.all, color: "bg-blue-50 text-blue-700" },
          { label: "Terkirim", value: counts.sent, color: "bg-green-50 text-green-700" },
          { label: "Sudah Dibuat", value: counts.generated, color: "bg-violet-50 text-violet-700" },
          { label: "Draft", value: counts.draft, color: "bg-gray-100 text-gray-600" },
        ].map((c) => (
          <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
            <span className="opacity-60">{c.label}: </span>{c.value}
          </div>
        ))}
      </div>

      {/* Table card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
              {(["all", "draft", "generated", "sent"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`text-xs px-2.5 py-1.5 rounded-md transition-all cursor-pointer font-medium whitespace-nowrap ${
                    statusFilter === s ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {s === "all" ? "Semua" : s === "draft" ? "Draft" : s === "generated" ? "Dibuat" : "Terkirim"}
                  <span className="ml-1 opacity-50">{counts[s]}</span>
                </button>
              ))}
            </div>

            {/* Period filter */}
            <select
              value={periodFilter}
              onChange={(e) => setPeriodFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
            >
              <option value="all">Semua Periode</option>
              {periods.map((p) => {
                const [m, y] = p.split("-");
                return <option key={p} value={p}>{monthNames[Number(m) - 1]} {y}</option>;
              })}
            </select>
          </div>

          <div className="flex items-center gap-2">
            {selectedIds.size > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg">
                <span className="text-xs font-semibold text-blue-700">{selectedIds.size} dipilih</span>
                <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Generate</button>
                <span className="text-blue-300">·</span>
                <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Kirim</button>
                <span className="text-blue-300">·</span>
                <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Download</button>
              </div>
            )}
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Cari karyawan / no. slip..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-52 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
              />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                <th className="px-4 py-3 w-10">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === filtered.length && filtered.length > 0}
                    onChange={toggleAll}
                    className="w-3.5 h-3.5 rounded cursor-pointer accent-blue-600"
                  />
                </th>
                {["No. Slip", "Karyawan", "Periode", "Gaji Bruto", "Potongan", "Gaji Netto", "Status", "Dikirim", ""].map((col) => (
                  <th key={col} className="text-left px-4 py-3">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((ps, idx) => {
                const sc       = statusConfig[ps.status];
                const dc       = deptColors[ps.dept] || "bg-gray-100 text-gray-600";
                const gradIdx  = ps.employeeId.charCodeAt(ps.employeeId.length - 1) % avatarGradients.length;
                const grad     = avatarGradients[gradIdx];
                const isSelected = selectedIds.has(ps.id);
                return (
                  <tr
                    key={ps.id}
                    className={`border-b border-gray-50 cursor-pointer hover:bg-blue-50/20 transition-colors ${
                      isSelected ? "bg-blue-50/50" : idx % 2 !== 0 ? "bg-gray-50/20" : ""
                    }`}
                  >
                    <td className="px-4 py-3.5" onClick={(e) => { e.stopPropagation(); toggleSelect(ps.id); }}>
                      <input type="checkbox" checked={isSelected} onChange={() => {}} className="w-3.5 h-3.5 rounded cursor-pointer accent-blue-600" />
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-mono font-semibold text-gray-700">{ps.payslipNumber}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                          {ps.avatar}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-800">{ps.employeeName}</p>
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>{ps.dept}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-600">{monthNames[ps.periodMonth - 1]} {ps.periodYear}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-semibold text-gray-700 tabular-nums">{fmtIDRShort(ps.grossSalary)}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-semibold text-red-600 tabular-nums">({fmtIDRShort(ps.totalDeduction)})</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDRShort(ps.netSalary)}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-400">{ps.sentAt ? ps.sentAt.slice(0, 10) : "—"}</span>
                    </td>
                    <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setPreview(ps)}
                          className="p-1.5 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors"
                          title="Preview"
                        >
                          <Eye size={13} />
                        </button>
                        {ps.status === "generated" && (
                          <button className="p-1.5 rounded-lg text-gray-300 hover:text-green-600 hover:bg-green-50 cursor-pointer transition-colors" title="Kirim">
                            <Send size={13} />
                          </button>
                        )}
                        {(ps.status === "generated" || ps.status === "sent") && (
                          <button className="p-1.5 rounded-lg text-gray-300 hover:text-gray-600 hover:bg-gray-100 cursor-pointer transition-colors" title="Download">
                            <Download size={13} />
                          </button>
                        )}
                        {ps.status === "draft" && (
                          <button className="p-1.5 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors" title="Generate">
                            <RefreshCw size={13} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={10} className="py-16 text-center text-sm text-gray-400">Tidak ada payslip yang cocok</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">
            {filtered.length} dari {payslips.length} slip
          </p>
          <div className="flex items-center gap-1">
            <button className="w-7 h-7 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center cursor-pointer"><ChevronLeft size={13} /></button>
            <button className="w-7 h-7 rounded-lg bg-blue-600 text-white text-xs font-semibold flex items-center justify-center">1</button>
            <button className="w-7 h-7 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center cursor-pointer"><ChevronRight size={13} /></button>
          </div>
        </div>
      </div>

      <div className="h-4" />
      {preview && <PayslipPreviewModal ps={preview} onClose={() => setPreview(null)} />}
    </main>
  );
}
