// ── Types ─────────────────────────────────────────────────────────────────
export type ActivityStatus =
  | "assigned" | "on_the_way" | "arrived" | "in_progress"
  | "completed" | "missed" | "cancelled" | "delayed" | "gps_inactive";

export type ActivityType =
  | "client_visit" | "sales_meeting" | "field_work"
  | "delivery" | "site_inspection" | "business_trip" | "other";

export type ActivityOutcome =
  | "deal_closed" | "follow_up" | "no_interest" | "demo_done" | "pending" | "";

export type Priority = "low" | "medium" | "high" | "urgent";

// legacy alias
export type VisitStatus = ActivityStatus;
export type VisitOutcome = ActivityOutcome;

export interface FieldEmployee {
  id: number;
  name: string;
  avatar: string;
  role: string;
  empId: string;
  phone: string;
  department: string;
  branch: string;
}

// legacy alias
export type SalesRep = FieldEmployee;

export interface FieldActivity {
  id: string;
  rep: FieldEmployee;
  activityType: ActivityType;
  clientName: string;
  clientCompany: string;
  clientPhone: string;
  clientEmail: string;
  contactPerson: string;
  location: string;
  address: string;
  district: string;
  date: string;
  scheduledTime: string;
  estimatedEnd: string;
  checkIn: string | null;
  checkOut: string | null;
  status: ActivityStatus;
  priority: Priority;
  photoCount: number;
  notes: string;
  outcome: ActivityOutcome;
  tags: string[];
  duration: number | null; // minutes
  assignedBy: string;
  objective: string;
  // GPS
  gpsLat: number;
  gpsLng: number;
  gpsAccuracy: number; // metres
  gpsLastUpdate: string;
  gpsActive: boolean;
  // Map display position (0–100 %)
  mapX: number;
  mapY: number;
}

// legacy alias
export type Visit = FieldActivity;

// ── Field Employees ─────────────────────────────────────────────────────────
export const salesReps: FieldEmployee[] = [
  { id: 1, name: "Carlos Rivera",  avatar: "CR", role: "Senior Account Executive", empId: "EMP0021", phone: "(212) 555-0141", department: "Sales",      branch: "HQ – Jakarta" },
  { id: 2, name: "Maya Patel",     avatar: "MP", role: "Account Executive",        empId: "EMP0022", phone: "(212) 555-0142", department: "Sales",      branch: "HQ – Jakarta" },
  { id: 3, name: "Jake Morrison",  avatar: "JM", role: "Field Technician",         empId: "EMP0023", phone: "(212) 555-0143", department: "Operations", branch: "Branch – Surabaya" },
  { id: 4, name: "Sophie Lin",     avatar: "SL", role: "Account Executive",        empId: "EMP0024", phone: "(212) 555-0144", department: "Sales",      branch: "HQ – Jakarta" },
  { id: 5, name: "David Okafor",   avatar: "DO", role: "Field Service Rep",        empId: "EMP0025", phone: "(212) 555-0145", department: "Operations", branch: "Branch – Bandung" },
  { id: 6, name: "Sarah Johnson",  avatar: "SJ", role: "Site Inspector",           empId: "EMP0026", phone: "(212) 555-0146", department: "Engineering",branch: "HQ – Jakarta" },
  { id: 7, name: "Kevin Lee",      avatar: "KL", role: "Delivery Coordinator",     empId: "EMP0027", phone: "(212) 555-0147", department: "Logistics",  branch: "Branch – Bali" },
];

// ── Activities (20 records) ─────────────────────────────────────────────────
export const visits: FieldActivity[] = [
  {
    id: "FA-001", rep: salesReps[0], activityType: "sales_meeting",
    clientName: "Richard Tan", clientCompany: "TechVentures Corp", contactPerson: "Richard Tan",
    clientPhone: "(212) 555-8801", clientEmail: "r.tan@techventures.com",
    location: "Midtown Business Tower", address: "350 Fifth Avenue, Suite 4100",
    district: "Midtown Manhattan", date: "2026-05-11", scheduledTime: "09:30", estimatedEnd: "11:00",
    checkIn: "09:28", checkOut: "11:15", status: "completed", priority: "high", photoCount: 3,
    notes: "Discussed Q3 enterprise package. Client showed strong interest in the HR module integration. Follow-up demo scheduled for May 18.",
    outcome: "follow_up", tags: ["Enterprise", "Q3 Pipeline"], duration: 107,
    assignedBy: "David Park", objective: "Present Q3 enterprise HR package and get commitment for a follow-up demo.",
    gpsLat: -6.2088, gpsLng: 106.8456, gpsAccuracy: 8, gpsLastUpdate: "11:15", gpsActive: false,
    mapX: 28, mapY: 35,
  },
  {
    id: "FA-002", rep: salesReps[0], activityType: "client_visit",
    clientName: "Jennifer Walsh", clientCompany: "Pacific Finance Group", contactPerson: "Jennifer Walsh",
    clientPhone: "(212) 555-8802", clientEmail: "j.walsh@pacificfinance.com",
    location: "Financial District Plaza", address: "140 Broadway, Floor 32",
    district: "Financial District", date: "2026-05-11", scheduledTime: "14:00", estimatedEnd: "15:30",
    checkIn: "14:03", checkOut: null, status: "in_progress", priority: "urgent", photoCount: 1,
    notes: "Currently presenting payroll compliance solutions. Client CFO in attendance.",
    outcome: "pending", tags: ["Payroll", "Compliance"], duration: null,
    assignedBy: "Alex Kumar", objective: "Present payroll compliance solution to CFO and procurement team.",
    gpsLat: -6.2115, gpsLng: 106.8412, gpsAccuracy: 12, gpsLastUpdate: "14:47", gpsActive: true,
    mapX: 62, mapY: 48,
  },
  {
    id: "FA-003", rep: salesReps[1], activityType: "sales_meeting",
    clientName: "Sandra Kim", clientCompany: "Metro Retail Solutions", contactPerson: "Sandra Kim",
    clientPhone: "(718) 555-9901", clientEmail: "s.kim@metroretail.com",
    location: "Brooklyn Heights Office", address: "55 Water Street, Brooklyn",
    district: "Brooklyn", date: "2026-05-11", scheduledTime: "10:00", estimatedEnd: "12:00",
    checkIn: "09:58", checkOut: "11:40", status: "completed", priority: "high", photoCount: 4,
    notes: "Full product demo completed for retail attendance module. Client satisfied with biometric integration. Sending proposal by EOD.",
    outcome: "deal_closed", tags: ["Retail", "Biometric", "Hot Lead"], duration: 102,
    assignedBy: "David Park", objective: "Close the retail attendance module deal — biometric demo.",
    gpsLat: -6.2250, gpsLng: 106.8350, gpsAccuracy: 6, gpsLastUpdate: "11:40", gpsActive: false,
    mapX: 45, mapY: 62,
  },
  {
    id: "FA-004", rep: salesReps[1], activityType: "field_work",
    clientName: "Tom Bradley", clientCompany: "Apex Manufacturing", contactPerson: "Tom Bradley",
    clientPhone: "(201) 555-7701", clientEmail: "t.bradley@apexmfg.com",
    location: "Industrial Park East", address: "2000 Industrial Ave, Sector 4",
    district: "East Zone", date: "2026-05-11", scheduledTime: "15:30", estimatedEnd: "17:00",
    checkIn: null, checkOut: null, status: "on_the_way", priority: "medium", photoCount: 0,
    notes: "", outcome: "", tags: ["Manufacturing", "Operations"], duration: null,
    assignedBy: "Alex Kumar", objective: "On-site walkthrough of factory floor attendance terminals.",
    gpsLat: -6.1980, gpsLng: 106.8620, gpsAccuracy: 15, gpsLastUpdate: "15:12", gpsActive: true,
    mapX: 74, mapY: 26,
  },
  {
    id: "FA-005", rep: salesReps[2], activityType: "site_inspection",
    clientName: "Laura Chen", clientCompany: "Golden Gate Insurance", contactPerson: "Laura Chen",
    clientPhone: "(212) 555-5501", clientEmail: "l.chen@goldengateins.com",
    location: "Uptown Commerce Center", address: "725 Park Avenue, Suite 300",
    district: "Upper East Side", date: "2026-05-11", scheduledTime: "11:00", estimatedEnd: "12:30",
    checkIn: "11:05", checkOut: "12:20", status: "completed", priority: "medium", photoCount: 2,
    notes: "Insurance sector compliance requirements reviewed. Client interested in audit trail features. Price negotiation ongoing.",
    outcome: "follow_up", tags: ["Insurance", "Compliance"], duration: 75,
    assignedBy: "David Park", objective: "Site inspection and compliance demo for insurance audit trail feature.",
    gpsLat: -6.2031, gpsLng: 106.8233, gpsAccuracy: 10, gpsLastUpdate: "12:20", gpsActive: false,
    mapX: 18, mapY: 41,
  },
  {
    id: "FA-006", rep: salesReps[2], activityType: "client_visit",
    clientName: "Marcus Johnson", clientCompany: "BlueSky Logistics", contactPerson: "Marcus Johnson",
    clientPhone: "(718) 555-4401", clientEmail: "m.johnson@blueskylog.com",
    location: "Logistics Hub Central", address: "110-40 Queens Blvd, Zone B",
    district: "North District", date: "2026-05-11", scheduledTime: "14:30", estimatedEnd: "16:00",
    checkIn: "14:28", checkOut: null, status: "arrived", priority: "high", photoCount: 1,
    notes: "GPS tracking integration for field workforce discussion. 3 decision makers present.",
    outcome: "pending", tags: ["Logistics", "GPS", "Field Team"], duration: null,
    assignedBy: "David Park", objective: "Demo GPS tracking integration for 120-person logistics field team.",
    gpsLat: -6.1900, gpsLng: 106.8500, gpsAccuracy: 9, gpsLastUpdate: "14:46", gpsActive: true,
    mapX: 55, mapY: 18,
  },
  {
    id: "FA-007", rep: salesReps[3], activityType: "business_trip",
    clientName: "Patricia Moore", clientCompany: "Summit Healthcare", contactPerson: "Patricia Moore",
    clientPhone: "(212) 555-3301", clientEmail: "p.moore@summithc.com",
    location: "Medical Center Tower", address: "550 First Avenue, Suite 1200",
    district: "East Midtown", date: "2026-05-11", scheduledTime: "09:00", estimatedEnd: "10:30",
    checkIn: "08:55", checkOut: "10:30", status: "completed", priority: "high", photoCount: 3,
    notes: "Healthcare payroll compliance presented. Client requested HIPAA-compliant data handling documentation. Strong buying signal.",
    outcome: "demo_done", tags: ["Healthcare", "HIPAA", "High Value"], duration: 95,
    assignedBy: "Alex Kumar", objective: "Present healthcare payroll compliance and HIPAA data handling.",
    gpsLat: -6.2200, gpsLng: 106.8550, gpsAccuracy: 7, gpsLastUpdate: "10:30", gpsActive: false,
    mapX: 68, mapY: 72,
  },
  {
    id: "FA-008", rep: salesReps[3], activityType: "client_visit",
    clientName: "Kevin Park", clientCompany: "Riverside Properties", contactPerson: "Kevin Park",
    clientPhone: "(718) 555-2201", clientEmail: "k.park@riversideprop.com",
    location: "North Business Center", address: "851 Grand Concourse, Block B",
    district: "North Zone", date: "2026-05-11", scheduledTime: "13:00", estimatedEnd: "14:30",
    checkIn: null, checkOut: null, status: "missed", priority: "medium", photoCount: 0,
    notes: "Client unreachable. Office was closed. Rescheduling for May 13.",
    outcome: "", tags: ["Real Estate"], duration: null,
    assignedBy: "Alex Kumar", objective: "Present property management HR solution to COO.",
    gpsLat: -6.1850, gpsLng: 106.8300, gpsAccuracy: 0, gpsLastUpdate: "—", gpsActive: false,
    mapX: 32, mapY: 12,
  },
  {
    id: "FA-009", rep: salesReps[4], activityType: "delivery",
    clientName: "Alicia Torres", clientCompany: "Digital Wave Agency", contactPerson: "Alicia Torres",
    clientPhone: "(212) 555-1101", clientEmail: "a.torres@digitalwave.com",
    location: "Creative Hub SoHo", address: "225 Broadway, Floor 18",
    district: "South Zone", date: "2026-05-11", scheduledTime: "10:30", estimatedEnd: "11:30",
    checkIn: "10:32", checkOut: "11:45", status: "completed", priority: "low", photoCount: 2,
    notes: "Agency explored leave management and freelancer payroll. 45-person team. Good fit for our flex plan.",
    outcome: "follow_up", tags: ["Agency", "Flex Plan"], duration: 73,
    assignedBy: "David Park", objective: "Deliver hardware terminals and complete setup walkthrough.",
    gpsLat: -6.2300, gpsLng: 106.8200, gpsAccuracy: 11, gpsLastUpdate: "11:45", gpsActive: false,
    mapX: 22, mapY: 78,
  },
  {
    id: "FA-010", rep: salesReps[4], activityType: "sales_meeting",
    clientName: "Brian Cole", clientCompany: "Premier Energy Solutions", contactPerson: "Brian Cole",
    clientPhone: "(201) 555-0011", clientEmail: "b.cole@premierenergy.com",
    location: "West Energy Campus", address: "515 W 34th St, Suite 800",
    district: "West Zone", date: "2026-05-11", scheduledTime: "16:00", estimatedEnd: "17:30",
    checkIn: null, checkOut: null, status: "delayed", priority: "high", photoCount: 0,
    notes: "Employee reported traffic delay. ETA pushed to 16:40.", outcome: "", tags: ["Energy", "Enterprise"], duration: null,
    assignedBy: "Alex Kumar", objective: "Enterprise HRIS presentation to C-suite. $250k deal potential.",
    gpsLat: -6.2050, gpsLng: 106.8180, gpsAccuracy: 14, gpsLastUpdate: "15:55", gpsActive: true,
    mapX: 12, mapY: 52,
  },
  {
    id: "FA-011", rep: salesReps[5], activityType: "site_inspection",
    clientName: "Grace Wong", clientCompany: "AsiaPacific Trading Co", contactPerson: "Grace Wong",
    clientPhone: "(212) 555-7721", clientEmail: "g.wong@asiapacific.com",
    location: "Trade District West", address: "80 Mulberry St, Floor 5",
    district: "West District", date: "2026-05-10", scheduledTime: "10:00", estimatedEnd: "12:00",
    checkIn: "09:58", checkOut: "11:25", status: "completed", priority: "medium", photoCount: 4,
    notes: "Presented multilingual payroll module. Client processes payroll across 3 countries. Interested in multi-currency support.",
    outcome: "deal_closed", tags: ["International", "Multi-currency"], duration: 87,
    assignedBy: "David Park", objective: "Inspect existing payroll system and propose integration roadmap.",
    gpsLat: -6.2160, gpsLng: 106.8310, gpsAccuracy: 8, gpsLastUpdate: "11:25", gpsActive: false,
    mapX: 36, mapY: 66,
  },
  {
    id: "FA-012", rep: salesReps[1], activityType: "sales_meeting",
    clientName: "Nathan Forbes", clientCompany: "NextGen Pharma", contactPerson: "Nathan Forbes",
    clientPhone: "(212) 555-6621", clientEmail: "n.forbes@nextgenpharma.com",
    location: "Science Tower", address: "299 Park Avenue, Floor 22",
    district: "Midtown Manhattan", date: "2026-05-10", scheduledTime: "13:30", estimatedEnd: "15:00",
    checkIn: "13:28", checkOut: "15:00", status: "completed", priority: "high", photoCount: 3,
    notes: "Pharma compliance walkthrough. GxP validation requirements discussed. Legal team needs to review contract.",
    outcome: "follow_up", tags: ["Pharma", "Compliance", "Legal Review"], duration: 92,
    assignedBy: "Alex Kumar", objective: "GxP compliance demo and contract scope discussion.",
    gpsLat: -6.2090, gpsLng: 106.8470, gpsAccuracy: 9, gpsLastUpdate: "15:00", gpsActive: false,
    mapX: 58, mapY: 44,
  },
  {
    id: "FA-013", rep: salesReps[2], activityType: "field_work",
    clientName: "Helen Castro", clientCompany: "Urban Eats Group", contactPerson: "Helen Castro",
    clientPhone: "(212) 555-5521", clientEmail: "h.castro@urbaneats.com",
    location: "Food Hub Central", address: "75 Ninth Ave, Suite 300",
    district: "Central District", date: "2026-05-10", scheduledTime: "11:00", estimatedEnd: "12:30",
    checkIn: "11:03", checkOut: "12:10", status: "completed", priority: "medium", photoCount: 2,
    notes: "Restaurant chain with 200+ part-time workers. Time tracking and shift scheduling demo done. Pricing was a concern.",
    outcome: "follow_up", tags: ["F&B", "Shift Work", "Part-time"], duration: 67,
    assignedBy: "David Park", objective: "Field assessment of 5 restaurant locations for time-tracking hardware.",
    gpsLat: -6.2175, gpsLng: 106.8420, gpsAccuracy: 10, gpsLastUpdate: "12:10", gpsActive: false,
    mapX: 48, mapY: 58,
  },
  {
    id: "FA-014", rep: salesReps[6], activityType: "delivery",
    clientName: "James Elliott", clientCompany: "Harbor Shipping Ltd", contactPerson: "James Elliott",
    clientPhone: "(718) 555-4421", clientEmail: "j.elliott@harborshipping.com",
    location: "Port Authority South", address: "1 Atlantic Ave, Dock 12",
    district: "South Port", date: "2026-05-10", scheduledTime: "14:00", estimatedEnd: "15:30",
    checkIn: "13:55", checkOut: "15:30", status: "completed", priority: "high", photoCount: 3,
    notes: "Shipping company with crews across 5 ports. Overtime and hazard pay calculations were the key discussion points.",
    outcome: "demo_done", tags: ["Shipping", "Maritime", "Overtime"], duration: 95,
    assignedBy: "Alex Kumar", objective: "Deliver biometric terminals to port authority depot and verify installation.",
    gpsLat: -6.2380, gpsLng: 106.8520, gpsAccuracy: 12, gpsLastUpdate: "15:30", gpsActive: false,
    mapX: 72, mapY: 84,
  },
  {
    id: "FA-015", rep: salesReps[4], activityType: "client_visit",
    clientName: "Rachel Green", clientCompany: "Skyline Architects", contactPerson: "Rachel Green",
    clientPhone: "(212) 555-3321", clientEmail: "r.green@skylinearch.com",
    location: "Design Center Tower", address: "100 Franklin St, Floor 3",
    district: "South Zone", date: "2026-05-10", scheduledTime: "09:30", estimatedEnd: "10:30",
    checkIn: "09:35", checkOut: "10:40", status: "completed", priority: "low", photoCount: 1,
    notes: "Small firm (18 people) looking for basic HR + payroll. Interested in starter plan with room to grow.",
    outcome: "deal_closed", tags: ["Architecture", "SMB"], duration: 65,
    assignedBy: "David Park", objective: "Exploratory meeting — identify needs and position starter plan.",
    gpsLat: -6.2280, gpsLng: 106.8190, gpsAccuracy: 8, gpsLastUpdate: "10:40", gpsActive: false,
    mapX: 14, mapY: 74,
  },
  {
    id: "FA-016", rep: salesReps[0], activityType: "business_trip",
    clientName: "David Park", clientCompany: "K-Tech Electronics", contactPerson: "Park Ji-woo",
    clientPhone: "(646) 555-1199", clientEmail: "d.park@ktechelectronics.com",
    location: "Tech Hub East", address: "32 W 32nd St, Floor 8",
    district: "East District", date: "2026-05-09", scheduledTime: "10:00", estimatedEnd: "12:00",
    checkIn: "10:02", checkOut: "11:45", status: "completed", priority: "urgent", photoCount: 5,
    notes: "Electronics manufacturer with 300 factory workers. Biometric attendance integration was the main selling point. Strong interest.",
    outcome: "deal_closed", tags: ["Manufacturing", "Biometric", "Hot Lead"], duration: 103,
    assignedBy: "Alex Kumar", objective: "Executive-level meeting to negotiate enterprise deal terms.",
    gpsLat: -6.1960, gpsLng: 106.8590, gpsAccuracy: 7, gpsLastUpdate: "11:45", gpsActive: false,
    mapX: 78, mapY: 22,
  },
  {
    id: "FA-017", rep: salesReps[1], activityType: "sales_meeting",
    clientName: "Michelle Davis", clientCompany: "Horizon Legal Partners", contactPerson: "Michelle Davis",
    clientPhone: "(212) 555-2299", clientEmail: "m.davis@horizonlegal.com",
    location: "Legal District Tower", address: "One Liberty Plaza, Floor 40",
    district: "Financial District", date: "2026-05-09", scheduledTime: "14:30", estimatedEnd: "16:00",
    checkIn: "14:28", checkOut: "16:00", status: "completed", priority: "medium", photoCount: 2,
    notes: "Law firm billing integration required. Time-tracking by matter/client is key requirement. Custom dev scope discussed.",
    outcome: "follow_up", tags: ["Legal", "Time-tracking", "Custom"], duration: 92,
    assignedBy: "David Park", objective: "Assess legal billing integration needs and discuss custom development scope.",
    gpsLat: -6.2120, gpsLng: 106.8400, gpsAccuracy: 10, gpsLastUpdate: "16:00", gpsActive: false,
    mapX: 42, mapY: 50,
  },
  {
    id: "FA-018", rep: salesReps[5], activityType: "site_inspection",
    clientName: "Oscar Williams", clientCompany: "Greenfield Consulting", contactPerson: "Oscar Williams",
    clientPhone: "(212) 555-1199", clientEmail: "o.williams@greenfield.com",
    location: "Business Tower Central", address: "1270 Avenue of the Americas",
    district: "Central Manhattan", date: "2026-05-09", scheduledTime: "11:00", estimatedEnd: "12:30",
    checkIn: "11:10", checkOut: "12:00", status: "completed", priority: "low", photoCount: 2,
    notes: "Management consulting firm exploring automated payroll. 60 consultants on variable compensation. Good prospect.",
    outcome: "follow_up", tags: ["Consulting", "Variable Pay"], duration: 50,
    assignedBy: "Alex Kumar", objective: "Site inspection and needs assessment for variable compensation module.",
    gpsLat: -6.2070, gpsLng: 106.8360, gpsAccuracy: 9, gpsLastUpdate: "12:00", gpsActive: false,
    mapX: 38, mapY: 38,
  },
  {
    id: "FA-019", rep: salesReps[3], activityType: "client_visit",
    clientName: "Vanessa Reed", clientCompany: "Starlight Fashion", contactPerson: "Vanessa Reed",
    clientPhone: "(212) 555-0099", clientEmail: "v.reed@starlightfashion.com",
    location: "Fashion District Showroom", address: "500 Seventh Ave, Floor 14",
    district: "Garment District", date: "2026-05-09", scheduledTime: "13:00", estimatedEnd: "14:30",
    checkIn: "13:05", checkOut: "14:10", status: "completed", priority: "medium", photoCount: 3,
    notes: "Fashion brand with 120 retail + HQ staff. Seasonal worker management and holiday pay calculation were key topics.",
    outcome: "demo_done", tags: ["Retail", "Fashion", "Seasonal"], duration: 65,
    assignedBy: "David Park", objective: "Demo seasonal workforce management and holiday payroll calculation.",
    gpsLat: -6.2140, gpsLng: 106.8280, gpsAccuracy: 11, gpsLastUpdate: "14:10", gpsActive: false,
    mapX: 26, mapY: 56,
  },
  {
    id: "FA-020", rep: salesReps[6], activityType: "delivery",
    clientName: "Anton Russo", clientCompany: "Little Italy Foods", contactPerson: "Anton Russo",
    clientPhone: "(212) 555-9988", clientEmail: "a.russo@littleitalyfoods.com",
    location: "Food Commerce Zone", address: "187 Grand St, Suite 200",
    district: "South Zone", date: "2026-05-09", scheduledTime: "10:00", estimatedEnd: "11:00",
    checkIn: "09:55", checkOut: "10:45", status: "completed", priority: "low", photoCount: 2,
    notes: "F&B distributor with hourly workers. Tips and commissions payout calculation was the main query. Interested in basic plan.",
    outcome: "follow_up", tags: ["F&B", "Hourly Workers"], duration: 50,
    assignedBy: "Alex Kumar", objective: "Deliver hardware order and collect signed delivery receipt with photo proof.",
    gpsLat: -6.2330, gpsLng: 106.8240, gpsAccuracy: 8, gpsLastUpdate: "10:45", gpsActive: false,
    mapX: 20, mapY: 82,
  },
];

// ── Derived: Top Performers ────────────────────────────────────────────────
export const topPerformers = salesReps.map((rep) => {
  const repVisits = visits.filter((v) => v.rep.id === rep.id);
  const completed = repVisits.filter((v) => v.status === "completed").length;
  const ongoing   = repVisits.filter((v) => ["in_progress", "arrived", "on_the_way"].includes(v.status)).length;
  const missed    = repVisits.filter((v) => v.status === "missed").length;
  const deals     = repVisits.filter((v) => v.outcome === "deal_closed").length;
  const avgDur    = repVisits.filter((v) => v.duration).reduce((s, v) => s + (v.duration ?? 0), 0)
    / (repVisits.filter((v) => v.duration).length || 1);
  return {
    rep, total: repVisits.length, completed, ongoing,
    planned: repVisits.filter((v) => v.status === "assigned").length,
    missed, deals,
    completionRate: repVisits.length > 0 ? Math.round((completed / repVisits.length) * 100) : 0,
    avgDuration: Math.round(avgDur),
  };
}).sort((a, b) => b.completed - a.completed);

// ── Weekly Activity Chart ──────────────────────────────────────────────────
export const weeklyActivity = [
  { day: "Mon", completed: 7, ongoing: 0, assigned: 1, missed: 0 },
  { day: "Tue", completed: 6, ongoing: 1, assigned: 2, missed: 1 },
  { day: "Wed", completed: 8, ongoing: 1, assigned: 1, missed: 0 },
  { day: "Thu", completed: 5, ongoing: 2, assigned: 2, missed: 1 },
  { day: "Fri", completed: 4, ongoing: 3, assigned: 6, missed: 0 },
];

// ── Monthly Visit Trend ────────────────────────────────────────────────────
export const monthlyVisitTrend = [
  { month: "Nov", total: 28 }, { month: "Dec", total: 24 },
  { month: "Jan", total: 31 }, { month: "Feb", total: 34 },
  { month: "Mar", total: 38 }, { month: "Apr", total: 36 },
  { month: "May", total: 20 },
];

// ── Activity Type Labels ───────────────────────────────────────────────────
export const activityTypeLabels: Record<ActivityType, string> = {
  client_visit:   "Client Visit",
  sales_meeting:  "Sales Meeting",
  field_work:     "Field Work",
  delivery:       "Delivery",
  site_inspection:"Site Inspection",
  business_trip:  "Business Trip",
  other:          "Other",
};
export const activityTypeColors: Record<ActivityType, string> = {
  client_visit:    "bg-blue-50 text-blue-700",
  sales_meeting:   "bg-indigo-50 text-indigo-700",
  field_work:      "bg-orange-50 text-orange-700",
  delivery:        "bg-green-50 text-green-700",
  site_inspection: "bg-teal-50 text-teal-700",
  business_trip:   "bg-purple-50 text-purple-700",
  other:           "bg-gray-100 text-gray-600",
};

// ── Outcome Labels ─────────────────────────────────────────────────────────
export const outcomeLabels: Record<ActivityOutcome, string> = {
  deal_closed: "Deal Closed", follow_up: "Follow-up", no_interest: "No Interest",
  demo_done: "Demo Done", pending: "Pending", "": "—",
};
export const outcomeColors: Record<ActivityOutcome, string> = {
  deal_closed: "bg-green-50 text-green-700", follow_up: "bg-blue-50 text-blue-700",
  no_interest: "bg-gray-100 text-gray-500", demo_done: "bg-purple-50 text-purple-700",
  pending: "bg-yellow-50 text-yellow-700", "": "bg-gray-50 text-gray-400",
};

// ── Status Labels / Colors / Dots ─────────────────────────────────────────
export const statusLabels: Record<ActivityStatus, string> = {
  assigned:    "Assigned",
  on_the_way:  "On the Way",
  arrived:     "Arrived",
  in_progress: "In Progress",
  completed:   "Completed",
  missed:      "Missed",
  cancelled:   "Cancelled",
  delayed:     "Delayed",
  gps_inactive:"GPS Inactive",
};
export const statusColors: Record<ActivityStatus, string> = {
  assigned:    "bg-gray-100 text-gray-600",
  on_the_way:  "bg-sky-50 text-sky-700",
  arrived:     "bg-blue-50 text-blue-700",
  in_progress: "bg-amber-50 text-amber-700",
  completed:   "bg-green-50 text-green-700",
  missed:      "bg-red-50 text-red-500",
  cancelled:   "bg-gray-100 text-gray-500",
  delayed:     "bg-orange-50 text-orange-700",
  gps_inactive:"bg-rose-50 text-rose-700",
};
export const statusDot: Record<ActivityStatus, string> = {
  assigned:    "bg-gray-400",
  on_the_way:  "bg-sky-500",
  arrived:     "bg-blue-500",
  in_progress: "bg-amber-500",
  completed:   "bg-green-500",
  missed:      "bg-red-500",
  cancelled:   "bg-gray-400",
  delayed:     "bg-orange-500",
  gps_inactive:"bg-rose-500",
};
export const priorityColors: Record<Priority, string> = {
  low:    "bg-gray-100 text-gray-500",
  medium: "bg-blue-50 text-blue-600",
  high:   "bg-orange-50 text-orange-600",
  urgent: "bg-red-50 text-red-600",
};

// ── Live field employees (subset of active ones for map) ──────────────────
export const liveActivities = visits.filter(v =>
  ["on_the_way","arrived","in_progress","delayed","gps_inactive"].includes(v.status)
);

// ── Alerts ─────────────────────────────────────────────────────────────────
export const fieldAlerts = [
  { type: "warning", msg: "Jake Morrison en route — arriving in ~18 mins",   sub: "FA-004 · Apex Manufacturing · ETA 15:28", icon: "clock" },
  { type: "warning", msg: "David Okafor — Premier Energy visit is delayed",  sub: "FA-010 · Originally 16:00 — pushed to 16:40", icon: "clock" },
  { type: "alert",   msg: "Kevin Park — Visit marked as missed",             sub: "FA-008 · Riverside Properties · needs reschedule", icon: "triangle" },
  { type: "alert",   msg: "GPS inactive — Sophie Lin (FA-010)",              sub: "Last seen: West Zone · 15:55", icon: "triangle" },
  { type: "info",    msg: "FA-002 proof photos still pending",               sub: "Jennifer Walsh · Pacific Finance · Carlos Rivera", icon: "pin" },
  { type: "success", msg: "Sandra Kim — Deal closed with Metro Retail",      sub: "FA-003 · Biometric module · confirmed", icon: "check" },
];
