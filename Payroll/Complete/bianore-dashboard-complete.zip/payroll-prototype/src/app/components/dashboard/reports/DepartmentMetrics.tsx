import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, PieChart, Pie,
} from "recharts";
import { MoreHorizontal, Building2, TrendingUp, AlertTriangle } from "lucide-react";
import { deptMetrics, workforceDistribution } from "./reportsData";

const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";

const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

function CardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="flex items-start justify-between mb-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
        <MoreHorizontal size={15} />
      </button>
    </div>
  );
}

function StarBar({ score }: { score: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <div key={s} className={`h-1.5 w-4 rounded-full ${s <= Math.round(score) ? "bg-amber-400" : "bg-gray-100"}`} />
      ))}
      <span className="ml-1.5 text-[10px] font-bold text-gray-600">{score}</span>
    </div>
  );
}

const RADIAN = Math.PI / 180;
function WorkforcePieLabel({ cx, cy, midAngle, innerRadius, outerRadius, name, value }: any) {
  const pct = ((value / workforceDistribution.reduce((s, d) => s + d.value, 0)) * 100).toFixed(0);
  if (parseInt(pct) < 8) return null;
  const r = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + r * Math.cos(-midAngle * RADIAN);
  const y = cy + r * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={10} fontWeight={700}>
      {pct}%
    </text>
  );
}

const sortedByRate = [...deptMetrics].sort((a, b) => b.attendanceRate - a.attendanceRate);
const sortedByLate = [...deptMetrics].sort((a, b) => b.lateRate - a.lateRate);

export function DepartmentMetrics() {
  return (
    <div className="space-y-5">
      {/* Summary Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Departments", value: deptMetrics.length, sub: "Active divisions" },
          { label: "Total Headcount", value: deptMetrics.reduce((s, d) => s + d.headcount, 0), sub: "Across all depts" },
          { label: "Best Attendance", value: "Executive", sub: "100% attendance rate" },
          { label: "Needs Attention", value: "Marketing", sub: "8.4% late rate" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-center gap-1.5 mb-1">
              <Building2 size={12} className="text-gray-400" />
              <p className="text-[10px] text-gray-400">{s.label}</p>
            </div>
            <p className="text-xl font-bold text-gray-900">{s.value}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{s.sub}</p>
          </div>
        ))}
      </div>

      {/* Attendance Rate + Workforce Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Attendance Rate by Dept */}
        <div className={`${cardClass} lg:col-span-2`}>
          <CardHeader title="Attendance Rate by Department" subtitle="April 2026 · sorted by rate" />
          <div className="space-y-3">
            {sortedByRate.map((d) => {
              const isLow = d.attendanceRate < 92;
              return (
                <div key={d.dept} className="flex items-center gap-3">
                  <div className="w-24 text-xs font-medium text-gray-600 text-right flex-shrink-0">{d.dept}</div>
                  <div className="flex-1 h-7 bg-gray-100 rounded-lg overflow-hidden">
                    <div
                      className="h-full rounded-lg flex items-center px-2 transition-all duration-500"
                      style={{ width: `${d.attendanceRate}%`, backgroundColor: d.color, opacity: isLow ? 0.75 : 1 }}
                    >
                      <span className="text-[9px] text-white font-bold">{d.attendanceRate}%</span>
                    </div>
                  </div>
                  <div className="w-20 flex-shrink-0 text-right">
                    <p className="text-xs font-bold text-gray-800">{d.headcount} emp</p>
                    {isLow && (
                      <p className="text-[9px] text-red-500 flex items-center gap-0.5 justify-end">
                        <AlertTriangle size={8} /> Below avg
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center gap-2 text-xs text-gray-400">
            <div className="w-3 h-3 rounded bg-red-200 flex-shrink-0" /> Below 92%: attention needed
            <div className="w-3 h-3 rounded bg-green-400 flex-shrink-0 ml-3" /> 95%+: excellent
          </div>
        </div>

        {/* Workforce Distribution */}
        <div className={cardClass}>
          <CardHeader title="Workforce Distribution" subtitle="By employment type" />
          <div className="flex flex-col items-center">
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={workforceDistribution} cx="50%" cy="50%" innerRadius={40} outerRadius={72}
                  dataKey="value" labelLine={false} label={WorkforcePieLabel}>
                  {workforceDistribution.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 w-full mt-2">
              {workforceDistribution.map((d) => (
                <div key={d.name} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: d.fill }} />
                  <span className="text-xs text-gray-600 flex-1">{d.name}</span>
                  <span className="text-xs font-bold text-gray-800">{d.value}</span>
                  <span className="text-[10px] text-gray-400">
                    {Math.round((d.value / workforceDistribution.reduce((s, dd) => s + dd.value, 0)) * 100)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Dept Comparison Table */}
      <div className={cardClass}>
        <CardHeader title="Department Comparison Matrix" subtitle="Attendance · Payroll · Performance — April 2026" />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px]">
            <thead>
              <tr className="border-b border-gray-100">
                {["Department", "Headcount", "Attendance Rate", "Late Rate", "Avg Net Salary", "OT Hours", "Total Payroll", "Performance"].map((col) => (
                  <th key={col} className="text-left pb-3 pr-4">
                    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedByRate.map((d, idx) => (
                <tr key={d.dept} className={`border-b border-gray-50 hover:bg-gray-50/60 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: d.color }} />
                      <span className="text-xs font-semibold text-gray-800">{d.dept}</span>
                    </div>
                  </td>
                  <td className="py-3 pr-4">
                    <span className="text-xs text-gray-600">{d.headcount}</span>
                  </td>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-1.5">
                      <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${d.attendanceRate}%`, backgroundColor: d.color }} />
                      </div>
                      <span className={`text-xs font-bold ${d.attendanceRate >= 95 ? "text-green-600" : d.attendanceRate >= 90 ? "text-yellow-600" : "text-red-500"}`}>
                        {d.attendanceRate}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3 pr-4">
                    <span className={`text-xs font-semibold ${d.lateRate > 6 ? "text-red-500" : d.lateRate > 4 ? "text-yellow-600" : "text-green-600"}`}>
                      {d.lateRate}%
                    </span>
                  </td>
                  <td className="py-3 pr-4">
                    <span className="text-xs text-gray-700">{fmt(d.avgNetSalary)}</span>
                  </td>
                  <td className="py-3 pr-4">
                    <span className={`text-xs font-semibold ${d.overtimeHours > 20 ? "text-purple-600" : "text-gray-600"}`}>
                      {d.overtimeHours}h
                    </span>
                  </td>
                  <td className="py-3 pr-4">
                    <span className="text-xs text-gray-700">{fmt(d.totalPayroll)}</span>
                  </td>
                  <td className="py-3">
                    <StarBar score={d.performanceScore} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Late Rate Comparison */}
      <div className={cardClass}>
        <CardHeader title="Late Rate by Department" subtitle="% of scheduled shifts arriving late" />
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={sortedByLate} barSize={28} layout="horizontal">
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
            <XAxis dataKey="dept" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={28} tickFormatter={(v) => `${v}%`} />
            <Tooltip {...tooltipStyle} formatter={(v) => [`${v}%`, "Late Rate"]} />
            <Bar id="dept-late-rate" dataKey="lateRate" name="Late Rate" radius={[4, 4, 0, 0]}>
              {sortedByLate.map((entry, i) => (
                <Cell key={i} fill={entry.lateRate > 6 ? "#ef4444" : entry.lateRate > 4 ? "#f59e0b" : "#10b981"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="flex items-center gap-4 mt-3 text-[10px]">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500 inline-block" /> &lt;4%: healthy</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-500 inline-block" /> 4–6%: monitor</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500 inline-block" /> &gt;6%: action needed</span>
        </div>
      </div>
    </div>
  );
}
