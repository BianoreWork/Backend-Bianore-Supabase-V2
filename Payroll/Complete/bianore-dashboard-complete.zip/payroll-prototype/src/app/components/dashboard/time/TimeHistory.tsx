import { useState } from "react";
import { motion } from "motion/react";
import { Search, Download } from "lucide-react";
import { leaveRequests, correctionRequests, overtimeRequests, statusConfig, leaveTypeConfig } from "./timeMockData";

const EASE = [0.22, 1, 0.36, 1] as const;

// Merge all requests into one unified history list
const allHistory = [
  ...leaveRequests.map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept, branch: r.branch,
    category: "Leave", type: r.type, status: r.status,
    date: r.startDate, submittedAt: r.submittedAt, approver: r.approver,
    detail: `${r.startDate}${r.startDate !== r.endDate ? ` → ${r.endDate}` : ""} · ${r.duration} day${r.duration > 1 ? "s" : ""}`,
  })),
  ...correctionRequests.map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept, branch: r.branch,
    category: "Correction", type: r.correctionType, status: r.status,
    date: r.attendanceDate, submittedAt: r.submittedAt, approver: r.approver,
    detail: r.correctionType,
  })),
  ...overtimeRequests.map(r => ({
    id: r.id, employee: r.employee, avatar: r.avatar, dept: r.dept, branch: r.branch,
    category: "Overtime", type: r.overtimeType, status: r.status,
    date: r.overtimeDate, submittedAt: r.submittedAt, approver: r.approver,
    detail: `${r.overtimeStart}–${r.overtimeEnd} · ${r.duration}h`,
  })),
].sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));

const categoryPill: Record<string, string> = {
  Leave:      "bg-blue-50 text-blue-700 border border-blue-200",
  Correction: "bg-teal-50 text-teal-700 border border-teal-200",
  Overtime:   "bg-purple-50 text-purple-700 border border-purple-200",
};

const categoryAvatar: Record<string, string> = {
  Leave:      "from-blue-500 to-indigo-600",
  Correction: "from-teal-500 to-emerald-600",
  Overtime:   "from-purple-500 to-violet-600",
};

export function TimeHistory() {
  const [search, setSearch]         = useState("");
  const [filterCat, setFilterCat]   = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const filtered = allHistory.filter(r => {
    const matchSearch = !search || r.employee.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase());
    const matchCat    = filterCat    === "all" || r.category === filterCat;
    const matchStatus = filterStatus === "all" || r.status   === filterStatus;
    return matchSearch && matchCat && matchStatus;
  });

  // Stats
  const stats = {
    total:    allHistory.length,
    approved: allHistory.filter(r => r.status === "approved").length,
    rejected: allHistory.filter(r => r.status === "rejected").length,
    pending:  allHistory.filter(r => r.status === "pending").length,
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
      className="space-y-4"
    >
      {/* Summary strip */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total Requests", value: stats.total,    color: "text-gray-800",   bg: "bg-white border border-gray-100" },
          { label: "Approved",       value: stats.approved, color: "text-green-700",  bg: "bg-green-50" },
          { label: "Pending",        value: stats.pending,  color: "text-amber-700",  bg: "bg-amber-50" },
          { label: "Rejected",       value: stats.rejected, color: "text-red-700",    bg: "bg-red-50" },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl px-4 py-3 shadow-sm`}>
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search employee or ID…"
            className="w-full pl-8 pr-4 py-2 text-xs bg-white border border-gray-200 rounded-xl outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400"/>
        </div>
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)}
          className="text-xs bg-white border border-gray-200 rounded-xl px-3 py-2 outline-none cursor-pointer text-gray-700">
          <option value="all">All Categories</option>
          <option value="Leave">Leave</option>
          <option value="Correction">Correction</option>
          <option value="Overtime">Overtime</option>
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="text-xs bg-white border border-gray-200 rounded-xl px-3 py-2 outline-none cursor-pointer text-gray-700">
          <option value="all">All Statuses</option>
          {(["pending","approved","rejected","draft","cancelled","needs_revision"] as const).map(s => (
            <option key={s} value={s}>{statusConfig[s].label}</option>
          ))}
        </select>
        <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 rounded-xl cursor-pointer transition-all ml-auto">
          <Download size={12}/> Export
        </button>
      </div>

      <p className="text-xs text-gray-400">{filtered.length} records total</p>

      {/* History Table */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {["Employee", "ID", "Category", "Type / Detail", "Date", "Status", "Approver", "Submitted"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-sm text-gray-400">No records found.</td></tr>
              ) : filtered.map(r => {
                const sc = statusConfig[r.status as keyof typeof statusConfig];
                return (
                  <tr key={r.id} className="hover:bg-gray-50 transition-colors cursor-pointer">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${categoryAvatar[r.category]} flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0`}>{r.avatar}</div>
                        <div>
                          <p className="font-semibold text-gray-800">{r.employee}</p>
                          <p className="text-[10px] text-gray-400">{r.dept}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-gray-500">{r.id}</td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${categoryPill[r.category]}`}>{r.category}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-600 max-w-[160px]">
                      <p className="font-medium text-gray-700 truncate">{r.type}</p>
                      <p className="text-[10px] text-gray-400 truncate">{r.detail}</p>
                    </td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.date}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${sc.dot}`}/>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${sc.pill}`}>{sc.label}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-500">{r.approver}</td>
                    <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{r.submittedAt.split(" ")[0]}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
