import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LayoutGrid, CalendarDays, ClipboardEdit, Timer, History, Plus } from "lucide-react";
import { TimeOverview } from "./TimeOverview";
import { TimeOff } from "./TimeOff";
import { AttendanceCorrections } from "./AttendanceCorrections";
import { OvertimeRequests } from "./OvertimeRequests";
import { TimeHistory } from "./TimeHistory";
import { NewRequestFormDrawer } from "./NewRequestFormDrawer";

const EASE = [0.22, 1, 0.36, 1] as const;

type TabId = "overview" | "time-off" | "corrections" | "overtime" | "history";

const tabs: { id: TabId; label: string; icon: React.ReactNode; badge?: number }[] = [
  { id: "overview",     label: "Overview",                icon: <LayoutGrid size={14}/>,     badge: 23 },
  { id: "time-off",     label: "Time Off",                icon: <CalendarDays size={14}/>,   badge: 9  },
  { id: "corrections",  label: "Attendance Corrections",   icon: <ClipboardEdit size={14}/>,  badge: 7  },
  { id: "overtime",     label: "Overtime",                icon: <Timer size={14}/>,           badge: 3  },
  { id: "history",      label: "History",                 icon: <History size={14}/>               },
];

export function TimePage() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [formOpen, setFormOpen]   = useState(false);

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5">

      {/* Page header */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.10, ease: EASE }}
        className="flex items-start justify-between gap-4 flex-wrap mb-5"
      >
        <div>
          <h1 className="text-xl font-bold text-gray-900">Time Management</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Leave requests, attendance corrections, and overtime — all in one place
          </p>
        </div>
        <button
          onClick={() => setFormOpen(true)}
          className="flex items-center gap-2 text-sm font-bold px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer transition-colors shadow-sm hover:shadow-md">
          <Plus size={15}/> New Request
        </button>
      </motion.div>

      {/* Tab navigation */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.38, delay: 0.18, ease: EASE }}
        className="flex items-center gap-0 bg-white border border-gray-100 rounded-2xl p-1 mb-5 overflow-x-auto shadow-sm"
      >
        {tabs.map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-all flex-shrink-0 ${
                isActive
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-gray-500 hover:bg-gray-50 hover:text-gray-700"
              }`}
            >
              <span className={isActive ? "text-white" : "text-gray-400"}>{tab.icon}</span>
              {tab.label}
              {tab.badge !== undefined && (
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                  isActive ? "bg-white/20 text-white" : "bg-amber-100 text-amber-700"
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </motion.div>

      {/* Tab content — animate on tab switch */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
        >
          {activeTab === "overview"    && <TimeOverview />}
          {activeTab === "time-off"    && <TimeOff />}
          {activeTab === "corrections" && <AttendanceCorrections />}
          {activeTab === "overtime"    && <OvertimeRequests />}
          {activeTab === "history"     && <TimeHistory />}
        </motion.div>
      </AnimatePresence>

      <div className="h-6"/>

      <NewRequestFormDrawer isOpen={formOpen} onClose={() => setFormOpen(false)}/>
    </main>
  );
}