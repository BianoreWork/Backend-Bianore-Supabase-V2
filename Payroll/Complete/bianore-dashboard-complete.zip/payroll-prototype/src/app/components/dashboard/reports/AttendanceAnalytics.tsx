import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Users, Clock, UserX, MoreHorizontal, TrendingDown } from "lucide-react";
import { dailyTrend, heatmapData, lateByDow, topLateEmployees } from "./reportsData";

const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";

const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

function CardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="flex items-start justify-between mb-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
        <MoreHorizontal size={15} />
      </button>
    </div>
  );
}

function heatColor(rate: number): string {
  if (rate >= 98) return "bg-green-500 text-white";
  if (rate >= 95) return "bg-green-300 text-green-900";
  if (rate >= 92) return "bg-green-100 text-green-800";
  if (rate >= 88) return "bg-yellow-200 text-yellow-800";
  return "bg-red-200 text-red-800";
}

interface AttendanceAnalyticsProps {
  onDrillDown: (title: string, data: { name: string; dept: string; lates: number; absences: number; impact: string }[]) => void;
}

export function AttendanceAnalytics({ onDrillDown }: AttendanceAnalyticsProps) {
  const weeks = [1, 2, 3, 4, 5];
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];

  const avgRate = (dailyTrend.reduce((s, d) => s + d.rate, 0) / dailyTrend.length).toFixed(1);
  const totalLate = dailyTrend.reduce((s, d) => s + d.late, 0);
  const totalAbsent = dailyTrend.reduce((s, d) => s + d.absent, 0);

  return (
    <div className="space-y-5">
      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Avg Attendance Rate", value: `${avgRate}%`, sub: "April 2026", icon: <Users size={15} />, color: "bg-green-50 text-green-600" },
          { label: "Total Late Incidents", value: totalLate, sub: "Across all workdays", icon: <Clock size={15} />, color: "bg-yellow-50 text-yellow-600" },
          { label: "Total Absent Days", value: totalAbsent, sub: "Across all workdays", icon: <UserX size={15} />, color: "bg-red-50 text-red-500" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${s.color}`}>{s.icon}</div>
            <div>
              <p className="text-xl font-bold text-gray-900">{s.value}</p>
              <p className="text-[10px] text-gray-400">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Daily Trend + Late by Day */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Daily Attendance Trend (2/3 width) */}
        <div className={`${cardClass} lg:col-span-2`}>
          <CardHeader title="Daily Attendance Trend" subtitle="Present · Late · Absent — April 2026" />
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={dailyTrend}>
              <defs>
                <linearGradient id="attPresent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="attLate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false}
                interval={3} />
              <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={32} />
              <Tooltip {...tooltipStyle} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
              <Area id="att-present" type="monotone" dataKey="present" name="Present" stroke="#3b82f6" strokeWidth={2} fill="url(#attPresent)" />
              <Area id="att-late" type="monotone" dataKey="late" name="Late" stroke="#f59e0b" strokeWidth={1.5} fill="url(#attLate)" />
              <Area id="att-absent" type="monotone" dataKey="absent" name="Absent" stroke="#ef4444" strokeWidth={1.5} fill="transparent" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Late by Day of Week (1/3 width) */}
        <div className={cardClass}>
          <CardHeader title="Late by Weekday" subtitle="Total incidents · April" />
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={lateByDow} barSize={18}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={24} />
              <Tooltip {...tooltipStyle} />
              <Bar id="dow-lates" dataKey="lates" name="Late" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Bar id="dow-abs" dataKey="absences" name="Absent" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Attendance Heatmap + Top Issues */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Heatmap (2/3 width) */}
        <div className={`${cardClass} lg:col-span-2`}>
          <CardHeader title="Attendance Heatmap" subtitle="5-week calendar view · attendance rate %" />
          <div className="overflow-x-auto">
            <div className="min-w-[400px]">
              {/* Day headers */}
              <div className="grid grid-cols-6 gap-1.5 mb-1.5">
                <div />
                {days.map((d) => (
                  <div key={d} className="text-center text-[10px] font-semibold text-gray-400 pb-1">{d}</div>
                ))}
              </div>
              {/* Weeks */}
              {weeks.map((w) => (
                <div key={w} className="grid grid-cols-6 gap-1.5 mb-1.5">
                  <div className="flex items-center text-[9px] font-semibold text-gray-400 pr-1">Wk {w}</div>
                  {days.map((d) => {
                    const cell = heatmapData.find((c) => c.week === w && c.day === d);
                    if (!cell) return <div key={d} className="h-12 rounded-lg bg-gray-50" />;
                    return (
                      <div
                        key={d}
                        title={`${cell.date} · ${cell.rate}% · ${cell.present} present · ${cell.late} late`}
                        onClick={() => onDrillDown(`${cell.date} Attendance`, topLateEmployees)}
                        className={`h-12 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:ring-2 hover:ring-blue-300 hover:scale-105 transition-all ${heatColor(cell.rate)}`}
                      >
                        <p className="text-[9px] font-medium opacity-70">{cell.date.split(" ")[1]}</p>
                        <p className="text-[11px] font-bold">{cell.rate}%</p>
                      </div>
                    );
                  })}
                </div>
              ))}
              {/* Legend */}
              <div className="flex items-center gap-2 mt-3 justify-end">
                <span className="text-[9px] text-gray-400">Low</span>
                {["bg-red-200", "bg-yellow-200", "bg-green-100", "bg-green-300", "bg-green-500"].map((c, i) => (
                  <div key={i} className={`w-4 h-3 rounded-sm ${c}`} />
                ))}
                <span className="text-[9px] text-gray-400">High</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top Late Employees (1/3 width) */}
        <div className={cardClass}>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-800">Top Issues</h3>
              <p className="text-xs text-gray-400 mt-0.5">Late & absent employees</p>
            </div>
            <button
              onClick={() => onDrillDown("Late & Absent Employees — April 2026", topLateEmployees)}
              className="text-[10px] text-blue-600 hover:text-blue-800 font-medium cursor-pointer"
            >
              View all →
            </button>
          </div>
          <div className="space-y-2">
            {topLateEmployees.map((emp, i) => (
              <div key={i} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => onDrillDown(`${emp.name} — April Detail`, topLateEmployees)}>
                <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-[9px] font-bold text-gray-500 flex-shrink-0">
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-gray-800 truncate">{emp.name}</p>
                  <p className="text-[10px] text-gray-400">{emp.dept}</p>
                </div>
                <div className="text-right">
                  {emp.lates > 0 && <p className="text-xs font-bold text-yellow-600">{emp.lates}× late</p>}
                  {emp.absences > 0 && <p className="text-xs font-bold text-red-500">{emp.absences}× absent</p>}
                  <p className="text-[10px] text-gray-400">{emp.impact}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center gap-1.5 text-xs text-red-600">
            <TrendingDown size={12} />
            <span className="font-medium">$1,505 total deductions</span>
          </div>
        </div>
      </div>
    </div>
  );
}
