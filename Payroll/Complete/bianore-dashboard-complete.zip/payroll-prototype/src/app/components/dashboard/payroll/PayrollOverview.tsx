import { useState } from "react";
import {
  DollarSign, Users, Clock, Zap, MinusCircle,
  TrendingUp, TrendingDown, Minus, CheckCircle,
  AlertTriangle, Bell, Download, Play, MoreHorizontal,
  ChevronRight, RefreshCw, FileText,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend, BarChart, Bar,
} from "recharts";
import {
  payrollRuns, payrollIssues, monthlyTrendIDR, deptCostsIDR,
  fmtIDRShort, fmtIDR,
  type PayrollRunStatus,
} from "./payrollMockData";

type SubPage = "overview" | "runs" | "components" | "employees"
  | "payslips" | "bpjs" | "tax" | "payment" | "reports" | "settings";

interface Props { onNavigate: (page: SubPage) => void }

const runStatusConfig: Record<PayrollRunStatus, { bg: string; text: string; dot: string; label: string }> = {
  draft:              { bg: "bg-gray-100",   text: "text-gray-600",   dot: "bg-gray-400",   label: "Draft" },
  calculating:        { bg: "bg-sky-50",     text: "text-sky-700",    dot: "bg-sky-400",    label: "Menghitung" },
  calculated:         { bg: "bg-blue-50",    text: "text-blue-700",   dot: "bg-blue-400",   label: "Terhitung" },
  pending_approval:   { bg: "bg-amber-50",   text: "text-amber-700",  dot: "bg-amber-500",  label: "Menunggu Approval" },
  approved:           { bg: "bg-violet-50",  text: "text-violet-700", dot: "bg-violet-500", label: "Disetujui" },
  payment_processing: { bg: "bg-indigo-50",  text: "text-indigo-700", dot: "bg-indigo-500", label: "Proses Bayar" },
  paid:               { bg: "bg-green-50",   text: "text-green-700",  dot: "bg-green-500",  label: "Lunas" },
  partially_paid:     { bg: "bg-orange-50",  text: "text-orange-700", dot: "bg-orange-500", label: "Sebagian Lunas" },
  failed:             { bg: "bg-red-50",     text: "text-red-600",    dot: "bg-red-500",    label: "Gagal" },
  cancelled:          { bg: "bg-gray-100",   text: "text-gray-500",   dot: "bg-gray-400",   label: "Dibatalkan" },
};

const typeLabel: Record<string, string> = {
  monthly: "Bulanan", bonus: "Bonus", thr: "THR",
  correction: "Koreksi", final: "Final",
};

const typeColor: Record<string, string> = {
  monthly:    "bg-blue-50 text-blue-700",
  bonus:      "bg-green-50 text-green-700",
  thr:        "bg-amber-50 text-amber-700",
  correction: "bg-orange-50 text-orange-700",
  final:      "bg-gray-100 text-gray-600",
};

const deptColors: Record<string, string> = {
  Engineering: "#3b82f6", Sales: "#10b981", Operations: "#f59e0b",
  Finance: "#06b6d4",     Marketing: "#ec4899", HR: "#8b5cf6",
};

const tooltipStyle = {
  contentStyle: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px", fontSize: "11px", padding: "8px 12px" },
  cursor: { fill: "rgba(59,130,246,0.05)" },
};

const kpis = [
  { id: "total", label: "Total Payroll (Mei)", value: fmtIDRShort(4_820_000_000), trendPct: "+1.5%", trendType: "up" as const, trendLabel: "vs April", icon: DollarSign, color: "blue" },
  { id: "paid",  label: "Karyawan Dibayar",   value: "283",                        trendPct: "+1.4%", trendType: "up" as const, trendLabel: "dari 287 total", icon: Users, color: "green" },
  { id: "pending", label: "Menunggu Approval", value: "11",                         trendPct: "-3",    trendType: "up" as const, trendLabel: "run ini", icon: Clock, color: "yellow" },
  { id: "deduction", label: "Total Potongan",  value: fmtIDRShort(380_250_000),    trendPct: "+2.2%", trendType: "down" as const, trendLabel: "vs bulan lalu", icon: MinusCircle, color: "red" },
  { id: "overtime",  label: "Biaya Lembur",   value: fmtIDRShort(235_000_000),    trendPct: "+4.9%", trendType: "down" as const, trendLabel: "bulan ini", icon: Zap, color: "purple" },
];

const colorMap: Record<string, { bg: string; icon: string }> = {
  blue:   { bg: "bg-blue-50",   icon: "text-blue-600" },
  green:  { bg: "bg-green-50",  icon: "text-green-600" },
  yellow: { bg: "bg-yellow-50", icon: "text-yellow-600" },
  red:    { bg: "bg-red-50",    icon: "text-red-500" },
  purple: { bg: "bg-purple-50", icon: "text-purple-600" },
};

const processSteps = [
  { label: "Draft",    desc: "Data awal" },
  { label: "Review",   desc: "Verifikasi HR" },
  { label: "Hitung",   desc: "Kalkulasi" },
  { label: "Approval", desc: "Multi-level" },
  { label: "Bayar",    desc: "Disbursement" },
];
const currentProcessStep = 3;

export function PayrollOverview({ onNavigate }: Props) {
  const [_ignored] = useState(null);
  const latestRuns = payrollRuns.slice(0, 5);
  const totalIDR = monthlyTrendIDR.filter(m => m.total > 0);

  return (
    <main className="px-6 py-5 space-y-5">
      {/* ── PAGE HEADER ── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Payroll Overview</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Ringkasan payroll, status run, dan analitik periode Mei 2025
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
            <Download size={13} className="text-gray-400" />
            Export
          </button>
          <button
            onClick={() => onNavigate("runs")}
            className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors cursor-pointer"
          >
            <Play size={12} />
            Buat Payroll Run
          </button>
        </div>
      </div>

      {/* ── PROCESS STEPPER ── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm font-semibold text-gray-800">Proses Payroll — Mei 2025</p>
            <p className="text-xs text-gray-400 mt-0.5">
              Step saat ini:{" "}
              <span className="text-blue-600 font-semibold">{processSteps[currentProcessStep].label}</span>
            </p>
          </div>
          <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200 animate-pulse">
            Menunggu Approval
          </span>
        </div>
        <div className="flex items-center gap-0">
          {processSteps.map((step, idx) => {
            const isDone    = idx < currentProcessStep;
            const isCurrent = idx === currentProcessStep;
            return (
              <div key={step.label} className="flex items-center flex-1 last:flex-none">
                <div className="flex flex-col items-center gap-1.5">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isDone    ? "bg-blue-600 text-white"
                    : isCurrent ? "bg-amber-500 text-white ring-4 ring-amber-100"
                    : "bg-gray-100 text-gray-400"
                  }`}>
                    {isDone ? <CheckCircle size={15} /> : idx + 1}
                  </div>
                  <div className="text-center">
                    <p className={`text-[11px] font-semibold whitespace-nowrap ${isCurrent ? "text-amber-700" : isDone ? "text-gray-700" : "text-gray-400"}`}>
                      {step.label}
                    </p>
                    <p className="text-[9px] text-gray-400 whitespace-nowrap hidden sm:block">{step.desc}</p>
                  </div>
                </div>
                {idx < processSteps.length - 1 && (
                  <div className={`flex-1 h-0.5 mb-5 mx-1 ${isDone ? "bg-blue-600" : "bg-gray-200"}`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── KPI CARDS ── */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((card) => {
          const colors = colorMap[card.color];
          const isUp      = card.trendType === "up";
          const isNeutral = card.trendPct.startsWith("-") && card.trendType === "up";
          return (
            <div key={card.id} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all duration-200 cursor-pointer">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-xl ${colors.bg} ${colors.icon} flex items-center justify-center`}>
                  <card.icon size={17} />
                </div>
                <div className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium ${
                  isNeutral ? "bg-gray-100 text-gray-600"
                  : isUp    ? "bg-green-50 text-green-700"
                  : "bg-red-50 text-red-600"
                }`}>
                  {isNeutral ? <Minus size={9} /> : isUp ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
                  <span>{card.trendPct}</span>
                </div>
              </div>
              <p className="text-xl font-bold text-gray-900 tracking-tight">{card.value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{card.label}</p>
              <p className="text-[10px] text-gray-400 mt-1.5">{card.trendLabel}</p>
            </div>
          );
        })}
      </div>

      {/* ── ALERTS ── */}
      <div className="flex items-center gap-2 flex-wrap">
        {payrollIssues.map((issue) => {
          const color =
            issue.type === "error"   ? "bg-red-50 text-red-700 border-red-200" :
            issue.type === "warning" ? "bg-amber-50 text-amber-700 border-amber-200" :
            "bg-blue-50 text-blue-700 border-blue-200";
          const icon =
            issue.type === "error"   ? <AlertTriangle size={11} /> :
            issue.type === "warning" ? <AlertTriangle size={11} /> :
            <Bell size={11} />;
          return (
            <div key={issue.message} className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border cursor-pointer hover:opacity-80 transition-opacity ${color}`}>
              {icon}{issue.message}
            </div>
          );
        })}
      </div>

      {/* ── LATEST RUNS TABLE ── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div>
            <h3 className="text-sm font-semibold text-gray-800">Payroll Runs Terbaru</h3>
            <p className="text-xs text-gray-400 mt-0.5">5 run payroll terakhir</p>
          </div>
          <button
            onClick={() => onNavigate("runs")}
            className="flex items-center gap-1 text-xs text-blue-600 font-medium hover:text-blue-800 cursor-pointer transition-colors"
          >
            Lihat Semua <ChevronRight size={13} />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                {["Kode Run", "Nama", "Tipe", "Periode", "Karyawan", "Total Netto", "Tgl Bayar", "Status", ""].map((col) => (
                  <th key={col} className="text-left px-4 py-3">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {latestRuns.map((run, idx) => {
                const sc = runStatusConfig[run.status];
                const tc = typeColor[run.payrollType];
                return (
                  <tr key={run.id} className={`border-b border-gray-50 hover:bg-blue-50/20 transition-colors cursor-pointer ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-mono font-semibold text-gray-700">{run.runCode}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-medium text-gray-800">{run.runName}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${tc}`}>
                        {typeLabel[run.payrollType]}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-600">
                        {new Date(0, run.month - 1).toLocaleString("id-ID", { month: "long" })} {run.year}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-700 font-medium">{run.totalEmployees > 0 ? run.totalEmployees : "—"}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-bold text-gray-900 tabular-nums">
                        {run.totalNetSalary > 0 ? fmtIDRShort(run.totalNetSalary) : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-500">{run.paymentDate}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <button className="p-1 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 transition-colors">
                        <MoreHorizontal size={14} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── CHARTS ROW ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Monthly Trend */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-800">Tren Payroll Bulanan</h3>
              <p className="text-xs text-gray-400 mt-0.5">5 bulan terakhir · IDR</p>
            </div>
            <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
              <MoreHorizontal size={15} />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={totalIDR}>
              <defs>
                <linearGradient id="payGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1_000_000_000).toFixed(1)}M`} />
              <Tooltip {...tooltipStyle} formatter={(v: number) => [fmtIDR(v), ""]} />
              <Legend wrapperStyle={{ fontSize: "11px" }} />
              <Area type="monotone" dataKey="total" name="Total Payroll" stroke="#3b82f6" strokeWidth={2} fill="url(#payGrad)" dot={{ r: 3, fill: "#3b82f6" }} />
              <Area type="monotone" dataKey="overtime" name="Lembur" stroke="#8b5cf6" strokeWidth={1.5} fill="none" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Dept Cost */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-800">Biaya per Departemen</h3>
              <p className="text-xs text-gray-400 mt-0.5">Mei 2025 · Total payroll</p>
            </div>
            <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
              <MoreHorizontal size={15} />
            </button>
          </div>
          <div className="space-y-3">
            {deptCostsIDR.map((d) => {
              const total = deptCostsIDR.reduce((s, x) => s + x.cost, 0);
              const pct   = Math.round((d.cost / total) * 100);
              const color = deptColors[d.dept] || "#6b7280";
              return (
                <div key={d.dept} className="flex items-center gap-3">
                  <div className="w-24 text-xs text-gray-600 font-medium text-right flex-shrink-0">{d.dept}</div>
                  <div className="flex-1 h-5 bg-gray-100 rounded-lg overflow-hidden">
                    <div
                      className="h-full rounded-lg flex items-center pl-2"
                      style={{ width: `${pct}%`, backgroundColor: color }}
                    >
                      <span className="text-[9px] text-white font-semibold">{pct}%</span>
                    </div>
                  </div>
                  <div className="w-24 text-right flex-shrink-0">
                    <p className="text-xs font-bold text-gray-800">{fmtIDRShort(d.cost)}</p>
                    <p className="text-[9px] text-gray-400">{d.headcount} org</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── QUICK ACTIONS ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Sync Absensi",     icon: RefreshCw, color: "text-blue-600",   bg: "bg-blue-50",   action: () => {} },
          { label: "Generate Payslip", icon: FileText,  color: "text-violet-600", bg: "bg-violet-50", action: () => onNavigate("payslips") },
          { label: "Export BPJS",      icon: Download,  color: "text-teal-600",   bg: "bg-teal-50",   action: () => onNavigate("bpjs") },
          { label: "Export PPh21",     icon: Download,  color: "text-amber-600",  bg: "bg-amber-50",  action: () => onNavigate("tax") },
        ].map((action) => (
          <button
            key={action.label}
            onClick={action.action}
            className="flex items-center gap-3 bg-white rounded-2xl border border-gray-100 shadow-sm px-4 py-3 hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all duration-200 cursor-pointer"
          >
            <div className={`w-8 h-8 rounded-xl ${action.bg} flex items-center justify-center flex-shrink-0`}>
              <action.icon size={15} className={action.color} />
            </div>
            <span className="text-xs font-semibold text-gray-700">{action.label}</span>
          </button>
        ))}
      </div>

      <div className="h-4" />
    </main>
  );
}
