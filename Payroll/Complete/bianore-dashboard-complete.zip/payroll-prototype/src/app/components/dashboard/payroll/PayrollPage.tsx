import { useState } from "react";
import {
  LayoutDashboard, Play, Layers, Users, FileText,
  Shield, Receipt, BarChart2, Settings, CreditCard,
  ChevronRight,
} from "lucide-react";
import { PayrollOverview }       from "./PayrollOverview";
import { PayrollRunsPage }       from "./PayrollRunsPage";
import { SalaryComponentsPage }  from "./SalaryComponentsPage";
import { EmployeePayrollPage }   from "./EmployeePayrollPage";
import { PayslipsPage }          from "./PayslipsPage";
import { BPJSPage }              from "./BPJSPage";
import { TaxPage }               from "./TaxPage";
import { PaymentPage }           from "./PaymentPage";
import { PayrollReportsPage }    from "./PayrollReportsPage";
import { PayrollSettingsPage }   from "./PayrollSettingsPage";

type SubPage =
  | "overview" | "runs" | "components" | "employees"
  | "payslips" | "bpjs" | "tax" | "payment" | "reports" | "settings";

interface NavGroup {
  label: string;
  items: { id: SubPage; label: string; Icon: React.ElementType; badge?: number }[];
}

const navGroups: NavGroup[] = [
  {
    label: "Operasional",
    items: [
      { id: "overview",    label: "Overview",         Icon: LayoutDashboard },
      { id: "runs",        label: "Payroll Runs",     Icon: Play,      badge: 1 },
      { id: "payslips",    label: "Payslip",          Icon: FileText },
      { id: "payment",     label: "Disbursement",     Icon: CreditCard },
    ],
  },
  {
    label: "Setup",
    items: [
      { id: "components",  label: "Komponen Gaji",    Icon: Layers },
      { id: "employees",   label: "Data Payroll Karyawan", Icon: Users },
      { id: "bpjs",        label: "BPJS",             Icon: Shield },
      { id: "tax",         label: "Pajak / PPh21",    Icon: Receipt },
    ],
  },
  {
    label: "Analitik",
    items: [
      { id: "reports",     label: "Laporan",          Icon: BarChart2 },
    ],
  },
  {
    label: "Konfigurasi",
    items: [
      { id: "settings",    label: "Pengaturan",       Icon: Settings },
    ],
  },
];

export function PayrollPage() {
  const [activeSub, setActiveSub] = useState<SubPage>("overview");

  const allItems = navGroups.flatMap((g) => g.items);
  const current  = allItems.find((i) => i.id === activeSub);

  return (
    <div className="flex flex-1 min-h-0 overflow-hidden">
      {/* ── Secondary Sidebar ───────────────────────────────────────────── */}
      <aside className="w-[192px] flex-shrink-0 bg-white border-r border-gray-100 flex flex-col py-3 px-2 overflow-y-auto">
        {/* Header chip */}
        <div className="flex items-center gap-2 px-3 py-2 mb-2">
          <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Receipt size={13} className="text-white" />
          </div>
          <span className="text-xs font-bold text-gray-800">Payroll</span>
        </div>

        {/* Nav groups */}
        <div className="space-y-4">
          {navGroups.map((group) => (
            <div key={group.label}>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest px-3 mb-1">
                {group.label}
              </p>
              <div className="space-y-0.5">
                {group.items.map(({ id, label, Icon, badge }) => {
                  const isActive = activeSub === id;
                  return (
                    <button
                      key={id}
                      onClick={() => setActiveSub(id)}
                      className={`
                        w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left
                        transition-all duration-150 cursor-pointer group
                        ${isActive
                          ? "bg-blue-50 text-blue-700"
                          : "text-gray-500 hover:bg-gray-50 hover:text-gray-700"
                        }
                      `}
                    >
                      <Icon
                        size={15}
                        className={`flex-shrink-0 ${isActive ? "text-blue-600" : "text-gray-400 group-hover:text-gray-600"}`}
                      />
                      <span className={`text-xs font-medium flex-1 ${isActive ? "text-blue-700 font-semibold" : ""}`}>
                        {label}
                      </span>
                      {badge && (
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isActive ? "bg-blue-100 text-blue-700" : "bg-amber-100 text-amber-700"}`}>
                          {badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* ── Content Area ────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto bg-gray-50/40">
        {/* Breadcrumb strip */}
        <div className="flex items-center gap-1.5 px-6 py-2.5 bg-white border-b border-gray-100 text-xs text-gray-400">
          <span>Payroll</span>
          <ChevronRight size={11} />
          <span className="text-gray-700 font-semibold">{current?.label}</span>
        </div>

        {/* Sub-page content */}
        {activeSub === "overview"    && <PayrollOverview onNavigate={setActiveSub} />}
        {activeSub === "runs"        && <PayrollRunsPage />}
        {activeSub === "components"  && <SalaryComponentsPage />}
        {activeSub === "employees"   && <EmployeePayrollPage />}
        {activeSub === "payslips"    && <PayslipsPage />}
        {activeSub === "bpjs"        && <BPJSPage />}
        {activeSub === "tax"         && <TaxPage />}
        {activeSub === "payment"     && <PaymentPage />}
        {activeSub === "reports"     && <PayrollReportsPage />}
        {activeSub === "settings"    && <PayrollSettingsPage />}
      </div>
    </div>
  );
}
