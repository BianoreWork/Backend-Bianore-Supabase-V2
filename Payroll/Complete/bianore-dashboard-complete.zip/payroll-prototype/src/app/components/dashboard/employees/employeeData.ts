export type EmploymentType = "full-time" | "part-time" | "contract" | "intern";
export type EmployeeStatus = "active" | "on-leave" | "resigned" | "terminated";
export type WorkScheduleType = "fixed" | "morning-shift" | "evening-shift" | "flexible" | "remote";
export type AccessRole = "admin" | "hr" | "manager" | "employee";

export interface EmployeeDocument {
  name: string;
  type: "contract" | "id" | "certification" | "other";
  status: "uploaded" | "pending" | "expired";
  date: string;
}

export interface PerformanceReview {
  date: string;
  period: string;
  score: number;
  reviewer: string;
  comment: string;
}

export interface FullEmployee {
  id: number;
  empId: string;
  name: string;
  avatar: string;
  email: string;
  phone: string;
  city: string;
  address: string;
  dept: string;
  role: string;
  managerId: number | null;
  employmentType: EmploymentType;
  status: EmployeeStatus;
  schedule: WorkScheduleType;
  joinDate: string;
  contractEnd: string | null;
  performanceScore: number;
  lastReviewDate: string | null;
  nextReviewDate: string;
  accessRole: AccessRole;
  onboardingStep: number; // 0 = complete, 1-5 = in progress
  documents: EmployeeDocument[];
  reviews: PerformanceReview[];
}

export const workScheduleLabels: Record<WorkScheduleType, { label: string; hours: string; color: string }> = {
  "fixed":          { label: "Fixed 9-5",       hours: "Mon–Fri · 09:00–17:00", color: "bg-blue-50 text-blue-700" },
  "morning-shift":  { label: "Morning Shift",    hours: "Mon–Fri · 07:00–15:00", color: "bg-green-50 text-green-700" },
  "evening-shift":  { label: "Evening Shift",    hours: "Mon–Fri · 15:00–23:00", color: "bg-purple-50 text-purple-700" },
  "flexible":       { label: "Flexible Hours",   hours: "Flexible · 8h/day",     color: "bg-amber-50 text-amber-700" },
  "remote":         { label: "Remote Work",      hours: "Flexible · 8h/day",     color: "bg-cyan-50 text-cyan-700" },
};

export const departments = ["Engineering", "Finance", "HR", "Marketing", "Operations", "Sales", "Executive"];

export const allEmployees: FullEmployee[] = [
  // ── EXECUTIVES & MANAGERS ──
  {
    id: 13, empId: "EMP0013", name: "Robert Chen", avatar: "RC", email: "r.chen@workforce.app",
    phone: "(212) 555-0100", city: "Manhattan, NY", address: "1 World Trade Center, NY",
    dept: "Executive", role: "Chief Executive Officer", managerId: null,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2015-03-01", contractEnd: null, performanceScore: 0, lastReviewDate: null,
    nextReviewDate: "2026-12-01", accessRole: "admin", onboardingStep: 0,
    documents: [
      { name: "Employment Agreement", type: "contract", status: "uploaded", date: "2015-03-01" },
    ],
    reviews: [],
  },
  {
    id: 14, empId: "EMP0014", name: "Alex Kumar", avatar: "AK", email: "a.kumar@workforce.app",
    phone: "(212) 555-0101", city: "Manhattan, NY", address: "45 Park Ave, NY",
    dept: "HR", role: "HR Manager", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2018-06-15", contractEnd: null, performanceScore: 4.6, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "hr", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2018-06-15" },
      { name: "National ID", type: "id", status: "uploaded", date: "2018-06-01" },
      { name: "SHRM Certification", type: "certification", status: "uploaded", date: "2022-09-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.6, reviewer: "Robert Chen", comment: "Exceptional HR leadership and team building." },
      { date: "2025-06-01", period: "Q2 2025", score: 4.4, reviewer: "Robert Chen", comment: "Strong performance across all HR functions." },
    ],
  },
  {
    id: 15, empId: "EMP0015", name: "Lisa Thompson", avatar: "LT", email: "l.thompson@workforce.app",
    phone: "(212) 555-0102", city: "Manhattan, NY", address: "10 Rockefeller Plaza, NY",
    dept: "Finance", role: "Finance Director", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2017-09-01", contractEnd: null, performanceScore: 4.8, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "manager", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2017-09-01" },
      { name: "CPA License", type: "certification", status: "uploaded", date: "2024-01-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.8, reviewer: "Robert Chen", comment: "Outstanding financial oversight and compliance." },
    ],
  },
  {
    id: 16, empId: "EMP0016", name: "Michael Chang", avatar: "MC", email: "m.chang@workforce.app",
    phone: "(212) 555-0103", city: "Brooklyn, NY", address: "500 Atlantic Ave, Brooklyn",
    dept: "Engineering", role: "Engineering Manager", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2019-02-10", contractEnd: null, performanceScore: 4.7, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "manager", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2019-02-10" },
      { name: "AWS Certification", type: "certification", status: "uploaded", date: "2023-05-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.7, reviewer: "Robert Chen", comment: "Strong technical leadership, shipped 3 major features." },
    ],
  },
  {
    id: 17, empId: "EMP0017", name: "Jennifer Lopez", avatar: "JL", email: "j.lopez@workforce.app",
    phone: "(212) 555-0104", city: "Queens, NY", address: "80-02 Kew Gardens Rd, Queens",
    dept: "Sales", role: "Sales Manager", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2020-01-06", contractEnd: null, performanceScore: 4.5, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "manager", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2020-01-06" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.5, reviewer: "Robert Chen", comment: "Exceeded Q4 sales targets by 18%." },
    ],
  },
  {
    id: 18, empId: "EMP0018", name: "James Wilson", avatar: "JW", email: "j.wilson@workforce.app",
    phone: "(212) 555-0105", city: "Bronx, NY", address: "200 E 161st St, Bronx",
    dept: "Operations", role: "Operations Manager", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "morning-shift",
    joinDate: "2016-08-22", contractEnd: null, performanceScore: 4.3, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "manager", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2016-08-22" },
      { name: "PMP Certification", type: "certification", status: "uploaded", date: "2021-03-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.3, reviewer: "Robert Chen", comment: "Solid operational improvements, reduced cost by 12%." },
    ],
  },
  // ── EXISTING TEAM MEMBERS (IDs 1–12 match attendance + payroll) ──
  {
    id: 1, empId: "EMP0001", name: "John Martinez", avatar: "JM", email: "j.martinez@workforce.app",
    phone: "(646) 555-0201", city: "Manhattan, NY", address: "123 Broadway Ave, Manhattan",
    dept: "Engineering", role: "Sr. Software Engineer", managerId: 16,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2021-04-12", contractEnd: null, performanceScore: 4.8, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2021-04-12" },
      { name: "National ID", type: "id", status: "uploaded", date: "2021-04-01" },
      { name: "AWS Certified Developer", type: "certification", status: "uploaded", date: "2023-08-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.8, reviewer: "Michael Chang", comment: "Excellent code quality, mentors junior devs effectively." },
      { date: "2025-06-01", period: "Q2 2025", score: 4.7, reviewer: "Michael Chang", comment: "Led API redesign project to completion ahead of schedule." },
    ],
  },
  {
    id: 2, empId: "EMP0002", name: "Sarah Chen", avatar: "SC", email: "s.chen@workforce.app",
    phone: "(718) 555-0202", city: "Queens, NY", address: "45 Northern Blvd, Queens",
    dept: "Marketing", role: "Marketing Manager", managerId: 13,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2020-07-20", contractEnd: null, performanceScore: 3.2, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-04-01", accessRole: "manager", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2020-07-20" },
      { name: "National ID", type: "id", status: "uploaded", date: "2020-07-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 3.2, reviewer: "Robert Chen", comment: "Attendance issues noted. Campaign results need improvement." },
      { date: "2025-06-01", period: "Q2 2025", score: 3.6, reviewer: "Robert Chen", comment: "Good creative output but punctuality concerns persist." },
    ],
  },
  {
    id: 3, empId: "EMP0003", name: "David Kim", avatar: "DK", email: "d.kim@workforce.app",
    phone: "(212) 555-0203", city: "Manhattan, NY", address: "1500 Broadway, Manhattan",
    dept: "Finance", role: "Senior Accountant", managerId: 15,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2019-11-05", contractEnd: null, performanceScore: 4.5, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2019-11-05" },
      { name: "CPA License", type: "certification", status: "uploaded", date: "2022-01-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.5, reviewer: "Lisa Thompson", comment: "Highly accurate financial reporting, proactive compliance." },
    ],
  },
  {
    id: 4, empId: "EMP0004", name: "Priya Sharma", avatar: "PS", email: "p.sharma@workforce.app",
    phone: "(929) 555-0204", city: "Bronx, NY", address: "821 Grand Concourse, Bronx",
    dept: "HR", role: "HR Specialist", managerId: 14,
    employmentType: "full-time", status: "on-leave", schedule: "fixed",
    joinDate: "2022-02-14", contractEnd: null, performanceScore: 3.8, lastReviewDate: "2025-09-01",
    nextReviewDate: "2026-03-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2022-02-14" },
      { name: "National ID", type: "id", status: "uploaded", date: "2022-02-01" },
    ],
    reviews: [
      { date: "2025-09-01", period: "Q3 2025", score: 3.8, reviewer: "Alex Kumar", comment: "Good HR skills, currently on medical leave." },
    ],
  },
  {
    id: 5, empId: "EMP0005", name: "Mike Torres", avatar: "MT", email: "m.torres@workforce.app",
    phone: "(347) 555-0205", city: "Brooklyn, NY", address: "275 Atlantic Ave, Brooklyn",
    dept: "Operations", role: "Operations Lead", managerId: 18,
    employmentType: "full-time", status: "active", schedule: "morning-shift",
    joinDate: "2020-09-01", contractEnd: null, performanceScore: 4.2, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2020-09-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.2, reviewer: "James Wilson", comment: "Consistently manages overtime and leads floor team well." },
    ],
  },
  {
    id: 6, empId: "EMP0006", name: "Lisa Park", avatar: "LP", email: "l.park@workforce.app",
    phone: "(917) 555-0206", city: "Queens, NY", address: "90-22 Queens Blvd, Queens",
    dept: "Sales", role: "Sales Executive", managerId: 17,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2021-08-16", contractEnd: null, performanceScore: 4.6, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2021-08-16" },
      { name: "Sales Certification", type: "certification", status: "uploaded", date: "2022-06-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.6, reviewer: "Jennifer Lopez", comment: "Top-performing sales exec, exceeded quarterly target." },
    ],
  },
  {
    id: 7, empId: "EMP0007", name: "Omar Faruk", avatar: "OF", email: "o.faruk@workforce.app",
    phone: "(718) 555-0207", city: "Bronx, NY", address: "500 E Fordham Rd, Bronx",
    dept: "Operations", role: "Operations Coordinator", managerId: 5,
    employmentType: "full-time", status: "active", schedule: "morning-shift",
    joinDate: "2023-01-09", contractEnd: null, performanceScore: 3.5, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-03-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2023-01-09" },
      { name: "National ID", type: "id", status: "pending", date: "2023-01-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 3.5, reviewer: "Mike Torres", comment: "Needs improvement on location compliance and accuracy." },
    ],
  },
  {
    id: 8, empId: "EMP0008", name: "Emma Wilson", avatar: "EW", email: "e.wilson@workforce.app",
    phone: "(646) 555-0208", city: "Manhattan, NY", address: "200 West St, Manhattan",
    dept: "Engineering", role: "Software Engineer", managerId: 16,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2022-06-01", contractEnd: null, performanceScore: 4.7, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2022-06-01" },
      { name: "Google Cloud Cert", type: "certification", status: "uploaded", date: "2024-02-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.7, reviewer: "Michael Chang", comment: "Exceptional problem solving and code review quality." },
    ],
  },
  {
    id: 9, empId: "EMP0009", name: "Carlos Rivera", avatar: "CR", email: "c.rivera@workforce.app",
    phone: "(929) 555-0209", city: "Brooklyn, NY", address: "480 Flatbush Ave, Brooklyn",
    dept: "Sales", role: "Sales Representative", managerId: 17,
    employmentType: "contract", status: "active", schedule: "fixed",
    joinDate: "2023-05-22", contractEnd: "2026-05-22", performanceScore: 3.0, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-02-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Contract Agreement", type: "contract", status: "uploaded", date: "2023-05-22" },
      { name: "National ID", type: "id", status: "uploaded", date: "2023-05-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 3.0, reviewer: "Jennifer Lopez", comment: "Punctuality issues impacting team performance. Needs PIP." },
    ],
  },
  {
    id: 10, empId: "EMP0010", name: "Aisha Johnson", avatar: "AJ", email: "a.johnson@workforce.app",
    phone: "(347) 555-0210", city: "Brooklyn, NY", address: "350 Flatbush Ave Ext, Brooklyn",
    dept: "Engineering", role: "Full Stack Developer", managerId: 16,
    employmentType: "full-time", status: "on-leave", schedule: "flexible",
    joinDate: "2022-11-14", contractEnd: null, performanceScore: 4.1, lastReviewDate: "2025-09-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2022-11-14" },
      { name: "React Certification", type: "certification", status: "uploaded", date: "2023-11-01" },
    ],
    reviews: [
      { date: "2025-09-01", period: "Q3 2025", score: 4.1, reviewer: "Michael Chang", comment: "Strong full-stack skills. Currently on personal leave." },
    ],
  },
  {
    id: 11, empId: "EMP0011", name: "Tom Bradley", avatar: "TB", email: "t.bradley@workforce.app",
    phone: "(212) 555-0211", city: "Manhattan, NY", address: "75 Wall St, Manhattan",
    dept: "Finance", role: "Financial Analyst", managerId: 15,
    employmentType: "full-time", status: "active", schedule: "fixed",
    joinDate: "2020-03-02", contractEnd: null, performanceScore: 4.3, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2020-03-02" },
      { name: "CFA Level 1", type: "certification", status: "uploaded", date: "2021-07-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.3, reviewer: "Lisa Thompson", comment: "Excellent financial modeling and reporting accuracy." },
    ],
  },
  {
    id: 12, empId: "EMP0012", name: "Mei Lin", avatar: "ML", email: "m.lin@workforce.app",
    phone: "(917) 555-0212", city: "Queens, NY", address: "136-20 Northern Blvd, Queens",
    dept: "Marketing", role: "Content Strategist", managerId: 2,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2023-03-27", contractEnd: null, performanceScore: 4.0, lastReviewDate: "2025-12-01",
    nextReviewDate: "2026-06-01", accessRole: "employee", onboardingStep: 0,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2023-03-27" },
      { name: "National ID", type: "id", status: "uploaded", date: "2023-03-01" },
    ],
    reviews: [
      { date: "2025-12-01", period: "Q4 2025", score: 4.0, reviewer: "Sarah Chen", comment: "Creative content output, growing SEO performance." },
    ],
  },
  // ── ONBOARDING (New Employees) ──
  {
    id: 19, empId: "EMP0019", name: "Hiroshi Tanaka", avatar: "HT", email: "h.tanaka@workforce.app",
    phone: "(646) 555-0219", city: "Manhattan, NY", address: "—",
    dept: "Engineering", role: "Junior Developer", managerId: 16,
    employmentType: "full-time", status: "active", schedule: "flexible",
    joinDate: "2026-04-28", contractEnd: null, performanceScore: 0, lastReviewDate: null,
    nextReviewDate: "2026-10-01", accessRole: "employee", onboardingStep: 3,
    documents: [
      { name: "Employment Contract", type: "contract", status: "uploaded", date: "2026-04-28" },
      { name: "National ID", type: "id", status: "pending", date: "2026-04-28" },
    ],
    reviews: [],
  },
  {
    id: 20, empId: "EMP0020", name: "Maria Santos", avatar: "MS", email: "m.santos@workforce.app",
    phone: "(929) 555-0220", city: "Brooklyn, NY", address: "—",
    dept: "Sales", role: "Sales Coordinator", managerId: 17,
    employmentType: "contract", status: "active", schedule: "fixed",
    joinDate: "2026-04-30", contractEnd: "2027-04-30", performanceScore: 0, lastReviewDate: null,
    nextReviewDate: "2026-10-01", accessRole: "employee", onboardingStep: 1,
    documents: [],
    reviews: [],
  },
];

export const onboardingStepLabels = [
  "Complete",
  "Add Employee Details",
  "Assign Role & Department",
  "Assign Work Schedule",
  "Upload Documents",
  "System Access Setup",
];

export const contractExpiringSoon = allEmployees.filter(
  (e) => e.contractEnd && new Date(e.contractEnd) <= new Date("2026-06-30") && e.status !== "resigned"
);
