import { useState } from "react";
import {
  Download, RefreshCw, Clock, DollarSign, Users,
  CheckSquare, Square, SlidersHorizontal, ChevronDown, FileText,
} from "lucide-react";
import { builderSources } from "./reportsData";
import { departments, allEmployees } from "../employees/employeeData";
import { employeeLogs } from "../mockData";
import { payrollRecords } from "../payroll/payrollData";

type SourceKey = keyof typeof builderSources;

const sourceIcons: Record<SourceKey, React.ReactNode> = {
  attendance: <Clock size={14} />,
  payroll:    <DollarSign size={14} />,
  employees:  <Users size={14} />,
};

const selectClass = "text-xs text-gray-700 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 appearance-none cursor-pointer w-full";

function buildPreviewData(source: SourceKey, fields: string[], deptFilter: string): Record<string, string>[] {
  if (source === "attendance") {
    let data = employeeLogs;
    if (deptFilter !== "All") data = data.filter((r) => r.dept === deptFilter);
    return data.slice(0, 10).map((r) => {
      const row: Record<string, string> = {};
      if (fields.includes("name"))     row["name"]     = r.name;
      if (fields.includes("dept"))     row["dept"]     = r.dept;
      if (fields.includes("date"))     row["date"]     = "Apr 30, 2026";
      if (fields.includes("checkIn"))  row["checkIn"]  = r.checkIn;
      if (fields.includes("checkOut")) row["checkOut"] = r.checkOut;
      if (fields.includes("status"))   row["status"]   = r.status;
      if (fields.includes("hours"))    row["hours"]    = r.hours;
      return row;
    });
  }
  if (source === "payroll") {
    let data = payrollRecords;
    if (deptFilter !== "All") data = data.filter((r) => r.dept === deptFilter);
    return data.slice(0, 10).map((r) => {
      const row: Record<string, string> = {};
      if (fields.includes("name"))       row["name"]       = r.name;
      if (fields.includes("dept"))       row["dept"]       = r.dept;
      if (fields.includes("baseSalary")) row["baseSalary"] = `$${r.baseSalary.toLocaleString()}`;
      if (fields.includes("netSalary"))  row["netSalary"]  = `$${r.netSalary.toLocaleString()}`;
      if (fields.includes("overtime"))   row["overtime"]   = r.overtime > 0 ? `$${r.overtime.toLocaleString()}` : "—";
      if (fields.includes("tax"))        row["tax"]        = `$${r.tax.toLocaleString()}`;
      if (fields.includes("status"))     row["status"]     = r.status.charAt(0).toUpperCase() + r.status.slice(1);
      return row;
    });
  }
  if (source === "employees") {
    let data = allEmployees;
    if (deptFilter !== "All") data = data.filter((e) => e.dept === deptFilter);
    return data.slice(0, 10).map((e) => {
      const row: Record<string, string> = {};
      if (fields.includes("empId"))            row["empId"]            = e.empId;
      if (fields.includes("name"))             row["name"]             = e.name;
      if (fields.includes("dept"))             row["dept"]             = e.dept;
      if (fields.includes("role"))             row["role"]             = e.role;
      if (fields.includes("employmentType"))   row["employmentType"]   = e.employmentType;
      if (fields.includes("status"))           row["status"]           = e.status;
      if (fields.includes("joinDate"))         row["joinDate"]         = new Date(e.joinDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      if (fields.includes("performanceScore")) row["performanceScore"] = e.performanceScore > 0 ? e.performanceScore.toFixed(1) : "—";
      return row;
    });
  }
  return [];
}

const fieldLabels: Record<string, string> = {
  name: "Employee Name", dept: "Department", date: "Date", checkIn: "Check-in", checkOut: "Check-out",
  status: "Status", hours: "Work Hours", baseSalary: "Base Salary", netSalary: "Net Salary",
  overtime: "Overtime", tax: "Tax", empId: "Employee ID", role: "Role",
  employmentType: "Type", joinDate: "Join Date", performanceScore: "Performance",
};

const statusColors: Record<string, string> = {
  Present: "bg-green-50 text-green-700",   Late: "bg-yellow-50 text-yellow-700",
  Absent: "bg-red-50 text-red-500",        active: "bg-green-50 text-green-700",
  "on-leave": "bg-yellow-50 text-yellow-700", Draft: "bg-gray-100 text-gray-600",
  Pending: "bg-amber-50 text-amber-700",   Approved: "bg-blue-50 text-blue-700",
  Paid: "bg-green-50 text-green-700",      contract: "bg-amber-50 text-amber-700",
  "full-time": "bg-blue-50 text-blue-700", intern: "bg-green-50 text-green-700",
};

export function ReportBuilder() {
  const [source, setSource] = useState<SourceKey>("attendance");
  const [selectedFields, setSelectedFields] = useState<string[]>(
    builderSources.attendance.fields.filter((f) => f.defaultOn).map((f) => f.key)
  );
  const [deptFilter, setDeptFilter] = useState("All");
  const [dateRange, setDateRange] = useState("last-30");
  const [statusFilter, setStatusFilter] = useState("All");
  const [generated, setGenerated] = useState(false);

  const toggleField = (key: string) =>
    setSelectedFields((prev) => prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]);

  const handleSourceChange = (s: SourceKey) => {
    setSource(s);
    setSelectedFields(builderSources[s].fields.filter((f) => f.defaultOn).map((f) => f.key));
    setGenerated(false);
  };

  const previewData = generated ? buildPreviewData(source, selectedFields, deptFilter) : [];
  const activeFields = selectedFields.filter((f) => builderSources[source].fields.some((sf) => sf.key === f));

  return (
    <div className="flex gap-5">
      {/* ── LEFT PANEL: Configuration ── */}
      <div className="w-72 flex-shrink-0 space-y-4">
        {/* Data Source */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-3">Data Source</p>
          <div className="space-y-2">
            {(Object.keys(builderSources) as SourceKey[]).map((key) => {
              const s = builderSources[key];
              return (
                <button key={key} onClick={() => handleSourceChange(key)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition-all cursor-pointer text-left ${
                    source === key ? "border-blue-400 bg-blue-50" : "border-gray-100 hover:border-gray-200 hover:bg-gray-50"
                  }`}>
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${source === key ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500"}`}>
                    {sourceIcons[key]}
                  </div>
                  <div>
                    <p className={`text-xs font-semibold ${source === key ? "text-blue-800" : "text-gray-700"}`}>{s.label}</p>
                    <p className="text-[9px] text-gray-400">{s.fields.length} available fields</p>
                  </div>
                  {source === key && (
                    <div className="ml-auto w-4 h-4 rounded-full bg-blue-600 flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-white" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Fields */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Fields</p>
            <span className="text-[10px] text-blue-600 font-semibold">{selectedFields.length} selected</span>
          </div>
          <div className="space-y-1.5">
            {builderSources[source].fields.map((field) => {
              const checked = selectedFields.includes(field.key);
              return (
                <button key={field.key} onClick={() => toggleField(field.key)}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition-all cursor-pointer ${
                    checked ? "bg-blue-50" : "hover:bg-gray-50"
                  }`}>
                  {checked
                    ? <CheckSquare size={14} className="text-blue-600 flex-shrink-0" />
                    : <Square size={14} className="text-gray-300 flex-shrink-0" />}
                  <span className={`text-xs ${checked ? "font-semibold text-blue-800" : "text-gray-600"}`}>{field.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-3">
          <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
            <SlidersHorizontal size={10} /> Filters
          </p>
          <div>
            <label className="text-[10px] text-gray-400 block mb-1">Date Range</label>
            <div className="relative">
              <select value={dateRange} onChange={(e) => setDateRange(e.target.value)} className={selectClass}>
                <option value="last-7">Last 7 days</option>
                <option value="last-30">Last 30 days</option>
                <option value="last-90">Last 3 months</option>
                <option value="this-year">This year</option>
              </select>
              <ChevronDown size={11} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          </div>
          <div>
            <label className="text-[10px] text-gray-400 block mb-1">Department</label>
            <div className="relative">
              <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className={selectClass}>
                <option value="All">All Departments</option>
                {departments.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
              <ChevronDown size={11} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          </div>
          <div>
            <label className="text-[10px] text-gray-400 block mb-1">Status</label>
            <div className="relative">
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={selectClass}>
                <option value="All">All Statuses</option>
                <option value="active">Active</option>
                <option value="on-leave">On Leave</option>
                <option value="contract">Contract</option>
              </select>
              <ChevronDown size={11} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Generate */}
        <button
          onClick={() => setGenerated(true)}
          disabled={selectedFields.length === 0}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${
            selectedFields.length > 0
              ? "bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg"
              : "bg-gray-100 text-gray-400 cursor-not-allowed"
          }`}
        >
          <RefreshCw size={14} /> Generate Preview
        </button>
      </div>

      {/* ── RIGHT PANEL: Preview ── */}
      <div className="flex-1 min-w-0">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col" style={{ minHeight: 520 }}>
          {/* Preview Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div>
              <p className="text-sm font-semibold text-gray-800">Report Preview</p>
              <p className="text-xs text-gray-400 mt-0.5">
                {builderSources[source].label}
                {generated ? ` · ${previewData.length} rows · ${activeFields.length} fields` : " · Click Generate Preview"}
              </p>
            </div>
            {generated && previewData.length > 0 && (
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer">
                  <Download size={12} /> CSV
                </button>
                <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer">
                  <FileText size={12} /> PDF
                </button>
              </div>
            )}
          </div>

          {/* Content */}
          {!generated ? (
            <div className="flex-1 flex flex-col items-center justify-center py-16 text-center px-8">
              <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-4">
                <RefreshCw size={28} className="text-blue-400" />
              </div>
              <p className="text-sm font-semibold text-gray-700 mb-2">Configure & Generate</p>
              <p className="text-xs text-gray-400 max-w-xs">
                Select a data source, choose your fields, apply filters, then click{" "}
                <span className="font-semibold text-blue-600">Generate Preview</span> to see your report.
              </p>
            </div>
          ) : previewData.length === 0 ? (
            <div className="flex-1 flex items-center justify-center py-16 text-center">
              <p className="text-sm text-gray-400">No data matches the selected filters.</p>
            </div>
          ) : (
            <div className="flex-1 overflow-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50/80 border-b border-gray-100 sticky top-0">
                    <th className="px-4 py-3 text-left w-10">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">#</span>
                    </th>
                    {activeFields.map((f) => (
                      <th key={f} className="px-4 py-3 text-left">
                        <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide">
                          {fieldLabels[f] || f}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.map((row, i) => (
                    <tr key={i} className={`border-b border-gray-50 hover:bg-gray-50/50 transition-colors ${i % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                      <td className="px-4 py-3">
                        <span className="text-[10px] text-gray-400 font-mono">{i + 1}</span>
                      </td>
                      {activeFields.map((f) => {
                        const val = row[f] ?? "—";
                        const isStatus = f === "status" || f === "employmentType";
                        const sc = statusColors[val];
                        return (
                          <td key={f} className="px-4 py-3">
                            {isStatus && sc ? (
                              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md capitalize ${sc}`}>{val}</span>
                            ) : (
                              <span className="text-xs text-gray-700">{val}</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
                <p className="text-xs text-gray-400">
                  Showing <span className="font-semibold text-gray-600">{previewData.length}</span> rows preview ·
                  Full export includes all matching records
                </p>
                <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer flex items-center gap-1">
                  <Download size={11} /> Export All
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
