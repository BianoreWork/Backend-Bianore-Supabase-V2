import { useState } from "react";
import {
  Search, Download, SlidersHorizontal, UserPlus, CalendarDays,
  ChevronDown, ChevronsUpDown, ChevronUp, AlertTriangle,
  CheckCircle, Clock, Users, FileText, Briefcase, Zap,
  MoreHorizontal, Edit2, UserX, Eye, Star,
} from "lucide-react";
import {
  allEmployees, onboardingStepLabels, contractExpiringSoon,
  workScheduleLabels, departments,
  type FullEmployee, type EmployeeStatus,
} from "./employeeData";
import { OrgChart } from "./OrgChart";
import { EmployeeProfileDrawer } from "./EmployeeProfileDrawer";
import { AddEmployeeModal } from "./AddEmployeeModal";

type PageTab = "directory" | "orgchart" | "schedules" | "onboarding";
type SortField = "name" | "dept" | "role" | "joinDate" | "status";
type SortDir = "asc" | "desc" | null;

const statusConfig: Record<EmployeeStatus, { bg: string; text: string; dot: string; label: string }> = {
  "active":     { bg: "bg-green-50",  text: "text-green-700",  dot: "bg-green-500",  label: "Active" },
  "on-leave":   { bg: "bg-yellow-50", text: "text-yellow-700", dot: "bg-yellow-500", label: "On Leave" },
  "resigned":   { bg: "bg-gray-100",  text: "text-gray-500",   dot: "bg-gray-400",   label: "Resigned" },
  "terminated": { bg: "bg-red-50",    text: "text-red-600",    dot: "bg-red-500",    label: "Terminated" },
};

const empTypeColors: Record<string, string> = {
  "full-time": "bg-blue-50 text-blue-700",
  "part-time": "bg-purple-50 text-purple-700",
  "contract":  "bg-amber-50 text-amber-700",
  "intern":    "bg-green-50 text-green-700",
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",   Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",        HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700", Sales: "bg-green-50 text-green-700",
  Executive: "bg-gray-100 text-gray-700",
};

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600",
  "from-amber-500 to-orange-600", "from-cyan-500 to-blue-600",
];

function SortIcon({ field, sortField, sortDir }: { field: SortField; sortField: SortField | null; sortDir: SortDir }) {
  if (sortField !== field) return <ChevronsUpDown size={11} className="text-gray-300" />;
  if (sortDir === "asc") return <ChevronUp size={11} className="text-blue-600" />;
  return <ChevronDown size={11} className="text-blue-600" />;
}

export function EmployeesPage() {
  const [activeTab, setActiveTab] = useState<PageTab>("directory");
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [typeFilter, setTypeFilter] = useState("All");
  const [sortField, setSortField] = useState<SortField | null>(null);
  const [sortDir, setSortDir] = useState<SortDir>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<FullEmployee | null>(null);
  const [addModalOpen, setAddModalOpen] = useState(false);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDir === "asc") setSortDir("desc");
      else if (sortDir === "desc") { setSortDir(null); setSortField(null); }
      else setSortDir("asc");
    } else { setSortField(field); setSortDir("asc"); }
  };

  const filtered = allEmployees
    .filter((e) => {
      const matchSearch =
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.empId.toLowerCase().includes(search.toLowerCase()) ||
        e.role.toLowerCase().includes(search.toLowerCase()) ||
        e.email.toLowerCase().includes(search.toLowerCase());
      const matchDept = deptFilter === "All" || e.dept === deptFilter;
      const matchStatus = statusFilter === "All" || e.status === statusFilter;
      const matchType = typeFilter === "All" || e.employmentType === typeFilter;
      return matchSearch && matchDept && matchStatus && matchType;
    })
    .sort((a, b) => {
      if (!sortField || !sortDir) return 0;
      const aVal = a[sortField as keyof FullEmployee] as string;
      const bVal = b[sortField as keyof FullEmployee] as string;
      return sortDir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    });

  const toggleSelect = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = new Set(selectedIds);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelectedIds(next);
  };
  const toggleAll = () => setSelectedIds(selectedIds.size === filtered.length ? new Set() : new Set(filtered.map((e) => e.id)));

  const handleRowClick = (emp: FullEmployee) => { setSelectedEmployee(emp); setDrawerOpen(true); };

  const counts = {
    total: allEmployees.length,
    active: allEmployees.filter((e) => e.status === "active").length,
    onLeave: allEmployees.filter((e) => e.status === "on-leave").length,
    contract: allEmployees.filter((e) => e.employmentType === "contract").length,
    onboarding: allEmployees.filter((e) => e.onboardingStep > 0).length,
  };

  const onboardingEmployees = allEmployees.filter((e) => e.onboardingStep > 0);
  const scheduleGroups = allEmployees.reduce<Record<string, FullEmployee[]>>((acc, e) => {
    const key = e.schedule;
    if (!acc[key]) acc[key] = [];
    acc[key].push(e);
    return acc;
  }, {});

  const tabs: { id: PageTab; label: string; icon: React.ReactNode }[] = [
    { id: "directory",  label: "Directory",   icon: <Users size={13} /> },
    { id: "orgchart",   label: "Org Chart",   icon: <Briefcase size={13} /> },
    { id: "schedules",  label: "Schedules",   icon: <Clock size={13} /> },
    { id: "onboarding", label: "Onboarding",  icon: <Zap size={13} /> },
  ];

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
      {/* ── PAGE HEADER ── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Employee Directory</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Manage your workforce — connected to Attendance and Payroll systems
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg">
            <CalendarDays size={13} className="text-gray-400" />
            <span>April 2026</span>
          </div>
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
            <Download size={13} className="text-gray-400" /> Export
          </button>
          <button
            onClick={() => setAddModalOpen(true)}
            className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors cursor-pointer"
          >
            <UserPlus size={13} /> Add Employee
          </button>
        </div>
      </div>

      {/* ── STATS STRIP ── */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: "Total Employees", value: counts.total, icon: <Users size={15} />, color: "text-blue-600 bg-blue-50" },
          { label: "Active", value: counts.active, icon: <CheckCircle size={15} />, color: "text-green-600 bg-green-50" },
          { label: "On Leave", value: counts.onLeave, icon: <Clock size={15} />, color: "text-yellow-600 bg-yellow-50" },
          { label: "Contract", value: counts.contract, icon: <FileText size={15} />, color: "text-amber-600 bg-amber-50" },
          { label: "Onboarding", value: counts.onboarding, icon: <Zap size={15} />, color: "text-purple-600 bg-purple-50" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${s.color}`}>
              {s.icon}
            </div>
            <div>
              <p className="text-lg font-bold text-gray-900">{s.value}</p>
              <p className="text-[10px] text-gray-400">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── ALERTS ── */}
      <div className="flex items-center gap-3 flex-wrap">
        {contractExpiringSoon.length > 0 && (
          <div className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border bg-amber-50 text-amber-700 border-amber-200 cursor-pointer hover:opacity-80 transition-opacity">
            <AlertTriangle size={11} />
            {contractExpiringSoon.length} contract{contractExpiringSoon.length > 1 ? "s" : ""} expiring within 90 days
          </div>
        )}
        {counts.onboarding > 0 && (
          <div className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border bg-purple-50 text-purple-700 border-purple-200 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setActiveTab("onboarding")}>
            <Zap size={11} />
            {counts.onboarding} employee{counts.onboarding > 1 ? "s" : ""} in onboarding
          </div>
        )}
        {counts.onLeave > 0 && (
          <div className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border bg-yellow-50 text-yellow-700 border-yellow-200 cursor-pointer hover:opacity-80 transition-opacity">
            <Clock size={11} />
            {counts.onLeave} employee{counts.onLeave > 1 ? "s" : ""} currently on leave
          </div>
        )}
      </div>

      {/* ── TABS ── */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* ══════════════════ DIRECTORY TAB ══════════════════ */}
      {activeTab === "directory" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {/* Toolbar */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Status filter tabs */}
              <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
                {["All", "active", "on-leave", "contract"].map((s) => (
                  <button key={s} onClick={() => setStatusFilter(s)}
                    className={`text-xs px-2.5 py-1.5 rounded-md transition-all cursor-pointer font-medium capitalize whitespace-nowrap ${
                      statusFilter === s ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
                    }`}>
                    {s === "All" ? "All" : s.replace("-", " ")}
                  </button>
                ))}
              </div>

              {/* Dept filter */}
              <div className="relative">
                <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}
                  className="text-xs text-gray-600 bg-white border border-gray-200 rounded-lg pl-3 pr-7 py-2 outline-none focus:border-blue-400 appearance-none cursor-pointer">
                  <option value="All">All Depts</option>
                  {departments.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
                <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              {selectedIds.size > 0 && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg">
                  <span className="text-xs font-semibold text-blue-700">{selectedIds.size} selected</span>
                  <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Assign Role</button>
                  <span className="text-blue-300">·</span>
                  <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Export</button>
                </div>
              )}
              <div className="relative">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input type="text" placeholder="Search by name, role, ID..."
                  value={search} onChange={(e) => setSearch(e.target.value)}
                  className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-48 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400" />
              </div>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer">
                <SlidersHorizontal size={12} /> Filter
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/60">
                  <th className="px-4 py-3 w-10">
                    <input type="checkbox" checked={selectedIds.size === filtered.length && filtered.length > 0}
                      onChange={toggleAll} className="w-3.5 h-3.5 rounded cursor-pointer accent-blue-600" />
                  </th>
                  {[
                    { key: "name" as SortField, label: "Employee" },
                    { key: null, label: "Employee ID" },
                    { key: "role" as SortField, label: "Role" },
                    { key: "dept" as SortField, label: "Department" },
                    { key: null, label: "Type" },
                    { key: "status" as SortField, label: "Status" },
                    { key: null, label: "Schedule" },
                    { key: "joinDate" as SortField, label: "Join Date" },
                  ].map((col, i) => (
                    <th key={i} className={`text-left px-4 py-3 ${col.key ? "cursor-pointer select-none group" : ""}`}
                      onClick={() => col.key && handleSort(col.key)}>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors">
                          {col.label}
                        </span>
                        {col.key && <SortIcon field={col.key} sortField={sortField} sortDir={sortDir} />}
                      </div>
                    </th>
                  ))}
                  <th className="px-4 py-3 w-16" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((emp, idx) => {
                  const sc = statusConfig[emp.status];
                  const dc = deptColors[emp.dept] || "bg-gray-50 text-gray-600";
                  const grad = avatarGradients[emp.id % avatarGradients.length];
                  const tc = empTypeColors[emp.employmentType] || "bg-gray-50 text-gray-600";
                  const ws = workScheduleLabels[emp.schedule];
                  const isSelected = selectedIds.has(emp.id);

                  return (
                    <tr key={emp.id}
                      onClick={() => handleRowClick(emp)}
                      className={`border-b border-gray-50 cursor-pointer group transition-colors ${
                        isSelected ? "bg-blue-50/60" : idx % 2 !== 0 ? "bg-gray-50/30 hover:bg-blue-50/30" : "hover:bg-blue-50/30"
                      }`}>
                      <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                        <input type="checkbox" checked={isSelected} onChange={() => {}}
                          onClick={(e) => toggleSelect(emp.id, e)}
                          className="w-3.5 h-3.5 rounded cursor-pointer accent-blue-600" />
                      </td>

                      {/* Employee */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                            {emp.avatar}
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">{emp.name}</p>
                            <p className="text-[10px] text-gray-400">{emp.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="text-xs font-mono text-gray-500">{emp.empId}</span>
                      </td>

                      <td className="px-4 py-3.5">
                        <p className="text-xs font-medium text-gray-700 truncate max-w-[160px]">{emp.role}</p>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`text-xs font-medium px-2 py-1 rounded-md ${dc}`}>{emp.dept}</span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`text-xs font-medium px-2 py-1 rounded-md capitalize ${tc}`}>
                          {emp.employmentType}
                        </span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                          {sc.label}
                        </span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${ws.color}`}>{ws.label}</span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="text-xs text-gray-500">
                          {new Date(emp.joinDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button title="View Profile"
                            onClick={() => handleRowClick(emp)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer">
                            <Eye size={13} />
                          </button>
                          <button title="Edit"
                            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer">
                            <Edit2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-16 text-center">
                <p className="text-sm text-gray-400">No employees match your filters.</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
            <p className="text-xs text-gray-400">
              Showing <span className="font-semibold text-gray-600">{filtered.length}</span> of{" "}
              <span className="font-semibold text-gray-600">{allEmployees.length}</span> employees
            </p>
            <div className="flex items-center gap-1">
              {[1, 2].map((p) => (
                <button key={p} className={`w-7 h-7 rounded-lg text-xs transition-colors cursor-pointer ${p === 1 ? "bg-blue-600 text-white font-semibold" : "text-gray-500 hover:bg-gray-100"}`}>{p}</button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ ORG CHART TAB ══════════════════ */}
      {activeTab === "orgchart" && (
        <OrgChart employees={allEmployees} onSelect={(emp) => { setSelectedEmployee(emp); setDrawerOpen(true); }} />
      )}

      {/* ══════════════════ SCHEDULES TAB ══════════════════ */}
      {activeTab === "schedules" && (
        <div className="space-y-5">
          {/* Schedule Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {Object.entries(workScheduleLabels).map(([key, val]) => {
              const count = allEmployees.filter((e) => e.schedule === key).length;
              return (
                <div key={key} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                  <p className="text-lg font-bold text-gray-900">{count}</p>
                  <p className={`text-[10px] font-semibold mt-1 px-1.5 py-0.5 rounded inline-block ${val.color}`}>{val.label}</p>
                  <p className="text-[9px] text-gray-400 mt-1">{val.hours}</p>
                </div>
              );
            })}
          </div>

          {/* Schedule Assignment Table */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Schedule Assignments</h3>
                <p className="text-xs text-gray-400 mt-0.5">Assign and manage work schedules for all employees</p>
              </div>
              <button className="text-xs text-blue-600 font-medium hover:text-blue-800 cursor-pointer">Bulk Assign</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50/60">
                    {["Employee", "Department", "Current Schedule", "Hours", "Actions"].map((col) => (
                      <th key={col} className="text-left px-5 py-3">
                        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {allEmployees.map((emp, idx) => {
                    const dc = deptColors[emp.dept] || "bg-gray-50 text-gray-600";
                    const ws = workScheduleLabels[emp.schedule];
                    const grad = avatarGradients[emp.id % avatarGradients.length];
                    return (
                      <tr key={emp.id} className={`border-b border-gray-50 hover:bg-gray-50/50 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0`}>
                              {emp.avatar}
                            </div>
                            <p className="text-xs font-semibold text-gray-800">{emp.name}</p>
                          </div>
                        </td>
                        <td className="px-5 py-3">
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>{emp.dept}</span>
                        </td>
                        <td className="px-5 py-3">
                          <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${ws.color}`}>{ws.label}</span>
                        </td>
                        <td className="px-5 py-3">
                          <span className="text-xs text-gray-500">{ws.hours}</span>
                        </td>
                        <td className="px-5 py-3">
                          <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer">Change</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ ONBOARDING TAB ══════════════════ */}
      {activeTab === "onboarding" && (
        <div className="space-y-5">
          {/* Onboarding Stats */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "In Progress", value: onboardingEmployees.length, color: "text-purple-600 bg-purple-50" },
              { label: "Completed This Month", value: allEmployees.filter(e => e.onboardingStep === 0 && new Date(e.joinDate) >= new Date("2026-04-01")).length, color: "text-green-600 bg-green-50" },
              { label: "Avg. Completion Days", value: "4.2", color: "text-blue-600 bg-blue-50" },
            ].map((s) => (
              <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-2 ${s.color}`}>
                  <Zap size={15} />
                </div>
                <p className="text-xl font-bold text-gray-900">{s.value}</p>
                <p className="text-[10px] text-gray-400 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Onboarding Progress List */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Active Onboarding</h3>
                <p className="text-xs text-gray-400 mt-0.5">{onboardingEmployees.length} employee{onboardingEmployees.length !== 1 ? "s" : ""} in progress</p>
              </div>
              <button onClick={() => setAddModalOpen(true)}
                className="flex items-center gap-1.5 text-xs text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg transition-colors cursor-pointer font-medium">
                <UserPlus size={12} /> Start New
              </button>
            </div>

            {onboardingEmployees.length > 0 ? (
              <div className="divide-y divide-gray-50">
                {onboardingEmployees.map((emp) => {
                  const grad = avatarGradients[emp.id % avatarGradients.length];
                  const progress = ((emp.onboardingStep - 1) / 5) * 100;
                  return (
                    <div key={emp.id} className="flex items-start gap-4 px-5 py-4 hover:bg-gray-50/50 transition-colors cursor-pointer" onClick={() => handleRowClick(emp)}>
                      <div className={`w-9 h-9 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                        {emp.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs font-semibold text-gray-800">{emp.name}</p>
                          <span className="text-[10px] text-purple-700 font-semibold bg-purple-50 px-2 py-0.5 rounded-full">
                            Step {emp.onboardingStep} / 5
                          </span>
                        </div>
                        <p className="text-[10px] text-gray-500 mb-2">{emp.role} · {emp.dept}</p>
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="text-gray-500 font-medium">{onboardingStepLabels[emp.onboardingStep]}</span>
                            <span className="text-gray-400">{Math.round(progress)}%</span>
                          </div>
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all" style={{ width: `${(emp.onboardingStep / 5) * 100}%` }} />
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 mt-2">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <div key={s} className={`flex-1 h-1 rounded-full ${s < emp.onboardingStep ? "bg-blue-500" : s === emp.onboardingStep ? "bg-purple-400" : "bg-gray-200"}`} />
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-16 text-center">
                <CheckCircle size={28} className="text-gray-200 mx-auto mb-2" />
                <p className="text-sm text-gray-400">No active onboarding processes.</p>
                <button onClick={() => setAddModalOpen(true)} className="mt-3 text-xs text-blue-600 font-semibold hover:text-blue-800 cursor-pointer">
                  Add a new employee
                </button>
              </div>
            )}
          </div>

          {/* Onboarding Steps Reference */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">Onboarding Flow</h3>
            <div className="flex items-start gap-3">
              {onboardingStepLabels.slice(1).map((step, i) => (
                <div key={i} className="flex flex-col items-center flex-1">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold mb-2">
                    {i + 1}
                  </div>
                  <p className="text-[10px] text-gray-600 text-center font-medium leading-tight">{step}</p>
                  {i < 4 && <div className="absolute" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="h-4" />

      {/* ── PROFILE DRAWER ── */}
      <EmployeeProfileDrawer
        isOpen={drawerOpen}
        employee={selectedEmployee}
        onClose={() => setDrawerOpen(false)}
      />

      {/* ── ADD EMPLOYEE MODAL ── */}
      <AddEmployeeModal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
      />
    </main>
  );
}
