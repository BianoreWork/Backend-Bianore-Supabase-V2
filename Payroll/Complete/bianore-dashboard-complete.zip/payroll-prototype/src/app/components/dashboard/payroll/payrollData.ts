export type PayrollStatus = "draft" | "pending" | "approved" | "paid";

export interface PayrollRecord {
  id: number;
  name: string;
  avatar: string;
  dept: string;
  position: string;
  // Earnings
  baseSalary: number;
  positionAllowance: number;
  transportAllowance: number;
  mealAllowance: number;
  overtime: number;
  overtimeHours: number;
  bonus: number;
  reimbursements: number;
  // Deductions
  lateDeduction: number;
  absenceDeduction: number;
  loanDeduction: number;
  tax: number;
  bpjsHealth: number;
  bpjsEmployment: number;
  // Computed totals
  totalEarnings: number;
  totalDeductions: number;
  netSalary: number;
  // Meta
  status: PayrollStatus;
  bankName: string;
  bankAccount: string;
  payPeriod: string;
  // Linked attendance data
  presentDays: number;
  lateDays: number;
  absentDays: number;
  overtimeDays: number;
  // Tax compliance
  taxStatus: "valid" | "warning";
}

export const payrollRecords: PayrollRecord[] = [
  {
    id: 1, name: "John Martinez", avatar: "JM", dept: "Engineering", position: "Sr. Software Engineer",
    baseSalary: 8500, positionAllowance: 500, transportAllowance: 150, mealAllowance: 100,
    overtime: 850, overtimeHours: 10, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 1258, bpjsHealth: 255, bpjsEmployment: 85,
    totalEarnings: 10100, totalDeductions: 1598, netSalary: 8502,
    status: "approved", bankName: "Chase Bank", bankAccount: "****4521",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 3, taxStatus: "valid",
  },
  {
    id: 2, name: "Sarah Chen", avatar: "SC", dept: "Marketing", position: "Marketing Manager",
    baseSalary: 6200, positionAllowance: 300, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 310, absenceDeduction: 0, loanDeduction: 0,
    tax: 873, bpjsHealth: 186, bpjsEmployment: 62,
    totalEarnings: 6750, totalDeductions: 1431, netSalary: 5319,
    status: "pending", bankName: "Bank of America", bankAccount: "****8832",
    payPeriod: "April 2026", presentDays: 19, lateDays: 5, absentDays: 0, overtimeDays: 0, taxStatus: "warning",
  },
  {
    id: 3, name: "David Kim", avatar: "DK", dept: "Finance", position: "Senior Accountant",
    baseSalary: 7100, positionAllowance: 400, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 500,
    tax: 1050, bpjsHealth: 213, bpjsEmployment: 71,
    totalEarnings: 7750, totalDeductions: 1834, netSalary: 5916,
    status: "approved", bankName: "Wells Fargo", bankAccount: "****1195",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 0, taxStatus: "valid",
  },
  {
    id: 4, name: "Priya Sharma", avatar: "PS", dept: "HR", position: "HR Specialist",
    baseSalary: 5800, positionAllowance: 250, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 264, loanDeduction: 0,
    tax: 784, bpjsHealth: 174, bpjsEmployment: 58,
    totalEarnings: 6300, totalDeductions: 1280, netSalary: 5020,
    status: "draft", bankName: "Citibank", bankAccount: "****7743",
    payPeriod: "April 2026", presentDays: 20, lateDays: 0, absentDays: 1, overtimeDays: 0, taxStatus: "valid",
  },
  {
    id: 5, name: "Mike Torres", avatar: "MT", dept: "Operations", position: "Operations Lead",
    baseSalary: 5500, positionAllowance: 250, transportAllowance: 150, mealAllowance: 100,
    overtime: 1375, overtimeHours: 20, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 1000,
    tax: 930, bpjsHealth: 165, bpjsEmployment: 55,
    totalEarnings: 7375, totalDeductions: 2150, netSalary: 5225,
    status: "paid", bankName: "US Bank", bankAccount: "****5520",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 5, taxStatus: "valid",
  },
  {
    id: 6, name: "Lisa Park", avatar: "LP", dept: "Sales", position: "Sales Executive",
    baseSalary: 6500, positionAllowance: 300, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 1200, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 1092, bpjsHealth: 195, bpjsEmployment: 65,
    totalEarnings: 8250, totalDeductions: 1352, netSalary: 6898,
    status: "approved", bankName: "Chase Bank", bankAccount: "****9284",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 0, taxStatus: "valid",
  },
  {
    id: 7, name: "Omar Faruk", avatar: "OF", dept: "Operations", position: "Operations Coordinator",
    baseSalary: 5200, positionAllowance: 200, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 720, bpjsHealth: 156, bpjsEmployment: 52,
    totalEarnings: 5650, totalDeductions: 928, netSalary: 4722,
    status: "draft", bankName: "TD Bank", bankAccount: "****3312",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 0, taxStatus: "warning",
  },
  {
    id: 8, name: "Emma Wilson", avatar: "EW", dept: "Engineering", position: "Software Engineer",
    baseSalary: 7800, positionAllowance: 450, transportAllowance: 150, mealAllowance: 100,
    overtime: 780, overtimeHours: 8, bonus: 500, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 1173, bpjsHealth: 234, bpjsEmployment: 78,
    totalEarnings: 9780, totalDeductions: 1485, netSalary: 8295,
    status: "approved", bankName: "Bank of America", bankAccount: "****6641",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 2, taxStatus: "valid",
  },
  {
    id: 9, name: "Carlos Rivera", avatar: "CR", dept: "Sales", position: "Sales Representative",
    baseSalary: 5900, positionAllowance: 250, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 590, absenceDeduction: 0, loanDeduction: 0,
    tax: 793, bpjsHealth: 177, bpjsEmployment: 59,
    totalEarnings: 6400, totalDeductions: 1619, netSalary: 4781,
    status: "pending", bankName: "Wells Fargo", bankAccount: "****2277",
    payPeriod: "April 2026", presentDays: 17, lateDays: 6, absentDays: 0, overtimeDays: 0, taxStatus: "warning",
  },
  {
    id: 10, name: "Aisha Johnson", avatar: "AJ", dept: "Engineering", position: "Full Stack Developer",
    baseSalary: 7500, positionAllowance: 400, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 341, loanDeduction: 0,
    tax: 1023, bpjsHealth: 225, bpjsEmployment: 75,
    totalEarnings: 8150, totalDeductions: 1664, netSalary: 6486,
    status: "pending", bankName: "Chase Bank", bankAccount: "****8810",
    payPeriod: "April 2026", presentDays: 20, lateDays: 0, absentDays: 1, overtimeDays: 0, taxStatus: "valid",
  },
  {
    id: 11, name: "Tom Bradley", avatar: "TB", dept: "Finance", position: "Financial Analyst",
    baseSalary: 6800, positionAllowance: 350, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 0, reimbursements: 200,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 993, bpjsHealth: 204, bpjsEmployment: 68,
    totalEarnings: 7600, totalDeductions: 1265, netSalary: 6335,
    status: "paid", bankName: "Citibank", bankAccount: "****4409",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 0, taxStatus: "valid",
  },
  {
    id: 12, name: "Mei Lin", avatar: "ML", dept: "Marketing", position: "Content Strategist",
    baseSalary: 5500, positionAllowance: 250, transportAllowance: 150, mealAllowance: 100,
    overtime: 0, overtimeHours: 0, bonus: 200, reimbursements: 0,
    lateDeduction: 0, absenceDeduction: 0, loanDeduction: 0,
    tax: 750, bpjsHealth: 165, bpjsEmployment: 55,
    totalEarnings: 6200, totalDeductions: 970, netSalary: 5230,
    status: "approved", bankName: "US Bank", bankAccount: "****7128",
    payPeriod: "April 2026", presentDays: 22, lateDays: 0, absentDays: 0, overtimeDays: 0, taxStatus: "valid",
  },
];

export const payrollKPIs = [
  {
    id: "total", label: "Total Payroll", value: "$284,500", raw: 284500,
    trend: "+$6,800", trendPct: "+2.4%", trendType: "up" as const, trendLabel: "vs last month",
    icon: "dollar-sign", color: "blue",
  },
  {
    id: "paid", label: "Employees Paid", value: "287",
    trend: "+12", trendPct: "+4.4%", trendType: "up" as const, trendLabel: "of 352 total",
    icon: "users", color: "green",
  },
  {
    id: "pending", label: "Pending Approvals", value: "11",
    trend: "-3", trendPct: "-21%", trendType: "up" as const, trendLabel: "from last run",
    icon: "clock", color: "yellow",
  },
  {
    id: "deductions", label: "Total Deductions", value: "$18,240",
    trend: "-$1,200", trendPct: "-6.2%", trendType: "up" as const, trendLabel: "vs last month",
    icon: "minus-circle", color: "red",
  },
  {
    id: "overtime", label: "Overtime Cost", value: "$14,040",
    trend: "+$1,980", trendPct: "+16.4%", trendType: "down" as const, trendLabel: "this period",
    icon: "zap", color: "purple",
  },
];

export const payrollProcessSteps = [
  { id: 0, label: "Draft", desc: "Initial data entry" },
  { id: 1, label: "Review", desc: "HR verification" },
  { id: 2, label: "Adjustment", desc: "Manual corrections" },
  { id: 3, label: "Approval", desc: "Multi-role sign-off" },
  { id: 4, label: "Paid", desc: "Disbursement complete" },
];

export const currentStep = 3; // Approval step

export const monthlyTrend = [
  { month: "Nov", total: 268000, deductions: 16200, overtime: 10800 },
  { month: "Dec", total: 275400, deductions: 17100, overtime: 12400 },
  { month: "Jan", total: 271200, deductions: 15800, overtime: 9600 },
  { month: "Feb", total: 280100, deductions: 18000, overtime: 13100 },
  { month: "Mar", total: 277600, deductions: 17400, overtime: 11800 },
  { month: "Apr", total: 284500, deductions: 18240, overtime: 14040 },
];

export const deptCosts = [
  { dept: "Engineering", cost: 98400, headcount: 48 },
  { dept: "Sales", cost: 64200, headcount: 52 },
  { dept: "Operations", cost: 52800, headcount: 61 },
  { dept: "Finance", cost: 38100, headcount: 22 },
  { dept: "Marketing", cost: 22400, headcount: 18 },
  { dept: "HR", cost: 10500, headcount: 8 },
];

export const auditLogs = [
  { id: 1, user: "Alex Kumar", role: "HR Manager", action: "Approved", target: "John Martinez", field: "Status", oldVal: "Pending", newVal: "Approved", time: "Apr 30, 2:30 PM" },
  { id: 2, user: "Alex Kumar", role: "HR Manager", action: "Modified", target: "Sarah Chen", field: "Late Deduction", oldVal: "$248", newVal: "$310", time: "Apr 30, 2:15 PM" },
  { id: 3, user: "System", role: "Auto", action: "Generated", target: "All Employees", field: "Payroll Draft", oldVal: "—", newVal: "Draft", time: "Apr 30, 9:00 AM" },
  { id: 4, user: "Lisa Thompson", role: "Finance Director", action: "Approved", target: "Tom Bradley", field: "Status", oldVal: "Pending", newVal: "Approved", time: "Apr 29, 5:12 PM" },
  { id: 5, user: "Lisa Thompson", role: "Finance Director", action: "Approved", target: "Mike Torres", field: "Status", oldVal: "Approved", newVal: "Paid", time: "Apr 29, 5:10 PM" },
  { id: 6, user: "Alex Kumar", role: "HR Manager", action: "Modified", target: "Mike Torres", field: "Overtime Hours", oldVal: "18h", newVal: "20h", time: "Apr 29, 3:44 PM" },
  { id: 7, user: "System", role: "Auto", action: "Synced", target: "All Employees", field: "Attendance Data", oldVal: "—", newVal: "Updated", time: "Apr 29, 8:00 AM" },
  { id: 8, user: "Robert Chen", role: "CEO", action: "Unlocked", target: "March 2026 Payroll", field: "Lock Status", oldVal: "Locked", newVal: "Unlocked", time: "Apr 1, 9:30 AM" },
];
