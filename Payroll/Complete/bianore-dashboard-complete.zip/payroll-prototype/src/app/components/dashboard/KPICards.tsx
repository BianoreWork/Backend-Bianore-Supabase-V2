import {
  Users,
  Clock,
  UserX,
  Activity,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowRight,
} from "lucide-react";
import { motion } from "motion/react";
import { kpiData } from "./mockData";

const EASE = [0.22, 1, 0.36, 1] as const;

const iconMap: Record<string, React.ReactNode> = {
  users:          <Users size={18} />,
  clock:          <Clock size={18} />,
  "user-x":       <UserX size={18} />,
  activity:       <Activity size={18} />,
  "dollar-sign":  <DollarSign size={18} />,
};

const colorMap: Record<string, { bg: string; icon: string }> = {
  blue:   { bg: "bg-blue-50",   icon: "text-blue-600"   },
  yellow: { bg: "bg-yellow-50", icon: "text-yellow-600" },
  red:    { bg: "bg-red-50",    icon: "text-red-500"    },
  green:  { bg: "bg-green-50",  icon: "text-green-600"  },
  purple: { bg: "bg-purple-50", icon: "text-purple-600" },
};

interface KPICardsProps {
  onKpiClick?: (filterId: string, filterStatus: string | null) => void;
}

export function KPICards({ onKpiClick }: KPICardsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
      {kpiData.map((card, index) => {
        const colors    = colorMap[card.color];
        const isUp      = card.trendType === "up";
        const isNeutral = card.trendType === "neutral";

        return (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0,  scale: 1    }}
            transition={{
              duration: 0.45,
              delay:    0.20 + index * 0.07,
              ease:     EASE,
            }}
            onClick={() => onKpiClick?.(card.id, card.filterStatus)}
            className="bg-white rounded-2xl p-4 cursor-pointer border border-gray-100 shadow-sm hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all duration-200 group"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-9 h-9 rounded-xl ${colors.bg} ${colors.icon} flex items-center justify-center`}>
                {iconMap[card.icon]}
              </div>
              <div
                className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium ${
                  isNeutral
                    ? "bg-gray-100 text-gray-600"
                    : isUp
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-600"
                }`}
              >
                {isNeutral ? (
                  <Minus size={10} />
                ) : isUp ? (
                  <TrendingUp size={10} />
                ) : (
                  <TrendingDown size={10} />
                )}
                <span>{card.trend}</span>
              </div>
            </div>

            <div className="mt-1">
              <p className="text-2xl font-bold text-gray-900 tracking-tight">
                {card.value}
              </p>
              <p className="text-xs text-gray-500 mt-0.5">{card.label}</p>
            </div>

            <div className="flex items-center justify-between mt-2">
              <p className="text-[10px] text-gray-400">{card.trendLabel}</p>
              <ArrowRight
                size={11}
                className="text-gray-300 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all"
              />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
