import { useState } from "react";
import { Shield, Download, CheckCircle, X, Edit3, BarChart2, FileText } from "lucide-react";
import { bpjsRateSettings, fmtIDR } from "./payrollMockData";

type BPJSTab = "settings" | "calculations" | "reports";

const programColors: Record<string, string> = {
  bpjs_kesehatan: "bg-blue-50 text-blue-700",
  jht:            "bg-green-50 text-green-700",
  jp:             "bg-violet-50 text-violet-700",
  jkk:            "bg-amber-50 text-amber-700",
  jkm:            "bg-orange-50 text-orange-700",
  jkp:            "bg-cyan-50 text-cyan-700",
};

const mockCalculations = [
  { emp: "Budi Santoso", avatar: "BS", dept: "Engineering", baseSalary: 18_000_000, kesehatanEmp: 120_000, kesehatanCo: 480_000, jhtEmp: 360_000, jhtCo: 666_000, jpEmp: 90_776, jpCo: 181_552, total: 1_898_328 },
  { emp: "Dewi Rahayu",  avatar: "DR", dept: "Marketing",   baseSalary: 14_000_000, kesehatanEmp: 120_000, kesehatanCo: 480_000, jhtEmp: 280_000, jhtCo: 518_000, jpEmp: 90_776, jpCo: 181_552, total: 1_670_328 },
  { emp: "Ahmad Fauzi",  avatar: "AF", dept: "Finance",     baseSalary: 16_000_000, kesehatanEmp: 120_000, kesehatanCo: 480_000, jhtEmp: 320_000, jhtCo: 592_000, jpEmp: 90_776, jpCo: 181_552, total: 1_784_328 },
  { emp: "Sari Putri",   avatar: "SP", dept: "HR",          baseSalary: 10_000_000, kesehatanEmp: 100_000, kesehatanCo: 400_000, jhtEmp: 200_000, jhtCo: 370_000, jpEmp: 0,      jpCo: 0,       total: 1_070_000 },
];

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600",
];

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700", Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",     HR: "bg-purple-50 text-purple-700",
};

export function BPJSPage() {
  const [activeTab, setActiveTab] = useState<BPJSTab>("settings");

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">BPJS</h1>
          <p className="text-sm text-gray-500 mt-0.5">Pengaturan tarif BPJS, kalkulasi, dan laporan iuran</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
            <Download size={13} className="text-gray-400" /> Export File BPJS
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {([
          { id: "settings"     as BPJSTab, label: "Tarif BPJS",   icon: <Shield size={13} /> },
          { id: "calculations" as BPJSTab, label: "Kalkulasi",     icon: <BarChart2 size={13} /> },
          { id: "reports"      as BPJSTab, label: "Laporan",       icon: <FileText size={13} /> },
        ]).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* ── SETTINGS TAB ── */}
      {activeTab === "settings" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
              <Shield size={12} className="text-amber-600 flex-shrink-0" />
              Tarif BPJS adalah tarif sistem default. Tenant dapat melakukan override untuk rate khusus.
            </div>
          </div>

          {bpjsRateSettings.map((rate) => {
            const pc = programColors[rate.programCode] || "bg-gray-100 text-gray-600";
            return (
              <div key={rate.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${pc}`}>
                      {rate.programCode.toUpperCase().replace("_", " ")}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{rate.programName}</p>
                      <p className="text-xs text-gray-400 mt-0.5">Berlaku sejak {rate.effectiveStartDate}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${rate.isActive ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {rate.isActive ? "Aktif" : "Nonaktif"}
                    </span>
                    <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
                      <Edit3 size={13} />
                    </button>
                  </div>
                </div>
                <div className="px-5 py-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-red-50 rounded-xl p-3 text-center">
                      <p className="text-[10px] text-red-500 uppercase tracking-wider font-semibold mb-1">Iuran Karyawan</p>
                      <p className="text-2xl font-bold text-red-700">{rate.employeeRate}%</p>
                    </div>
                    <div className="bg-blue-50 rounded-xl p-3 text-center">
                      <p className="text-[10px] text-blue-500 uppercase tracking-wider font-semibold mb-1">Iuran Perusahaan</p>
                      <p className="text-2xl font-bold text-blue-700">{rate.employerRate}%</p>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-3 text-center">
                      <p className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-1">Batas Gaji (Cap)</p>
                      <p className="text-sm font-bold text-gray-700">
                        {rate.salaryCap ? fmtIDR(rate.salaryCap) : "Tidak ada"}
                      </p>
                    </div>
                  </div>
                  {rate.salaryCap && (
                    <p className="text-[10px] text-gray-400 mt-3 flex items-center gap-1.5">
                      <Shield size={10} />
                      Iuran dihitung dari gaji yang digunakan, maksimal {fmtIDR(rate.salaryCap)}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── CALCULATIONS TAB ── */}
      {activeTab === "calculations" && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            {[
              { label: "Total Iuran Karyawan", value: fmtIDR(mockCalculations.reduce((s, c) => s + c.kesehatanEmp + c.jhtEmp + c.jpEmp, 0)), color: "bg-red-50 text-red-700" },
              { label: "Total Iuran Perusahaan", value: fmtIDR(mockCalculations.reduce((s, c) => s + c.kesehatanCo + c.jhtCo + c.jpCo, 0)), color: "bg-blue-50 text-blue-700" },
              { label: "Total BPJS", value: fmtIDR(mockCalculations.reduce((s, c) => s + c.total, 0)), color: "bg-green-50 text-green-700" },
            ].map((c) => (
              <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
                <span className="opacity-60">{c.label}: </span>{c.value}
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Kalkulasi BPJS — Mei 2025</h3>
                <p className="text-xs text-gray-400 mt-0.5">Per karyawan, semua program</p>
              </div>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <Download size={12} /> Export
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px]">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50/60">
                    {["Karyawan", "Dept", "Gaji Dasar", "Kes. Emp", "Kes. Co", "JHT Emp", "JHT Co", "JP Emp", "JP Co", "Total"].map((col) => (
                      <th key={col} className="text-left px-4 py-3">
                        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {mockCalculations.map((c, idx) => {
                    const dc      = deptColors[c.dept] || "bg-gray-100 text-gray-600";
                    const gradIdx = idx % avatarGradients.length;
                    const grad    = avatarGradients[gradIdx];
                    return (
                      <tr key={c.emp} className={`border-b border-gray-50 hover:bg-blue-50/20 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                              {c.avatar}
                            </div>
                            <span className="text-xs font-semibold text-gray-800">{c.emp}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${dc}`}>{c.dept}</span>
                        </td>
                        <td className="px-4 py-3.5"><span className="text-xs font-semibold text-gray-700 tabular-nums">{fmtIDR(c.baseSalary)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">{fmtIDR(c.kesehatanEmp)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-blue-600 tabular-nums">{fmtIDR(c.kesehatanCo)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">{fmtIDR(c.jhtEmp)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-blue-600 tabular-nums">{fmtIDR(c.jhtCo)}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">{c.jpEmp > 0 ? fmtIDR(c.jpEmp) : "—"}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs text-blue-600 tabular-nums">{c.jpCo > 0 ? fmtIDR(c.jpCo) : "—"}</span></td>
                        <td className="px-4 py-3.5"><span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(c.total)}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-3 border-t border-gray-100">
              <p className="text-xs text-gray-400">{mockCalculations.length} karyawan ditampilkan</p>
            </div>
          </div>
        </div>
      )}

      {/* ── REPORTS TAB ── */}
      {activeTab === "reports" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {[
              { title: "Laporan Bulanan BPJS", desc: "Rekap iuran semua karyawan per periode", icon: FileText, color: "bg-blue-50", iconColor: "text-blue-600" },
              { title: "File Upload BPJS Kesehatan", desc: "Format e-Dabu untuk upload massal", icon: Download, color: "bg-teal-50", iconColor: "text-teal-600" },
              { title: "File Upload BPJSTK", desc: "Format Siap Kerja untuk Ketenagakerjaan", icon: Download, color: "bg-green-50", iconColor: "text-green-600" },
              { title: "Laporan Tahunan BPJS", desc: "Rekapitulasi iuran selama setahun", icon: BarChart2, color: "bg-violet-50", iconColor: "text-violet-600" },
            ].map((item) => (
              <div key={item.title} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl ${item.color} flex items-center justify-center flex-shrink-0`}>
                    <item.icon size={18} className={item.iconColor} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">{item.title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
                  </div>
                  <Download size={15} className="text-gray-300 group-hover:text-blue-500 transition-colors flex-shrink-0 mt-1" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="h-4" />
    </main>
  );
}
