import { useState } from "react";
import {
  Building2, ClipboardList, Calendar, DollarSign, Users, Phone,
  Bell, Shield, Zap, Lock, Plus, Trash2, Save, Key, Copy,
  CheckCircle, Globe, Upload, RefreshCw, Eye, EyeOff, Check,
  MapPin, Camera, Clock, AlertTriangle, Settings, ChevronDown,
  Navigation, Radio, X, Edit2,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────
type SettingSection =
  | "company" | "branches" | "geofence" | "attendance" | "schedules" | "payroll"
  | "employees" | "sales" | "notifications" | "permissions"
  | "integrations" | "security";

const sections: { id: SettingSection; label: string; icon: React.ElementType; desc: string }[] = [
  { id: "company",       label: "Company Settings",       icon: Building2,    desc: "Profile & branding" },
  { id: "branches",      label: "Branches / Locations",   icon: Navigation,   desc: "Work locations" },
  { id: "geofence",      label: "Check-in & Geofence",    icon: Radio,        desc: "Location rules" },
  { id: "attendance",    label: "Attendance Policies",    icon: ClipboardList,desc: "Rules & thresholds" },
  { id: "schedules",     label: "Work Schedules",         icon: Calendar,     desc: "Shifts & hours" },
  { id: "payroll",       label: "Payroll Settings",       icon: DollarSign,   desc: "Salary & tax" },
  { id: "employees",     label: "Employee Settings",      icon: Users,        desc: "HR defaults" },
  { id: "sales",         label: "Sales Calling",          icon: Phone,        desc: "Visit rules" },
  { id: "notifications", label: "Notifications",          icon: Bell,         desc: "Alerts & reminders" },
  { id: "permissions",   label: "Roles & Permissions",    icon: Shield,       desc: "Access control" },
  { id: "integrations",  label: "Integrations",           icon: Zap,          desc: "APIs & services" },
  { id: "security",      label: "Security",               icon: Lock,         desc: "Auth & audit" },
];

// ── Shared UI ──────────────────────────────────────────────────────────────
function Toggle({ enabled, onChange }: { enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!enabled)}
      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer flex-shrink-0 ${enabled ? "bg-blue-600" : "bg-gray-200"}`}>
      <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${enabled ? "translate-x-4" : "translate-x-0.5"}`} />
    </button>
  );
}

function SettingGroup({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-gray-50">
        <p className="text-sm font-semibold text-gray-800">{title}</p>
        {description && <p className="text-[11px] text-gray-400 mt-0.5">{description}</p>}
      </div>
      <div className="divide-y divide-gray-50">{children}</div>
    </div>
  );
}

function Row({ label, desc, children, col }: { label: string; desc?: string; children: React.ReactNode; col?: boolean }) {
  return (
    <div className={`flex px-5 py-3.5 gap-4 ${col ? "flex-col" : "items-center justify-between"}`}>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-gray-700">{label}</p>
        {desc && <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed">{desc}</p>}
      </div>
      <div className={col ? "" : "flex-shrink-0"}>{children}</div>
    </div>
  );
}

function SaveBtn({ onSave }: { onSave?: () => void }) {
  const [saved, setSaved] = useState(false);
  return (
    <button onClick={() => { onSave?.(); setSaved(true); setTimeout(() => setSaved(false), 2200); }}
      className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2.5 rounded-xl cursor-pointer transition-all ${saved ? "bg-green-600 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"}`}>
      {saved ? <><CheckCircle size={13} /> Saved!</> : <><Save size={13} /> Save Changes</>}
    </button>
  );
}

function SectionHeader({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-base font-bold text-gray-900">{title}</h2>
      <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
    </div>
  );
}

const inp = "text-xs text-gray-800 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-all";
const sel = `${inp} cursor-pointer appearance-none`;
const numInp = `${inp} w-20 text-center`;

// ── 1. COMPANY ─────────────────────────────────────────────────────────────
function CompanySection() {
  const [form, setForm] = useState({
    name: "WorkForce Corp", type: "Technology", size: "50–200",
    timezone: "America/New_York", currency: "USD", language: "English",
    website: "https://workforce.app",
  });
  const [locs, setLocs] = useState([
    { id: 1, name: "HQ — Manhattan", address: "1 World Trade Center, NY", main: true },
    { id: 2, name: "Brooklyn Office", address: "55 Water St, Brooklyn, NY", main: false },
  ]);
  const u = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Company Settings" desc="Manage your organization profile, branding, and locations." />
      <SettingGroup title="Company Profile" description="Basic information about your organization">
        <div className="px-5 py-4 flex items-center gap-4">
          <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm">
            <Building2 size={22} className="text-white" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-700 mb-1">Company Logo</p>
            <p className="text-[10px] text-gray-400 mb-2">PNG or SVG recommended · max 2MB</p>
            <button className="flex items-center gap-1.5 text-[11px] font-semibold text-blue-600 border border-blue-200 px-3 py-1.5 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors">
              <Upload size={10} /> Upload Logo
            </button>
          </div>
        </div>
        <Row label="Company Name"><input value={form.name} onChange={e => u("name", e.target.value)} className={`${inp} w-56`} /></Row>
        <Row label="Business Type">
          <select value={form.type} onChange={e => u("type", e.target.value)} className={`${sel} w-48`}>
            {["Technology", "Finance", "Healthcare", "Manufacturing", "Retail", "Education", "Logistics", "Other"].map(t => <option key={t}>{t}</option>)}
          </select>
        </Row>
        <Row label="Company Size">
          <select value={form.size} onChange={e => u("size", e.target.value)} className={`${sel} w-36`}>
            {["1–10", "11–50", "50–200", "201–500", "501–1000", "1000+"].map(s => <option key={s}>{s}</option>)}
          </select>
        </Row>
        <Row label="Website"><input value={form.website} onChange={e => u("website", e.target.value)} className={`${inp} w-56`} /></Row>
      </SettingGroup>

      <SettingGroup title="Locale & Regional" description="Timezone, currency, and language defaults">
        <Row label="Timezone">
          <select value={form.timezone} onChange={e => u("timezone", e.target.value)} className={`${sel} w-52`}>
            {["America/New_York","America/Chicago","America/Los_Angeles","Europe/London","Asia/Jakarta","Asia/Singapore","Asia/Tokyo"].map(t => <option key={t}>{t}</option>)}
          </select>
        </Row>
        <Row label="Currency">
          <select value={form.currency} onChange={e => u("currency", e.target.value)} className={`${sel} w-28`}>
            {["USD","EUR","GBP","IDR","SGD","MYR","JPY","AUD"].map(c => <option key={c}>{c}</option>)}
          </select>
        </Row>
        <Row label="Language">
          <select value={form.language} onChange={e => u("language", e.target.value)} className={`${sel} w-36`}>
            {["English","Indonesian","Japanese","German","French","Spanish"].map(l => <option key={l}>{l}</option>)}
          </select>
        </Row>
      </SettingGroup>

      <SettingGroup title="Office Locations" description="Physical offices and branches">
        {locs.map(loc => (
          <div key={loc.id} className="flex items-center gap-3 px-5 py-3.5">
            <div className="w-7 h-7 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <Globe size={12} className="text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-semibold text-gray-800">{loc.name}</p>
                {loc.main && <span className="text-[9px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">HQ</span>}
              </div>
              <p className="text-[10px] text-gray-400">{loc.address}</p>
            </div>
            {!loc.main && (
              <button onClick={() => setLocs(p => p.filter(l => l.id !== loc.id))}
                className="p-1.5 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 cursor-pointer transition-colors">
                <Trash2 size={13} />
              </button>
            )}
          </div>
        ))}
        <div className="px-5 py-3">
          <button onClick={() => setLocs(p => [...p, { id: Date.now(), name: "New Office", address: "Enter address", main: false }])}
            className="flex items-center gap-1.5 text-[11px] font-semibold text-blue-600 hover:text-blue-800 cursor-pointer">
            <Plus size={12} /> Add Location
          </button>
        </div>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 2. ATTENDANCE ──────────────────────────────────────────────────────────
function AttendanceSection() {
  const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const [days, setDays] = useState([true, true, true, true, true, false, false]);
  const [form, setForm] = useState({
    startTime: "09:00", endTime: "17:00", breakMin: "60",
    graceMins: "10", lateThreshold: "15",
    deductType: "fixed", deductAmount: "50000",
    absentThresholdHours: "4",
    requirePhoto: false, requireGPS: true, allowMobileCheckin: true,
    checkinWindowBefore: "30", checkinWindowAfter: "120",
  });
  const u = (k: string, v: string | boolean) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Attendance Policies" desc="Define working hours, check-in rules, and late penalties." />
      <SettingGroup title="Working Schedule" description="Standard working days and hours">
        <Row label="Working Days" col>
          <div className="flex gap-2 flex-wrap">
            {dayNames.map((d, i) => (
              <button key={d} onClick={() => setDays(p => { const n = [...p]; n[i] = !n[i]; return n; })}
                className={`text-[11px] font-bold w-10 h-8 rounded-lg cursor-pointer transition-all ${days[i] ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}>
                {d}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Work Hours">
          <div className="flex items-center gap-2">
            <input type="time" value={form.startTime} onChange={e => u("startTime", e.target.value)} className={inp} />
            <span className="text-xs text-gray-400">to</span>
            <input type="time" value={form.endTime} onChange={e => u("endTime", e.target.value)} className={inp} />
          </div>
        </Row>
        <Row label="Break Duration" desc="Total break time deducted from work hours">
          <div className="flex items-center gap-2">
            <input value={form.breakMin} onChange={e => u("breakMin", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes</span>
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Check-in / Check-out Rules">
        <Row label="Grace Period" desc="Allowed lateness before marked as late">
          <div className="flex items-center gap-2">
            <input value={form.graceMins} onChange={e => u("graceMins", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes</span>
          </div>
        </Row>
        <Row label="Check-in Window (before scheduled)">
          <div className="flex items-center gap-2">
            <input value={form.checkinWindowBefore} onChange={e => u("checkinWindowBefore", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes early</span>
          </div>
        </Row>
        <Row label="Check-in Window (after scheduled)">
          <div className="flex items-center gap-2">
            <input value={form.checkinWindowAfter} onChange={e => u("checkinWindowAfter", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes after</span>
          </div>
        </Row>
        <Row label="Require Photo on Check-in" desc="Employee must take a selfie to check in">
          <Toggle enabled={form.requirePhoto} onChange={v => u("requirePhoto", v)} />
        </Row>
        <Row label="Require GPS Validation" desc="Location must match office address within radius">
          <Toggle enabled={form.requireGPS} onChange={v => u("requireGPS", v)} />
        </Row>
        <Row label="Allow Mobile Check-in" desc="Employees can check in via mobile app">
          <Toggle enabled={form.allowMobileCheckin} onChange={v => u("allowMobileCheckin", v)} />
        </Row>
      </SettingGroup>

      <SettingGroup title="Late & Absence Policy">
        <Row label="Late Threshold" desc="Minutes after grace period before penalty applies">
          <div className="flex items-center gap-2">
            <input value={form.lateThreshold} onChange={e => u("lateThreshold", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes</span>
          </div>
        </Row>
        <Row label="Late Deduction Type">
          <div className="flex gap-2">
            {["fixed", "percentage", "none"].map(t => (
              <button key={t} onClick={() => u("deductType", t)}
                className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer capitalize transition-all ${form.deductType === t ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                {t === "fixed" ? "Fixed Amount" : t === "percentage" ? "% of Daily Pay" : "No Penalty"}
              </button>
            ))}
          </div>
        </Row>
        {form.deductType !== "none" && (
          <Row label={form.deductType === "fixed" ? "Deduction Amount" : "Deduction Percentage"}>
            <div className="flex items-center gap-2">
              {form.deductType === "fixed" && <span className="text-[10px] text-gray-400">$</span>}
              <input value={form.deductAmount} onChange={e => u("deductAmount", e.target.value)} className={numInp} />
              {form.deductType === "percentage" && <span className="text-[10px] text-gray-400">% per late instance</span>}
            </div>
          </Row>
        )}
        <Row label="Absent Threshold" desc="Hours with no check-in before marked as absent">
          <div className="flex items-center gap-2">
            <input value={form.absentThresholdHours} onChange={e => u("absentThresholdHours", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">hours</span>
          </div>
        </Row>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 3. WORK SCHEDULES ──────────────────────────────────────────────────────
const DAY_LABELS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const SCHED_COLORS = ["bg-blue-600","bg-amber-500","bg-purple-500","bg-green-500","bg-cyan-500"];

function SchedulesSection() {
  const [schedules, setSchedules] = useState([
    { id: 1, name: "Fixed (Standard)", days: [true,true,true,true,true,false,false], start: "09:00", end: "17:00", brk: 60 },
    { id: 2, name: "Morning Shift",    days: [true,true,true,true,true,true,false],  start: "06:00", end: "14:00", brk: 30 },
    { id: 3, name: "Evening Shift",    days: [true,true,true,true,true,true,false],  start: "14:00", end: "22:00", brk: 30 },
    { id: 4, name: "Flexible Hours",   days: [true,true,true,true,true,false,false], start: "08:00", end: "20:00", brk: 60 },
    { id: 5, name: "Remote Work",      days: [true,true,true,true,true,false,false], start: "08:00", end: "17:00", brk: 60 },
  ]);
  const [editId, setEditId] = useState<number | null>(null);

  return (
    <div className="space-y-5">
      <SectionHeader title="Work Schedules" desc="Define and manage shifts, fixed schedules, and working patterns." />
      <div className="grid grid-cols-1 gap-4">
        {schedules.map((sch, idx) => {
          const isEdit = editId === sch.id;
          return (
            <div key={sch.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="flex items-center gap-3 px-5 py-3.5">
                <div className={`w-2 h-10 rounded-full ${SCHED_COLORS[idx % SCHED_COLORS.length]} flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  {isEdit ? (
                    <input value={sch.name} onChange={e => setSchedules(p => p.map(s => s.id === sch.id ? { ...s, name: e.target.value } : s))}
                      className={`${inp} w-full mb-0`} />
                  ) : (
                    <p className="text-xs font-bold text-gray-800">{sch.name}</p>
                  )}
                  <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                    {DAY_LABELS.map((d, i) => (
                      <span key={d} className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${sch.days[i] ? "bg-blue-50 text-blue-700" : "bg-gray-100 text-gray-400"}`}>{d}</span>
                    ))}
                    <span className="text-[10px] text-gray-500 ml-1">· {sch.start}–{sch.end} · {sch.brk}m break</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isEdit && (
                    <button onClick={() => setEditId(null)} className="text-[11px] font-bold text-green-600 bg-green-50 border border-green-200 px-3 py-1.5 rounded-lg cursor-pointer hover:bg-green-100 transition-colors">
                      Done
                    </button>
                  )}
                  <button onClick={() => setEditId(isEdit ? null : sch.id)}
                    className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${isEdit ? "text-gray-500 bg-gray-100" : "text-blue-600 bg-blue-50 hover:bg-blue-100"}`}>
                    {isEdit ? "Cancel" : "Edit"}
                  </button>
                  {schedules.length > 1 && (
                    <button onClick={() => setSchedules(p => p.filter(s => s.id !== sch.id))}
                      className="p-1.5 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 cursor-pointer transition-colors">
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>
              </div>
              {isEdit && (
                <div className="px-5 pb-4 pt-1 border-t border-gray-50 space-y-3">
                  <div className="flex gap-2 flex-wrap">
                    {DAY_LABELS.map((d, i) => (
                      <button key={d} onClick={() => setSchedules(p => p.map(s => s.id === sch.id ? { ...s, days: s.days.map((v, j) => j === i ? !v : v) } : s))}
                        className={`text-[11px] font-bold w-10 h-7 rounded-lg cursor-pointer transition-all ${sch.days[i] ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}>
                        {d}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-500 w-16">Start</span>
                      <input type="time" value={sch.start} onChange={e => setSchedules(p => p.map(s => s.id === sch.id ? { ...s, start: e.target.value } : s))} className={inp} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-500 w-16">End</span>
                      <input type="time" value={sch.end} onChange={e => setSchedules(p => p.map(s => s.id === sch.id ? { ...s, end: e.target.value } : s))} className={inp} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-500 w-16">Break</span>
                      <input type="number" value={sch.brk} onChange={e => setSchedules(p => p.map(s => s.id === sch.id ? { ...s, brk: Number(e.target.value) } : s))} className={`${inp} w-16`} />
                      <span className="text-[10px] text-gray-400">min</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <button onClick={() => {
        const id = Date.now();
        setSchedules(p => [...p, { id, name: "New Schedule", days: [true,true,true,true,true,false,false], start: "09:00", end: "17:00", brk: 60 }]);
        setEditId(id);
      }} className="flex items-center gap-2 text-xs font-bold text-blue-600 bg-white border border-blue-200 hover:bg-blue-50 px-4 py-2.5 rounded-xl cursor-pointer transition-colors shadow-sm">
        <Plus size={14} /> Add New Schedule
      </button>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 4. PAYROLL ─────────────────────────────────────────────────────────────
function PayrollSection() {
  const [cycle, setCycle] = useState("Monthly");
  const [payDay, setPayDay] = useState("25");
  const [taxMethod, setTaxMethod] = useState("Progressive");
  const [components, setComponents] = useState([
    { id: "base",        label: "Base Salary",         type: "base",     enabled: true,  amount: "",      unit: "" },
    { id: "transport",   label: "Transport Allowance", type: "allowance",enabled: true,  amount: "500",   unit: "fixed" },
    { id: "meal",        label: "Meal Allowance",      type: "allowance",enabled: true,  amount: "300",   unit: "fixed" },
    { id: "housing",     label: "Housing Allowance",   type: "allowance",enabled: false, amount: "0",     unit: "fixed" },
    { id: "performance", label: "Performance Bonus",   type: "allowance",enabled: false, amount: "10",    unit: "%" },
    { id: "overtime",    label: "Overtime Pay",        type: "allowance",enabled: true,  amount: "1.5",   unit: "×" },
    { id: "late",        label: "Late Deduction",      type: "deduction",enabled: true,  amount: "50000", unit: "fixed" },
    { id: "absent",      label: "Absence Deduction",   type: "deduction",enabled: true,  amount: "1",     unit: "day" },
  ]);
  const [bpjs, setBpjs] = useState({
    kesEmp: "4", kesEe: "1",
    jhtEmp: "3.7", jhtEe: "2",
    jpEmp: "2", jpEe: "1",
    jkk: "0.24", jkm: "0.3",
  });
  const ub = (k: string, v: string) => setBpjs(b => ({ ...b, [k]: v }));

  const colorType = (t: string) => t === "base" ? "text-blue-700 bg-blue-50" : t === "allowance" ? "text-green-700 bg-green-50" : "text-red-600 bg-red-50";

  return (
    <div className="space-y-5">
      <SectionHeader title="Payroll Settings" desc="Configure salary components, tax rules, and pay cycles." />
      <SettingGroup title="Pay Cycle">
        <Row label="Pay Period">
          <div className="flex gap-2">
            {["Monthly", "Bi-weekly", "Weekly"].map(p => (
              <button key={p} onClick={() => setCycle(p)}
                className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all ${cycle === p ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                {p}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Pay Day" desc="Day of month salary is processed">
          <div className="flex items-center gap-2">
            <input value={payDay} onChange={e => setPayDay(e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">of the month</span>
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Salary Components" description="Toggle and configure each pay component">
        {components.map(c => (
          <div key={c.id} className="flex items-center gap-3 px-5 py-3">
            <Toggle enabled={c.enabled} onChange={v => setComponents(p => p.map(x => x.id === c.id ? { ...x, enabled: v } : x))} />
            <div className="flex-1 flex items-center gap-2 min-w-0">
              <p className="text-xs font-semibold text-gray-700">{c.label}</p>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded capitalize ${colorType(c.type)}`}>{c.type}</span>
            </div>
            {c.unit && c.enabled && (
              <div className="flex items-center gap-1.5">
                {c.unit !== "day" && c.unit !== "×" && <span className="text-[10px] text-gray-400">{c.unit === "%" ? "" : "$"}</span>}
                <input value={c.amount} onChange={e => setComponents(p => p.map(x => x.id === c.id ? { ...x, amount: e.target.value } : x))}
                  className={`${inp} w-20`} disabled={c.id === "base"} />
                <span className="text-[10px] text-gray-400">{c.unit}</span>
              </div>
            )}
            {c.id === "base" && <span className="text-[10px] text-blue-600 font-semibold">Set per employee</span>}
          </div>
        ))}
      </SettingGroup>

      <SettingGroup title="Tax Configuration (PPh 21)">
        <Row label="Calculation Method">
          <div className="flex gap-2">
            {["Progressive", "TER (Flat Rate)", "Gross-up"].map(m => (
              <button key={m} onClick={() => setTaxMethod(m)}
                className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all ${taxMethod === m ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                {m}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Auto-calculate Tax" desc="System calculates PPh 21 per payroll run">
          <Toggle enabled={true} onChange={() => {}} />
        </Row>
        <Row label="Include Annual Tax Correction" desc="Apply end-of-year PPh 21 correction">
          <Toggle enabled={false} onChange={() => {}} />
        </Row>
      </SettingGroup>

      <SettingGroup title="BPJS Configuration" description="Social security contribution rates">
        <div className="px-5 py-4">
          <div className="grid grid-cols-1 gap-2">
            {[
              { label: "BPJS Kesehatan", empKey: "kesEmp", eeKey: "kesEe", empLabel: "4%", eeLabel: "1%" },
              { label: "BPJS JHT",       empKey: "jhtEmp", eeKey: "jhtEe", empLabel: "3.7%", eeLabel: "2%" },
              { label: "BPJS JP",        empKey: "jpEmp",  eeKey: "jpEe",  empLabel: "2%",  eeLabel: "1%" },
            ].map(r => (
              <div key={r.label} className="flex items-center gap-4 py-2 border-b border-gray-50 last:border-0">
                <p className="text-xs font-semibold text-gray-700 w-36 flex-shrink-0">{r.label}</p>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-gray-400 w-20">Employer</span>
                  <input value={(bpjs as Record<string, string>)[r.empKey]} onChange={e => ub(r.empKey, e.target.value)} className={`${inp} w-16`} />
                  <span className="text-[10px] text-gray-400">%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-gray-400 w-20">Employee</span>
                  <input value={(bpjs as Record<string, string>)[r.eeKey]} onChange={e => ub(r.eeKey, e.target.value)} className={`${inp} w-16`} />
                  <span className="text-[10px] text-gray-400">%</span>
                </div>
              </div>
            ))}
            {[
              { label: "BPJS JKK",  key: "jkk", note: "Employer only · varies by risk" },
              { label: "BPJS JKM",  key: "jkm", note: "Employer only · 0.3% fixed" },
            ].map(r => (
              <div key={r.label} className="flex items-center gap-4 py-2 border-b border-gray-50 last:border-0">
                <p className="text-xs font-semibold text-gray-700 w-36 flex-shrink-0">{r.label}</p>
                <div className="flex items-center gap-2">
                  <input value={(bpjs as Record<string, string>)[r.key]} onChange={e => ub(r.key, e.target.value)} className={`${inp} w-16`} />
                  <span className="text-[10px] text-gray-400">%</span>
                </div>
                <span className="text-[10px] text-gray-400 italic">{r.note}</span>
              </div>
            ))}
          </div>
        </div>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 5. EMPLOYEES ───────────────────────────────────────────────────────────
function EmployeesSection() {
  const [depts, setDepts] = useState(["Executive", "HR", "Finance", "Engineering", "Sales", "Marketing", "Operations"]);
  const [empTypes, setEmpTypes] = useState(["Full-time", "Part-time", "Contract", "Intern", "Freelance"]);
  const [newDept, setNewDept] = useState("");
  const [probation, setProbation] = useState("3");
  const [defaultRole, setDefaultRole] = useState("Employee");
  const [onboarding, setOnboarding] = useState(["Sign Employment Contract","Submit National ID","Profile Photo Upload","Set Up Email Account","Complete HR Orientation","Set Up Payroll Details"]);
  const [newTask, setNewTask] = useState("");

  return (
    <div className="space-y-5">
      <SectionHeader title="Employee Settings" desc="Configure departments, employment types, and onboarding defaults." />
      <SettingGroup title="Department Structure">
        <div className="px-5 py-3 flex flex-wrap gap-2">
          {depts.map(d => (
            <div key={d} className="flex items-center gap-1.5 bg-gray-100 rounded-lg px-2.5 py-1.5">
              <span className="text-xs font-semibold text-gray-700">{d}</span>
              <button onClick={() => setDepts(p => p.filter(x => x !== d))} className="text-gray-400 hover:text-red-500 cursor-pointer transition-colors">
                <Trash2 size={11} />
              </button>
            </div>
          ))}
        </div>
        <div className="px-5 py-3 flex items-center gap-2">
          <input value={newDept} onChange={e => setNewDept(e.target.value)} placeholder="New department name" className={`${inp} flex-1`}
            onKeyDown={e => { if (e.key === "Enter" && newDept.trim()) { setDepts(p => [...p, newDept.trim()]); setNewDept(""); }}} />
          <button onClick={() => { if (newDept.trim()) { setDepts(p => [...p, newDept.trim()]); setNewDept(""); }}}
            className="flex items-center gap-1 text-[11px] font-bold text-blue-600 bg-blue-50 border border-blue-200 px-3 py-2 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors">
            <Plus size={11} /> Add
          </button>
        </div>
      </SettingGroup>

      <SettingGroup title="Employment Types">
        <div className="px-5 py-3 flex flex-wrap gap-2">
          {empTypes.map(t => (
            <div key={t} className="flex items-center gap-1.5 bg-gray-100 rounded-lg px-2.5 py-1.5">
              <span className="text-xs font-semibold text-gray-700">{t}</span>
              <button onClick={() => setEmpTypes(p => p.filter(x => x !== t))} className="text-gray-400 hover:text-red-500 cursor-pointer transition-colors">
                <Trash2 size={11} />
              </button>
            </div>
          ))}
        </div>
      </SettingGroup>

      <SettingGroup title="HR Defaults">
        <Row label="Default Access Role">
          <select value={defaultRole} onChange={e => setDefaultRole(e.target.value)} className={`${sel} w-36`}>
            {["Admin","HR","Manager","Employee"].map(r => <option key={r}>{r}</option>)}
          </select>
        </Row>
        <Row label="Probation Period">
          <div className="flex items-center gap-2">
            <input value={probation} onChange={e => setProbation(e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">months</span>
          </div>
        </Row>
        <Row label="Auto-send Welcome Email" desc="Send onboarding email when new employee is added">
          <Toggle enabled={true} onChange={() => {}} />
        </Row>
        <Row label="Require Document Upload" desc="Block activation until required documents are submitted">
          <Toggle enabled={true} onChange={() => {}} />
        </Row>
      </SettingGroup>

      <SettingGroup title="Default Onboarding Checklist" description="Tasks auto-assigned to every new employee">
        <div className="divide-y divide-gray-50">
          {onboarding.map((task, i) => (
            <div key={i} className="flex items-center gap-3 px-5 py-2.5">
              <div className="w-4 h-4 bg-green-50 rounded flex items-center justify-center flex-shrink-0"><Check size={10} className="text-green-600" /></div>
              <p className="text-xs text-gray-700 flex-1">{task}</p>
              <button onClick={() => setOnboarding(p => p.filter((_, j) => j !== i))} className="text-gray-300 hover:text-red-500 cursor-pointer transition-colors">
                <Trash2 size={12} />
              </button>
            </div>
          ))}
          <div className="flex items-center gap-2 px-5 py-3">
            <input value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="Add new task..." className={`${inp} flex-1`}
              onKeyDown={e => { if (e.key === "Enter" && newTask.trim()) { setOnboarding(p => [...p, newTask.trim()]); setNewTask(""); }}} />
            <button onClick={() => { if (newTask.trim()) { setOnboarding(p => [...p, newTask.trim()]); setNewTask(""); }}}
              className="text-[11px] font-bold text-blue-600 bg-blue-50 border border-blue-200 px-3 py-2 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors">
              <Plus size={11} />
            </button>
          </div>
        </div>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 6. SALES CALLING ───────────────────────────────────────────────────────
function SalesSection() {
  const [cfg, setCfg] = useState({
    requireGPS: true, gpsAccuracy: "100", allowGPSOverride: false,
    requirePhoto: true, minPhotos: "1", maxPhotoMB: "5",
    autoTimestamp: true, requireNotes: true, minNotesLen: "50",
    maxVisitHours: "4", reminderMinsBefore: "30",
    alertMissingReport: true, dailySummary: true,
  });
  const u = (k: string, v: string | boolean) => setCfg(c => ({ ...c, [k]: v }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Sales Calling Settings" desc="Validate visit data, enforce GPS and photo requirements." />
      <SettingGroup title="GPS Validation" description="Location verification for field visits">
        <Row label="Require GPS Validation" desc="Visit check-in must match registered client location">
          <Toggle enabled={cfg.requireGPS} onChange={v => u("requireGPS", v)} />
        </Row>
        {cfg.requireGPS && (
          <>
            <Row label="Accuracy Threshold" desc="Max distance from client location to accept GPS">
              <div className="flex items-center gap-2">
                <input value={cfg.gpsAccuracy} onChange={e => u("gpsAccuracy", e.target.value)} className={numInp} />
                <span className="text-[10px] text-gray-400">meters</span>
              </div>
            </Row>
            <Row label="Allow GPS Override" desc="Sales rep can override with manager-approved reason">
              <Toggle enabled={cfg.allowGPSOverride} onChange={v => u("allowGPSOverride", v)} />
            </Row>
          </>
        )}
      </SettingGroup>

      <SettingGroup title="Photo Proof" description="Visit verification through photo submission">
        <Row label="Require Photo Proof" desc="Photo is mandatory before visit can be marked complete">
          <Toggle enabled={cfg.requirePhoto} onChange={v => u("requirePhoto", v)} />
        </Row>
        {cfg.requirePhoto && (
          <>
            <Row label="Minimum Photos Required">
              <div className="flex items-center gap-2">
                <input value={cfg.minPhotos} onChange={e => u("minPhotos", e.target.value)} className={numInp} />
                <span className="text-[10px] text-gray-400">photo(s)</span>
              </div>
            </Row>
            <Row label="Max Photo File Size">
              <div className="flex items-center gap-2">
                <input value={cfg.maxPhotoMB} onChange={e => u("maxPhotoMB", e.target.value)} className={numInp} />
                <span className="text-[10px] text-gray-400">MB each</span>
              </div>
            </Row>
          </>
        )}
      </SettingGroup>

      <SettingGroup title="Visit Rules">
        <Row label="Auto-record Timestamp" desc="System automatically records check-in/check-out time">
          <Toggle enabled={cfg.autoTimestamp} onChange={v => u("autoTimestamp", v)} />
        </Row>
        <Row label="Require Activity Notes" desc="Notes field must be filled before marking complete">
          <Toggle enabled={cfg.requireNotes} onChange={v => u("requireNotes", v)} />
        </Row>
        {cfg.requireNotes && (
          <Row label="Minimum Notes Length">
            <div className="flex items-center gap-2">
              <input value={cfg.minNotesLen} onChange={e => u("minNotesLen", e.target.value)} className={numInp} />
              <span className="text-[10px] text-gray-400">characters</span>
            </div>
          </Row>
        )}
        <Row label="Maximum Visit Duration">
          <div className="flex items-center gap-2">
            <input value={cfg.maxVisitHours} onChange={e => u("maxVisitHours", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">hours</span>
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Visit Notifications">
        <Row label="Remind Before Visit">
          <div className="flex items-center gap-2">
            <input value={cfg.reminderMinsBefore} onChange={e => u("reminderMinsBefore", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes before</span>
          </div>
        </Row>
        <Row label="Alert on Missing Report" desc="Notify manager if completed visit has no notes/photo">
          <Toggle enabled={cfg.alertMissingReport} onChange={v => u("alertMissingReport", v)} />
        </Row>
        <Row label="Daily Visit Summary Email" desc="Send daily activity digest to managers">
          <Toggle enabled={cfg.dailySummary} onChange={v => u("dailySummary", v)} />
        </Row>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 7. NOTIFICATIONS ───────────────────────────────────────────────────────
const notifEvents = [
  { id: "att_daily",    label: "Daily Attendance Summary",  cat: "Attendance" },
  { id: "att_late",     label: "Late Arrival Alert",        cat: "Attendance" },
  { id: "att_absent",   label: "Absence Alert",             cat: "Attendance" },
  { id: "pay_due",      label: "Payroll Processing Due",    cat: "Payroll" },
  { id: "pay_slip",     label: "Payslip Ready",             cat: "Payroll" },
  { id: "pay_approve",  label: "Payroll Approval Request",  cat: "Payroll" },
  { id: "emp_new",      label: "New Employee Onboarding",   cat: "Employees" },
  { id: "leave_req",    label: "Leave Request Submitted",   cat: "Employees" },
  { id: "visit_remind", label: "Upcoming Visit Reminder",   cat: "Sales" },
  { id: "visit_done",   label: "Visit Completed",           cat: "Sales" },
  { id: "visit_miss",   label: "Missing Visit Report",      cat: "Sales" },
  { id: "sys_alert",    label: "System Security Alerts",    cat: "System" },
];
const catColors: Record<string, string> = {
  Attendance: "bg-blue-50 text-blue-700", Payroll: "bg-green-50 text-green-700",
  Employees: "bg-purple-50 text-purple-700", Sales: "bg-amber-50 text-amber-700",
  System: "bg-red-50 text-red-600",
};

function NotificationsSection() {
  const init = Object.fromEntries(notifEvents.map(e => [e.id, { email: true, inApp: true }]));
  const [notifs, setNotifs] = useState<Record<string, { email: boolean; inApp: boolean }>>(init);
  const [digest, setDigest] = useState("Real-time");
  const [quietStart, setQuietStart] = useState("22:00");
  const [quietEnd, setQuietEnd] = useState("08:00");
  const toggle = (id: string, channel: "email" | "inApp") =>
    setNotifs(n => ({ ...n, [id]: { ...n[id], [channel]: !n[id][channel] } }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Notification Settings" desc="Control which events trigger email and in-app alerts." />
      <SettingGroup title="Notification Events" description="Configure email and in-app alerts per event type">
        <div className="px-5 py-2 flex items-center gap-8 border-b border-gray-50">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex-1">Event</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider w-16 text-center">Email</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider w-16 text-center">In-App</p>
        </div>
        {notifEvents.map(ev => (
          <div key={ev.id} className="flex items-center gap-4 px-5 py-3 hover:bg-gray-50/50 transition-colors">
            <div className="flex-1 flex items-center gap-2 min-w-0">
              <p className="text-xs font-semibold text-gray-700">{ev.label}</p>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${catColors[ev.cat]}`}>{ev.cat}</span>
            </div>
            <div className="w-16 flex justify-center"><Toggle enabled={notifs[ev.id]?.email} onChange={() => toggle(ev.id, "email")} /></div>
            <div className="w-16 flex justify-center"><Toggle enabled={notifs[ev.id]?.inApp} onChange={() => toggle(ev.id, "inApp")} /></div>
          </div>
        ))}
      </SettingGroup>

      <SettingGroup title="Delivery Preferences">
        <Row label="Notification Frequency">
          <div className="flex gap-2">
            {["Real-time", "Hourly Digest", "Daily Digest"].map(f => (
              <button key={f} onClick={() => setDigest(f)}
                className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all ${digest === f ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                {f}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Quiet Hours" desc="Suppress non-critical notifications during these hours">
          <div className="flex items-center gap-2">
            <input type="time" value={quietStart} onChange={e => setQuietStart(e.target.value)} className={inp} />
            <span className="text-[10px] text-gray-400">to</span>
            <input type="time" value={quietEnd} onChange={e => setQuietEnd(e.target.value)} className={inp} />
          </div>
        </Row>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 8. ROLES & PERMISSIONS ─────────────────────────────────────────────────
const modules = ["Dashboard","Attendance","Payroll","Employees","Reports","Sales Calling","Settings"];
const perms = ["View","Edit","Approve","Delete"];
type RoleKey = "admin" | "hr" | "manager" | "employee";
const roleColors: Record<RoleKey, string> = {
  admin: "bg-red-50 text-red-700 border-red-200", hr: "bg-purple-50 text-purple-700 border-purple-200",
  manager: "bg-blue-50 text-blue-700 border-blue-200", employee: "bg-green-50 text-green-700 border-green-200",
};
const defaultMatrix: Record<RoleKey, Record<string, Record<string, boolean>>> = {
  admin:    Object.fromEntries(modules.map(m => [m, Object.fromEntries(perms.map(p => [p, true]))])),
  hr:       Object.fromEntries(modules.map(m => [m, { View: true,  Edit: m !== "Settings", Approve: ["Attendance","Payroll","Employees"].includes(m), Delete: false }])),
  manager:  Object.fromEntries(modules.map(m => [m, { View: true,  Edit: ["Attendance","Sales Calling"].includes(m), Approve: m === "Attendance", Delete: false }])),
  employee: Object.fromEntries(modules.map(m => [m, { View: ["Dashboard","Attendance","Payroll","Sales Calling"].includes(m), Edit: m === "Sales Calling", Approve: false, Delete: false }])),
};

function PermissionsSection() {
  const [role, setRole] = useState<RoleKey>("admin");
  const [matrix, setMatrix] = useState(defaultMatrix);
  const toggle = (mod: string, perm: string) =>
    setMatrix(m => ({ ...m, [role]: { ...m[role], [mod]: { ...m[role][mod], [perm]: !m[role][mod][perm] } } }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Roles & Permissions" desc="Configure what each role can view, edit, approve, and delete across all modules." />
      <div className="flex items-center gap-2 flex-wrap">
        {(["admin","hr","manager","employee"] as RoleKey[]).map(r => (
          <button key={r} onClick={() => setRole(r)}
            className={`text-xs font-bold px-4 py-2 rounded-xl border cursor-pointer transition-all capitalize ${role === r ? roleColors[r] : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
            {r === "hr" ? "HR" : r.charAt(0).toUpperCase() + r.slice(1)}
          </button>
        ))}
        <span className="ml-1 text-[10px] text-gray-400">— editing permissions for this role</span>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-50 flex items-center">
          <p className="text-xs font-bold text-gray-700 flex-1">Module</p>
          {perms.map(p => <p key={p} className="text-[10px] font-bold text-gray-400 uppercase tracking-wide w-20 text-center">{p}</p>)}
        </div>
        <div className="divide-y divide-gray-50">
          {modules.map(mod => (
            <div key={mod} className="flex items-center px-5 py-3.5 hover:bg-gray-50/50 transition-colors">
              <p className="text-xs font-semibold text-gray-700 flex-1">{mod}</p>
              {perms.map(perm => (
                <div key={perm} className="w-20 flex justify-center">
                  <button
                    onClick={() => role !== "admin" && toggle(mod, perm)}
                    title={role === "admin" ? "Admin always has full access" : undefined}
                    className={`w-5 h-5 rounded flex items-center justify-center transition-all cursor-pointer border ${
                      matrix[role][mod]?.[perm]
                        ? "bg-blue-600 border-blue-600"
                        : "bg-white border-gray-300 hover:border-gray-400"
                    } ${role === "admin" ? "opacity-60 cursor-not-allowed" : ""}`}>
                    {matrix[role][mod]?.[perm] && <Check size={10} className="text-white" />}
                  </button>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-3 px-1">
        <div className="flex items-center gap-1.5"><div className="w-4 h-4 bg-blue-600 rounded flex items-center justify-center"><Check size={8} className="text-white" /></div><span className="text-[10px] text-gray-500">Allowed</span></div>
        <div className="flex items-center gap-1.5"><div className="w-4 h-4 bg-white border border-gray-300 rounded" /><span className="text-[10px] text-gray-500">Restricted</span></div>
      </div>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 9. INTEGRATIONS ────────────────────────────────────────────────────────
const services = [
  { id: "slack",  name: "Slack",           logo: "S", color: "bg-purple-600",  desc: "Team notifications & alerts" },
  { id: "gmail",  name: "Google Mail",     logo: "G", color: "bg-red-500",     desc: "Email notifications" },
  { id: "gcal",   name: "Google Calendar", logo: "C", color: "bg-blue-500",    desc: "Sync schedules & shifts" },
  { id: "qb",     name: "QuickBooks",      logo: "Q", color: "bg-green-600",   desc: "Accounting & payroll export" },
  { id: "xero",   name: "Xero",            logo: "X", color: "bg-blue-700",    desc: "Cloud accounting sync" },
  { id: "zapier", name: "Zapier",          logo: "Z", color: "bg-orange-500",  desc: "Connect 5,000+ apps" },
];

function IntegrationsSection() {
  const [connected, setConnected] = useState<Record<string, boolean>>({ slack: true, gmail: true });
  const [apiEnabled, setApiEnabled] = useState(true);
  const [showKey, setShowKey] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState("https://hooks.workforce.app/xyz123");
  const [copied, setCopied] = useState(false);
  const apiKey = "wf_live_sk_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6";

  return (
    <div className="space-y-5">
      <SectionHeader title="Integrations" desc="Connect WorkForce with external tools, APIs, and services." />
      <SettingGroup title="API Access" description="Manage your API credentials and access">
        <Row label="Enable API Access" desc="Allow external systems to connect via REST API">
          <Toggle enabled={apiEnabled} onChange={setApiEnabled} />
        </Row>
        {apiEnabled && (
          <Row label="API Key" col>
            <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5">
              <Key size={13} className="text-gray-400 flex-shrink-0" />
              <code className="text-[11px] font-mono text-gray-700 flex-1 truncate">
                {showKey ? apiKey : apiKey.slice(0, 12) + "•".repeat(24)}
              </code>
              <button onClick={() => setShowKey(!showKey)} className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">
                {showKey ? <EyeOff size={13} /> : <Eye size={13} />}
              </button>
              <button onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                className="p-1 text-gray-400 hover:text-blue-600 cursor-pointer transition-colors">
                {copied ? <CheckCircle size={13} className="text-green-500" /> : <Copy size={13} />}
              </button>
              <button className="flex items-center gap-1 text-[10px] font-semibold text-orange-600 bg-orange-50 px-2 py-1 rounded-lg cursor-pointer hover:bg-orange-100 transition-colors">
                <RefreshCw size={10} /> Regenerate
              </button>
            </div>
          </Row>
        )}
      </SettingGroup>

      <SettingGroup title="Connected Services" description="Third-party integrations and connectors">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-0 divide-y divide-gray-50">
          {services.map(svc => (
            <div key={svc.id} className="flex items-center gap-3 px-5 py-4">
              <div className={`w-9 h-9 ${svc.color} rounded-xl flex items-center justify-center text-white text-sm font-black flex-shrink-0`}>
                {svc.logo}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-gray-800">{svc.name}</p>
                <p className="text-[10px] text-gray-400">{svc.desc}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {connected[svc.id] && <span className="text-[9px] font-bold text-green-700 bg-green-50 px-1.5 py-0.5 rounded">Connected</span>}
                <button onClick={() => setConnected(c => ({ ...c, [svc.id]: !c[svc.id] }))}
                  className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                    connected[svc.id] ? "text-red-500 bg-red-50 hover:bg-red-100" : "text-blue-600 bg-blue-50 hover:bg-blue-100"
                  }`}>
                  {connected[svc.id] ? "Disconnect" : "Connect"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </SettingGroup>

      <SettingGroup title="Webhooks" description="Receive real-time event notifications at your endpoint">
        <Row label="Webhook URL" col>
          <input value={webhookUrl} onChange={e => setWebhookUrl(e.target.value)} className={`${inp} w-full`} placeholder="https://your-endpoint.com/webhook" />
        </Row>
        <Row label="Trigger Events" col>
          <div className="flex flex-wrap gap-2">
            {["Visit Completed","Payroll Processed","Employee Added","Attendance Flagged","Leave Approved"].map(ev => (
              <label key={ev} className="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-blue-600 cursor-pointer" />
                <span className="text-[11px] text-gray-700">{ev}</span>
              </label>
            ))}
          </div>
        </Row>
        <div className="px-5 pb-4">
          <button className="text-[11px] font-bold text-blue-600 border border-blue-200 px-4 py-2 rounded-xl hover:bg-blue-50 cursor-pointer transition-colors">
            Send Test Payload
          </button>
        </div>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── 10. SECURITY ───────────────────────────────────────────────────────────
const auditLog = [
  { event: "Password changed",       user: "Alex Kumar",    time: "Today · 09:15 AM",    type: "security" },
  { event: "User role updated",      user: "Robert Chen",   time: "Today · 08:30 AM",    type: "admin" },
  { event: "Settings saved",         user: "Alex Kumar",    time: "Yesterday · 04:45 PM", type: "settings" },
  { event: "Payroll approved",       user: "Alex Kumar",    time: "May 4 · 11:00 AM",    type: "payroll" },
  { event: "New employee added",     user: "Alex Kumar",    time: "May 3 · 02:30 PM",    type: "employee" },
  { event: "API key regenerated",    user: "Robert Chen",   time: "May 2 · 10:15 AM",    type: "security" },
  { event: "Login from new device",  user: "Carlos Rivera", time: "May 1 · 08:00 AM",    type: "security" },
];
const auditColor: Record<string, string> = {
  security: "bg-red-50 text-red-600", admin: "bg-purple-50 text-purple-700",
  settings: "bg-blue-50 text-blue-700", payroll: "bg-green-50 text-green-700",
  employee: "bg-amber-50 text-amber-700",
};

function SecuritySection() {
  const [pwd, setPwd] = useState({ minLength: "8", requireUpper: true, requireSpecial: true, requireNumber: true, expireDays: "90", preventReuse: "5" });
  const [session, setSession] = useState({ timeoutMins: "30", maxSessions: "3", rememberDays: "14" });
  const [twoFA, setTwoFA] = useState(false);
  const [twoFAMethod, setTwoFAMethod] = useState("Email OTP");
  const up = (k: string, v: string | boolean) => setPwd(p => ({ ...p, [k]: v }));
  const us = (k: string, v: string) => setSession(s => ({ ...s, [k]: v }));

  return (
    <div className="space-y-5">
      <SectionHeader title="Security Settings" desc="Password policies, session management, 2FA, and audit logs." />
      <SettingGroup title="Password Policy" description="Rules enforced when users set or change passwords">
        <Row label="Minimum Password Length">
          <div className="flex items-center gap-2">
            <input value={pwd.minLength} onChange={e => up("minLength", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">characters</span>
          </div>
        </Row>
        <Row label="Require Uppercase Letter"><Toggle enabled={pwd.requireUpper} onChange={v => up("requireUpper", v)} /></Row>
        <Row label="Require Special Character"><Toggle enabled={pwd.requireSpecial} onChange={v => up("requireSpecial", v)} /></Row>
        <Row label="Require Number"><Toggle enabled={pwd.requireNumber} onChange={v => up("requireNumber", v)} /></Row>
        <Row label="Password Expiry" desc="Force password change after N days (0 = never)">
          <div className="flex items-center gap-2">
            <input value={pwd.expireDays} onChange={e => up("expireDays", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">days</span>
          </div>
        </Row>
        <Row label="Prevent Password Reuse" desc="Block reuse of last N passwords">
          <div className="flex items-center gap-2">
            <input value={pwd.preventReuse} onChange={e => up("preventReuse", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">previous passwords</span>
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Session Management">
        <Row label="Session Timeout" desc="Auto-logout after inactivity">
          <div className="flex items-center gap-2">
            <input value={session.timeoutMins} onChange={e => us("timeoutMins", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">minutes</span>
          </div>
        </Row>
        <Row label="Max Concurrent Sessions" desc="Per user across all devices">
          <input value={session.maxSessions} onChange={e => us("maxSessions", e.target.value)} className={numInp} />
        </Row>
        <Row label="Remember Me Duration">
          <div className="flex items-center gap-2">
            <input value={session.rememberDays} onChange={e => us("rememberDays", e.target.value)} className={numInp} />
            <span className="text-[10px] text-gray-400">days</span>
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Two-Factor Authentication">
        <Row label="Require 2FA" desc="Enforce two-factor authentication for all users">
          <Toggle enabled={twoFA} onChange={setTwoFA} />
        </Row>
        {twoFA && (
          <Row label="2FA Method">
            <select value={twoFAMethod} onChange={e => setTwoFAMethod(e.target.value)} className={`${sel} w-40`}>
              {["Email OTP","SMS OTP","Authenticator App","Hardware Key"].map(m => <option key={m}>{m}</option>)}
            </select>
          </Row>
        )}
      </SettingGroup>

      <SettingGroup title="Activity Audit Log" description="Recent system-level actions across all users">
        <div className="divide-y divide-gray-50">
          {auditLog.map((entry, i) => (
            <div key={i} className="flex items-center gap-3 px-5 py-3">
              <div className={`text-[9px] font-bold px-2 py-1 rounded-lg capitalize w-20 text-center flex-shrink-0 ${auditColor[entry.type]}`}>
                {entry.type}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-gray-800">{entry.event}</p>
                <p className="text-[10px] text-gray-400">{entry.user}</p>
              </div>
              <p className="text-[10px] text-gray-400 flex-shrink-0">{entry.time}</p>
            </div>
          ))}
        </div>
        <div className="px-5 py-3">
          <button className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 cursor-pointer">
            View full audit log →
          </button>
        </div>
      </SettingGroup>
      <div className="flex justify-end"><SaveBtn /></div>
    </div>
  );
}

// ── BRANCHES SECTION ────────────────────────────────────────────────────────
const branchMockData = [
  { id: 1, name: "HQ – Jakarta",        code: "JKT-HQ", address: "Jl. Sudirman No.1", city: "Jakarta",   employees: 87, locations: 2, status: "Active",   manager: "David Park",  tz: "Asia/Jakarta" },
  { id: 2, name: "Branch – Surabaya",   code: "SBY-01", address: "Jl. Raya Darmo 22", city: "Surabaya",  employees: 34, locations: 1, status: "Active",   manager: "Alex Kumar",  tz: "Asia/Jakarta" },
  { id: 3, name: "Branch – Bandung",    code: "BDG-01", address: "Jl. Asia Afrika 10", city: "Bandung",  employees: 19, locations: 1, status: "Active",   manager: "Maria Santos",tz: "Asia/Jakarta" },
  { id: 4, name: "Branch – Bali",       code: "DPS-01", address: "Jl. Ngurah Rai 5",  city: "Bali",     employees: 11, locations: 1, status: "Active",   manager: "Kevin Lee",   tz: "Asia/Makassar" },
  { id: 5, name: "Office – Singapore",  code: "SGP-01", address: "1 Raffles Place",   city: "Singapore", employees: 8,  locations: 1, status: "Inactive", manager: "—",           tz: "Asia/Singapore" },
];

function BranchFormDrawer({ branch, onClose }: { branch: typeof branchMockData[number] | null; onClose: () => void }) {
  const isNew = !branch;
  const inp2 = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400";
  const sel2 = `${inp2} cursor-pointer appearance-none`;
  const lbl2 = "block text-[11px] font-semibold text-gray-600 mb-1.5";
  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-[2px] z-30" onClick={onClose}/>
      <aside className="fixed right-0 top-0 h-full w-[420px] max-w-[95vw] bg-gray-50 z-40 shadow-2xl border-l border-gray-200 flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 bg-white border-b border-gray-100">
          <p className="text-sm font-bold text-gray-900">{isNew ? "Add New Branch" : `Edit: ${branch?.name}`}</p>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer"><X size={15} className="text-gray-500"/></button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3.5">
          <div><label className={lbl2}>Branch Name <span className="text-red-500">*</span></label><input defaultValue={branch?.name ?? ""} placeholder="e.g. Branch – Yogyakarta" className={inp2}/></div>
          <div><label className={lbl2}>Branch Code <span className="text-red-500">*</span></label><input defaultValue={branch?.code ?? ""} placeholder="e.g. YGY-01" className={inp2}/></div>
          <div><label className={lbl2}>Address <span className="text-red-500">*</span></label><input defaultValue={branch?.address ?? ""} placeholder="Street address" className={inp2}/></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl2}>City</label><input defaultValue={branch?.city ?? ""} placeholder="City" className={inp2}/></div>
            <div><label className={lbl2}>Time Zone</label>
              <div className="relative"><select defaultValue={branch?.tz ?? "Asia/Jakarta"} className={sel2}>
                {["Asia/Jakarta","Asia/Makassar","Asia/Jayapura","Asia/Singapore","America/New_York","Europe/London"].map(t => <option key={t}>{t}</option>)}
              </select><ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/></div>
            </div>
          </div>
          <div><label className={lbl2}>Branch Manager</label>
            <div className="relative"><select defaultValue={branch?.manager ?? ""} className={sel2}>
              <option value="">— Unassigned —</option>
              {["David Park","Alex Kumar","Maria Santos","Kevin Lee","Sarah Johnson"].map(m => <option key={m}>{m}</option>)}
            </select><ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/></div>
          </div>
          <div><label className={lbl2}>Default Working Schedule</label>
            <div className="relative"><select className={sel2}>
              {["Standard – Mon-Fri 08:00-17:00","Flex – Mon-Fri 09:00-18:00","6-Day – Mon-Sat 08:00-17:00","Custom"].map(s => <option key={s}>{s}</option>)}
            </select><ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/></div>
          </div>
          <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-4 py-3">
            <div><p className="text-xs font-semibold text-gray-700">Remote Check-in Allowed</p><p className="text-[10px] text-gray-400">Employees can check in from outside office</p></div>
            <button className="relative inline-flex h-5 w-9 items-center rounded-full bg-blue-600 cursor-pointer"><span className="inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm translate-x-4"/></button>
          </div>
          <div><label className={lbl2}>Status</label>
            <div className="flex gap-2">
              {["Active","Inactive"].map(s => (
                <button key={s} className={`flex-1 text-xs font-semibold py-2 rounded-xl border cursor-pointer transition-all ${s === (branch?.status ?? "Active") ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200"}`}>{s}</button>
              ))}
            </div>
          </div>
          <div><label className={lbl2}>Notes</label><textarea rows={3} placeholder="Internal notes about this branch…" className={`${inp2} resize-none`}/></div>
        </div>
        <div className="flex gap-2.5 px-4 py-3.5 bg-white border-t border-gray-100">
          <button onClick={onClose} className="flex-1 text-xs font-semibold py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer">Cancel</button>
          <button className="flex-1 text-xs font-bold py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white cursor-pointer transition-colors">{isNew ? "Create Branch" : "Save Changes"}</button>
        </div>
      </aside>
    </>
  );
}

function BranchesSection() {
  const [editTarget, setEditTarget] = useState<typeof branchMockData[number] | null | "new">(null);
  return (
    <div className="space-y-5">
      <SectionHeader title="Branches / Work Locations" desc="Manage all company office locations and work sites." />
      <div className="flex items-center justify-between">
        <p className="text-xs text-gray-400">{branchMockData.length} branches configured</p>
        <button onClick={() => setEditTarget("new")} className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer transition-colors"><Plus size={12}/> Add Branch</button>
      </div>
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {["Branch Name","Code","City","Manager","Employees","Check-in Locations","Status",""].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {branchMockData.map(b => (
                <tr key={b.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center flex-shrink-0"><Navigation size={12} className="text-white"/></div>
                      <p className="font-semibold text-gray-800">{b.name}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-gray-500">{b.code}</td>
                  <td className="px-4 py-3 text-gray-600">{b.city}</td>
                  <td className="px-4 py-3 text-gray-600">{b.manager}</td>
                  <td className="px-4 py-3 text-gray-700 font-semibold">{b.employees}</td>
                  <td className="px-4 py-3 text-gray-600">{b.locations}</td>
                  <td className="px-4 py-3"><span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${b.status === "Active" ? "bg-green-50 text-green-700 border border-green-200" : "bg-gray-100 text-gray-500 border border-gray-200"}`}>{b.status}</span></td>
                  <td className="px-4 py-3">
                    <button onClick={() => setEditTarget(b)} className="flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-700 font-medium cursor-pointer"><Edit2 size={11}/> Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {editTarget && <BranchFormDrawer branch={editTarget === "new" ? null : editTarget} onClose={() => setEditTarget(null)}/>}
    </div>
  );
}

// ── GEOFENCE / CHECK-IN LOCATIONS SECTION ───────────────────────────────────
const locationMockData = [
  { id: 1, name: "HQ Main Entrance",     branch: "HQ – Jakarta",      address: "Jl. Sudirman No.1",   lat: "-6.2088", lng: "106.8456", radius: "100 m", employees: "All",           selfie: true,  status: "Active" },
  { id: 2, name: "HQ Parking Entrance",  branch: "HQ – Jakarta",      address: "Jl. Sudirman No.1B",  lat: "-6.2090", lng: "106.8458", radius: "50 m",  employees: "Selected Dept", selfie: false, status: "Active" },
  { id: 3, name: "Surabaya Office",      branch: "Branch – Surabaya", address: "Jl. Raya Darmo 22",   lat: "-7.2575", lng: "112.7521", radius: "100 m", employees: "All",           selfie: true,  status: "Active" },
  { id: 4, name: "Bandung Co-working",   branch: "Branch – Bandung",  address: "Jl. Asia Afrika 10",  lat: "-6.9175", lng: "107.6191", radius: "200 m", employees: "All",           selfie: true,  status: "Active" },
  { id: 5, name: "Bali Office",          branch: "Branch – Bali",     address: "Jl. Ngurah Rai 5",    lat: "-8.6705", lng: "115.2126", radius: "100 m", employees: "All",           selfie: false, status: "Inactive" },
];

function LocationFormDrawer({ location, onClose }: { location: typeof locationMockData[number] | null; onClose: () => void }) {
  const isNew = !location;
  const inp2 = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400";
  const sel2 = `${inp2} cursor-pointer appearance-none`;
  const lbl2 = "block text-[11px] font-semibold text-gray-600 mb-1.5";
  const [customRadius, setCustomRadius] = useState(false);
  const [allowedFor, setAllowedFor]     = useState(location?.employees ?? "All Employees");
  const [selfie, setSelfie]             = useState(location?.selfie ?? true);

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-[2px] z-30" onClick={onClose}/>
      <aside className="fixed right-0 top-0 h-full w-[440px] max-w-[95vw] bg-gray-50 z-40 shadow-2xl border-l border-gray-200 flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 bg-white border-b border-gray-100">
          <p className="text-sm font-bold text-gray-900">{isNew ? "Add Check-in Location" : `Edit: ${location?.name}`}</p>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer"><X size={15} className="text-gray-500"/></button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3.5">
          <div><label className={lbl2}>Location Name <span className="text-red-500">*</span></label><input defaultValue={location?.name ?? ""} placeholder="e.g. Main Entrance" className={inp2}/></div>
          <div><label className={lbl2}>Linked Branch <span className="text-red-500">*</span></label>
            <div className="relative"><select defaultValue={location?.branch ?? ""} className={sel2}>
              <option value="">— Select branch —</option>
              {["HQ – Jakarta","Branch – Surabaya","Branch – Bandung","Branch – Bali"].map(b => <option key={b}>{b}</option>)}
            </select><ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/></div>
          </div>
          <div><label className={lbl2}>Address</label><input defaultValue={location?.address ?? ""} placeholder="Street address" className={inp2}/></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl2}>Latitude <span className="text-red-500">*</span></label><input defaultValue={location?.lat ?? ""} placeholder="-6.2088" className={inp2}/></div>
            <div><label className={lbl2}>Longitude <span className="text-red-500">*</span></label><input defaultValue={location?.lng ?? ""} placeholder="106.8456" className={inp2}/></div>
          </div>
          <div>
            <label className={lbl2}>Geofence Radius <span className="text-red-500">*</span></label>
            <div className="grid grid-cols-4 gap-2 mb-2">
              {["50 m","100 m","200 m","Custom"].map(r => (
                <button key={r} onClick={() => setCustomRadius(r === "Custom")}
                  className={`text-xs font-semibold py-2 rounded-xl border cursor-pointer transition-all ${
                    (customRadius && r === "Custom") || (!customRadius && r === (location?.radius ?? "100 m"))
                      ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-blue-300"
                  }`}>{r}</button>
              ))}
            </div>
            {customRadius && <input type="number" placeholder="Enter metres (e.g. 150)" className={inp2}/>}
          </div>
          <div>
            <label className={lbl2}>Allowed For</label>
            <div className="flex flex-col gap-2">
              {["All Employees","Selected Employees","Selected Departments"].map(opt => (
                <button key={opt} onClick={() => setAllowedFor(opt)}
                  className={`text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all text-left ${allowedFor === opt ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-blue-300"}`}>
                  {opt}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-4 py-3">
            <div><p className="text-xs font-semibold text-gray-700">Require Selfie / Biometric Verification</p><p className="text-[10px] text-gray-400">Employee must take selfie when checking in here</p></div>
            <button onClick={() => setSelfie(!selfie)} className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${selfie ? "bg-blue-600" : "bg-gray-200"}`}>
              <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${selfie ? "translate-x-4" : "translate-x-0.5"}`}/>
            </button>
          </div>
          <div><label className={lbl2}>Status</label>
            <div className="flex gap-2">
              {["Active","Inactive"].map(s => (
                <button key={s} className={`flex-1 text-xs font-semibold py-2 rounded-xl border cursor-pointer transition-all ${s === (location?.status ?? "Active") ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200"}`}>{s}</button>
              ))}
            </div>
          </div>
          <div><label className={lbl2}>Notes</label><textarea rows={2} placeholder="Optional notes…" className={`${inp2} resize-none`}/></div>
        </div>
        <div className="flex gap-2.5 px-4 py-3.5 bg-white border-t border-gray-100">
          <button onClick={onClose} className="flex-1 text-xs font-semibold py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer">Cancel</button>
          <button className="flex-1 text-xs font-bold py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white cursor-pointer transition-colors">{isNew ? "Add Location" : "Save Changes"}</button>
        </div>
      </aside>
    </>
  );
}

function GeofenceSection() {
  const [editTarget, setEditTarget] = useState<typeof locationMockData[number] | null | "new">(null);
  const [outsideBehavior, setOutsideBehavior] = useState("allow_flag");
  const [checkInFrom, setCheckInFrom]         = useState("assigned_branch");
  const [remoteExempt, setRemoteExempt]       = useState(true);
  const [maxLocations, setMaxLocations]        = useState("3");

  const behaviorOptions = [
    { id: "block",        label: "Block Check-in",              desc: "Employee cannot check in outside radius" },
    { id: "allow_flag",   label: "Allow but Flag",              desc: "Check-in recorded, flagged for review" },
    { id: "allow_reason", label: "Allow with Required Reason",  desc: "Employee must provide reason" },
  ];
  const checkInFromOptions = [
    { id: "assigned_branch",  label: "Assigned Branch Only" },
    { id: "any_branch",       label: "Any Company Branch" },
    { id: "approved_locations",label: "Selected Approved Locations" },
  ];

  const inp2 = "text-xs text-gray-800 bg-white border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all";

  return (
    <div className="space-y-5">
      <SectionHeader title="Check-in Locations & Geofence" desc="Configure allowed check-in areas, geofence rules, and radius settings." />

      {/* Global policy cards */}
      <SettingGroup title="Global Check-in Policy" description="Rules that apply to all branches unless overridden">
        <Row label="Maximum Check-in Locations per Branch" desc="Limit how many approved locations each branch can have">
          <div className="flex items-center gap-2">
            <input type="number" value={maxLocations} onChange={e => setMaxLocations(e.target.value)} className={`${inp2} w-16 text-center`} min="1" max="20"/>
            <span className="text-xs text-gray-400">locations</span>
          </div>
        </Row>
        <Row label="Remote Employees Exempt from Geofence" desc="Remote-tagged employees can check in from anywhere">
          <button onClick={() => setRemoteExempt(!remoteExempt)} className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${remoteExempt ? "bg-blue-600" : "bg-gray-200"}`}>
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${remoteExempt ? "translate-x-4" : "translate-x-0.5"}`}/>
          </button>
        </Row>
      </SettingGroup>

      <SettingGroup title="Employee Check-in Permission" description="Where employees are allowed to check in from">
        <Row label="Employees Can Check In From" col>
          <div className="flex flex-col gap-2 mt-1">
            {checkInFromOptions.map(opt => (
              <label key={opt.id} onClick={() => setCheckInFrom(opt.id)} className="flex items-center gap-2.5 cursor-pointer group">
                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors ${checkInFrom === opt.id ? "border-blue-600 bg-blue-600" : "border-gray-300 group-hover:border-blue-400"}`}>
                  {checkInFrom === opt.id && <div className="w-1.5 h-1.5 rounded-full bg-white"/>}
                </div>
                <span className="text-xs text-gray-700 font-medium">{opt.label}</span>
              </label>
            ))}
          </div>
        </Row>
      </SettingGroup>

      <SettingGroup title="Outside Geofence Behavior" description="What happens when an employee checks in outside the allowed radius">
        <Row label="If Check-in Is Outside Geofence Radius" col>
          <div className="flex flex-col gap-2 mt-1">
            {behaviorOptions.map(opt => (
              <label key={opt.id} onClick={() => setOutsideBehavior(opt.id)} className="flex items-start gap-2.5 cursor-pointer group bg-white border border-gray-100 rounded-xl p-3 hover:border-blue-200 transition-colors">
                <div className={`mt-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${outsideBehavior === opt.id ? "border-blue-600 bg-blue-600" : "border-gray-300 group-hover:border-blue-400"}`}>
                  {outsideBehavior === opt.id && <div className="w-1.5 h-1.5 rounded-full bg-white"/>}
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-800">{opt.label}</p>
                  <p className="text-[10px] text-gray-400">{opt.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </Row>
      </SettingGroup>

      <div className="flex justify-end"><SaveBtn /></div>

      {/* Locations table */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-bold text-gray-900">Approved Check-in Locations</p>
          <p className="text-xs text-gray-400 mt-0.5">{locationMockData.length} locations across all branches</p>
        </div>
        <button onClick={() => setEditTarget("new")} className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer transition-colors"><Plus size={12}/> Add Location</button>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {["Location Name","Branch","Address","Coordinates","Radius","Allowed Employees","Selfie","Status",""].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {locationMockData.map(loc => (
                <tr key={loc.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-green-50 flex items-center justify-center flex-shrink-0"><MapPin size={11} className="text-green-600"/></div>
                      <p className="font-semibold text-gray-800">{loc.name}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{loc.branch}</td>
                  <td className="px-4 py-3 text-gray-500 max-w-[140px] truncate">{loc.address}</td>
                  <td className="px-4 py-3 font-mono text-gray-400 text-[10px] whitespace-nowrap">{loc.lat}, {loc.lng}</td>
                  <td className="px-4 py-3"><span className="text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 px-1.5 py-0.5 rounded-md">{loc.radius}</span></td>
                  <td className="px-4 py-3 text-gray-500">{loc.employees}</td>
                  <td className="px-4 py-3">{loc.selfie ? <span className="text-[10px] font-bold text-green-700 bg-green-50 px-1.5 py-0.5 rounded-md border border-green-200">Required</span> : <span className="text-[10px] text-gray-400">—</span>}</td>
                  <td className="px-4 py-3"><span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${loc.status === "Active" ? "bg-green-50 text-green-700 border border-green-200" : "bg-gray-100 text-gray-500 border border-gray-200"}`}>{loc.status}</span></td>
                  <td className="px-4 py-3"><button onClick={() => setEditTarget(loc)} className="flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-700 font-medium cursor-pointer"><Edit2 size={11}/> Edit</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editTarget && <LocationFormDrawer location={editTarget === "new" ? null : editTarget} onClose={() => setEditTarget(null)}/>}
    </div>
  );
}

// ── MAIN PAGE ──────────────────────────────────────────────────────────────
export function SettingsPage() {
  const [active, setActive] = useState<SettingSection>("company");

  const renderSection = () => {
    switch (active) {
      case "company":       return <CompanySection />;
      case "branches":      return <BranchesSection />;
      case "geofence":      return <GeofenceSection />;
      case "attendance":    return <AttendanceSection />;
      case "schedules":     return <SchedulesSection />;
      case "payroll":       return <PayrollSection />;
      case "employees":     return <EmployeesSection />;
      case "sales":         return <SalesSection />;
      case "notifications": return <NotificationsSection />;
      case "permissions":   return <PermissionsSection />;
      case "integrations":  return <IntegrationsSection />;
      case "security":      return <SecuritySection />;
    }
  };

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* ── Settings Sub-nav ── */}
      <aside className="w-56 flex-shrink-0 bg-white border-r border-gray-100 overflow-y-auto py-3 px-2">
        <div className="px-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gray-800 rounded-lg flex items-center justify-center">
              <Settings size={12} className="text-white" />
            </div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">System Settings</p>
          </div>
        </div>
        <nav className="space-y-0.5">
          {sections.map(s => {
            const isActive = active === s.id;
            return (
              <button key={s.id} onClick={() => setActive(s.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all cursor-pointer ${
                  isActive ? "bg-blue-50" : "hover:bg-gray-50"
                }`}>
                <s.icon size={14} className={isActive ? "text-blue-600 flex-shrink-0" : "text-gray-400 flex-shrink-0"} />
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-semibold truncate ${isActive ? "text-blue-800" : "text-gray-700"}`}>{s.label}</p>
                  <p className="text-[9px] text-gray-400 truncate">{s.desc}</p>
                </div>
                {isActive && <div className="w-1.5 h-1.5 bg-blue-600 rounded-full flex-shrink-0" />}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* ── Section Content ── */}
      <main className="flex-1 overflow-y-auto px-6 py-5">
        {renderSection()}
        <div className="h-6" />
      </main>
    </div>
  );
}
