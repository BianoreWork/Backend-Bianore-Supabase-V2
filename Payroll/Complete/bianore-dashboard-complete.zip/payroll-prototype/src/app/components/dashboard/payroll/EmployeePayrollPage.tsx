import { useState } from "react";
import {
  Search, CheckCircle, AlertTriangle, X,
  Shield, CreditCard, Receipt, User,
  MoreHorizontal, RefreshCw, Download,
} from "lucide-react";
import { employeePayrollProfiles, fmtIDR, type EmployeePayrollProfile } from "./payrollMockData";

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600", "from-amber-500 to-orange-600",
];

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing:   "bg-pink-50 text-pink-700",
  Finance:     "bg-cyan-50 text-cyan-700",
  HR:          "bg-purple-50 text-purple-700",
  Operations:  "bg-orange-50 text-orange-700",
  Sales:       "bg-green-50 text-green-700",
};

const validationConfig = {
  validated:   { label: "Tervalidasi", bg: "bg-green-50 text-green-700",  icon: <CheckCircle size={11} className="text-green-600" /> },
  unvalidated: { label: "Belum Divalidasi", bg: "bg-amber-50 text-amber-700",  icon: <AlertTriangle size={11} className="text-amber-600" /> },
  invalid:     { label: "Invalid", bg: "bg-red-50 text-red-600",      icon: <AlertTriangle size={11} className="text-red-500" /> },
};

function ProfileDrawer({ emp, onClose }: { emp: EmployeePayrollProfile; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<"profile" | "bank" | "tax" | "bpjs">("profile");
  const gradIdx = emp.employeeId.charCodeAt(emp.employeeId.length - 1) % avatarGradients.length;
  const grad    = avatarGradients[gradIdx];
  const dc      = deptColors[emp.dept] || "bg-gray-100 text-gray-600";

  const tabs = [
    { id: "profile" as const, label: "Profil Payroll", icon: <User size={13} /> },
    { id: "bank"    as const, label: "Rekening Bank",  icon: <CreditCard size={13} /> },
    { id: "tax"     as const, label: "Profil Pajak",   icon: <Receipt size={13} /> },
    { id: "bpjs"    as const, label: "Profil BPJS",    icon: <Shield size={13} /> },
  ];

  const bpjsPrograms = [
    { label: "BPJS Kesehatan",          active: emp.bpjsKesehatanActive,         number: emp.bpjsKesehatanNumber },
    { label: "JHT",                     active: emp.jhtActive,                   number: emp.bpjsKetenagakerjaanNumber },
    { label: "JP (Jaminan Pensiun)",    active: emp.jpActive,                    number: emp.bpjsKetenagakerjaanNumber },
    { label: "JKK (Kec. Kerja)",        active: emp.jkkActive,                   number: null },
    { label: "JKM (Kematian)",          active: emp.jkmActive,                   number: null },
  ];

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full w-[520px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}>
              {emp.avatar}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-bold text-gray-900">{emp.name}</p>
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                  emp.payrollStatus === "active" ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-500"
                }`}>
                  {emp.payrollStatus === "active" ? "Aktif" : "Nonaktif"}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>{emp.dept}</span>
                <span className="text-[10px] text-gray-400">{emp.position}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><X size={16} /></button>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-0 px-5 border-b border-gray-100 flex-shrink-0 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-3 text-xs font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          {/* Profile tab */}
          {activeTab === "profile" && (
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4">
                <p className="text-xs text-blue-100">Gaji Pokok</p>
                <p className="text-2xl font-bold text-white mt-0.5">{fmtIDR(emp.baseSalary)}</p>
                <p className="text-xs text-blue-200 mt-1">{emp.salaryType === "monthly" ? "Per bulan" : "Per hari"}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                {[
                  { label: "ID Karyawan",         value: emp.employeeId },
                  { label: "Tipe Gaji",            value: emp.salaryType === "monthly" ? "Bulanan" : "Harian" },
                  { label: "Metode Pembayaran",    value: emp.paymentMethod === "bank_transfer" ? "Transfer Bank" : "Tunai" },
                  { label: "Eligible Lembur",      value: emp.overtimeEligible ? "Ya" : "Tidak" },
                  { label: "Potongan Absensi",     value: emp.attendanceDeductionEnabled ? "Aktif" : "Nonaktif" },
                  { label: "Potong Pajak (PPh21)", value: emp.taxEnabled ? "Aktif" : "Nonaktif" },
                  { label: "Potong BPJS",          value: emp.bpjsEnabled ? "Aktif" : "Nonaktif" },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-center justify-between py-0.5">
                    <span className="text-xs text-gray-500">{label}</span>
                    <span className="text-xs font-semibold text-gray-800">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bank tab */}
          {activeTab === "bank" && (
            <div className="space-y-3">
              {emp.bankName ? (
                <>
                  <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border ${
                    emp.bankValidationStatus === "validated"   ? "bg-green-50 border-green-200" :
                    emp.bankValidationStatus === "invalid"     ? "bg-red-50 border-red-200" :
                    "bg-amber-50 border-amber-200"
                  }`}>
                    {validationConfig[emp.bankValidationStatus].icon}
                    <div>
                      <p className={`text-xs font-semibold ${
                        emp.bankValidationStatus === "validated" ? "text-green-800" :
                        emp.bankValidationStatus === "invalid"   ? "text-red-700" :
                        "text-amber-800"
                      }`}>
                        {validationConfig[emp.bankValidationStatus].label}
                      </p>
                      <p className={`text-[10px] ${
                        emp.bankValidationStatus === "validated" ? "text-green-600" :
                        emp.bankValidationStatus === "invalid"   ? "text-red-600" :
                        "text-amber-600"
                      }`}>
                        {emp.bankValidationStatus === "validated"
                          ? "Rekening telah terverifikasi"
                          : emp.bankValidationStatus === "invalid"
                          ? "Rekening tidak valid — perlu diperbarui"
                          : "Rekening belum diverifikasi — validasi sebelum disbursement"}
                      </p>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                    {[
                      { label: "Bank",           value: emp.bankName },
                      { label: "Kode Bank",      value: emp.bankCode },
                      { label: "No. Rekening",   value: emp.accountNumber },
                      { label: "Nama Pemegang",  value: emp.accountHolderName },
                    ].map(({ label, value }) => (
                      <div key={label} className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{label}</span>
                        <span className={`text-xs font-semibold text-gray-800 ${label === "No. Rekening" ? "font-mono" : ""}`}>{value}</span>
                      </div>
                    ))}
                  </div>
                  <button className="w-full flex items-center justify-center gap-2 text-xs text-blue-600 border border-blue-200 hover:bg-blue-50 py-2.5 rounded-xl cursor-pointer transition-colors font-medium">
                    <RefreshCw size={12} /> Validasi Ulang Rekening
                  </button>
                </>
              ) : (
                <div className="py-12 text-center">
                  <CreditCard size={32} className="text-gray-200 mx-auto mb-3" />
                  <p className="text-sm text-gray-400">Belum ada rekening bank</p>
                  <button className="mt-3 text-xs text-blue-600 font-medium cursor-pointer hover:text-blue-800">Tambah Rekening</button>
                </div>
              )}
            </div>
          )}

          {/* Tax tab */}
          {activeTab === "tax" && (
            <div className="space-y-3">
              {emp.taxEnabled ? (
                <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                  {[
                    { label: "NIK",              value: emp.nik || "—" },
                    { label: "NPWP",             value: emp.npwp || "Belum ada NPWP" },
                    { label: "Status PTKP",      value: emp.ptkpStatus || "—" },
                    { label: "Metode Pajak",     value: emp.taxMethod === "gross" ? "Gross (dipotong karyawan)" : emp.taxMethod === "nett" ? "Nett (ditanggung perusahaan)" : "Gross Up" },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{label}</span>
                      <span className={`text-xs font-semibold ${!emp.npwp && label === "NPWP" ? "text-red-500" : "text-gray-800"}`}>{value}</span>
                    </div>
                  ))}
                  {!emp.npwp && (
                    <div className="flex items-start gap-2 pt-2 border-t border-gray-200">
                      <AlertTriangle size={12} className="text-amber-500 flex-shrink-0 mt-0.5" />
                      <p className="text-[10px] text-amber-700">NPWP belum diisi — karyawan akan dikenakan tarif pajak lebih tinggi (120%)</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-gray-50 rounded-xl p-4 flex items-center gap-2">
                  <AlertTriangle size={13} className="text-gray-400" />
                  <p className="text-xs text-gray-500">Pemotongan PPh21 nonaktif untuk karyawan ini</p>
                </div>
              )}
            </div>
          )}

          {/* BPJS tab */}
          {activeTab === "bpjs" && (
            <div className="space-y-3">
              {bpjsPrograms.map((prog) => (
                <div key={prog.label} className={`flex items-center justify-between p-3 rounded-xl border ${prog.active ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"}`}>
                  <div className="flex items-center gap-2.5">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center ${prog.active ? "bg-green-500" : "bg-gray-300"}`}>
                      {prog.active
                        ? <CheckCircle size={13} className="text-white" />
                        : <X size={13} className="text-white" />}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-800">{prog.label}</p>
                      {prog.number && <p className="text-[10px] text-gray-400 font-mono">{prog.number}</p>}
                    </div>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${prog.active ? "text-green-700 bg-green-100" : "text-gray-400 bg-gray-200"}`}>
                    {prog.active ? "Aktif" : "Nonaktif"}
                  </span>
                </div>
              ))}
              <div className="bg-blue-50 rounded-xl p-3 flex items-start gap-2">
                <Shield size={12} className="text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-[10px] text-blue-700">Iuran dihitung otomatis berdasarkan tarif BPJS yang berlaku saat tanggal bayar</p>
              </div>
            </div>
          )}
        </div>

        {/* Bottom actions */}
        <div className="flex items-center gap-2 px-5 py-3.5 border-t border-gray-100 bg-white flex-shrink-0">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
            <Download size={12} /> Export Data
          </button>
          <div className="flex-1" />
          <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
            Simpan Perubahan
          </button>
        </div>
      </div>
    </>
  );
}

export function EmployeePayrollPage() {
  const [search, setSearch]   = useState("");
  const [selected, setSelected] = useState<EmployeePayrollProfile | null>(null);

  const filtered = employeePayrollProfiles.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.dept.toLowerCase().includes(search.toLowerCase()) ||
    e.position.toLowerCase().includes(search.toLowerCase())
  );

  const issues = employeePayrollProfiles.filter((e) =>
    e.bankValidationStatus !== "validated" || !e.npwp || !e.taxEnabled
  ).length;

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Data Payroll Karyawan</h1>
          <p className="text-sm text-gray-500 mt-0.5">Profil payroll, rekening bank, profil pajak, dan BPJS karyawan</p>
        </div>
        <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
          <Download size={13} className="text-gray-400" /> Export
        </button>
      </div>

      {/* Summary */}
      <div className="flex items-center gap-3 flex-wrap">
        {[
          { label: "Total Karyawan", value: employeePayrollProfiles.length, color: "bg-blue-50 text-blue-700" },
          { label: "Rekening Tervalidasi", value: employeePayrollProfiles.filter((e) => e.bankValidationStatus === "validated").length, color: "bg-green-50 text-green-700" },
          { label: "Perlu Perhatian", value: issues, color: "bg-amber-50 text-amber-700" },
          { label: "BPJS Aktif", value: employeePayrollProfiles.filter((e) => e.bpjsKesehatanActive).length, color: "bg-purple-50 text-purple-700" },
        ].map((c) => (
          <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
            <span className="opacity-60">{c.label}: </span>{c.value}
          </div>
        ))}
      </div>

      {/* Table card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Cari karyawan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-52 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Search size={12} />
            {filtered.length} karyawan
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                {["Karyawan", "Dept", "Tipe Gaji", "Gaji Pokok", "Rekening Bank", "Status PTKP", "BPJS", "Perlu Perhatian", ""].map((col) => (
                  <th key={col} className="text-left px-4 py-3">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((emp, idx) => {
                const vc  = validationConfig[emp.bankValidationStatus];
                const dc  = deptColors[emp.dept] || "bg-gray-100 text-gray-600";
                const gradIdx = emp.employeeId.charCodeAt(emp.employeeId.length - 1) % avatarGradients.length;
                const grad    = avatarGradients[gradIdx];
                const hasIssue = emp.bankValidationStatus !== "validated" || !emp.npwp;
                return (
                  <tr
                    key={emp.employeeId}
                    onClick={() => setSelected(emp)}
                    className={`border-b border-gray-50 cursor-pointer hover:bg-blue-50/20 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}
                  >
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                          {emp.avatar}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-800">{emp.name}</p>
                          <p className="text-[10px] text-gray-400">{emp.position}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${dc}`}>{emp.dept}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-600 capitalize">{emp.salaryType}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(emp.baseSalary)}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        {vc.icon}
                        <div>
                          <p className="text-xs text-gray-700">{emp.bankName || "—"}</p>
                          <p className="text-[10px] text-gray-400 font-mono">{emp.accountNumber || "—"}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-700">{emp.ptkpStatus || "—"}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      {emp.bpjsKesehatanActive
                        ? <CheckCircle size={14} className="text-green-500" />
                        : <X size={14} className="text-gray-300" />}
                    </td>
                    <td className="px-4 py-3.5">
                      {hasIssue
                        ? <span className="inline-flex items-center gap-1 text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full font-semibold">
                            <AlertTriangle size={9} /> Perhatian
                          </span>
                        : <span className="text-gray-200 text-sm">—</span>
                      }
                    </td>
                    <td className="px-4 py-3.5">
                      <button className="p-1.5 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors">
                        <MoreHorizontal size={14} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="px-5 py-3 border-t border-gray-100">
          <p className="text-xs text-gray-400">{filtered.length} dari {employeePayrollProfiles.length} karyawan</p>
        </div>
      </div>

      <div className="h-4" />
      {selected && <ProfileDrawer emp={selected} onClose={() => setSelected(null)} />}
    </main>
  );
}
