import { useState } from "react";
import {
  CreditCard, CheckCircle, AlertTriangle, X,
  RefreshCw, Download, ChevronRight, Send,
  Clock, MoreHorizontal,
} from "lucide-react";
import { paymentBatches, paymentItems, fmtIDR, fmtIDRShort, type PaymentBatch } from "./payrollMockData";

const batchStatusConfig = {
  pending:    { label: "Menunggu",     bg: "bg-gray-100",   text: "text-gray-600",   dot: "bg-gray-400" },
  validating: { label: "Validasi",     bg: "bg-sky-50",     text: "text-sky-700",    dot: "bg-sky-400" },
  processing: { label: "Proses Bayar", bg: "bg-indigo-50",  text: "text-indigo-700", dot: "bg-indigo-500" },
  success:    { label: "Berhasil",     bg: "bg-green-50",   text: "text-green-700",  dot: "bg-green-500" },
  partial:    { label: "Sebagian",     bg: "bg-orange-50",  text: "text-orange-700", dot: "bg-orange-500" },
  failed:     { label: "Gagal",        bg: "bg-red-50",     text: "text-red-600",    dot: "bg-red-500" },
};

const itemStatusConfig = {
  pending:     { label: "Menunggu",   bg: "bg-gray-100",   text: "text-gray-600" },
  validating:  { label: "Validasi",   bg: "bg-sky-50",     text: "text-sky-700"  },
  processing:  { label: "Proses",     bg: "bg-indigo-50",  text: "text-indigo-700" },
  success:     { label: "Berhasil",   bg: "bg-green-50",   text: "text-green-700" },
  failed:      { label: "Gagal",      bg: "bg-red-50",     text: "text-red-600"  },
  retried:     { label: "Retry",      bg: "bg-amber-50",   text: "text-amber-700" },
  reversed:    { label: "Reversed",   bg: "bg-gray-100",   text: "text-gray-500" },
  manual_paid: { label: "Manual",     bg: "bg-teal-50",    text: "text-teal-700"  },
};

const providerBadge: Record<string, { label: string; bg: string; text: string }> = {
  brick:    { label: "Brick",    bg: "bg-blue-50",   text: "text-blue-700"  },
  oy:       { label: "OY!",     bg: "bg-green-50",  text: "text-green-700" },
  xendit:   { label: "Xendit",  bg: "bg-violet-50", text: "text-violet-700"},
  doku:     { label: "DOKU",    bg: "bg-amber-50",  text: "text-amber-700" },
  manual:   { label: "Manual",  bg: "bg-gray-100",  text: "text-gray-600"  },
  bank_file:{ label: "Bank File",bg: "bg-cyan-50",  text: "text-cyan-700"  },
  bank_api: { label: "Bank API",bg: "bg-teal-50",   text: "text-teal-700"  },
};

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600",
];

// ── Batch Detail Drawer ───────────────────────────────────────────────────────
function BatchDetailDrawer({ batch, onClose }: { batch: PaymentBatch; onClose: () => void }) {
  const sc = batchStatusConfig[batch.status];
  const pb = providerBadge[batch.provider];
  const items = paymentItems.filter((pi) => pi.batchId === batch.id);

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full w-[560px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <p className="text-sm font-bold text-gray-900 font-mono">{batch.batchCode}</p>
              <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                {sc.label}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">{batch.payrollRunName}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><X size={16} /></button>
        </div>

        {/* Summary */}
        <div className="px-5 py-4 border-b border-gray-100 flex-shrink-0">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-blue-100">Total Disbursement</p>
                <p className="text-lg font-bold text-white mt-0.5">{fmtIDRShort(batch.totalAmount)}</p>
              </div>
              <div>
                <p className="text-xs text-blue-100">Total Karyawan</p>
                <p className="text-lg font-bold text-white mt-0.5">{batch.totalEmployees}</p>
              </div>
              <div>
                <p className="text-xs text-blue-100">Provider</p>
                <p className="text-sm font-bold text-white mt-0.5">{pb?.label}</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 mt-3">
            <div className="bg-green-50 rounded-xl p-3 text-center">
              <p className="text-lg font-bold text-green-700">{batch.successCount}</p>
              <p className="text-[10px] text-green-600 font-semibold uppercase tracking-wider">Berhasil</p>
            </div>
            <div className="bg-red-50 rounded-xl p-3 text-center">
              <p className="text-lg font-bold text-red-600">{batch.failedCount}</p>
              <p className="text-[10px] text-red-500 font-semibold uppercase tracking-wider">Gagal</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-3 text-center">
              <p className="text-lg font-bold text-gray-600">{batch.pendingCount}</p>
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">Pending</p>
            </div>
          </div>
        </div>

        {/* Payment items */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          <p className="text-xs font-semibold text-gray-700 mb-3">Detail Pembayaran</p>
          {items.length === 0 ? (
            <div className="py-8 text-center">
              <CreditCard size={28} className="text-gray-200 mx-auto mb-2" />
              <p className="text-xs text-gray-400">Preview — lihat detail di dashboard batch</p>
            </div>
          ) : (
            <div className="space-y-2">
              {items.map((item, idx) => {
                const isc  = itemStatusConfig[item.status];
                const grad = avatarGradients[idx % avatarGradients.length];
                return (
                  <div key={item.id} className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${
                    item.status === "failed" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-200"
                  }`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                        {item.avatar}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{item.employeeName}</p>
                        <p className="text-[10px] text-gray-400 font-mono">{item.bankName} {item.accountNumber}</p>
                        {item.failureReason && (
                          <p className="text-[10px] text-red-600 mt-0.5 flex items-center gap-1">
                            <AlertTriangle size={8} /> {item.failureReason}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(item.amount)}</p>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${isc.bg} ${isc.text}`}>{isc.label}</span>
                      {item.status === "failed" && (
                        <button className="text-[10px] text-blue-600 border border-blue-200 hover:bg-blue-50 px-2 py-1 rounded-lg cursor-pointer font-medium">
                          Retry
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Bottom actions */}
        <div className="flex items-center gap-2 px-5 py-3.5 border-t border-gray-100 flex-shrink-0">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
            <Download size={12} /> Export File Bank
          </button>
          <div className="flex-1" />
          {batch.status === "pending" && (
            <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
              <Send size={12} /> Kirim ke Provider
            </button>
          )}
          {batch.failedCount > 0 && (
            <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 px-4 py-2 rounded-lg cursor-pointer">
              <RefreshCw size={12} /> Retry Gagal ({batch.failedCount})
            </button>
          )}
        </div>
      </div>
    </>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export function PaymentPage() {
  const [selected, setSelected] = useState<PaymentBatch | null>(null);

  const totalSuccess = paymentBatches.reduce((s, b) => s + (b.status === "success" ? b.totalAmount : 0), 0);
  const totalFailed  = paymentBatches.reduce((s, b) => s + (b.failedCount > 0 ? 38_000_000 : 0), 0);

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Disbursement</h1>
          <p className="text-sm text-gray-500 mt-0.5">Kelola batch pembayaran gaji — via Brick, OY!, Xendit, atau Bank File</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
            <Download size={13} className="text-gray-400" /> Export Rekap
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="flex items-center gap-3 flex-wrap">
        {[
          { label: "Total Dibayarkan (YTD)", value: fmtIDRShort(totalSuccess), color: "bg-green-50 text-green-700" },
          { label: "Gagal / Pending Retry", value: fmtIDRShort(totalFailed), color: "bg-red-50 text-red-600" },
          { label: "Batch Berhasil", value: `${paymentBatches.filter((b) => b.status === "success").length} batch`, color: "bg-blue-50 text-blue-700" },
          { label: "Provider Aktif", value: "Brick", color: "bg-violet-50 text-violet-700" },
        ].map((c) => (
          <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
            <span className="opacity-60">{c.label}: </span>{c.value}
          </div>
        ))}
      </div>

      {/* Batch list */}
      <div className="space-y-3">
        {paymentBatches.map((batch) => {
          const sc = batchStatusConfig[batch.status];
          const pb = providerBadge[batch.provider];
          const progressPct = batch.totalEmployees > 0
            ? Math.round((batch.successCount / batch.totalEmployees) * 100)
            : 0;
          return (
            <div
              key={batch.id}
              onClick={() => setSelected(batch)}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md hover:border-blue-200 transition-all duration-200 cursor-pointer overflow-hidden"
            >
              <div className="flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CreditCard size={18} className="text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-bold text-gray-900 font-mono">{batch.batchCode}</p>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${pb?.bg} ${pb?.text}`}>{pb?.label}</span>
                      <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{batch.payrollRunName}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 flex-shrink-0">
                  <div className="text-right">
                    <p className="text-sm font-bold text-gray-900 tabular-nums">{fmtIDRShort(batch.totalAmount)}</p>
                    <p className="text-xs text-gray-400">{batch.totalEmployees} karyawan</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-green-700">{batch.successCount} ✓</span>
                      {batch.failedCount > 0 && (
                        <span className="text-xs font-semibold text-red-600">{batch.failedCount} ✗</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400">{batch.submittedAt?.slice(0, 10)}</p>
                  </div>
                  <ChevronRight size={16} className="text-gray-300" />
                </div>
              </div>

              {/* Progress bar */}
              {batch.totalEmployees > 0 && (
                <div className="px-5 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          batch.failedCount > 0 ? "bg-gradient-to-r from-green-500 to-orange-400" : "bg-green-500"
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-gray-500 flex-shrink-0">{progressPct}% berhasil</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Provider info */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Konfigurasi Provider Pembayaran</h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {[
            { name: "Brick", status: "active",   desc: "Disbursement aktif — untuk payroll utama", color: "bg-blue-600" },
            { name: "OY!",   status: "inactive", desc: "Provider cadangan — belum dikonfigurasi",  color: "bg-green-500" },
            { name: "Xendit",status: "inactive", desc: "Provider alternatif — belum dikonfigurasi", color: "bg-violet-500" },
          ].map((p) => (
            <div key={p.name} className={`border rounded-xl p-4 ${p.status === "active" ? "border-blue-200 bg-blue-50/50" : "border-gray-200"}`}>
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-6 h-6 ${p.color} rounded-lg flex items-center justify-center`}>
                  <CreditCard size={12} className="text-white" />
                </div>
                <p className="text-xs font-bold text-gray-800">{p.name}</p>
                {p.status === "active" && (
                  <span className="text-[10px] font-semibold text-green-700 bg-green-50 px-1.5 py-0.5 rounded-full ml-auto">Aktif</span>
                )}
              </div>
              <p className="text-[10px] text-gray-500">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="h-4" />
      {selected && <BatchDetailDrawer batch={selected} onClose={() => setSelected(null)} />}
    </main>
  );
}
