import { useState } from "react";
import {
  Settings, CheckCircle, X, Plus, Edit3,
  CreditCard, Shield, RefreshCw, Bell, Save,
} from "lucide-react";

type SettingsTab = "general" | "approval" | "provider" | "notifications";

const approvalSteps = [
  { id: 1, order: 1, role: "HR Manager", type: "single", required: true },
  { id: 2, order: 2, role: "Finance Director", type: "single", required: true },
  { id: 3, order: 3, role: "CEO / Owner", type: "single", required: false },
];

const providers = [
  { id: "brick",  name: "Brick",   logo: "🏦", status: "active",   description: "Disbursement API — terhubung aktif", apiKey: "brk_live_****8a2f" },
  { id: "oy",     name: "OY!",     logo: "💚", status: "inactive", description: "Belum dikonfigurasi", apiKey: "" },
  { id: "xendit", name: "Xendit",  logo: "💜", status: "inactive", description: "Belum dikonfigurasi", apiKey: "" },
  { id: "manual", name: "Manual",  logo: "📋", status: "inactive", description: "Upload file atau input manual", apiKey: "" },
];

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
      {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
    </div>
  );
}

function FormField({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-700 mb-1.5">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
    </div>
  );
}

export function PayrollSettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>("general");
  const [saved, setSaved] = useState(false);

  const [generalSettings, setGeneral] = useState({
    companyName: "PT Bianore Indonesia",
    taxId: "01.234.567.8-999.000",
    payrollDay: "5",
    cutoffDay: "last",
    prorationMethod: "calendar_days",
    overtimeMultiplier: "1.5",
    lateMinThreshold: "15",
    autoCalculate: true,
    requireLockBeforePayment: true,
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Pengaturan Payroll</h1>
          <p className="text-sm text-gray-500 mt-0.5">Konfigurasi umum, approval flow, dan provider pembayaran</p>
        </div>
        <button
          onClick={handleSave}
          className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg cursor-pointer transition-all ${
            saved ? "text-white bg-green-600" : "text-white bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {saved ? <><CheckCircle size={13} /> Tersimpan!</> : <><Save size={13} /> Simpan Pengaturan</>}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {([
          { id: "general"       as SettingsTab, label: "Umum",           icon: <Settings size={13} /> },
          { id: "approval"      as SettingsTab, label: "Approval Flow",  icon: <Shield size={13} /> },
          { id: "provider"      as SettingsTab, label: "Provider Bayar", icon: <CreditCard size={13} /> },
          { id: "notifications" as SettingsTab, label: "Notifikasi",     icon: <Bell size={13} /> },
        ]).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* ── GENERAL ── */}
      {activeTab === "general" && (
        <div className="space-y-5">
          {/* Company info */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <SectionHeader title="Informasi Perusahaan" subtitle="Data perusahaan untuk penghitungan pajak dan payslip" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <FormField label="Nama Perusahaan" required>
                <input
                  value={generalSettings.companyName}
                  onChange={(e) => setGeneral({ ...generalSettings, companyName: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all"
                />
              </FormField>
              <FormField label="NPWP Perusahaan" required>
                <input
                  value={generalSettings.taxId}
                  onChange={(e) => setGeneral({ ...generalSettings, taxId: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all font-mono"
                />
              </FormField>
            </div>
          </div>

          {/* Payroll schedule */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <SectionHeader title="Jadwal & Periode" subtitle="Hari bayar gaji dan cutoff absensi" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <FormField label="Tanggal Bayar Gaji" required>
                <select
                  value={generalSettings.payrollDay}
                  onChange={(e) => setGeneral({ ...generalSettings, payrollDay: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  {[1, 5, 10, 15, 20, 25, 28].map((d) => (
                    <option key={d} value={String(d)}>Tanggal {d}</option>
                  ))}
                </select>
              </FormField>
              <FormField label="Cutoff Absensi" required>
                <select
                  value={generalSettings.cutoffDay}
                  onChange={(e) => setGeneral({ ...generalSettings, cutoffDay: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="last">Akhir Bulan</option>
                  {[25, 26, 27, 28].map((d) => <option key={d} value={String(d)}>Tanggal {d}</option>)}
                </select>
              </FormField>
              <FormField label="Metode Prorate" required>
                <select
                  value={generalSettings.prorationMethod}
                  onChange={(e) => setGeneral({ ...generalSettings, prorationMethod: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="calendar_days">Hari Kalender</option>
                  <option value="working_days">Hari Kerja</option>
                </select>
              </FormField>
            </div>
          </div>

          {/* Overtime & late */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <SectionHeader title="Lembur & Keterlambatan" subtitle="Pengaturan perhitungan lembur dan toleransi keterlambatan" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <FormField label="Multiplier Lembur (Hari Kerja)">
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.5"
                    value={generalSettings.overtimeMultiplier}
                    onChange={(e) => setGeneral({ ...generalSettings, overtimeMultiplier: e.target.value })}
                    className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all"
                  />
                  <span className="text-xs text-gray-500">× upah per jam</span>
                </div>
              </FormField>
              <FormField label="Toleransi Terlambat (menit)">
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={generalSettings.lateMinThreshold}
                    onChange={(e) => setGeneral({ ...generalSettings, lateMinThreshold: e.target.value })}
                    className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all"
                  />
                  <span className="text-xs text-gray-500">menit</span>
                </div>
              </FormField>
            </div>
          </div>

          {/* Toggles */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <SectionHeader title="Pengaturan Lanjutan" />
            <div className="space-y-4">
              {[
                { key: "autoCalculate",          label: "Hitung Otomatis",           desc: "Kalkulasi gaji otomatis dijalankan setiap awal bulan" },
                { key: "requireLockBeforePayment", label: "Wajib Lock Sebelum Bayar", desc: "Payroll run harus dikunci sebelum batch pembayaran dibuat" },
              ].map(({ key, label, desc }) => {
                const val = generalSettings[key as keyof typeof generalSettings] as boolean;
                return (
                  <div key={key} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                    <div>
                      <p className="text-xs font-semibold text-gray-700">{label}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{desc}</p>
                    </div>
                    <button
                      onClick={() => setGeneral({ ...generalSettings, [key]: !val })}
                      className={`w-10 h-5 rounded-full transition-colors flex items-center px-0.5 cursor-pointer flex-shrink-0 ${val ? "bg-blue-600" : "bg-gray-300"}`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full shadow transition-transform ${val ? "translate-x-5" : "translate-x-0"}`} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── APPROVAL FLOW ── */}
      {activeTab === "approval" && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <SectionHeader title="Alur Approval Payroll" subtitle="Urutan approver sebelum payroll dapat diproses" />
              <button className="flex items-center gap-1.5 text-xs text-blue-600 border border-blue-200 hover:bg-blue-50 px-3 py-1.5 rounded-lg cursor-pointer font-medium">
                <Plus size={12} /> Tambah Step
              </button>
            </div>
            <div className="space-y-3">
              {approvalSteps.map((step, idx) => (
                <div key={step.id} className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {step.order}
                  </div>
                  <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-gray-800">{step.role}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] text-gray-500">
                          Tipe: {step.type === "single" ? "Satu Approver" : "Semua Approver"}
                        </span>
                        {step.required
                          ? <span className="text-[10px] text-red-600 font-semibold bg-red-50 px-1.5 py-0.5 rounded">Wajib</span>
                          : <span className="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">Opsional</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 rounded-lg hover:bg-gray-200 text-gray-400 cursor-pointer"><Edit3 size={13} /></button>
                      {!step.required && (
                        <button className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 cursor-pointer"><X size={13} /></button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-2 text-[10px] text-gray-500 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2">
              <Shield size={11} className="text-blue-500" />
              Perubahan alur approval akan berlaku mulai payroll run berikutnya
            </div>
          </div>
        </div>
      )}

      {/* ── PAYMENT PROVIDER ── */}
      {activeTab === "provider" && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-xs text-amber-800 flex items-center gap-2">
            <CreditCard size={13} className="text-amber-600 flex-shrink-0" />
            Hanya satu provider yang dapat aktif sekaligus untuk disbursement gaji
          </div>
          {providers.map((p) => (
            <div key={p.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden ${p.status === "active" ? "border-blue-300" : "border-gray-100"}`}>
              <div className="flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">{p.logo}</div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-gray-800">{p.name}</p>
                      {p.status === "active" && (
                        <span className="text-[10px] font-semibold text-green-700 bg-green-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <CheckCircle size={9} /> Aktif
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">{p.description}</p>
                    {p.apiKey && (
                      <p className="text-[10px] text-gray-400 font-mono mt-1">{p.apiKey}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {p.status === "active" ? (
                    <>
                      <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg cursor-pointer">
                        <RefreshCw size={12} /> Test Koneksi
                      </button>
                      <button className="flex items-center gap-1.5 text-xs text-blue-600 border border-blue-200 hover:bg-blue-50 px-3 py-1.5 rounded-lg cursor-pointer font-medium">
                        <Edit3 size={12} /> Edit
                      </button>
                    </>
                  ) : (
                    <button className="flex items-center gap-1.5 text-xs text-blue-600 border border-blue-200 hover:bg-blue-50 px-3 py-1.5 rounded-lg cursor-pointer font-medium">
                      <Plus size={12} /> Konfigurasi
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── NOTIFICATIONS ── */}
      {activeTab === "notifications" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <SectionHeader title="Notifikasi Payroll" subtitle="Konfigurasi pengiriman notifikasi ke HR, Finance, dan Karyawan" />
          <div className="space-y-4">
            {[
              { label: "Payroll Run Dibuat",          desc: "Notifikasi ke HR Manager ketika payroll run baru dibuat", channel: "Email + WhatsApp" },
              { label: "Submit untuk Approval",        desc: "Notifikasi ke approver berikutnya saat payroll disubmit", channel: "Email" },
              { label: "Payroll Disetujui",            desc: "Notifikasi ke Finance ketika payroll disetujui semua level", channel: "Email + WhatsApp" },
              { label: "Pembayaran Berhasil",          desc: "Notifikasi ke karyawan setelah gaji berhasil ditransfer", channel: "Email + WhatsApp" },
              { label: "Pembayaran Gagal",             desc: "Notifikasi ke Finance jika ada transfer yang gagal", channel: "Email + WhatsApp" },
              { label: "Payslip Tersedia",             desc: "Notifikasi ke karyawan ketika payslip sudah bisa diunduh", channel: "Email" },
            ].map((n) => (
              <div key={n.label} className="flex items-center justify-between py-2.5 border-b border-gray-100 last:border-0">
                <div>
                  <p className="text-xs font-semibold text-gray-700">{n.label}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{n.desc}</p>
                  <p className="text-[10px] text-blue-600 mt-0.5 flex items-center gap-1"><Bell size={9} /> {n.channel}</p>
                </div>
                <button className="w-10 h-5 rounded-full bg-blue-600 flex items-center px-0.5 cursor-pointer flex-shrink-0">
                  <div className="w-4 h-4 bg-white rounded-full shadow translate-x-5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="h-4" />
    </main>
  );
}
