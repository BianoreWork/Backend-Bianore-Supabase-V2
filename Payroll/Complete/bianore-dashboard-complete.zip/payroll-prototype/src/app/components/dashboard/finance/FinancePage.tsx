import { useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import {
  DollarSign, TrendingUp, TrendingDown, Minus, MoreHorizontal,
  Plus, Search, Download, Check, X, Receipt, CreditCard,
  Building2, FileText, Upload, CheckCircle, AlertTriangle,
  Wallet, ArrowUpRight, Clock, Send, RefreshCw, Eye, Filter,
  ChevronDown, Banknote, Landmark, PiggyBank, ReceiptText,
} from "lucide-react";
import {
  expenses as initExpenses, reimbursements as initReimbursements,
  loans as initLoans, payments as initPayments, invoices as initInvoices,
  deptBudgets, monthlyFinancial, expenseByCat, costByDept,
  expenseStatusCfg, reimburseStatusCfg, loanStatusCfg,
  paymentStatusCfg, invoiceStatusCfg, catCfg,
  type Expense, type ExpenseStatus, type Payment, type Invoice,
} from "./financeData";

// ── Constants ─────────────────────────────────────────────────────────────
const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";
const fmt  = (n: number) => `$${n.toLocaleString()}`;
const fmtK = (n: number) => n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${n}`;

const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

type FinanceTab = "overview" | "expenses" | "reimbursements" | "loans" | "payments" | "budget" | "invoices";
const tabs: { id: FinanceTab; label: string }[] = [
  { id: "overview",       label: "Overview"        },
  { id: "expenses",       label: "Expenses"        },
  { id: "reimbursements", label: "Reimbursements"  },
  { id: "loans",          label: "Loans"           },
  { id: "payments",       label: "Payments"        },
  { id: "budget",         label: "Budget"          },
  { id: "invoices",       label: "Invoices"        },
];

const inp = "text-xs text-gray-800 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-all";
const sel = `${inp} cursor-pointer appearance-none`;

// ── Shared components ─────────────────────────────────────────────────────
function CardHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      {action ?? (
        <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
          <MoreHorizontal size={15} />
        </button>
      )}
    </div>
  );
}

const avatarColors = ["bg-blue-500","bg-emerald-500","bg-violet-500","bg-amber-500","bg-rose-500","bg-cyan-500"];
function Avatar({ initials, idx, size = "md" }: { initials: string; idx: number; size?: "sm" | "md" }) {
  const dim = size === "sm" ? "w-7 h-7 text-[9px]" : "w-8 h-8 text-[10px]";
  return (
    <div className={`${dim} ${avatarColors[idx % avatarColors.length]} rounded-full flex items-center justify-center text-white font-bold flex-shrink-0`}>
      {initials}
    </div>
  );
}

function Badge({ label, cls }: { label: string; cls: string }) {
  return <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${cls}`}>{label}</span>;
}

function KpiCard({ label, value, trend, trendType, icon, iconBg, sub }: {
  label: string; value: string; trend: string; trendType: "up" | "down" | "neutral";
  icon: React.ReactNode; iconBg: string; sub?: string;
}) {
  const isUp = trendType === "up"; const isN = trendType === "neutral";
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
      <div className="flex items-start justify-between mb-2">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${iconBg}`}>{icon}</div>
        <span className={`flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
          isN ? "bg-gray-100 text-gray-500" : isUp ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"
        }`}>
          {isN ? <Minus size={8}/> : isUp ? <TrendingUp size={8}/> : <TrendingDown size={8}/>}
          {trend}
        </span>
      </div>
      <p className="text-2xl font-bold text-gray-900 tracking-tight mt-1">{value}</p>
      <p className="text-xs text-gray-500 mt-0.5">{label}</p>
      {sub && <p className="text-[10px] text-gray-400 mt-1.5 pt-1.5 border-t border-gray-50">{sub}</p>}
    </div>
  );
}

function EmptyState({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="w-10 h-10 bg-gray-100 rounded-2xl flex items-center justify-center mb-3 text-gray-400">{icon}</div>
      <p className="text-sm font-semibold text-gray-600">{title}</p>
      <p className="text-xs text-gray-400 mt-1">{desc}</p>
    </div>
  );
}

// ── Modal wrapper ─────────────────────────────────────────────────────────
function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: React.ReactNode; footer: React.ReactNode }) {
  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-bold text-gray-800">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer text-gray-400"><X size={15}/></button>
        </div>
        <div className="px-5 py-4 space-y-3">{children}</div>
        <div className="flex justify-end gap-2 px-5 py-4 border-t border-gray-50">{footer}</div>
      </div>
    </div>
  );
}

// ── 1. Overview Tab ───────────────────────────────────────────────────────
function OverviewTab() {
  return (
    <div className="space-y-5">
      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <KpiCard label="Total Payroll Cost"     value="$284.5k" trend="+3.2%" trendType="down" sub="vs $275k last month"
          icon={<DollarSign size={18}/>} iconBg="bg-blue-50 text-blue-600" />
        <KpiCard label="Total Expenses"         value="$42.8k"  trend="+8.1%" trendType="down" sub="14 claims this month"
          icon={<ReceiptText size={18}/>} iconBg="bg-amber-50 text-amber-600" />
        <KpiCard label="Reimbursements"         value="$12.35k" trend="-2.4%" trendType="up"  sub="7 items queued"
          icon={<Wallet size={18}/>} iconBg="bg-purple-50 text-purple-600" />
        <KpiCard label="Outstanding Payments"   value="$18.9k"  trend="0%"    trendType="neutral" sub="6 pending transfers"
          icon={<Clock size={18}/>} iconBg="bg-orange-50 text-orange-500" />
        <KpiCard label="Net Operational Cost"   value="$339.6k" trend="+2.8%" trendType="down" sub="vs $337k last month"
          icon={<TrendingUp size={18}/>} iconBg="bg-green-50 text-green-600" />
      </div>

      {/* Main chart + Summary side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className={`${cardClass} lg:col-span-2`}>
          <CardHeader title="Monthly Financial Trend" subtitle="Jan – May 2026 · Payroll, expenses & net cost" />
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyFinancial} margin={{ top: 4, right: 4, bottom: 0, left: -10 }}>
              <defs>
                {[["pay","#3b82f6"],["exp","#f59e0b"],["net","#10b981"]].map(([k,c]) => (
                  <linearGradient key={k} id={`fg-${k}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="10%" stopColor={c} stopOpacity={0.18}/>
                    <stop offset="90%" stopColor={c} stopOpacity={0}/>
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false}/>
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`}/>
              <Tooltip {...tooltipStyle} formatter={(v: number) => [`$${v.toLocaleString()}`, undefined]}/>
              <Legend wrapperStyle={{ fontSize: 10, paddingTop: 8 }}/>
              <Area type="monotone" dataKey="payroll"       name="Payroll"       stroke="#3b82f6" strokeWidth={2} fill="url(#fg-pay)" dot={false}/>
              <Area type="monotone" dataKey="expenses"      name="Expenses"      stroke="#f59e0b" strokeWidth={2} fill="url(#fg-exp)" dot={false}/>
              <Area type="monotone" dataKey="net"           name="Net Cost"      stroke="#10b981" strokeWidth={2} fill="url(#fg-net)" dot={false}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Summary breakdown */}
        <div className={cardClass}>
          <CardHeader title="May 2026 Summary" subtitle="Current month breakdown"/>
          <div className="space-y-3">
            {[
              { label: "Payroll Cost",   value: 284500, pct: 84, color: "#3b82f6" },
              { label: "Expenses",       value: 42800,  pct: 13, color: "#f59e0b" },
              { label: "Reimbursements", value: 12350,  pct:  4, color: "#8b5cf6" },
            ].map(r => (
              <div key={r.label}>
                <div className="flex justify-between mb-1">
                  <span className="text-[11px] text-gray-600 font-medium">{r.label}</span>
                  <span className="text-[11px] font-bold text-gray-800">{fmt(r.value)}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${r.pct}%`, backgroundColor: r.color }}/>
                </div>
                <p className="text-[9px] text-gray-400 mt-0.5">{r.pct}% of total</p>
              </div>
            ))}
            <div className="pt-3 border-t border-gray-50">
              <div className="flex justify-between">
                <span className="text-xs font-bold text-gray-700">Net Operational Cost</span>
                <span className="text-xs font-bold text-gray-900">$339,650</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Two charts side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Expense by category pie */}
        <div className={cardClass}>
          <CardHeader title="Expense Breakdown" subtitle="By category · May 2026"/>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={expenseByCat} cx="50%" cy="50%" innerRadius={38} outerRadius={60} paddingAngle={3} dataKey="value">
                  {expenseByCat.map((e, i) => <Cell key={i} fill={e.color}/>)}
                </Pie>
                <Tooltip {...tooltipStyle} formatter={(v: number) => [fmt(v), undefined]}/>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {expenseByCat.map(c => (
                <div key={c.name} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: c.color }}/>
                  <span className="text-[10px] text-gray-600 flex-1">{c.name}</span>
                  <span className="text-[10px] font-bold text-gray-800">{fmt(c.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Cost per department */}
        <div className={cardClass}>
          <CardHeader title="Cost per Department" subtitle="Payroll + expenses · May 2026"/>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={costByDept} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false}/>
              <XAxis dataKey="dept" tick={{ fontSize: 9, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize: 9, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`}/>
              <Tooltip {...tooltipStyle} formatter={(v: number) => [fmt(v), undefined]}/>
              <Bar dataKey="payroll"  name="Payroll"  fill="#3b82f6" radius={[3,3,0,0]} maxBarSize={28}/>
              <Bar dataKey="expenses" name="Expenses" fill="#f59e0b" radius={[3,3,0,0]} maxBarSize={28}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent activity */}
      <div className={cardClass}>
        <CardHeader title="Recent Financial Activity" subtitle="Latest transactions and actions"/>
        <div className="divide-y divide-gray-50">
          {[
            { icon: <ReceiptText size={13}/>, bg: "bg-amber-50 text-amber-600", label: "Expense submitted — Travel",     sub: "Robert Chen · $2,400",    time: "5m ago",  status: "pending"  },
            { icon: <CheckCircle size={13}/>,  bg: "bg-green-50 text-green-600",  label: "Expense approved — Software",    sub: "Alex Kumar · $1,200",     time: "1h ago",  status: "approved" },
            { icon: <Wallet size={13}/>,       bg: "bg-purple-50 text-purple-600",label: "Reimbursement queued",           sub: "Maria Santos · $3,200",   time: "3h ago",  status: "queued"   },
            { icon: <Banknote size={13}/>,     bg: "bg-blue-50 text-blue-600",    label: "Payroll payment scheduled",      sub: "8 employees · May 25",    time: "1d ago",  status: "pending"  },
            { icon: <FileText size={13}/>,     bg: "bg-cyan-50 text-cyan-600",    label: "Invoice sent — BuildFirst",      sub: "INV-2026-004 · $22,000",  time: "2d ago",  status: "overdue"  },
            { icon: <Landmark size={13}/>,     bg: "bg-rose-50 text-rose-600",    label: "Loan approved — Home Renovation",sub: "Alex Kumar · $5,000",     time: "5d ago",  status: "active"   },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 py-3 hover:bg-gray-50/50 transition-colors cursor-pointer">
              <div className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 ${item.bg}`}>{item.icon}</div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-gray-800">{item.label}</p>
                <p className="text-[10px] text-gray-400">{item.sub}</p>
              </div>
              <span className="text-[10px] text-gray-400 flex-shrink-0">{item.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── 2. Expenses Tab ───────────────────────────────────────────────────────
function SubmitExpenseModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (e: Partial<Expense>) => void }) {
  const [form, setForm] = useState({ category: "Travel", description: "", amount: "", date: "2026-05-05" });
  const u = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));
  return (
    <Modal title="Submit Expense Claim" onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-xs font-semibold px-4 py-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 cursor-pointer">Cancel</button>
        <button onClick={() => { onSubmit(form); onClose(); }} className="text-xs font-bold px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 cursor-pointer">Submit Claim</button>
      </>}>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Category</label>
        <select value={form.category} onChange={e => u("category", e.target.value)} className={`${sel} w-full`}>
          {["Travel","Meals","Office Supplies","Software","Marketing","Training","Other"].map(c => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Description</label>
        <input value={form.description} onChange={e => u("description", e.target.value)} className={`${inp} w-full`} placeholder="Describe the expense..." />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Amount ($)</label>
          <input type="number" value={form.amount} onChange={e => u("amount", e.target.value)} className={`${inp} w-full`} placeholder="0.00" />
        </div>
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Date</label>
          <input type="date" value={form.date} onChange={e => u("date", e.target.value)} className={`${inp} w-full`} />
        </div>
      </div>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Receipt Upload</label>
        <div className="border-2 border-dashed border-gray-200 rounded-xl p-4 text-center hover:border-blue-300 cursor-pointer transition-colors">
          <Upload size={16} className="mx-auto text-gray-400 mb-1.5"/>
          <p className="text-[11px] text-gray-500">Click to upload or drag & drop</p>
          <p className="text-[10px] text-gray-400 mt-0.5">PNG, JPG, PDF — max 5MB</p>
        </div>
      </div>
    </Modal>
  );
}

function ExpensesTab() {
  const [rows, setRows]       = useState(initExpenses);
  const [search, setSearch]   = useState("");
  const [filterCat, setCat]   = useState("All");
  const [filterSt, setSt]     = useState("All");
  const [showModal, setModal] = useState(false);

  const filtered = rows.filter(e => {
    const q = search.toLowerCase();
    return (
      (e.employee.name.toLowerCase().includes(q) || e.description.toLowerCase().includes(q)) &&
      (filterCat === "All" || e.category === filterCat) &&
      (filterSt  === "All" || e.status   === filterSt)
    );
  });

  const approve = (id: string) => setRows(r => r.map(e => e.id === id ? { ...e, status: "approved" as ExpenseStatus } : e));
  const reject  = (id: string) => setRows(r => r.map(e => e.id === id ? { ...e, status: "rejected" as ExpenseStatus } : e));

  const stats = {
    total:    rows.length,
    approved: rows.filter(e => e.status === "approved").length,
    pending:  rows.filter(e => e.status === "pending").length,
    amount:   rows.filter(e => e.status === "approved").reduce((a, e) => a + e.amount, 0),
  };

  return (
    <div className="space-y-5">
      {showModal && <SubmitExpenseModal onClose={() => setModal(false)} onSubmit={() => {}} />}

      {/* Stats mini-row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Claims",    value: stats.total,    suffix: "",  color: "text-gray-900", bg: "bg-gray-50 text-gray-500" },
          { label: "Approved",        value: stats.approved, suffix: "",  color: "text-green-700",bg: "bg-green-50 text-green-600"},
          { label: "Pending Review",  value: stats.pending,  suffix: "",  color: "text-amber-700",bg: "bg-amber-50 text-amber-600"},
          { label: "Approved Amount", value: stats.amount,   suffix: "$", color: "text-blue-700", bg: "bg-blue-50 text-blue-600" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className={`text-xl font-bold ${s.color}`}>{s.suffix === "$" ? fmt(s.value) : s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className={cardClass}>
        {/* toolbar */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-48">
            <Search size={13} className="text-gray-400 flex-shrink-0"/>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search expenses..." className="text-xs text-gray-700 outline-none flex-1 bg-transparent placeholder:text-gray-400"/>
          </div>
          <select value={filterCat} onChange={e => setCat(e.target.value)} className={`${sel} w-40`}>
            <option value="All">All Categories</option>
            {["Travel","Meals","Office Supplies","Software","Marketing","Training","Other"].map(c => <option key={c}>{c}</option>)}
          </select>
          <select value={filterSt} onChange={e => setSt(e.target.value)} className={`${sel} w-36`}>
            {["All","pending","approved","rejected"].map(s => <option key={s} value={s}>{s === "All" ? "All Status" : s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
          <button onClick={() => setModal(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl cursor-pointer transition-colors shadow-sm">
            <Plus size={13}/> Submit Expense
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-gray-100">
                {["Employee","Description","Category","Amount","Date","Status","Actions"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((e, i) => (
                <tr key={e.id} className="border-b border-gray-50 hover:bg-blue-50/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <Avatar initials={e.employee.avatar} idx={i} size="sm"/>
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{e.employee.name}</p>
                        <p className="text-[9px] text-gray-400">{e.employee.dept}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 max-w-[200px]">
                    <p className="text-xs text-gray-700 truncate">{e.description}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      {e.hasReceipt ? (
                        <span className="flex items-center gap-0.5 text-[9px] text-green-600"><Receipt size={9}/> Receipt</span>
                      ) : (
                        <span className="text-[9px] text-gray-300">No receipt</span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge label={e.category} cls={catCfg[e.category].cls}/>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-xs font-bold text-gray-900">{fmt(e.amount)}</p>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600">{e.date}</td>
                  <td className="px-4 py-3">
                    <Badge label={expenseStatusCfg[e.status].label} cls={expenseStatusCfg[e.status].cls}/>
                  </td>
                  <td className="px-4 py-3">
                    {e.status === "pending" ? (
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => approve(e.id)}
                          className="flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">
                          <Check size={10}/> Approve
                        </button>
                        <button onClick={() => reject(e.id)}
                          className="flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 hover:bg-red-100 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">
                          <X size={10}/> Reject
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] text-gray-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState icon={<ReceiptText size={18}/>} title="No expenses found" desc="Try adjusting your search or filter."/>}
        </div>
      </div>
    </div>
  );
}

// ── 3. Reimbursements Tab ─────────────────────────────────────────────────
function ReimbursementsTab() {
  const [rows, setRows] = useState(initReimbursements);
  const total = rows.reduce((a, r) => a + r.amount, 0);
  const queued = rows.filter(r => r.status === "queued").reduce((a, r) => a + r.amount, 0);

  const toggleMethod = (id: string) =>
    setRows(r => r.map(x => x.id === id ? { ...x, method: x.method === "in_payroll" ? "separate" : "in_payroll" } : x));
  const processRow = (id: string) =>
    setRows(r => r.map(x => x.id === id && x.status === "queued" ? { ...x, status: "processing" } : x));

  return (
    <div className="space-y-5">
      {/* Summary row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Reimbursable",  value: fmt(total),                                   cls: "text-gray-900"   },
          { label: "Queued for Payment",  value: fmt(queued),                                  cls: "text-amber-700"  },
          { label: "Processed This Month",value: fmt(rows.filter(r=>r.status==="paid").reduce((a,r)=>a+r.amount,0)), cls: "text-green-700" },
          { label: "Linked to Payroll",   value: fmt(rows.filter(r=>r.method==="in_payroll").reduce((a,r)=>a+r.amount,0)), cls: "text-blue-700"  },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className={`text-xl font-bold ${s.cls}`}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className={cardClass}>
        <CardHeader title="Reimbursement Queue" subtitle="Approved expenses awaiting payment processing"/>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px]">
            <thead>
              <tr className="border-b border-gray-100">
                {["Employee","Expense","Category","Amount","Approved","Status","Payment Method","Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.id} className="border-b border-gray-50 hover:bg-blue-50/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <Avatar initials={r.employee.avatar} idx={i} size="sm"/>
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{r.employee.name}</p>
                        <p className="text-[9px] text-gray-400">{r.employee.dept}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-[10px] text-gray-400">{r.expenseId}</td>
                  <td className="px-4 py-3"><Badge label={r.category} cls={catCfg[r.category].cls}/></td>
                  <td className="px-4 py-3 text-xs font-bold text-gray-900">{fmt(r.amount)}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{r.approvedDate}</td>
                  <td className="px-4 py-3"><Badge label={reimburseStatusCfg[r.status].label} cls={reimburseStatusCfg[r.status].cls}/></td>
                  <td className="px-4 py-3">
                    {r.status !== "paid" ? (
                      <button onClick={() => toggleMethod(r.id)}
                        className={`text-[10px] font-semibold px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                          r.method === "in_payroll"
                            ? "bg-purple-50 text-purple-700 hover:bg-purple-100"
                            : "bg-blue-50 text-blue-700 hover:bg-blue-100"
                        }`}>
                        {r.method === "in_payroll" ? "In Payroll" : "Separate Transfer"}
                      </button>
                    ) : (
                      <span className="text-[10px] text-gray-400">
                        {r.method === "in_payroll" ? "Via Payroll" : "Bank Transfer"}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {r.status === "queued" ? (
                      <button onClick={() => processRow(r.id)}
                        className="flex items-center gap-1 text-[10px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">
                        <Send size={10}/> Process
                      </button>
                    ) : (
                      <span className="text-[10px] text-gray-300">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── 4. Loans Tab ──────────────────────────────────────────────────────────
function LoanModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ employee: "Alex Kumar", amount: "", purpose: "Personal", months: "12" });
  const u = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));
  const monthly = form.amount && form.months ? fmt(Math.ceil(+form.amount / +form.months)) : "—";
  return (
    <Modal title="Loan / Cash Advance Request" onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-xs font-semibold px-4 py-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 cursor-pointer">Cancel</button>
        <button onClick={onClose} className="text-xs font-bold px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 cursor-pointer">Submit Request</button>
      </>}>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Employee</label>
        <select value={form.employee} onChange={e => u("employee", e.target.value)} className={`${sel} w-full`}>
          {["Alex Kumar","Priya Sharma","Robert Chen","Maria Santos","Carlos Rivera","Lisa Park","James Wilson","Nina Patel"].map(n => <option key={n}>{n}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Loan Amount ($)</label>
          <input type="number" value={form.amount} onChange={e => u("amount", e.target.value)} className={`${inp} w-full`} placeholder="0" />
        </div>
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Repayment Period</label>
          <select value={form.months} onChange={e => u("months", e.target.value)} className={`${sel} w-full`}>
            {["3","6","12","18","24"].map(m => <option key={m} value={m}>{m} months</option>)}
          </select>
        </div>
      </div>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Purpose</label>
        <select value={form.purpose} onChange={e => u("purpose", e.target.value)} className={`${sel} w-full`}>
          {["Personal","Medical Emergency","Education","Home Purchase","Vehicle Purchase","Home Renovation","Other"].map(p => <option key={p}>{p}</option>)}
        </select>
      </div>
      {form.amount && (
        <div className="bg-blue-50 rounded-xl px-4 py-3">
          <p className="text-[11px] text-blue-700 font-semibold">Estimated monthly deduction: <span className="font-bold">{monthly}</span></p>
          <p className="text-[10px] text-blue-500 mt-0.5">Automatically deducted from payroll each month</p>
        </div>
      )}
    </Modal>
  );
}

function LoansTab() {
  const [rows, setRows] = useState(initLoans);
  const [showModal, setModal] = useState(false);

  const approve = (id: string) => setRows(r => r.map(l => l.id === id && l.status === "pending" ? { ...l, status: "active" as const } : l));
  const reject  = (id: string) => setRows(r => r.map(l => l.id === id && l.status === "pending" ? { ...l, status: "rejected" as const } : l));

  const totalOutstanding = rows.filter(l => l.status === "active").reduce((a, l) => a + l.remaining, 0);
  const totalMonthly     = rows.filter(l => l.status === "active").reduce((a, l) => a + l.monthlyDeduction, 0);

  return (
    <div className="space-y-5">
      {showModal && <LoanModal onClose={() => setModal(false)}/>}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Outstanding", value: fmt(totalOutstanding), cls: "text-blue-700"  },
          { label: "Monthly Deductions",value: fmt(totalMonthly),    cls: "text-amber-700" },
          { label: "Pending Approval",  value: String(rows.filter(l=>l.status==="pending").length), cls: "text-yellow-700" },
          { label: "Completed Loans",   value: String(rows.filter(l=>l.status==="completed").length),cls: "text-green-700"},
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className={`text-xl font-bold ${s.cls}`}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className={cardClass}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-gray-800">Employee Loans & Cash Advances</h3>
            <p className="text-xs text-gray-400 mt-0.5">Repayment tracking linked to payroll</p>
          </div>
          <button onClick={() => setModal(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl cursor-pointer shadow-sm">
            <Plus size={13}/> New Loan
          </button>
        </div>
        <div className="space-y-3">
          {rows.map((l, i) => {
            const progress = l.totalMonths > 0 ? (l.paidMonths / l.totalMonths) * 100 : 0;
            return (
              <div key={l.id} className="bg-gray-50/60 rounded-2xl p-4 border border-gray-100 hover:border-blue-200 transition-colors">
                <div className="flex items-start gap-3">
                  <Avatar initials={l.employee.avatar} idx={i}/>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-xs font-bold text-gray-800">{l.employee.name}</p>
                      <span className="text-[9px] text-gray-400">{l.employee.dept}</span>
                      <Badge label={loanStatusCfg[l.status].label} cls={loanStatusCfg[l.status].cls}/>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-0.5">{l.purpose} · Requested {l.requestDate}</p>
                    <div className="flex items-center gap-4 mt-2 flex-wrap">
                      <div><p className="text-[9px] text-gray-400">Total Loan</p><p className="text-xs font-bold text-gray-900">{fmt(l.amount)}</p></div>
                      <div><p className="text-[9px] text-gray-400">Remaining</p><p className={`text-xs font-bold ${l.remaining > 0 ? "text-blue-700" : "text-green-700"}`}>{fmt(l.remaining)}</p></div>
                      <div><p className="text-[9px] text-gray-400">Monthly Cut</p><p className="text-xs font-bold text-gray-900">{fmt(l.monthlyDeduction)}</p></div>
                      <div><p className="text-[9px] text-gray-400">Progress</p><p className="text-xs font-bold text-gray-900">{l.paidMonths}/{l.totalMonths} mo</p></div>
                    </div>
                    {l.status === "active" && (
                      <div className="mt-2">
                        <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{ width: `${progress}%` }}/>
                        </div>
                        <p className="text-[9px] text-gray-400 mt-0.5">{progress.toFixed(0)}% repaid</p>
                      </div>
                    )}
                  </div>
                  {l.status === "pending" && (
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button onClick={() => approve(l.id)} className="flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1.5 rounded-lg cursor-pointer">
                        <Check size={10}/> Approve
                      </button>
                      <button onClick={() => reject(l.id)} className="flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 hover:bg-red-100 px-2.5 py-1.5 rounded-lg cursor-pointer">
                        <X size={10}/> Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── 5. Payments Tab ───────────────────────────────────────────────────────
function PaymentsTab() {
  const [rows, setRows] = useState(initPayments);
  const [filter, setFilter] = useState("All");

  const markPaid   = (id: string) => setRows(r => r.map(p => p.id === id ? { ...p, status: "paid" as const, paidDate: "May 5, 2026" } : p));
  const retryFail  = (id: string) => setRows(r => r.map(p => p.id === id ? { ...p, status: "pending" as const } : p));

  const shown = filter === "All" ? rows : rows.filter(p => p.status === filter);
  const typeColors: Record<string, string> = {
    Salary: "bg-blue-50 text-blue-700", Reimbursement: "bg-purple-50 text-purple-700",
    "Loan Repayment": "bg-amber-50 text-amber-700", Bonus: "bg-green-50 text-green-700",
  };

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Scheduled",  value: fmt(rows.reduce((a,p)=>a+p.amount,0)),            cls: "text-gray-900"  },
          { label: "Pending",          value: fmt(rows.filter(p=>p.status==="pending").reduce((a,p)=>a+p.amount,0)), cls: "text-amber-700"},
          { label: "Paid",             value: fmt(rows.filter(p=>p.status==="paid").reduce((a,p)=>a+p.amount,0)),    cls: "text-green-700"},
          { label: "Failed",           value: String(rows.filter(p=>p.status==="failed").length)+" txn", cls: "text-red-600"  },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className={`text-xl font-bold ${s.cls}`}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className={cardClass}>
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <CardHeader title="Payment Tracking" subtitle="All outgoing salary, reimbursement & bonus payments" action={<></>}/>
          <div className="flex gap-1 bg-gray-100/70 p-1 rounded-xl">
            {["All","pending","paid","failed"].map(f => (
              <button key={f} onClick={() => setFilter(f)}
                className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all capitalize ${filter === f ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
                {f === "All" ? "All" : f.charAt(0).toUpperCase()+f.slice(1)}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-gray-100">
                {["Payee","Type","Amount","Method","Scheduled","Paid Date","Status","Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {shown.map((p, i) => (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-blue-50/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <Avatar initials={p.payee.avatar} idx={i} size="sm"/>
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{p.payee.name}</p>
                        <p className="text-[9px] text-gray-400">{p.payee.dept}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3"><Badge label={p.type} cls={typeColors[p.type] ?? "bg-gray-100 text-gray-600"}/></td>
                  <td className="px-4 py-3 text-xs font-bold text-gray-900">{fmt(p.amount)}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{p.method}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{p.scheduledDate}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{p.paidDate ?? <span className="text-gray-300">—</span>}</td>
                  <td className="px-4 py-3"><Badge label={paymentStatusCfg[p.status].label} cls={paymentStatusCfg[p.status].cls}/></td>
                  <td className="px-4 py-3">
                    {p.status === "pending" && (
                      <button onClick={() => markPaid(p.id)}
                        className="flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">
                        <Check size={10}/> Mark Paid
                      </button>
                    )}
                    {p.status === "failed" && (
                      <button onClick={() => retryFail(p.id)}
                        className="flex items-center gap-1 text-[10px] font-bold text-orange-700 bg-orange-50 hover:bg-orange-100 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">
                        <RefreshCw size={10}/> Retry
                      </button>
                    )}
                    {p.status === "paid" && <span className="text-[10px] text-gray-300">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── 6. Budget Tab ─────────────────────────────────────────────────────────
function BudgetTab() {
  const [period, setPeriod] = useState("May 2026");

  return (
    <div className="space-y-5">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div className="flex gap-1 bg-gray-100/70 p-1 rounded-xl">
          {["May 2026","Q2 2026","FY 2026"].map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`text-[11px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all ${period === p ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {p}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-3 text-center">
          {[
            { label: "Total Budget",  value: "$346k",  cls: "text-gray-900"  },
            { label: "Total Spent",   value: "$284.5k",cls: "text-blue-700"  },
            { label: "Over Budget",   value: "2 depts",cls: "text-red-600"   },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-100 px-4 py-2.5">
              <p className={`text-sm font-bold ${s.cls}`}>{s.value}</p>
              <p className="text-[10px] text-gray-400">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Budget cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {deptBudgets.map(b => {
          const payPct = Math.min((b.payrollActual / b.payrollBudget) * 100, 100);
          const expPct = Math.min((b.expenseActual / b.expenseBudget) * 100, 100);
          const payOver = b.payrollActual > b.payrollBudget;
          const expOver = b.expenseActual > b.expenseBudget;
          return (
            <div key={b.dept} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-2.5 h-8 rounded-full" style={{ backgroundColor: b.color }}/>
                <div>
                  <h3 className="text-sm font-bold text-gray-800">{b.dept}</h3>
                  <p className="text-[10px] text-gray-400">Total allocated: {fmt(b.payrollBudget + b.expenseBudget)}</p>
                </div>
                {(payOver || expOver) && (
                  <div className="ml-auto flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 px-2 py-1 rounded-lg">
                    <AlertTriangle size={10}/> Over Budget
                  </div>
                )}
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1.5">
                    <span className="text-[11px] font-semibold text-gray-600">Payroll</span>
                    <span className={`text-[11px] font-bold ${payOver ? "text-red-600" : "text-gray-700"}`}>
                      {fmt(b.payrollActual)} / {fmt(b.payrollBudget)}
                      {payOver && <span className="text-[9px] ml-1">(+{fmtK(b.payrollActual - b.payrollBudget)})</span>}
                    </span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all"
                      style={{ width: `${payPct}%`, backgroundColor: payOver ? "#ef4444" : b.color }}/>
                  </div>
                  <p className="text-[9px] text-gray-400 mt-0.5">{payPct.toFixed(0)}% used{!payOver && ` · ${fmt(b.payrollBudget - b.payrollActual)} remaining`}</p>
                </div>
                <div>
                  <div className="flex justify-between mb-1.5">
                    <span className="text-[11px] font-semibold text-gray-600">Expenses</span>
                    <span className={`text-[11px] font-bold ${expOver ? "text-red-600" : "text-gray-700"}`}>
                      {fmt(b.expenseActual)} / {fmt(b.expenseBudget)}
                      {expOver && <span className="text-[9px] ml-1">(+{fmtK(b.expenseActual - b.expenseBudget)})</span>}
                    </span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all"
                      style={{ width: `${expPct}%`, backgroundColor: expOver ? "#ef4444" : b.color, opacity: 0.7 }}/>
                  </div>
                  <p className="text-[9px] text-gray-400 mt-0.5">{expPct.toFixed(0)}% used{!expOver && ` · ${fmt(b.expenseBudget - b.expenseActual)} remaining`}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Budget vs actual chart */}
      <div className={cardClass}>
        <CardHeader title="Budget vs Actual — All Departments" subtitle="Payroll comparison for current period"/>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={deptBudgets.map(b => ({ dept: b.dept, Budget: b.payrollBudget, Actual: b.payrollActual }))} margin={{ top: 4, right: 4, bottom: 0, left: -8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false}/>
            <XAxis dataKey="dept" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`}/>
            <Tooltip {...tooltipStyle} formatter={(v: number) => [fmt(v), undefined]}/>
            <Legend wrapperStyle={{ fontSize: 10, paddingTop: 8 }}/>
            <Bar dataKey="Budget" fill="#e5e7eb" radius={[3,3,0,0]} maxBarSize={32}/>
            <Bar dataKey="Actual" fill="#3b82f6" radius={[3,3,0,0]} maxBarSize={32}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ── 7. Invoices Tab ───────────────────────────────────────────────────────
function InvoiceModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ client: "", company: "", description: "", amount: "", tax: "10", dueDate: "" });
  const u = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));
  const total = form.amount ? (parseFloat(form.amount) * (1 + parseFloat(form.tax || "0") / 100)) : 0;
  return (
    <Modal title="Create Invoice" onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-xs font-semibold px-4 py-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 cursor-pointer">Cancel</button>
        <button onClick={onClose} className="text-xs font-bold px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 cursor-pointer">Generate Invoice</button>
      </>}>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Client Name</label>
          <input value={form.client} onChange={e => u("client", e.target.value)} className={`${inp} w-full`} placeholder="Client name"/>
        </div>
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Company</label>
          <input value={form.company} onChange={e => u("company", e.target.value)} className={`${inp} w-full`} placeholder="Company"/>
        </div>
      </div>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Service Description</label>
        <input value={form.description} onChange={e => u("description", e.target.value)} className={`${inp} w-full`} placeholder="e.g. HR Consulting — May 2026"/>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-2">
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Amount ($)</label>
          <input type="number" value={form.amount} onChange={e => u("amount", e.target.value)} className={`${inp} w-full`} placeholder="0"/>
        </div>
        <div>
          <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Tax (%)</label>
          <input type="number" value={form.tax} onChange={e => u("tax", e.target.value)} className={`${inp} w-full`}/>
        </div>
      </div>
      <div>
        <label className="text-[11px] font-semibold text-gray-600 mb-1 block">Due Date</label>
        <input type="date" value={form.dueDate} onChange={e => u("dueDate", e.target.value)} className={`${inp} w-full`}/>
      </div>
      {form.amount && (
        <div className="bg-blue-50 rounded-xl px-4 py-3">
          <p className="text-[11px] text-blue-700 font-semibold">Invoice Total (incl. tax): <span className="font-bold">{fmt(Math.round(total))}</span></p>
        </div>
      )}
    </Modal>
  );
}

function InvoicesTab() {
  const [rows, setRows]     = useState(initInvoices);
  const [search, setSearch] = useState("");
  const [filterSt, setSt]   = useState("All");
  const [showModal, setModal] = useState(false);

  const filtered = rows.filter(inv =>
    (inv.client.toLowerCase().includes(search.toLowerCase()) || inv.invoiceNo.toLowerCase().includes(search.toLowerCase())) &&
    (filterSt === "All" || inv.status === filterSt)
  );

  const markPaid   = (id: string) => setRows(r => r.map(inv => inv.id === id ? { ...inv, status: "paid"  as const } : inv));
  const sendRemind = () => {};

  const stats = {
    total:    rows.filter(r => r.status !== "draft").reduce((a, r) => a + r.amount, 0),
    paid:     rows.filter(r => r.status === "paid").reduce((a, r) => a + r.amount, 0),
    unpaid:   rows.filter(r => r.status === "unpaid").reduce((a, r) => a + r.amount, 0),
    overdue:  rows.filter(r => r.status === "overdue").length,
  };

  return (
    <div className="space-y-5">
      {showModal && <InvoiceModal onClose={() => setModal(false)}/>}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Invoiced",  value: fmt(stats.total),  cls: "text-gray-900"  },
          { label: "Collected",       value: fmt(stats.paid),   cls: "text-green-700" },
          { label: "Outstanding",     value: fmt(stats.unpaid), cls: "text-amber-700" },
          { label: "Overdue",         value: `${stats.overdue} invoices`, cls: "text-red-600" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className={`text-xl font-bold ${s.cls}`}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className={cardClass}>
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-48 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
            <Search size={13} className="text-gray-400 flex-shrink-0"/>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search invoices..." className="text-xs text-gray-700 outline-none flex-1 bg-transparent"/>
          </div>
          <select value={filterSt} onChange={e => setSt(e.target.value)} className={`${sel} w-36`}>
            {["All","paid","unpaid","overdue","draft"].map(s => <option key={s} value={s}>{s === "All" ? "All Status" : s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
          </select>
          <button className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-xl hover:bg-gray-50 cursor-pointer shadow-sm">
            <Download size={13}/> Export
          </button>
          <button onClick={() => setModal(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl cursor-pointer shadow-sm">
            <Plus size={13}/> Create Invoice
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-gray-100">
                {["Invoice #","Client","Description","Amount","Tax","Issued","Due Date","Status","Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(inv => (
                <tr key={inv.id} className={`border-b border-gray-50 hover:bg-blue-50/20 transition-colors ${inv.status === "overdue" ? "bg-red-50/20" : ""}`}>
                  <td className="px-4 py-3">
                    <p className="text-xs font-bold text-blue-700">{inv.invoiceNo}</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-xs font-semibold text-gray-800">{inv.client}</p>
                    <p className="text-[9px] text-gray-400">{inv.company}</p>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600 max-w-[180px]">
                    <p className="truncate">{inv.description}</p>
                  </td>
                  <td className="px-4 py-3 text-xs font-bold text-gray-900">{fmt(inv.amount)}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{fmt(inv.tax)}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{inv.issuedDate}</td>
                  <td className="px-4 py-3">
                    <p className={`text-xs font-semibold ${inv.status === "overdue" ? "text-red-600" : "text-gray-700"}`}>{inv.dueDate}</p>
                  </td>
                  <td className="px-4 py-3">
                    <Badge label={invoiceStatusCfg[inv.status].label} cls={invoiceStatusCfg[inv.status].cls}/>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      {inv.status !== "paid" && inv.status !== "draft" && (
                        <button onClick={() => markPaid(inv.id)}
                          className="flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1.5 rounded-lg cursor-pointer">
                          <Check size={10}/> Paid
                        </button>
                      )}
                      {inv.status === "overdue" && (
                        <button onClick={sendRemind}
                          className="flex items-center gap-1 text-[10px] font-bold text-orange-700 bg-orange-50 hover:bg-orange-100 px-2.5 py-1.5 rounded-lg cursor-pointer">
                          <Send size={10}/> Remind
                        </button>
                      )}
                      {(inv.status === "paid" || inv.status === "draft") && (
                        <button className="flex items-center gap-1 text-[10px] font-semibold text-gray-500 hover:text-gray-700 cursor-pointer">
                          <Eye size={10}/> View
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState icon={<FileText size={18}/>} title="No invoices found" desc="Try adjusting your search or filter."/>}
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────
export function FinancePage() {
  const [activeTab, setActiveTab] = useState<FinanceTab>("overview");

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5">
      {/* Page header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Finance</h1>
          <p className="text-xs text-gray-400 mt-0.5">May 2026 · Financial control center</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-xl hover:bg-gray-50 cursor-pointer shadow-sm transition-colors">
            <Download size={13}/> Export Report
          </button>
          <button className="flex items-center gap-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl cursor-pointer transition-colors shadow-sm">
            <Plus size={13}/> New Entry
          </button>
        </div>
      </div>

      {/* Tab nav */}
      <div className="flex items-center gap-1 bg-gray-100/70 p-1 rounded-2xl mb-5 w-fit">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`text-xs font-semibold px-4 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
              activeTab === t.id ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Render active tab */}
      {activeTab === "overview"       && <OverviewTab/>}
      {activeTab === "expenses"       && <ExpensesTab/>}
      {activeTab === "reimbursements" && <ReimbursementsTab/>}
      {activeTab === "loans"          && <LoansTab/>}
      {activeTab === "payments"       && <PaymentsTab/>}
      {activeTab === "budget"         && <BudgetTab/>}
      {activeTab === "invoices"       && <InvoicesTab/>}

      <div className="h-6"/>
    </main>
  );
}
