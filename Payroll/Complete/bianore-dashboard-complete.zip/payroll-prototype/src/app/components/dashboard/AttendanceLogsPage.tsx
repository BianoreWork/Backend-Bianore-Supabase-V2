import { useState, useEffect } from "react";
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Download,
  Search,
  SlidersHorizontal,
  X,
  AlertTriangle,
  CalendarDays,
  RefreshCw,
} from "lucide-react";
import { employeeLogs, employeeDetailData, type EmployeeLog } from "./mockData";

type SortField = "name" | "dept" | "checkIn" | "checkOut" | "status" | "hours";
type SortDir = "asc" | "desc" | null;

const statusConfig: Record<string, { bg: string; text: string; dot: string }> = {
  Present: { bg: "bg-green-50", text: "text-green-700", dot: "bg-green-500" },
  Late: { bg: "bg-yellow-50", text: "text-yellow-700", dot: "bg-yellow-500" },
  Absent: { bg: "bg-red-50", text: "text-red-600", dot: "bg-red-500" },
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",
  HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700",
  Sales: "bg-green-50 text-green-700",
};

const avatarGradients = [
  "from-blue-500 to-indigo-600",
  "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600",
  "from-rose-500 to-pink-600",
  "from-amber-500 to-orange-600",
];

function SortIcon({
  field,
  sortField,
  sortDir,
}: {
  field: SortField;
  sortField: SortField | null;
  sortDir: SortDir;
}) {
  if (sortField !== field) return <ChevronsUpDown size={11} className="text-gray-300" />;
  if (sortDir === "asc") return <ChevronUp size={11} className="text-blue-600" />;
  return <ChevronDown size={11} className="text-blue-600" />;
}

interface AttendanceLogsPageProps {
  kpiFilter: string | null;
  kpiFilterStatus: string | null;
  onClearFilter: () => void;
  onRowClick: (employee: EmployeeLog) => void;
}

const kpiFilterLabels: Record<string, string> = {
  present: "Present",
  late: "Late",
  absent: "Absent",
  checkins: "Active Check-ins",
  payroll: "All",
};

export function AttendanceLogsPage({
  kpiFilter,
  kpiFilterStatus,
  onClearFilter,
  onRowClick,
}: AttendanceLogsPageProps) {
  const [sortField, setSortField] = useState<SortField | null>(null);
  const [sortDir, setSortDir] = useState<SortDir>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [deptFilter, setDeptFilter]     = useState("All");
  const [branchFilter, setBranchFilter] = useState("All");
  const [flagFilter, setFlagFilter]     = useState("All");
  const [dateFilter, setDateFilter]     = useState("");
  const [showMoreFilters, setShowMoreFilters] = useState(false);

  const departments = ["All", "Engineering", "Marketing", "Finance", "HR", "Operations", "Sales"];
  const branches    = ["All", "HQ – Jakarta", "Branch – Surabaya", "Branch – Bandung", "Branch – Bali"];
  const flagTypes   = ["All", "GPS mismatch", "Face mismatch", "No check-in", "No check-out", "Late", "Manual override"];

  // When kpiFilter changes, sync statusFilter
  useEffect(() => {
    if (kpiFilterStatus) {
      setStatusFilter(kpiFilterStatus);
    } else {
      setStatusFilter("All");
    }
  }, [kpiFilter, kpiFilterStatus]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDir === "asc") setSortDir("desc");
      else if (sortDir === "desc") { setSortDir(null); setSortField(null); }
      else { setSortDir("asc"); }
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  const filtered = employeeLogs
    .filter((e) => {
      const matchSearch =
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.dept.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "All" || e.status === statusFilter;
      const matchDept   = deptFilter === "All"   || e.dept === deptFilter;
      // branch & flag filters are UI-level (mock data doesn't have these fields, shown as functional UI)
      return matchSearch && matchStatus && matchDept;
    })
    .sort((a, b) => {
      if (!sortField || !sortDir) return 0;
      const aVal = a[sortField];
      const bVal = b[sortField];
      const dir = sortDir === "asc" ? 1 : -1;
      return aVal > bVal ? dir : aVal < bVal ? -dir : 0;
    });

  const columns: { key: SortField; label: string }[] = [
    { key: "name", label: "Employee Name" },
    { key: "dept", label: "Department" },
    { key: "checkIn", label: "Check-in Time" },
    { key: "checkOut", label: "Check-out Time" },
    { key: "status", label: "Status" },
    { key: "hours", label: "Work Duration" },
  ];

  const hasFlags = (id: number) => {
    const d = employeeDetailData[id];
    return d && d.flags.length > 0;
  };

  const counts = {
    total: employeeLogs.length,
    present: employeeLogs.filter((e) => e.status === "Present").length,
    late: employeeLogs.filter((e) => e.status === "Late").length,
    absent: employeeLogs.filter((e) => e.status === "Absent").length,
    flagged: Object.keys(employeeDetailData).filter((id) => employeeDetailData[Number(id)].flags.length > 0).length,
  };

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
      {/* Page Title */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Attendance Logs</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            View and manage all employee check-in/out records with status and flags
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg">
            <CalendarDays size={13} className="text-gray-400" />
            <span>Thursday, Apr 30, 2026</span>
          </div>
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
            <RefreshCw size={13} className="text-gray-400" />
            Refresh
          </button>
        </div>
      </div>

      {/* Summary Chips */}
      <div className="flex items-center gap-2.5 flex-wrap">
        {[
          { label: "Total", count: counts.total, color: "bg-gray-100 text-gray-700" },
          { label: "Present", count: counts.present, color: "bg-green-50 text-green-700" },
          { label: "Late", count: counts.late, color: "bg-yellow-50 text-yellow-700" },
          { label: "Absent", count: counts.absent, color: "bg-red-50 text-red-600" },
          { label: "Flagged", count: counts.flagged, color: "bg-orange-50 text-orange-700" },
        ].map((s) => (
          <div
            key={s.label}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold ${s.color}`}
          >
            {s.label}
            <span className="opacity-70 font-bold">{s.count}</span>
          </div>
        ))}

        {/* KPI Filter tag */}
        {kpiFilter && kpiFilterStatus && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span>Filtered: {kpiFilterLabels[kpiFilter]}</span>
            <button
              onClick={onClearFilter}
              className="hover:text-blue-900 cursor-pointer"
            >
              <X size={11} />
            </button>
          </div>
        )}
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            {/* Status Tabs */}
            <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
              {["All", "Present", "Late", "Absent"].map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setStatusFilter(s);
                    if (s !== kpiFilterStatus) onClearFilter();
                  }}
                  className={`text-xs px-3 py-1.5 rounded-md transition-all cursor-pointer font-medium whitespace-nowrap ${
                    statusFilter === s
                      ? "bg-white text-gray-800 shadow-sm"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Date */}
            <input type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 cursor-pointer text-gray-700"/>

            {/* Department */}
            <select value={deptFilter} onChange={e => setDeptFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 outline-none cursor-pointer text-gray-700">
              {departments.map(d => <option key={d} value={d}>{d === "All" ? "All Departments" : d}</option>)}
            </select>

            {/* Branch */}
            <select value={branchFilter} onChange={e => setBranchFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 outline-none cursor-pointer text-gray-700">
              {branches.map(b => <option key={b} value={b}>{b === "All" ? "All Branches" : b}</option>)}
            </select>

            {/* Flag type */}
            <select value={flagFilter} onChange={e => setFlagFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 outline-none cursor-pointer text-gray-700">
              {flagTypes.map(f => <option key={f} value={f}>{f === "All" ? "All Flags" : f}</option>)}
            </select>

            {/* Search */}
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name or dept..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-44 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
              />
            </div>

            {(deptFilter !== "All" || branchFilter !== "All" || flagFilter !== "All" || dateFilter) && (
              <button onClick={() => { setDeptFilter("All"); setBranchFilter("All"); setFlagFilter("All"); setDateFilter(""); }}
                className="text-xs text-red-500 hover:text-red-700 cursor-pointer font-medium">
                Clear
              </button>
            )}

            <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer">
              <Download size={13} />
              Export
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className="text-left px-5 py-3 cursor-pointer select-none group"
                    onClick={() => handleSort(col.key)}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors">
                        {col.label}
                      </span>
                      <SortIcon field={col.key} sortField={sortField} sortDir={sortDir} />
                    </div>
                  </th>
                ))}
                {/* Flag column */}
                <th className="text-left px-5 py-3">
                  <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">
                    Flags
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((emp, idx) => {
                const sc = statusConfig[emp.status];
                const dc = deptColors[emp.dept] || "bg-gray-50 text-gray-600";
                const grad = avatarGradients[emp.id % avatarGradients.length];
                const flagged = hasFlags(emp.id);
                const flagCount = employeeDetailData[emp.id]?.flags.length ?? 0;

                return (
                  <tr
                    key={emp.id}
                    onClick={() => onRowClick(emp)}
                    className={`border-b border-gray-50 hover:bg-blue-50/40 transition-colors cursor-pointer group ${
                      idx % 2 !== 0 ? "bg-gray-50/30" : ""
                    }`}
                  >
                    {/* Name */}
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}
                        >
                          {emp.avatar}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">
                            {emp.name}
                          </p>
                          <p className="text-[10px] text-gray-400">
                            EMP#{String(emp.id).padStart(4, "0")}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Dept */}
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-medium px-2 py-1 rounded-md ${dc}`}>
                        {emp.dept}
                      </span>
                    </td>

                    {/* Check-in */}
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-medium ${emp.checkIn === "—" ? "text-gray-300" : "text-gray-700"}`}>
                        {emp.checkIn}
                      </span>
                    </td>

                    {/* Check-out */}
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-medium ${emp.checkOut === "—" ? "text-gray-300" : "text-gray-700"}`}>
                        {emp.checkOut}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {emp.status}
                      </span>
                    </td>

                    {/* Duration */}
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-medium ${emp.hours === "0h" ? "text-gray-300" : "text-gray-700"}`}>
                        {emp.hours}
                      </span>
                    </td>

                    {/* Flags */}
                    <td className="px-5 py-3.5">
                      {flagged ? (
                        <div className="flex items-center gap-1 text-orange-600">
                          <AlertTriangle size={13} className="text-orange-500" />
                          <span className="text-[10px] font-semibold text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded-md">
                            {flagCount} flag{flagCount > 1 ? "s" : ""}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-gray-300">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="py-16 text-center">
              <p className="text-sm text-gray-400">No records match your filters.</p>
              <button
                onClick={() => { setSearch(""); setStatusFilter("All"); onClearFilter(); }}
                className="mt-2 text-xs text-blue-600 hover:underline cursor-pointer"
              >
                Clear filters
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">
            Showing <span className="font-semibold text-gray-600">{filtered.length}</span> of{" "}
            <span className="font-semibold text-gray-600">{employeeLogs.length}</span> records
          </p>
          <div className="flex items-center gap-1">
            {[1, 2, 3, "...", 14].map((p, i) => (
              <button
                key={i}
                className={`w-7 h-7 rounded-lg text-xs transition-colors cursor-pointer ${
                  p === 1
                    ? "bg-blue-600 text-white font-semibold"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="h-4" />
    </main>
  );
}
