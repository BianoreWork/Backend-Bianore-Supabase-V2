import { useState } from "react";
import {
  X, User, Briefcase, Clock, Shield, CheckCircle,
  ChevronRight, ChevronLeft, Building2, Mail, Phone, MapPin, CalendarDays,
} from "lucide-react";
import { departments, workScheduleLabels, allEmployees, type EmploymentType, type WorkScheduleType, type AccessRole } from "./employeeData";

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit?: (data: NewEmployeeData) => void;
}

interface NewEmployeeData {
  name: string; email: string; phone: string; city: string;
  dept: string; role: string; managerId: number | ""; employmentType: EmploymentType;
  joinDate: string; contractEnd: string;
  schedule: WorkScheduleType;
  accessRole: AccessRole;
}

const steps = [
  { id: 1, label: "Personal Info",    icon: User },
  { id: 2, label: "Role & Dept",      icon: Briefcase },
  { id: 3, label: "Work Schedule",    icon: Clock },
  { id: 4, label: "Access & Finish",  icon: Shield },
];

const managers = allEmployees.filter((e) => e.accessRole === "manager" || e.accessRole === "admin" || e.accessRole === "hr");

const inputClass = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-all placeholder:text-gray-400";
const labelClass = "text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5";
const selectClass = `${inputClass} appearance-none cursor-pointer`;

export function AddEmployeeModal({ isOpen, onClose, onSubmit }: AddEmployeeModalProps) {
  const [step, setStep] = useState(1);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState<NewEmployeeData>({
    name: "", email: "", phone: "", city: "",
    dept: "Engineering", role: "", managerId: "",
    employmentType: "full-time", joinDate: "", contractEnd: "",
    schedule: "fixed",
    accessRole: "employee",
  });

  const set = (field: keyof NewEmployeeData, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const canNext = () => {
    if (step === 1) return form.name.trim() !== "" && form.email.trim() !== "";
    if (step === 2) return form.dept !== "" && form.role.trim() !== "" && form.joinDate !== "";
    return true;
  };

  const handleSubmit = () => {
    onSubmit?.(form);
    setSuccess(true);
  };

  const handleClose = () => {
    setStep(1);
    setSuccess(false);
    setForm({
      name: "", email: "", phone: "", city: "",
      dept: "Engineering", role: "", managerId: "",
      employmentType: "full-time", joinDate: "", contractEnd: "",
      schedule: "fixed", accessRole: "employee",
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-[2px] z-50 flex items-center justify-center p-4" onClick={handleClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-[560px] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div>
            <p className="text-sm font-bold text-gray-900">{success ? "Employee Created" : "Add New Employee"}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">
              {success ? "Employee has been added to the system" : `Step ${step} of ${steps.length}`}
            </p>
          </div>
          <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer">
            <X size={16} />
          </button>
        </div>

        {/* Success State */}
        {success ? (
          <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-4">
              <CheckCircle size={32} className="text-green-500" />
            </div>
            <p className="text-base font-bold text-gray-900 mb-1">{form.name} has been added!</p>
            <p className="text-xs text-gray-500 mb-6">
              Onboarding email sent to <span className="font-semibold">{form.email}</span>.<br />
              The employee will appear in the directory once they log in.
            </p>
            <div className="flex gap-3">
              <button onClick={handleClose} className="text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-4 py-2.5 rounded-lg transition-colors cursor-pointer">
                Close
              </button>
              <button
                onClick={() => { setSuccess(false); setStep(1); }}
                className="text-xs text-white bg-blue-600 hover:bg-blue-700 px-4 py-2.5 rounded-lg transition-colors cursor-pointer"
              >
                Add Another Employee
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Step Progress */}
            <div className="flex items-center px-6 py-4 border-b border-gray-100 bg-gray-50/50">
              {steps.map((s, i) => {
                const Icon = s.icon;
                const isDone = step > s.id;
                const isCurrent = step === s.id;
                return (
                  <div key={s.id} className="flex items-center flex-1 last:flex-none">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                        isDone ? "bg-blue-600" : isCurrent ? "bg-blue-600 ring-4 ring-blue-100" : "bg-gray-200"
                      }`}>
                        {isDone ? <CheckCircle size={13} className="text-white" /> : <Icon size={13} className={isCurrent ? "text-white" : "text-gray-400"} />}
                      </div>
                      <span className={`text-[10px] font-semibold whitespace-nowrap hidden sm:block ${isCurrent ? "text-blue-700" : isDone ? "text-gray-600" : "text-gray-400"}`}>
                        {s.label}
                      </span>
                    </div>
                    {i < steps.length - 1 && (
                      <div className={`flex-1 h-px mx-2 ${isDone ? "bg-blue-300" : "bg-gray-200"}`} />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Form Body */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
              {/* STEP 1: Personal Info */}
              {step === 1 && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <label className={labelClass}>Full Name *</label>
                      <div className="relative">
                        <User size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input value={form.name} onChange={(e) => set("name", e.target.value)}
                          placeholder="e.g. Jane Smith" className={`${inputClass} pl-8`} />
                      </div>
                    </div>
                    <div className="col-span-2">
                      <label className={labelClass}>Email Address *</label>
                      <div className="relative">
                        <Mail size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)}
                          placeholder="jane.smith@workforce.app" className={`${inputClass} pl-8`} />
                      </div>
                    </div>
                    <div>
                      <label className={labelClass}>Phone Number</label>
                      <div className="relative">
                        <Phone size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input value={form.phone} onChange={(e) => set("phone", e.target.value)}
                          placeholder="(555) 555-0000" className={`${inputClass} pl-8`} />
                      </div>
                    </div>
                    <div>
                      <label className={labelClass}>City / Location</label>
                      <div className="relative">
                        <MapPin size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input value={form.city} onChange={(e) => set("city", e.target.value)}
                          placeholder="Manhattan, NY" className={`${inputClass} pl-8`} />
                      </div>
                    </div>
                  </div>
                  <div className="px-4 py-3 bg-blue-50 rounded-xl border border-blue-100">
                    <p className="text-[10px] text-blue-700 font-medium">
                      💡 A welcome email with system credentials will be automatically sent to the provided email address after setup is complete.
                    </p>
                  </div>
                </>
              )}

              {/* STEP 2: Role & Department */}
              {step === 2 && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Department *</label>
                    <div className="relative">
                      <Building2 size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                      <select value={form.dept} onChange={(e) => set("dept", e.target.value)} className={`${selectClass} pl-8`}>
                        {departments.map((d) => <option key={d} value={d}>{d}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className={labelClass}>Role / Position *</label>
                    <input value={form.role} onChange={(e) => set("role", e.target.value)}
                      placeholder="e.g. Software Engineer" className={inputClass} />
                  </div>
                  <div>
                    <label className={labelClass}>Reports To</label>
                    <select value={form.managerId} onChange={(e) => set("managerId", e.target.value)} className={selectClass}>
                      <option value="">Select manager</option>
                      {managers.filter((m) => m.dept === form.dept || m.dept === "Executive").map((m) => (
                        <option key={m.id} value={m.id}>{m.name} · {m.role}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Employment Type *</label>
                    <select value={form.employmentType} onChange={(e) => set("employmentType", e.target.value as EmploymentType)} className={selectClass}>
                      <option value="full-time">Full-time</option>
                      <option value="part-time">Part-time</option>
                      <option value="contract">Contract</option>
                      <option value="intern">Intern</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Join Date *</label>
                    <div className="relative">
                      <CalendarDays size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                      <input type="date" value={form.joinDate} onChange={(e) => set("joinDate", e.target.value)} className={`${inputClass} pl-8`} />
                    </div>
                  </div>
                  {(form.employmentType === "contract" || form.employmentType === "intern") && (
                    <div>
                      <label className={labelClass}>Contract End Date</label>
                      <div className="relative">
                        <CalendarDays size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        <input type="date" value={form.contractEnd} onChange={(e) => set("contractEnd", e.target.value)} className={`${inputClass} pl-8`} />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* STEP 3: Work Schedule */}
              {step === 3 && (
                <div className="space-y-3">
                  <label className={labelClass}>Select Work Schedule *</label>
                  <div className="grid grid-cols-1 gap-2">
                    {(Object.entries(workScheduleLabels) as [WorkScheduleType, { label: string; hours: string; color: string }][]).map(([key, val]) => (
                      <button
                        key={key}
                        onClick={() => set("schedule", key)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-all cursor-pointer text-left ${
                          form.schedule === key
                            ? "border-blue-400 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${form.schedule === key ? "bg-blue-600" : "bg-gray-300"}`} />
                        <div className="flex-1">
                          <p className={`text-xs font-semibold ${form.schedule === key ? "text-blue-800" : "text-gray-700"}`}>{val.label}</p>
                          <p className="text-[10px] text-gray-400 mt-0.5">{val.hours}</p>
                        </div>
                        {form.schedule === key && <CheckCircle size={14} className="text-blue-600 flex-shrink-0" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 4: Access & Finish */}
              {step === 4 && (
                <div className="space-y-4">
                  <div>
                    <label className={labelClass}>System Access Role</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { val: "employee", label: "Employee", desc: "View own data only" },
                        { val: "manager", label: "Manager", desc: "View team data" },
                        { val: "hr", label: "HR", desc: "Manage all HR data" },
                        { val: "admin", label: "Admin", desc: "Full system access" },
                      ].map((role) => (
                        <button
                          key={role.val}
                          onClick={() => set("accessRole", role.val as AccessRole)}
                          className={`p-3 rounded-xl border transition-all cursor-pointer text-left ${
                            form.accessRole === role.val
                              ? "border-blue-400 bg-blue-50"
                              : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-0.5">
                            <p className={`text-xs font-semibold ${form.accessRole === role.val ? "text-blue-800" : "text-gray-700"}`}>{role.label}</p>
                            {form.accessRole === role.val && <CheckCircle size={12} className="text-blue-600" />}
                          </div>
                          <p className="text-[10px] text-gray-400">{role.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                    <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-3">Review Summary</p>
                    {[
                      { label: "Name", value: form.name || "—" },
                      { label: "Email", value: form.email || "—" },
                      { label: "Department", value: form.dept },
                      { label: "Role", value: form.role || "—" },
                      { label: "Employment", value: form.employmentType },
                      { label: "Schedule", value: workScheduleLabels[form.schedule]?.label || "—" },
                      { label: "Access Role", value: form.accessRole },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">{row.label}</span>
                        <span className="font-semibold text-gray-800 capitalize">{row.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100 bg-gray-50/50">
              <button
                onClick={() => step > 1 ? setStep(step - 1) : handleClose()}
                className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-white px-4 py-2.5 rounded-lg transition-colors cursor-pointer font-medium"
              >
                <ChevronLeft size={13} />
                {step === 1 ? "Cancel" : "Back"}
              </button>
              <div className="flex items-center gap-1.5">
                {steps.map((s) => (
                  <div key={s.id} className={`w-1.5 h-1.5 rounded-full transition-all ${step === s.id ? "bg-blue-600 w-4" : step > s.id ? "bg-blue-300" : "bg-gray-200"}`} />
                ))}
              </div>
              {step < 4 ? (
                <button
                  onClick={() => canNext() && setStep(step + 1)}
                  disabled={!canNext()}
                  className={`flex items-center gap-1.5 text-xs px-4 py-2.5 rounded-lg transition-colors cursor-pointer font-semibold ${
                    canNext() ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  Next <ChevronRight size={13} />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  className="flex items-center gap-1.5 text-xs bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg transition-colors cursor-pointer font-semibold"
                >
                  <CheckCircle size={13} /> Create Employee
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
