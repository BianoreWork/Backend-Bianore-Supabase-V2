import { useState } from "react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar,
} from "recharts";
import {
  Download, Bell, CalendarDays, TrendingUp, TrendingDown, Minus,
  Clock, Users, UserX, DollarSign, Zap, AlertTriangle, CheckCircle,
  Info, MoreHorizontal, Filter, ChevronDown, X,
} from "lucide-react";
import {
  attendanceRateSparkline, lateIncidentsSparkline, absentDaysSparkline,
  payrollSparkline, avgSalarySparkline, overtimeSparkline,
  monthlyPayrollTrend, deptMetrics, insights,
  topLateEmployees, dailyTrend, type InsightCard,
} from "./reportsData";
import { AttendanceAnalytics } from "./AttendanceAnalytics";
import { PayrollAnalytics } from "./PayrollAnalytics";
import { DepartmentMetrics } from "./DepartmentMetrics";
import { ReportBuilder } from "./ReportBuilder";
import { ScheduleModal } from "./ScheduleModal";

type ReportTab = "overview" | "attendance" | "payroll" | "departments" | "builder";

interface DrillDownData {
  title: string;
  rows: { name: string; dept: string; lates: number; absences: number; impact: string }[];
}

// ── Shared Styles ──────────────────────────────────────────────────────────
const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";

const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

const fmtK = (n: number) => `$${(n / 1000).toFixed(0)}k`;
const fmt  = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

// ── KPI Overview Data ──────────────────────────────────────────────────────
const overviewKPIs = [
  {
    id: "att-rate", label: "Attendance Rate", value: "94.8%",
    trend: "+1.2%", trendType: "up" as const, trendLabel: "vs last month",
    sparkline: attendanceRateSparkline, sparkColor: "#3b82f6",
    icon: <Users size={15} />, iconBg: "bg-blue-50 text-blue-600",
  },
  {
    id: "late", label: "Late Incidents", value: "47",
    trend: "-8", trendType: "up" as const, trendLabel: "vs last month",
    sparkline: lateIncidentsSparkline, sparkColor: "#f59e0b",
    icon: <Clock size={15} />, iconBg: "bg-yellow-50 text-yellow-600",
  },
  {
    id: "absent", label: "Absent Days", value: "28",
    trend: "-3", trendType: "up" as const, trendLabel: "vs last month",
    sparkline: absentDaysSparkline, sparkColor: "#ef4444",
    icon: <UserX size={15} />, iconBg: "bg-red-50 text-red-500",
  },
  {
    id: "payroll", label: "Total Payroll", value: "$284.5k",
    trend: "+2.4%", trendType: "down" as const, trendLabel: "vs last month",
    sparkline: payrollSparkline.map((v) => v / 1000), sparkColor: "#8b5cf6",
    icon: <DollarSign size={15} />, iconBg: "bg-purple-50 text-purple-600",
  },
  {
    id: "avg-salary", label: "Avg Net Salary", value: "$6,210",
    trend: "+$130", trendType: "neutral" as const, trendLabel: "vs last month",
    sparkline: avgSalarySparkline.map((v) => v / 100), sparkColor: "#10b981",
    icon: <DollarSign size={15} />, iconBg: "bg-green-50 text-green-600",
  },
  {
    id: "overtime", label: "Overtime Hours", value: "58h",
    trend: "+22%", trendType: "down" as const, trendLabel: "vs last month",
    sparkline: overtimeSparkline, sparkColor: "#f97316",
    icon: <Zap size={15} />, iconBg: "bg-orange-50 text-orange-500",
  },
];

const insightConfig = {
  success: { bg: "bg-green-50 border-green-200",  icon: <CheckCircle size={14} className="text-green-600 flex-shrink-0" />, metricColor: "text-green-700 bg-green-100" },
  warning: { bg: "bg-amber-50 border-amber-200",  icon: <AlertTriangle size={14} className="text-amber-600 flex-shrink-0" />, metricColor: "text-amber-700 bg-amber-100" },
  alert:   { bg: "bg-red-50 border-red-200",      icon: <AlertTriangle size={14} className="text-red-500 flex-shrink-0" />,   metricColor: "text-red-700 bg-red-100" },
  info:    { bg: "bg-blue-50 border-blue-200",    icon: <Info size={14} className="text-blue-600 flex-shrink-0" />,            metricColor: "text-blue-700 bg-blue-100" },
};

// ── Export Dropdown ────────────────────────────────────────────────────────
function ExportDropdown({ onSchedule }: { onSchedule: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
        <Download size={13} className="text-gray-400" /> Export <ChevronDown size={11} className="text-gray-400" />
      </button>
      {open && (
        <div className="absolute top-full right-0 mt-1 w-44 bg-white border border-gray-100 rounded-xl shadow-xl z-20 py-1 overflow-hidden">
          {[
            { label: "Export as CSV", onClick: () => setOpen(false) },
            { label: "Export as PDF", onClick: () => setOpen(false) },
            { label: "Print Report", onClick: () => setOpen(false) },
          ].map((item) => (
            <button key={item.label} onClick={item.onClick}
              className="w-full text-left text-xs text-gray-700 px-4 py-2.5 hover:bg-gray-50 transition-colors cursor-pointer">
              {item.label}
            </button>
          ))}
          <div className="border-t border-gray-100 my-1" />
          <button onClick={() => { setOpen(false); onSchedule(); }}
            className="w-full text-left text-xs text-blue-600 font-semibold px-4 py-2.5 hover:bg-blue-50 transition-colors cursor-pointer flex items-center gap-2">
            <Bell size={11} /> Schedule Report
          </button>
        </div>
      )}
      {open && <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />}
    </div>
  );
}

// ── Drill Down Modal ───────────────────────────────────────────────────────
function DrillDownModal({ data, onClose }: { data: DrillDownData | null; onClose: () => void }) {
  if (!data) return null;
  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-[2px] z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[560px] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div>
            <p className="text-sm font-bold text-gray-900">{data.title}</p>
            <p className="text-xs text-gray-400 mt-0.5">Drill-down detail · {data.rows.length} records</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer">
              <Download size={12} className="inline mr-1" /> CSV
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
              <X size={15} />
            </button>
          </div>
        </div>
        <div className="overflow-auto max-h-[60vh]">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {["Employee", "Department", "Late Incidents", "Absences", "Salary Impact"].map((col) => (
                  <th key={col} className="text-left px-5 py-3">
                    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.rows.map((row, i) => (
                <tr key={i} className={`border-b border-gray-50 ${i % 2 !== 0 ? "bg-gray-50/30" : ""}`}>
                  <td className="px-5 py-3 text-xs font-semibold text-gray-800">{row.name}</td>
                  <td className="px-5 py-3 text-xs text-gray-600">{row.dept}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs font-bold ${row.lates > 0 ? "text-yellow-600" : "text-gray-300"}`}>
                      {row.lates > 0 ? `${row.lates}×` : "—"}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`text-xs font-bold ${row.absences > 0 ? "text-red-500" : "text-gray-300"}`}>
                      {row.absences > 0 ? `${row.absences}×` : "—"}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-xs font-semibold text-gray-700">{row.impact}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Main ReportsPage ───────────────────────────────────────────────────────
export function ReportsPage() {
  const [activeTab, setActiveTab] = useState<ReportTab>("overview");
  const [dateRange, setDateRange] = useState("last-30");
  const [deptFilter, setDeptFilter] = useState("All");
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [drillDown, setDrillDown] = useState<DrillDownData | null>(null);

  const handleDrillDown = (
    title: string,
    data: { name: string; dept: string; lates: number; absences: number; impact: string }[]
  ) => setDrillDown({ title, data });

  const tabs: { id: ReportTab; label: string }[] = [
    { id: "overview",    label: "Overview" },
    { id: "attendance",  label: "Attendance Analytics" },
    { id: "payroll",     label: "Payroll Analytics" },
    { id: "departments", label: "Departments" },
    { id: "builder",     label: "Report Builder" },
  ];

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
      {/* ── PAGE HEADER ── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Unified insights from Attendance, Payroll, and Employees — April 2026
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
          {/* Date Range */}
          <div className="relative">
            <CalendarDays size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <select value={dateRange} onChange={(e) => setDateRange(e.target.value)}
              className="text-xs text-gray-600 bg-white border border-gray-200 pl-7 pr-7 py-2 rounded-lg outline-none appearance-none cursor-pointer focus:border-blue-400">
              <option value="last-7">Last 7 days</option>
              <option value="last-30">Last 30 days</option>
              <option value="last-90">Last 3 months</option>
              <option value="this-year">This year</option>
            </select>
            <ChevronDown size={11} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          {/* Dept Filter */}
          <div className="relative">
            <Filter size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}
              className="text-xs text-gray-600 bg-white border border-gray-200 pl-7 pr-7 py-2 rounded-lg outline-none appearance-none cursor-pointer focus:border-blue-400">
              <option value="All">All Depts</option>
              {["Engineering", "Finance", "HR", "Marketing", "Operations", "Sales"].map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
            <ChevronDown size={11} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          <ExportDropdown onSchedule={() => setScheduleOpen(true)} />
          <button onClick={() => setScheduleOpen(true)}
            className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors cursor-pointer">
            <Bell size={13} /> Schedule
          </button>
        </div>
      </div>

      {/* ── TABS ── */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* ══════════════════════ OVERVIEW TAB ══════════════════════ */}
      {activeTab === "overview" && (
        <>
          {/* KPI Cards with Sparklines */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {overviewKPIs.map((kpi) => {
              const isUp = kpi.trendType === "up";
              const isNeutral = kpi.trendType === "neutral";
              return (
                <div key={kpi.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5 transition-all cursor-pointer group">
                  <div className="flex items-start justify-between mb-2">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${kpi.iconBg}`}>{kpi.icon}</div>
                    <div className={`flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                      isNeutral ? "bg-gray-100 text-gray-500" : isUp ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"
                    }`}>
                      {isNeutral ? <Minus size={8} /> : isUp ? <TrendingUp size={8} /> : <TrendingDown size={8} />}
                      {kpi.trend}
                    </div>
                  </div>
                  {/* Sparkline */}
                  <div className="h-8 mb-1 -mx-1">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={kpi.sparkline.map((v, i) => ({ v, i }))}>
                        <defs>
                          <linearGradient id={`sg-${kpi.id}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={kpi.sparkColor} stopOpacity={0.2} />
                            <stop offset="95%" stopColor={kpi.sparkColor} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <Area id={`sparkline-${kpi.id}`} type="monotone" dataKey="v" stroke={kpi.sparkColor} strokeWidth={1.5} fill={`url(#sg-${kpi.id})`} dot={false} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-xl font-bold text-gray-900 leading-tight">{kpi.value}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{kpi.label}</p>
                </div>
              );
            })}
          </div>

          {/* Insights Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
            {insights.map((ins) => {
              const cfg = insightConfig[ins.type];
              return (
                <div key={ins.id} className={`rounded-xl border px-3 py-3 flex items-start gap-2.5 ${cfg.bg}`}>
                  {cfg.icon}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-1 flex-wrap">
                      <p className="text-[11px] font-bold text-gray-800 leading-tight">{ins.title}</p>
                      {ins.metric && (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap ${cfg.metricColor}`}>{ins.metric}</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-600 mt-0.5 leading-relaxed line-clamp-2">{ins.body}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Main Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Attendance Overview Chart */}
            <div className={cardClass}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Attendance Overview</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Daily trend · April 2026</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => setActiveTab("attendance")}
                    className="text-[10px] text-blue-600 hover:text-blue-800 font-medium cursor-pointer">
                    Deep dive →
                  </button>
                  <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
                    <MoreHorizontal size={14} />
                  </button>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={dailyTrend.slice(-10)}>
                  <defs>
                    <linearGradient id="ovPresent" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.12} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={30} />
                  <Tooltip {...tooltipStyle} />
                  <Area id="ov-present" type="monotone" dataKey="present" name="Present" stroke="#3b82f6" strokeWidth={2} fill="url(#ovPresent)" />
                  <Area id="ov-late" type="monotone" dataKey="late" name="Late" stroke="#f59e0b" strokeWidth={1.5} fill="transparent" strokeDasharray="4 2" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Payroll Trend */}
            <div className={cardClass}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Payroll Cost Trend</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Last 12 months</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => setActiveTab("payroll")}
                    className="text-[10px] text-blue-600 hover:text-blue-800 font-medium cursor-pointer">
                    Deep dive →
                  </button>
                  <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
                    <MoreHorizontal size={14} />
                  </button>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={monthlyPayrollTrend.slice(-8)}>
                  <defs>
                    <linearGradient id="ovPay" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.12} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={fmtK} width={36} />
                  <Tooltip {...tooltipStyle} formatter={(v: number) => [fmt(v), ""]} />
                  <Area id="ov-payroll" type="monotone" dataKey="total" name="Total Payroll" stroke="#8b5cf6" strokeWidth={2} fill="url(#ovPay)" dot={{ r: 3, fill: "#8b5cf6" }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Dept Attendance + Top Issues */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Dept Attendance Rates */}
            <div className={`${cardClass} lg:col-span-2`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Attendance Rate by Department</h3>
                  <p className="text-xs text-gray-400 mt-0.5">April 2026 · Company avg: 94.8%</p>
                </div>
                <button onClick={() => setActiveTab("departments")}
                  className="text-[10px] text-blue-600 hover:text-blue-800 font-medium cursor-pointer">
                  View all →
                </button>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={[...deptMetrics].sort((a, b) => b.attendanceRate - a.attendanceRate)} barSize={20}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                  <XAxis dataKey="dept" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[80, 100]} tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={28} tickFormatter={(v) => `${v}%`} />
                  <Tooltip {...tooltipStyle} formatter={(v) => [`${v}%`, "Attendance Rate"]} />
                  <Bar id="ov-dept-att" dataKey="attendanceRate" name="Attendance Rate" radius={[4, 4, 0, 0]}>
                    {deptMetrics.map((entry, i) => (
                      <rect key={i} fill={entry.color} onClick={() => handleDrillDown(`${entry.dept} · Attendance Breakdown`, topLateEmployees.filter(e => e.dept === entry.dept || true))} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Summary Stats */}
            <div className={cardClass}>
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Quick Summary</h3>
              <div className="space-y-3">
                {[
                  { label: "Best dept", value: "Executive", sub: "100% attendance", color: "text-green-600" },
                  { label: "Needs attention", value: "Marketing", sub: "8.4% late rate", color: "text-red-500" },
                  { label: "Highest OT", value: "Engineering", sub: "38 hrs this month", color: "text-purple-600" },
                  { label: "Payroll growth", value: "+2.4%", sub: "vs last month", color: "text-blue-600" },
                  { label: "Total headcount", value: "216", sub: "Across 7 departments", color: "text-gray-700" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <span className="text-xs text-gray-500">{item.label}</span>
                    <div className="text-right">
                      <p className={`text-xs font-bold ${item.color}`}>{item.value}</p>
                      <p className="text-[9px] text-gray-400">{item.sub}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* ══════════════════════ OTHER TABS ══════════════════════ */}
      {activeTab === "attendance" && (
        <AttendanceAnalytics onDrillDown={handleDrillDown} />
      )}
      {activeTab === "payroll" && <PayrollAnalytics />}
      {activeTab === "departments" && <DepartmentMetrics />}
      {activeTab === "builder" && <ReportBuilder />}

      <div className="h-4" />

      {/* ── MODALS ── */}
      <ScheduleModal isOpen={scheduleOpen} onClose={() => setScheduleOpen(false)} />
      <DrillDownModal data={drillDown} onClose={() => setDrillDown(null)} />
    </main>
  );
}
