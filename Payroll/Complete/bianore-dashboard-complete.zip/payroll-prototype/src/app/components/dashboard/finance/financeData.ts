// ── Types ─────────────────────────────────────────────────────────────────
export type ExpenseCategory =
  | "Travel" | "Meals" | "Office Supplies" | "Software"
  | "Marketing" | "Training" | "Other";
export type ExpenseStatus       = "pending" | "approved" | "rejected";
export type ReimburseStatus     = "queued"  | "processing" | "paid" | "in_payroll";
export type LoanStatus          = "active"  | "pending"    | "completed" | "rejected";
export type PaymentStatus       = "pending" | "paid"       | "failed";
export type InvoiceStatus       = "paid"    | "unpaid"     | "overdue"   | "draft";

interface FinEmp { name: string; dept: string; avatar: string; }

export interface Expense {
  id: string; employee: FinEmp; category: ExpenseCategory;
  description: string; amount: number; date: string;
  status: ExpenseStatus; hasReceipt: boolean;
}
export interface Reimbursement {
  id: string; expenseId: string; employee: FinEmp;
  category: ExpenseCategory; amount: number; approvedDate: string;
  status: ReimburseStatus; method: "in_payroll" | "separate";
}
export interface Loan {
  id: string; employee: FinEmp; amount: number; purpose: string;
  requestDate: string; status: LoanStatus;
  remaining: number; monthlyDeduction: number;
  paidMonths: number; totalMonths: number;
}
export interface Payment {
  id: string; payee: FinEmp; type: "Salary" | "Reimbursement" | "Loan Repayment" | "Bonus";
  amount: number; method: string; scheduledDate: string;
  paidDate: string | null; status: PaymentStatus; ref: string;
}
export interface DeptBudget {
  dept: string; color: string;
  payrollBudget: number; payrollActual: number;
  expenseBudget: number; expenseActual: number;
}
export interface Invoice {
  id: string; invoiceNo: string; client: string; company: string;
  description: string; amount: number; tax: number;
  issuedDate: string; dueDate: string; status: InvoiceStatus;
}

// ── Status color maps ─────────────────────────────────────────────────────
export const expenseStatusCfg: Record<ExpenseStatus, { cls: string; label: string }> = {
  pending:  { cls: "bg-yellow-50 text-yellow-700", label: "Pending" },
  approved: { cls: "bg-green-50 text-green-700",   label: "Approved" },
  rejected: { cls: "bg-red-50 text-red-600",       label: "Rejected" },
};
export const reimburseStatusCfg: Record<ReimburseStatus, { cls: string; label: string }> = {
  queued:      { cls: "bg-yellow-50 text-yellow-700",  label: "Queued" },
  processing:  { cls: "bg-blue-50 text-blue-700",      label: "Processing" },
  paid:        { cls: "bg-green-50 text-green-700",    label: "Paid" },
  in_payroll:  { cls: "bg-purple-50 text-purple-700",  label: "In Payroll" },
};
export const loanStatusCfg: Record<LoanStatus, { cls: string; label: string }> = {
  active:    { cls: "bg-blue-50 text-blue-700",    label: "Active" },
  pending:   { cls: "bg-yellow-50 text-yellow-700",label: "Pending" },
  completed: { cls: "bg-green-50 text-green-700",  label: "Completed" },
  rejected:  { cls: "bg-red-50 text-red-600",      label: "Rejected" },
};
export const paymentStatusCfg: Record<PaymentStatus, { cls: string; label: string }> = {
  pending: { cls: "bg-yellow-50 text-yellow-700", label: "Pending" },
  paid:    { cls: "bg-green-50 text-green-700",   label: "Paid" },
  failed:  { cls: "bg-red-50 text-red-600",       label: "Failed" },
};
export const invoiceStatusCfg: Record<InvoiceStatus, { cls: string; label: string }> = {
  paid:    { cls: "bg-green-50 text-green-700",  label: "Paid" },
  unpaid:  { cls: "bg-yellow-50 text-yellow-700",label: "Unpaid" },
  overdue: { cls: "bg-red-50 text-red-600",      label: "Overdue" },
  draft:   { cls: "bg-gray-100 text-gray-500",   label: "Draft" },
};
export const catCfg: Record<ExpenseCategory, { cls: string; dot: string }> = {
  Travel:            { cls: "bg-blue-50 text-blue-700",   dot: "#3b82f6" },
  Meals:             { cls: "bg-amber-50 text-amber-700", dot: "#f59e0b" },
  "Office Supplies": { cls: "bg-green-50 text-green-700", dot: "#10b981" },
  Software:          { cls: "bg-purple-50 text-purple-700",dot: "#8b5cf6" },
  Marketing:         { cls: "bg-pink-50 text-pink-700",   dot: "#ec4899" },
  Training:          { cls: "bg-cyan-50 text-cyan-700",   dot: "#06b6d4" },
  Other:             { cls: "bg-gray-100 text-gray-500",  dot: "#9ca3af" },
};

// ── Monthly financial trend (Jan–May 2026) ───────────────────────────────
export const monthlyFinancial = [
  { month: "Jan", payroll: 268000, expenses: 38200, reimbursements: 9800,  net: 316000 },
  { month: "Feb", payroll: 271500, expenses: 41000, reimbursements: 11200, net: 323700 },
  { month: "Mar", payroll: 275000, expenses: 39500, reimbursements: 10500, net: 325000 },
  { month: "Apr", payroll: 280000, expenses: 44200, reimbursements: 12800, net: 337000 },
  { month: "May", payroll: 284500, expenses: 42800, reimbursements: 12350, net: 339650 },
];

// ── Expense breakdown by category (pie chart) ────────────────────────────
export const expenseByCat = [
  { name: "Travel",          value: 14200, color: "#3b82f6" },
  { name: "Software",        value: 9800,  color: "#8b5cf6" },
  { name: "Meals",           value: 7400,  color: "#f59e0b" },
  { name: "Marketing",       value: 5600,  color: "#ec4899" },
  { name: "Office Supplies", value: 3800,  color: "#10b981" },
  { name: "Training",        value: 2000,  color: "#06b6d4" },
];

// ── Cost per department ───────────────────────────────────────────────────
export const costByDept = [
  { dept: "Engineering", payroll: 98000, expenses: 12400 },
  { dept: "Sales",       payroll: 64000, expenses: 15800 },
  { dept: "HR",          payroll: 32000, expenses: 4200  },
  { dept: "Finance",     payroll: 28000, expenses: 3800  },
  { dept: "Marketing",   payroll: 36000, expenses: 9600  },
  { dept: "Operations",  payroll: 26500, expenses: 5200  },
];

// ── Employees ─────────────────────────────────────────────────────────────
const E = [
  { name: "Alex Kumar",    dept: "Engineering", avatar: "AK" },
  { name: "Priya Sharma",  dept: "HR",          avatar: "PS" },
  { name: "Robert Chen",   dept: "Sales",       avatar: "RC" },
  { name: "Maria Santos",  dept: "Marketing",   avatar: "MS" },
  { name: "Carlos Rivera", dept: "Operations",  avatar: "CR" },
  { name: "Lisa Park",     dept: "Finance",     avatar: "LP" },
  { name: "James Wilson",  dept: "Engineering", avatar: "JW" },
  { name: "Nina Patel",    dept: "Sales",       avatar: "NP" },
];

// ── Expenses ──────────────────────────────────────────────────────────────
export const expenses: Expense[] = [
  { id: "EX001", employee: E[2], category: "Travel",          description: "Client visit — Jakarta–Surabaya flight",  amount: 2400, date: "May 5, 2026",  status: "pending",  hasReceipt: true  },
  { id: "EX002", employee: E[0], category: "Software",        description: "GitHub Copilot — annual subscription",    amount: 1200, date: "May 4, 2026",  status: "approved", hasReceipt: true  },
  { id: "EX003", employee: E[3], category: "Marketing",       description: "Social media ad campaign — Q2",           amount: 3200, date: "May 3, 2026",  status: "approved", hasReceipt: true  },
  { id: "EX004", employee: E[7], category: "Meals",           description: "Client dinner — 4 attendees",             amount:  480, date: "May 2, 2026",  status: "pending",  hasReceipt: false },
  { id: "EX005", employee: E[4], category: "Office Supplies", description: "Stationery & printer cartridges",         amount:  320, date: "May 1, 2026",  status: "approved", hasReceipt: true  },
  { id: "EX006", employee: E[1], category: "Training",        description: "SHRM certification course",               amount: 1800, date: "Apr 30, 2026", status: "pending",  hasReceipt: true  },
  { id: "EX007", employee: E[6], category: "Travel",          description: "Team offsite — accommodation",            amount: 3600, date: "Apr 28, 2026", status: "rejected", hasReceipt: true  },
  { id: "EX008", employee: E[5], category: "Software",        description: "Tableau license — monthly",               amount:  840, date: "Apr 27, 2026", status: "approved", hasReceipt: true  },
  { id: "EX009", employee: E[2], category: "Meals",           description: "Team lunch — Q2 kick-off",                amount:  680, date: "Apr 25, 2026", status: "approved", hasReceipt: false },
  { id: "EX010", employee: E[0], category: "Travel",          description: "Conference — transport & parking",        amount: 1100, date: "Apr 24, 2026", status: "approved", hasReceipt: true  },
  { id: "EX011", employee: E[3], category: "Office Supplies", description: "Ergonomic desk accessories",              amount:  920, date: "Apr 22, 2026", status: "pending",  hasReceipt: true  },
  { id: "EX012", employee: E[7], category: "Training",        description: "Sales enablement workshop",               amount:  600, date: "Apr 20, 2026", status: "approved", hasReceipt: true  },
];

// ── Reimbursements ────────────────────────────────────────────────────────
export const reimbursements: Reimbursement[] = [
  { id: "RM001", expenseId: "EX002", employee: E[0], category: "Software",        amount: 1200, approvedDate: "May 4, 2026",  status: "in_payroll", method: "in_payroll" },
  { id: "RM002", expenseId: "EX003", employee: E[3], category: "Marketing",       amount: 3200, approvedDate: "May 3, 2026",  status: "queued",     method: "separate"   },
  { id: "RM003", expenseId: "EX005", employee: E[4], category: "Office Supplies", amount:  320, approvedDate: "May 1, 2026",  status: "paid",       method: "separate"   },
  { id: "RM004", expenseId: "EX008", employee: E[5], category: "Software",        amount:  840, approvedDate: "Apr 27, 2026", status: "paid",       method: "in_payroll" },
  { id: "RM005", expenseId: "EX009", employee: E[2], category: "Meals",           amount:  680, approvedDate: "Apr 25, 2026", status: "processing", method: "separate"   },
  { id: "RM006", expenseId: "EX010", employee: E[0], category: "Travel",          amount: 1100, approvedDate: "Apr 24, 2026", status: "in_payroll", method: "in_payroll" },
  { id: "RM007", expenseId: "EX012", employee: E[7], category: "Training",        amount:  600, approvedDate: "Apr 20, 2026", status: "paid",       method: "separate"   },
];

// ── Loans ─────────────────────────────────────────────────────────────────
export const loans: Loan[] = [
  { id: "LN001", employee: E[1], amount: 6000, purpose: "Medical Emergency",  requestDate: "Mar 1, 2026",  status: "active",    remaining: 4000, monthlyDeduction: 500, paidMonths: 4,  totalMonths: 12 },
  { id: "LN002", employee: E[4], amount: 3000, purpose: "Education",          requestDate: "Feb 15, 2026", status: "active",    remaining: 2000, monthlyDeduction: 500, paidMonths: 2,  totalMonths: 6  },
  { id: "LN003", employee: E[7], amount: 4500, purpose: "Home Purchase",      requestDate: "Apr 10, 2026", status: "pending",   remaining: 4500, monthlyDeduction: 375, paidMonths: 0,  totalMonths: 12 },
  { id: "LN004", employee: E[2], amount: 2000, purpose: "Personal",           requestDate: "Jan 5, 2026",  status: "completed", remaining: 0,    monthlyDeduction: 500, paidMonths: 4,  totalMonths: 4  },
  { id: "LN005", employee: E[6], amount: 8000, purpose: "Vehicle Purchase",   requestDate: "Apr 20, 2026", status: "pending",   remaining: 8000, monthlyDeduction: 400, paidMonths: 0,  totalMonths: 20 },
  { id: "LN006", employee: E[0], amount: 5000, purpose: "Home Renovation",    requestDate: "Dec 1, 2025",  status: "active",    remaining: 1000, monthlyDeduction: 500, paidMonths: 8,  totalMonths: 10 },
];

// ── Payments ──────────────────────────────────────────────────────────────
export const payments: Payment[] = [
  { id: "PAY001", payee: E[0], type: "Salary",         amount: 8500, method: "Bank Transfer", scheduledDate: "May 25, 2026", paidDate: null,           status: "pending", ref: "SAL-2026-05-001" },
  { id: "PAY002", payee: E[1], type: "Salary",         amount: 5200, method: "Bank Transfer", scheduledDate: "May 25, 2026", paidDate: null,           status: "pending", ref: "SAL-2026-05-002" },
  { id: "PAY003", payee: E[2], type: "Salary",         amount: 6800, method: "Bank Transfer", scheduledDate: "May 25, 2026", paidDate: null,           status: "pending", ref: "SAL-2026-05-003" },
  { id: "PAY004", payee: E[3], type: "Reimbursement",  amount: 3200, method: "Bank Transfer", scheduledDate: "May 7, 2026",  paidDate: null,           status: "pending", ref: "RMB-2026-05-001" },
  { id: "PAY005", payee: E[4], type: "Reimbursement",  amount:  680, method: "E-wallet",      scheduledDate: "May 5, 2026",  paidDate: "May 5, 2026",  status: "paid",    ref: "RMB-2026-04-005" },
  { id: "PAY006", payee: E[5], type: "Reimbursement",  amount:  840, method: "Bank Transfer", scheduledDate: "Apr 30, 2026", paidDate: "Apr 30, 2026", status: "paid",    ref: "RMB-2026-04-008" },
  { id: "PAY007", payee: E[1], type: "Loan Repayment", amount:  500, method: "Auto-deduct",   scheduledDate: "May 25, 2026", paidDate: null,           status: "pending", ref: "LN-2026-05-001" },
  { id: "PAY008", payee: E[4], type: "Loan Repayment", amount:  500, method: "Auto-deduct",   scheduledDate: "May 25, 2026", paidDate: null,           status: "pending", ref: "LN-2026-05-002" },
  { id: "PAY009", payee: E[6], type: "Bonus",          amount: 2400, method: "Bank Transfer", scheduledDate: "Apr 30, 2026", paidDate: "Apr 29, 2026", status: "paid",    ref: "BON-2026-04-001" },
  { id: "PAY010", payee: E[7], type: "Salary",         amount: 5900, method: "Bank Transfer", scheduledDate: "Apr 25, 2026", paidDate: null,           status: "failed",  ref: "SAL-2026-04-008" },
];

// ── Department budgets ────────────────────────────────────────────────────
export const deptBudgets: DeptBudget[] = [
  { dept: "Engineering", color: "#3b82f6", payrollBudget: 105000, payrollActual: 98000, expenseBudget: 15000, expenseActual: 12400 },
  { dept: "Sales",       color: "#10b981", payrollBudget: 60000,  payrollActual: 64000, expenseBudget: 14000, expenseActual: 15800 },
  { dept: "Marketing",   color: "#f59e0b", payrollBudget: 38000,  payrollActual: 36000, expenseBudget: 12000, expenseActual: 9600  },
  { dept: "HR",          color: "#8b5cf6", payrollBudget: 35000,  payrollActual: 32000, expenseBudget: 5000,  expenseActual: 4200  },
  { dept: "Operations",  color: "#06b6d4", payrollBudget: 28000,  payrollActual: 26500, expenseBudget: 6000,  expenseActual: 5200  },
  { dept: "Finance",     color: "#ec4899", payrollBudget: 30000,  payrollActual: 28000, expenseBudget: 4000,  expenseActual: 3800  },
];

// ── Invoices ──────────────────────────────────────────────────────────────
export const invoices: Invoice[] = [
  { id: "INV001", invoiceNo: "INV-2026-001", client: "TechVentures Inc.",    company: "Technology",   description: "IT Consulting — Apr 2026",          amount: 18500, tax: 1850, issuedDate: "Apr 30, 2026", dueDate: "May 15, 2026", status: "paid"    },
  { id: "INV002", invoiceNo: "INV-2026-002", client: "GlobalRetail Ltd.",    company: "Retail",       description: "HR Services — Q1 2026",             amount: 12400, tax: 1240, issuedDate: "Apr 1, 2026",  dueDate: "Apr 30, 2026", status: "paid"    },
  { id: "INV003", invoiceNo: "INV-2026-003", client: "MedCare Solutions",    company: "Healthcare",   description: "Payroll Processing — Apr 2026",      amount:  8600, tax:  860, issuedDate: "May 1, 2026",  dueDate: "May 20, 2026", status: "unpaid"  },
  { id: "INV004", invoiceNo: "INV-2026-004", client: "BuildFirst Const.",    company: "Construction", description: "Field Staff Billing — Apr 2026",     amount: 22000, tax: 2200, issuedDate: "Apr 15, 2026", dueDate: "May 1, 2026",  status: "overdue" },
  { id: "INV005", invoiceNo: "INV-2026-005", client: "EduLearn Academy",     company: "Education",    description: "Attendance System — Apr 2026",       amount:  5200, tax:  520, issuedDate: "May 2, 2026",  dueDate: "May 25, 2026", status: "unpaid"  },
  { id: "INV006", invoiceNo: "INV-2026-006", client: "LogiFlow Partners",    company: "Logistics",    description: "Sales Tracking — Mar–Apr 2026",      amount: 14800, tax: 1480, issuedDate: "Apr 28, 2026", dueDate: "May 10, 2026", status: "overdue" },
  { id: "INV007", invoiceNo: "INV-2026-007", client: "FintechEdge Corp.",    company: "Finance",      description: "Payroll SaaS License — May 2026",    amount:  3600, tax:  360, issuedDate: "May 5, 2026",  dueDate: "May 31, 2026", status: "draft"   },
  { id: "INV008", invoiceNo: "INV-2026-008", client: "NexusMfg Group",       company: "Manufacturing",description: "HR Analytics Dashboard — Q2",        amount:  9900, tax:  990, issuedDate: "May 4, 2026",  dueDate: "Jun 4, 2026",  status: "unpaid"  },
];
