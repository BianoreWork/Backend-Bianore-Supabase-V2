import { useState } from "react";
import { motion } from "motion/react";
import { Search, Filter, Plus } from "lucide-react";
import { overtimeRequests, statusConfig, type OvertimeRequest, type RequestStatus, type OvertimeType } from "./timeMockData";
import { RequestDetailDrawer } from "./RequestDetailDrawer";

const EASE = [0.22, 1, 0.36, 1] as const;

const overtimeTypes: OvertimeType[] = ["Before shift", "After shift", "Rest day / Holiday"];

const otTypeConfig: Record<OvertimeType, string> = {
  "Before shift":      "bg-blue-50 text-blue-700 border border-blue-200",
  "After shift":       "bg-purple-50 text-purple-700 border border-purple-200",
  "Rest day / Holiday":"bg-red-50 text-red-700 border border-red-200",
};

const departments = ["All Departments", "Engineering", "Marketing", "HR", "Finance", "Operations", "Sales", "Customer Support"];
const statuses: RequestStatus[] = ["pending", "approved", "rejected"];

export function OvertimeRequests() {
  const [search, setSearch]           = useState("");
  const [filterType, setFilterType]   = useState<OvertimeType | "all">("all");
  const [filterStatus, setFilterStatus] = useState<RequestStatus | "all">("all");
  const [filterDept, setFilterDept]   = useState("All Departments");
  const [showFilters, setShowFilters] = useState(false);
  const [selected, setSelected]       = useState<OvertimeRequest | null>(null);
  const [drawerOpen, setDrawerOpen]   = useState(false);

  const filtered = overtimeRequests.filter(r => {
    const matchSearch = !search || r.employee.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase());
    const matchType   = filterType   === "all" || r.overtimeType === filterType;
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    const matchDept   = filterDept   === "All Departments" || r.dept === filterDept;
    return matchSearch && matchType && matchStatus && matchDept;
  });

  const openDrawer = (req: OvertimeRequest) => { setSelected(req); setDrawerOpen(true); };

  const totalPendingHours = overtimeRequests
    .filter(r => r.status === "pending")
    .reduce((sum, r) => sum + r.duration, 0);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: EASE }}
        className="space-y-4"
      >
        {/* Summary strip */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Pending OT",   value: overtimeRequests.filter(r => r.status === "pending").length,  color: "text-amber-600",  bg: "bg-amber-50" },
            { label: "Approved OT",  value: overtimeRequests.filter(r => r.status === "approved").length, color: "text-green-600",  bg: "bg-green-50" },
            { label: "Pending Hours",value: `${totalPendingHours}h`,                                        color: "text-purple-600", bg: "bg-purple-50" },
          ].map(s => (
            <div key={s.label} className={`${s.bg} rounded-2xl px-4 py-3 border border-white`}>
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-gray-600 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search employee or request ID…"
              className="w-full pl-8 pr-4 py-2 text-xs bg-white border border-gray-200 rounded-xl outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400"/>
          </div>
          <select value={filterType} onChange={e => setFilterType(e.target.value as any)}
            className="text-xs bg-white border border-gray-200 rounded-xl px-3 py-2 outline-none cursor-pointer text-gray-700">
            <option value="all">All OT Types</option>
            {overtimeTypes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as any)}
            className="text-xs bg-white border border-gray-200 rounded-xl px-3 py-2 outline-none cursor-pointer text-gray-700">
            <option value="all">All Statuses</option>
            {statuses.map(s => <option key={s} value={s}>{statusConfig[s].label}</option>)}
          </select>
          <button onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all ${showFilters ? "bg-blue-50 border-blue-200 text-blue-700" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
            <Filter size={12}/> More
          </button>
          <button className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer transition-colors ml-auto">
            <Plus size={13}/> New OT Request
          </button>
        </div>

        {showFilters && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} transition={{ duration: 0.2 }}
            className="flex items-center gap-2 flex-wrap bg-white border border-gray-100 rounded-2xl px-4 py-3">
            <select value={filterDept} onChange={e => setFilterDept(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 outline-none cursor-pointer">
              {departments.map(d => <option key={d}>{d}</option>)}
            </select>
            <span className="text-xs text-gray-400">OT Date:</span>
            <input type="date" className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 outline-none cursor-pointer"/>
            <span className="text-xs text-gray-400">to</span>
            <input type="date" className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 outline-none cursor-pointer"/>
          </motion.div>
        )}

        <p className="text-xs text-gray-400">{filtered.length} overtime request{filtered.length !== 1 ? "s" : ""}</p>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  {["Employee", "ID", "Date", "OT Type", "Scheduled Shift", "OT Period", "Duration", "Project", "Status", "Approver", "Actions"].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.length === 0 ? (
                  <tr><td colSpan={11} className="px-4 py-10 text-center text-sm text-gray-400">No overtime requests match your filters.</td></tr>
                ) : filtered.map(r => {
                  const sc = statusConfig[r.status];
                  const tc = otTypeConfig[r.overtimeType];
                  return (
                    <tr key={r.id} onClick={() => openDrawer(r)} className="hover:bg-gray-50 transition-colors cursor-pointer">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">{r.avatar}</div>
                          <div>
                            <p className="font-semibold text-gray-800">{r.employee}</p>
                            <p className="text-[10px] text-gray-400">{r.dept}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-gray-500">{r.id}</td>
                      <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.overtimeDate}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md whitespace-nowrap ${tc}`}>{r.overtimeType}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{r.scheduledShift}</td>
                      <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.overtimeStart} – {r.overtimeEnd}</td>
                      <td className="px-4 py-3 text-gray-700 font-semibold">{r.duration}h</td>
                      <td className="px-4 py-3 text-gray-500 max-w-[120px] truncate">{r.project ?? "—"}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${sc.pill}`}>{sc.label}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-500">{r.approver}</td>
                      <td className="px-4 py-3">
                        {r.status === "pending" ? (
                          <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                            <button className="text-[10px] font-bold px-2 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 cursor-pointer">Approve</button>
                            <button className="text-[10px] font-bold px-2 py-1 border border-gray-200 text-gray-600 rounded-lg hover:bg-red-50 hover:text-red-600 cursor-pointer">Reject</button>
                          </div>
                        ) : (
                          <button className="text-[10px] text-blue-600 hover:text-blue-700 font-medium cursor-pointer">View</button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>

      <RequestDetailDrawer
        isOpen={drawerOpen} mode="overtime"
        request={selected}  onClose={() => setDrawerOpen(false)}
      />
    </>
  );
}
