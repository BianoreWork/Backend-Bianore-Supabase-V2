export type PageId = "dashboard" | "attendance" | "time" | "payroll" | "employees" | "reports" | "sales" | "finance" | "settings";

export const kpiData = [
  {
    id: "present",
    label: "Present Today",
    value: 312,
    trend: "+18",
    trendType: "up" as const,
    trendLabel: "vs yesterday",
    icon: "users",
    color: "blue",
    filterStatus: "Present",
  },
  {
    id: "late",
    label: "Late Employees",
    value: 24,
    trend: "+3",
    trendType: "down" as const,
    trendLabel: "vs yesterday",
    icon: "clock",
    color: "yellow",
    filterStatus: "Late",
  },
  {
    id: "absent",
    label: "Absent Employees",
    value: 16,
    trend: "-5",
    trendType: "up" as const,
    trendLabel: "vs yesterday",
    icon: "user-x",
    color: "red",
    filterStatus: "Absent",
  },
  {
    id: "checkins",
    label: "Active Check-ins",
    value: 289,
    trend: "+22",
    trendType: "up" as const,
    trendLabel: "working now",
    icon: "activity",
    color: "green",
    filterStatus: "Present",
  },
  {
    id: "payroll",
    label: "Est. Payroll Cost",
    value: "$284,500",
    trend: "+2.4%",
    trendType: "neutral" as const,
    trendLabel: "this month",
    icon: "dollar-sign",
    color: "purple",
    filterStatus: null,
  },
];

export const alerts = [
  {
    id: 1,
    type: "danger" as const,
    title: "Not Checked In",
    description: "14 employees haven't checked in (2h+ past shift start)",
    time: "09:45 AM",
  },
  {
    id: 2,
    type: "danger" as const,
    title: "Face Validation Failed",
    description: "3 check-in attempts failed biometric validation",
    time: "08:32 AM",
  },
  {
    id: 3,
    type: "warning" as const,
    title: "Out-of-Location Check-in",
    description: "7 employees checked in outside designated zones",
    time: "08:18 AM",
  },
  {
    id: 4,
    type: "warning" as const,
    title: "Unapproved Payroll",
    description: "11 payroll entries awaiting manager approval",
    time: "08:00 AM",
  },
];

export const attendanceByDept = [
  { dept: "Engineering", present: 78, late: 6, absent: 4 },
  { dept: "Sales", present: 62, late: 8, absent: 3 },
  { dept: "HR", present: 24, late: 2, absent: 1 },
  { dept: "Finance", present: 31, late: 3, absent: 2 },
  { dept: "Marketing", present: 44, late: 4, absent: 3 },
  { dept: "Operations", present: 73, late: 1, absent: 3 },
];

export const attendanceTrend = [
  { day: "Mon", present: 298, late: 22, absent: 32 },
  { day: "Tue", present: 305, late: 18, absent: 28 },
  { day: "Wed", present: 314, late: 20, absent: 18 },
  { day: "Thu", present: 308, late: 25, absent: 19 },
  { day: "Fri", present: 312, late: 24, absent: 16 },
  { day: "Sat", present: 180, late: 10, absent: 8 },
  { day: "Sun", present: 95, late: 5, absent: 4 },
];

export const payrollBreakdown = [
  { name: "Engineering", value: 98000, color: "#3b82f6" },
  { name: "Sales", value: 64000, color: "#10b981" },
  { name: "Operations", value: 52000, color: "#8b5cf6" },
  { name: "Finance", value: 38000, color: "#f59e0b" },
  { name: "Marketing", value: 22000, color: "#ef4444" },
  { name: "HR", value: 10500, color: "#06b6d4" },
];

export const overtimeTrend = [
  { week: "Wk 1", hours: 142, cost: 8540 },
  { week: "Wk 2", hours: 168, cost: 10080 },
  { week: "Wk 3", hours: 195, cost: 11700 },
  { week: "Wk 4", hours: 178, cost: 10680 },
  { week: "Wk 5", hours: 220, cost: 13200 },
  { week: "Wk 6", hours: 201, cost: 12060 },
  { week: "Wk 7", hours: 189, cost: 11340 },
  { week: "Wk 8", hours: 234, cost: 14040 },
];

export const activityFeed = [
  { id: 1, name: "John Martinez", action: "checked in", status: "present", time: "08:59 AM", icon: "login", dept: "Engineering" },
  { id: 2, name: "Sarah Chen", action: "checked in late", status: "late", time: "09:12 AM", icon: "clock", dept: "Marketing" },
  { id: 3, name: "David Kim", action: "checked in", status: "present", time: "08:47 AM", icon: "login", dept: "Finance" },
  { id: 4, name: "Priya Sharma", action: "face validation failed", status: "alert", time: "08:32 AM", icon: "alert", dept: "HR" },
  { id: 5, name: "Mike Torres", action: "started overtime", status: "overtime", time: "06:05 PM", icon: "zap", dept: "Operations" },
  { id: 6, name: "Lisa Park", action: "checked out", status: "out", time: "05:30 PM", icon: "logout", dept: "Sales" },
  { id: 7, name: "Omar Faruk", action: "out-of-location check-in", status: "alert", time: "08:18 AM", icon: "map-pin", dept: "Operations" },
  { id: 8, name: "Emma Wilson", action: "checked in", status: "present", time: "08:55 AM", icon: "login", dept: "Engineering" },
];

export interface EmployeeLog {
  id: number;
  name: string;
  dept: string;
  checkIn: string;
  checkOut: string;
  status: string;
  hours: string;
  avatar: string;
}

export const employeeLogs: EmployeeLog[] = [
  { id: 1, name: "John Martinez", dept: "Engineering", checkIn: "08:59 AM", checkOut: "06:02 PM", status: "Present", hours: "9h 3m", avatar: "JM" },
  { id: 2, name: "Sarah Chen", dept: "Marketing", checkIn: "09:12 AM", checkOut: "05:45 PM", status: "Late", hours: "8h 33m", avatar: "SC" },
  { id: 3, name: "David Kim", dept: "Finance", checkIn: "08:47 AM", checkOut: "05:30 PM", status: "Present", hours: "8h 43m", avatar: "DK" },
  { id: 4, name: "Priya Sharma", dept: "HR", checkIn: "—", checkOut: "—", status: "Absent", hours: "0h", avatar: "PS" },
  { id: 5, name: "Mike Torres", dept: "Operations", checkIn: "08:30 AM", checkOut: "07:10 PM", status: "Present", hours: "10h 40m", avatar: "MT" },
  { id: 6, name: "Lisa Park", dept: "Sales", checkIn: "09:00 AM", checkOut: "05:30 PM", status: "Present", hours: "8h 30m", avatar: "LP" },
  { id: 7, name: "Omar Faruk", dept: "Operations", checkIn: "08:18 AM", checkOut: "05:00 PM", status: "Present", hours: "8h 42m", avatar: "OF" },
  { id: 8, name: "Emma Wilson", dept: "Engineering", checkIn: "08:55 AM", checkOut: "06:00 PM", status: "Present", hours: "9h 5m", avatar: "EW" },
  { id: 9, name: "Carlos Rivera", dept: "Sales", checkIn: "09:45 AM", checkOut: "05:15 PM", status: "Late", hours: "7h 30m", avatar: "CR" },
  { id: 10, name: "Aisha Johnson", dept: "Engineering", checkIn: "—", checkOut: "—", status: "Absent", hours: "0h", avatar: "AJ" },
  { id: 11, name: "Tom Bradley", dept: "Finance", checkIn: "08:50 AM", checkOut: "05:50 PM", status: "Present", hours: "9h 0m", avatar: "TB" },
  { id: 12, name: "Mei Lin", dept: "Marketing", checkIn: "08:45 AM", checkOut: "05:45 PM", status: "Present", hours: "9h 0m", avatar: "ML" },
];

export type FlagCode =
  | "location_mismatch"
  | "face_not_matched"
  | "camera_failure"
  | "suspicious_time"
  | "overtime"
  | "late";

export interface EmployeeDetail {
  gps: string;
  gpsAddress: string;
  locationZone: string;
  locationMatch: boolean;
  biometricScore: number;
  biometricMatch: boolean;
  cameraStatus: "ok" | "failed" | "warning";
  capturedAt: string;
  shiftStart: string;
  shiftType: string;
  flags: FlagCode[];
}

export const employeeDetailData: Record<number, EmployeeDetail> = {
  1: {
    gps: "40.7128° N, 74.0060° W",
    gpsAddress: "123 Broadway Ave, Manhattan, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 98,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:59:14 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
  2: {
    gps: "40.8448° N, 73.8648° W",
    gpsAddress: "821 Grand Concourse, Bronx, NY",
    locationZone: "Branch A - Eastside",
    locationMatch: false,
    biometricScore: 91,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "09:12:03 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: ["location_mismatch", "late"],
  },
  3: {
    gps: "40.7589° N, 73.9851° W",
    gpsAddress: "1500 Broadway, Times Square, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 96,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:47:22 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
  4: {
    gps: "—",
    gpsAddress: "—",
    locationZone: "—",
    locationMatch: false,
    biometricScore: 0,
    biometricMatch: false,
    cameraStatus: "failed",
    capturedAt: "—",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: ["camera_failure"],
  },
  5: {
    gps: "40.6892° N, 74.0445° W",
    gpsAddress: "275 Atlantic Ave, Brooklyn, NY",
    locationZone: "Branch B - Westside",
    locationMatch: true,
    biometricScore: 99,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:30:05 AM",
    shiftStart: "08:30 AM",
    shiftType: "Early Shift",
    flags: ["overtime"],
  },
  6: {
    gps: "40.7282° N, 73.7949° W",
    gpsAddress: "90-22 Queens Blvd, Queens, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 95,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "09:00:41 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
  7: {
    gps: "40.8448° N, 73.8648° W",
    gpsAddress: "821 Grand Concourse, Bronx, NY",
    locationZone: "HQ - Downtown",
    locationMatch: false,
    biometricScore: 72,
    biometricMatch: false,
    cameraStatus: "ok",
    capturedAt: "08:18:27 AM",
    shiftStart: "08:30 AM",
    shiftType: "Early Shift",
    flags: ["location_mismatch", "face_not_matched"],
  },
  8: {
    gps: "40.7128° N, 74.0060° W",
    gpsAddress: "123 Broadway Ave, Manhattan, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 97,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:55:19 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
  9: {
    gps: "40.6501° N, 73.9496° W",
    gpsAddress: "480 Flatbush Ave, Brooklyn, NY",
    locationZone: "Branch B - Westside",
    locationMatch: false,
    biometricScore: 89,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "09:45:12 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: ["late", "location_mismatch"],
  },
  10: {
    gps: "—",
    gpsAddress: "—",
    locationZone: "—",
    locationMatch: false,
    biometricScore: 0,
    biometricMatch: false,
    cameraStatus: "failed",
    capturedAt: "—",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: ["camera_failure"],
  },
  11: {
    gps: "40.7128° N, 74.0060° W",
    gpsAddress: "123 Broadway Ave, Manhattan, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 96,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:50:33 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
  12: {
    gps: "40.7128° N, 74.0060° W",
    gpsAddress: "123 Broadway Ave, Manhattan, NY",
    locationZone: "HQ - Downtown",
    locationMatch: true,
    biometricScore: 94,
    biometricMatch: true,
    cameraStatus: "ok",
    capturedAt: "08:45:07 AM",
    shiftStart: "09:00 AM",
    shiftType: "Morning Shift",
    flags: [],
  },
};