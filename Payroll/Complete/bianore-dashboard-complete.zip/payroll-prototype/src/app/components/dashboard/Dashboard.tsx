import { useState } from "react";
import { NavSidebar } from "./NavSidebar";
import { Header } from "./Header";
import { Sidebar } from "./Sidebar";
import { OverviewPage } from "./OverviewPage";
import { AttendanceLogsPage } from "./AttendanceLogsPage";
import { AttendanceDrawer } from "./AttendanceDrawer";
import { PlaceholderPage } from "./PlaceholderPage";
import { PayrollPage } from "./payroll/PayrollPage";
import { EmployeesPage } from "./employees/EmployeesPage";
import { ReportsPage } from "./reports/ReportsPage";
import { SalesPage } from "./sales/SalesPage";
import { FinancePage } from "./finance/FinancePage";
import { SettingsPage } from "./settings/SettingsPage";
import { TimePage } from "./time/TimePage";
import type { PageId, EmployeeLog } from "./mockData";
import type { AuthUser } from "../auth/authData";

interface DashboardProps {
  user: AuthUser | null;
  onLogout: () => void;
}

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [activePage, setActivePage] = useState<PageId>(import.meta.env.DEV ? "payroll" : "dashboard");
  const [filterSidebarOpen, setFilterSidebarOpen] = useState(false);

  // KPI → Logs filter state
  const [kpiFilter, setKpiFilter] = useState<string | null>(null);
  const [kpiFilterStatus, setKpiFilterStatus] = useState<string | null>(null);

  // Drawer state
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<EmployeeLog | null>(null);

  const handleKpiClick = (filterId: string, filterStatus: string | null) => {
    setKpiFilter(filterId);
    setKpiFilterStatus(filterStatus);
    setActivePage("attendance");
  };

  const handleViewAllLogs = () => {
    setKpiFilter(null);
    setKpiFilterStatus(null);
    setActivePage("attendance");
  };

  const handleRowClick = (employee: EmployeeLog) => {
    setSelectedEmployee(employee);
    setDrawerOpen(true);
  };

  const handleClearFilter = () => {
    setKpiFilter(null);
    setKpiFilterStatus(null);
  };

  return (
    <div
      className="flex h-screen bg-gray-50 overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* ── LEFT NAV SIDEBAR ── */}
      <NavSidebar activePage={activePage} onPageChange={setActivePage} onLogout={onLogout} />

      {/* ── MAIN CONTENT COLUMN ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Sticky Header */}
        <Header
          activePage={activePage}
          onMenuToggle={() => setFilterSidebarOpen(!filterSidebarOpen)}
          isFilterOpen={filterSidebarOpen}
          user={user}
          onLogout={onLogout}
        />

        {/* Body: Filter panel (dashboard only) + Page content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Filter Sidebar — only on dashboard page */}
          {activePage === "dashboard" && (
            <Sidebar
              isOpen={filterSidebarOpen}
              onClose={() => setFilterSidebarOpen(false)}
            />
          )}

          {/* Page Content */}
          {activePage === "dashboard" && (
            <OverviewPage
              onKpiClick={handleKpiClick}
              onViewAllLogs={handleViewAllLogs}
            />
          )}

          {activePage === "attendance" && (
            <AttendanceLogsPage
              kpiFilter={kpiFilter}
              kpiFilterStatus={kpiFilterStatus}
              onClearFilter={handleClearFilter}
              onRowClick={handleRowClick}
            />
          )}

          {activePage === "time"       && <TimePage />}

          {activePage === "payroll"    && <PayrollPage />}

          {activePage === "employees"  && <EmployeesPage />}

          {activePage === "reports"    && <ReportsPage />}

          {activePage === "sales"      && <SalesPage />}

          {activePage === "finance"    && <FinancePage />}

          {activePage === "settings"   && <SettingsPage />}
        </div>
      </div>

      {/* ── ATTENDANCE DETAIL DRAWER ── */}
      <AttendanceDrawer
        isOpen={drawerOpen}
        employee={selectedEmployee}
        onClose={() => setDrawerOpen(false)}
      />
    </div>
  );
}