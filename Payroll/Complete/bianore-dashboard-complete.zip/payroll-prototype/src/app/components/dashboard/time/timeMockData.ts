export type RequestStatus = "pending" | "approved" | "rejected" | "draft" | "cancelled" | "needs_revision";
export type LeaveType     = "Annual Leave" | "Sick Leave" | "Permission" | "Special Leave";
export type CorrectionType = "Forgot check-in" | "Forgot check-out" | "Incorrect check-in time" | "Incorrect check-out time" | "Wrong attendance status" | "Location issue" | "App issue" | "Other";
export type OvertimeType  = "Before shift" | "After shift" | "Rest day / Holiday";

// ── LEAVE REQUESTS ────────────────────────────────────────────────────────────
export interface LeaveRequest {
  id: string;
  employee: string;
  employeeId: string;
  avatar: string;
  dept: string;
  branch: string;
  type: LeaveType;
  startDate: string;
  endDate: string;
  duration: number;
  halfDay: boolean;
  halfDayPart?: "first" | "second";
  reason: string;
  status: RequestStatus;
  approver: string;
  submittedAt: string;
  updatedAt: string;
  adminNote?: string;
  attachment?: boolean;
  attendanceImpact?: string;
  rejectionReason?: string;
  sickNote?: boolean;
}

export const leaveRequests: LeaveRequest[] = [
  {
    id: "LR-001",
    employee: "Sarah Johnson",    employeeId: "EMP-0042",
    avatar: "SJ", dept: "IT Department", branch: "HQ – Jakarta",
    type: "Annual Leave",         startDate: "2026-05-12", endDate: "2026-05-14",
    duration: 3, halfDay: false,  reason: "Family vacation trip to Bali.",
    status: "pending",            approver: "David Park",
    submittedAt: "2026-05-08 09:14",  updatedAt: "2026-05-08 09:14",
    attendanceImpact: "Employee will be marked as On Leave from May 12–14 after approval.",
  },
  {
    id: "LR-002",
    employee: "Michael Chen",     employeeId: "EMP-0018",
    avatar: "MC", dept: "Engineering", branch: "HQ – Jakarta",
    type: "Sick Leave",           startDate: "2026-05-11", endDate: "2026-05-11",
    duration: 1, halfDay: false,  reason: "High fever and cough.",
    status: "pending",            approver: "Sarah Johnson",
    submittedAt: "2026-05-11 07:30",  updatedAt: "2026-05-11 07:30",
    attachment: true, sickNote: true,
    attendanceImpact: "Employee will be marked as Sick Leave on May 11 after approval.",
  },
  {
    id: "LR-003",
    employee: "Amy Rodriguez",    employeeId: "EMP-0056",
    avatar: "AR", dept: "Marketing", branch: "Branch – Surabaya",
    type: "Permission",           startDate: "2026-05-11", endDate: "2026-05-11",
    duration: 1, halfDay: true, halfDayPart: "first",
    reason: "Government appointment at local office.",
    status: "approved",           approver: "Alex Kumar",
    submittedAt: "2026-05-09 14:00",  updatedAt: "2026-05-10 11:20",
    attendanceImpact: "First half of May 11 marked as Permission.",
  },
  {
    id: "LR-004",
    employee: "David Park",       employeeId: "EMP-0001",
    avatar: "DP", dept: "Executive", branch: "HQ – Jakarta",
    type: "Annual Leave",         startDate: "2026-05-15", endDate: "2026-05-19",
    duration: 5, halfDay: false,  reason: "Personal rest and family engagement.",
    status: "pending",            approver: "Board Office",
    submittedAt: "2026-05-07 10:00",  updatedAt: "2026-05-07 10:00",
    attendanceImpact: "Employee will be marked as On Leave from May 15–19 after approval.",
  },
  {
    id: "LR-005",
    employee: "Emma Wilson",      employeeId: "EMP-0033",
    avatar: "EW", dept: "Finance", branch: "HQ – Jakarta",
    type: "Special Leave",        startDate: "2026-05-20", endDate: "2026-05-20",
    duration: 1, halfDay: false,  reason: "Bereavement – close relative.",
    status: "approved",           approver: "David Park",
    submittedAt: "2026-05-19 18:45",  updatedAt: "2026-05-20 07:00",
    attendanceImpact: "Marked as Special Leave on May 20.",
  },
  {
    id: "LR-006",
    employee: "James Kim",        employeeId: "EMP-0027",
    avatar: "JK", dept: "Sales", branch: "Branch – Bandung",
    type: "Sick Leave",           startDate: "2026-05-10", endDate: "2026-05-10",
    duration: 1, halfDay: false,  reason: "Headache / migraine.",
    status: "rejected",           approver: "Alex Kumar",
    submittedAt: "2026-05-10 08:00",  updatedAt: "2026-05-10 09:30",
    rejectionReason: "No medical certificate provided within 24 hours.",
  },
  {
    id: "LR-007",
    employee: "Lisa Thompson",    employeeId: "EMP-0061",
    avatar: "LT", dept: "HR", branch: "HQ – Jakarta",
    type: "Permission",           startDate: "2026-05-11", endDate: "2026-05-11",
    duration: 1, halfDay: false,  reason: "Child school event.",
    status: "pending",            approver: "Alex Kumar",
    submittedAt: "2026-05-10 16:20",  updatedAt: "2026-05-10 16:20",
  },
  {
    id: "LR-008",
    employee: "Robert Davis",     employeeId: "EMP-0039",
    avatar: "RD", dept: "Operations", branch: "Branch – Bali",
    type: "Annual Leave",         startDate: "2026-05-22", endDate: "2026-05-26",
    duration: 5, halfDay: false,  reason: "Wedding anniversary holiday.",
    status: "draft",              approver: "Unassigned",
    submittedAt: "2026-05-11 11:00",  updatedAt: "2026-05-11 11:00",
  },
  {
    id: "LR-009",
    employee: "Patricia Moore",   employeeId: "EMP-0048",
    avatar: "PM", dept: "Customer Support", branch: "HQ – Jakarta",
    type: "Sick Leave",           startDate: "2026-05-11", endDate: "2026-05-11",
    duration: 1, halfDay: false,  reason: "Stomach flu.",
    status: "approved",           approver: "Sarah Johnson",
    submittedAt: "2026-05-11 06:55",  updatedAt: "2026-05-11 08:10",
    attachment: true, sickNote: true,
    attendanceImpact: "Marked as Sick Leave on May 11.",
  },
  {
    id: "LR-010",
    employee: "Kevin Lee",        employeeId: "EMP-0019",
    avatar: "KL", dept: "Engineering", branch: "HQ – Jakarta",
    type: "Annual Leave",         startDate: "2026-06-01", endDate: "2026-06-05",
    duration: 5, halfDay: false,  reason: "Family reunion overseas.",
    status: "needs_revision",     approver: "Sarah Johnson",
    submittedAt: "2026-05-06 09:00",  updatedAt: "2026-05-09 14:30",
    adminNote: "Please resubmit with manager pre-approval for absences exceeding 3 days.",
  },
];

// ── ATTENDANCE CORRECTIONS ────────────────────────────────────────────────────
export interface CorrectionRequest {
  id: string;
  employee: string;
  employeeId: string;
  avatar: string;
  dept: string;
  branch: string;
  attendanceDate: string;
  correctionType: CorrectionType;
  originalCheckIn?: string;
  originalCheckOut?: string;
  requestedCheckIn?: string;
  requestedCheckOut?: string;
  requestedStatus?: string;
  reason: string;
  status: RequestStatus;
  approver: string;
  submittedAt: string;
  updatedAt: string;
  attachment?: boolean;
  relatedFlags?: string[];
  reviewerNote?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export const correctionRequests: CorrectionRequest[] = [
  {
    id: "CR-001",
    employee: "Alex Kumar",       employeeId: "EMP-0005",
    avatar: "AK", dept: "HR", branch: "HQ – Jakarta",
    attendanceDate: "2026-05-09", correctionType: "Forgot check-in",
    originalCheckIn: "—", originalCheckOut: "17:32",
    requestedCheckIn: "08:05",   reason: "Phone battery died before check-in. Arrived at 08:05 confirmed by office CCTV.",
    status: "pending",            approver: "David Park",
    submittedAt: "2026-05-09 18:00", updatedAt: "2026-05-09 18:00",
    relatedFlags: ["No check-in"],
  },
  {
    id: "CR-002",
    employee: "Maria Santos",     employeeId: "EMP-0031",
    avatar: "MS", dept: "Marketing", branch: "Branch – Surabaya",
    attendanceDate: "2026-05-10", correctionType: "Incorrect check-out time",
    originalCheckIn: "08:02", originalCheckOut: "14:00",
    requestedCheckOut: "17:45",   reason: "Check-out was accidentally triggered during lunch break.",
    status: "approved",           approver: "Alex Kumar",
    submittedAt: "2026-05-10 19:00", updatedAt: "2026-05-11 09:00",
    approvedBy: "Alex Kumar",     approvedAt: "2026-05-11 09:00",
    relatedFlags: ["No check-out"],
  },
  {
    id: "CR-003",
    employee: "John Smith",       employeeId: "EMP-0022",
    avatar: "JS", dept: "Sales", branch: "Branch – Bandung",
    attendanceDate: "2026-05-08", correctionType: "Location issue",
    originalCheckIn: "08:10", originalCheckOut: "17:15",
    reason: "GPS signal was poor near office entrance. Actual location was inside building.",
    status: "pending",            approver: "Alex Kumar",
    submittedAt: "2026-05-08 20:00", updatedAt: "2026-05-08 20:00",
    attachment: true,
    relatedFlags: ["GPS mismatch", "Outside geofence"],
  },
  {
    id: "CR-004",
    employee: "Jennifer Brown",   employeeId: "EMP-0044",
    avatar: "JB", dept: "Operations", branch: "HQ – Jakarta",
    attendanceDate: "2026-05-11", correctionType: "Forgot check-out",
    originalCheckIn: "08:00", originalCheckOut: "—",
    requestedCheckOut: "17:30",   reason: "Left in a hurry due to family emergency, forgot to check out.",
    status: "pending",            approver: "David Park",
    submittedAt: "2026-05-11 20:05", updatedAt: "2026-05-11 20:05",
    relatedFlags: ["No check-out"],
  },
  {
    id: "CR-005",
    employee: "Chris Taylor",     employeeId: "EMP-0029",
    avatar: "CT", dept: "Customer Support", branch: "HQ – Jakarta",
    attendanceDate: "2026-05-07", correctionType: "Wrong attendance status",
    originalCheckIn: "08:45", originalCheckOut: "17:00",
    requestedStatus: "Present",   reason: "Marked as late due to app clock sync issue. Was on time.",
    status: "rejected",           approver: "Sarah Johnson",
    submittedAt: "2026-05-08 10:00", updatedAt: "2026-05-09 11:30",
    reviewerNote: "GPS data shows check-in was confirmed at 08:45. Request does not meet revision criteria.",
    relatedFlags: ["Late check-in"],
  },
  {
    id: "CR-006",
    employee: "Nina Patel",       employeeId: "EMP-0037",
    avatar: "NP", dept: "Engineering", branch: "HQ – Jakarta",
    attendanceDate: "2026-05-10", correctionType: "App issue",
    originalCheckIn: "—", originalCheckOut: "—",
    requestedCheckIn: "08:02", requestedCheckOut: "17:20",
    reason: "App crash prevented check-in and check-out. Screenshot attached as evidence.",
    status: "approved",           approver: "Alex Kumar",
    submittedAt: "2026-05-10 18:30", updatedAt: "2026-05-11 08:45",
    attachment: true,
    approvedBy: "Alex Kumar",     approvedAt: "2026-05-11 08:45",
  },
  {
    id: "CR-007",
    employee: "Tom Anderson",     employeeId: "EMP-0053",
    avatar: "TA", dept: "Finance", branch: "HQ – Jakarta",
    attendanceDate: "2026-05-11", correctionType: "Incorrect check-in time",
    originalCheckIn: "09:30", originalCheckOut: "18:00",
    requestedCheckIn: "08:00",    reason: "System recorded wrong time due to timezone glitch on device.",
    status: "pending",            approver: "David Park",
    submittedAt: "2026-05-11 19:00", updatedAt: "2026-05-11 19:00",
    relatedFlags: ["Late check-in"],
  },
  {
    id: "CR-008",
    employee: "Lisa Chen",        employeeId: "EMP-0066",
    avatar: "LC", dept: "HR", branch: "Branch – Bali",
    attendanceDate: "2026-05-09", correctionType: "Other",
    originalCheckIn: "07:55", originalCheckOut: "16:50",
    reason: "Manual attendance adjustment request — shift was changed last minute and records were not updated.",
    status: "needs_revision",     approver: "Alex Kumar",
    submittedAt: "2026-05-09 21:00", updatedAt: "2026-05-10 10:00",
    reviewerNote: "Please include the updated shift schedule approval document.",
  },
];

// ── OVERTIME REQUESTS ─────────────────────────────────────────────────────────
export interface OvertimeRequest {
  id: string;
  employee: string;
  employeeId: string;
  avatar: string;
  dept: string;
  branch: string;
  overtimeDate: string;
  overtimeType: OvertimeType;
  scheduledShift: string;
  overtimeStart: string;
  overtimeEnd: string;
  duration: number; // hours
  reason: string;
  project?: string;
  status: RequestStatus;
  approver: string;
  submittedAt: string;
  updatedAt: string;
  attachment?: boolean;
  approverNote?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export const overtimeRequests: OvertimeRequest[] = [
  {
    id: "OT-001",
    employee: "Mark Johnson",     employeeId: "EMP-0014",
    avatar: "MJ", dept: "Engineering", branch: "HQ – Jakarta",
    overtimeDate: "2026-05-11",   overtimeType: "After shift",
    scheduledShift: "08:00 – 17:00",
    overtimeStart: "17:00",       overtimeEnd: "19:00",
    duration: 2,                  reason: "Critical bug fix required before client demo at 08:00 next morning.",
    project: "Client Portal v2.1",
    status: "pending",            approver: "Sarah Johnson",
    submittedAt: "2026-05-10 16:00", updatedAt: "2026-05-10 16:00",
  },
  {
    id: "OT-002",
    employee: "Sarah Lee",        employeeId: "EMP-0025",
    avatar: "SL", dept: "Marketing", branch: "HQ – Jakarta",
    overtimeDate: "2026-05-10",   overtimeType: "Before shift",
    scheduledShift: "09:00 – 18:00",
    overtimeStart: "07:30",       overtimeEnd: "09:00",
    duration: 1.5,                reason: "Campaign material finalisation before broadcast cutoff.",
    project: "Q2 Campaign Launch",
    status: "approved",           approver: "Alex Kumar",
    submittedAt: "2026-05-09 17:00", updatedAt: "2026-05-10 08:00",
    approvedBy: "Alex Kumar",     approvedAt: "2026-05-10 08:00",
  },
  {
    id: "OT-003",
    employee: "David Kim",        employeeId: "EMP-0008",
    avatar: "DK", dept: "Operations", branch: "Branch – Surabaya",
    overtimeDate: "2026-05-11",   overtimeType: "Rest day / Holiday",
    scheduledShift: "Off – Sunday",
    overtimeStart: "08:00",       overtimeEnd: "12:00",
    duration: 4,                  reason: "Emergency warehouse stocktake required by management.",
    status: "pending",            approver: "David Park",
    submittedAt: "2026-05-10 19:30", updatedAt: "2026-05-10 19:30",
  },
  {
    id: "OT-004",
    employee: "Emily White",      employeeId: "EMP-0047",
    avatar: "EW", dept: "Finance", branch: "HQ – Jakarta",
    overtimeDate: "2026-05-09",   overtimeType: "After shift",
    scheduledShift: "08:00 – 17:00",
    overtimeStart: "17:00",       overtimeEnd: "20:00",
    duration: 3,                  reason: "Monthly financial close reports.",
    project: "Month-End Close May",
    status: "approved",           approver: "David Park",
    submittedAt: "2026-05-08 15:00", updatedAt: "2026-05-09 17:05",
    approvedBy: "David Park",     approvedAt: "2026-05-09 17:05",
  },
  {
    id: "OT-005",
    employee: "Ryan Park",        employeeId: "EMP-0059",
    avatar: "RP", dept: "Customer Support", branch: "HQ – Jakarta",
    overtimeDate: "2026-05-10",   overtimeType: "After shift",
    scheduledShift: "08:00 – 17:00",
    overtimeStart: "17:00",       overtimeEnd: "18:30",
    duration: 1.5,                reason: "Handling escalated customer complaint resolution.",
    status: "pending",            approver: "Alex Kumar",
    submittedAt: "2026-05-10 17:30", updatedAt: "2026-05-10 17:30",
  },
  {
    id: "OT-006",
    employee: "Jessica Chen",     employeeId: "EMP-0072",
    avatar: "JC", dept: "Engineering", branch: "HQ – Jakarta",
    overtimeDate: "2026-05-08",   overtimeType: "Before shift",
    scheduledShift: "09:00 – 18:00",
    overtimeStart: "07:00",       overtimeEnd: "09:00",
    duration: 2,                  reason: "Urgent server migration before business hours.",
    project: "Infra Migration Q2",
    status: "rejected",           approver: "Sarah Johnson",
    submittedAt: "2026-05-07 18:00", updatedAt: "2026-05-08 09:00",
    approverNote: "Migration was postponed by CTO. Overtime not required.",
  },
];

// ── SUMMARY STATS ─────────────────────────────────────────────────────────────
export const timeSummary = {
  totalPending:   23,
  pendingLeave:   9,
  pendingSick:    4,
  pendingCorrections: 7,
  pendingOvertime: 3,
  approvedToday:  11,
  onLeaveToday: [
    { name: "Amy Rodriguez",  type: "Permission",   dept: "Marketing",  avatar: "AR" },
    { name: "Patricia Moore", type: "Sick Leave",   dept: "Cust. Support", avatar: "PM" },
    { name: "Emma Wilson",    type: "Special Leave", dept: "Finance",   avatar: "EW" },
    { name: "Grace Tan",      type: "Annual Leave", dept: "Engineering", avatar: "GT" },
    { name: "Henry Liu",      type: "Annual Leave", dept: "Sales",      avatar: "HL" },
  ],
  recentActivity: [
    { actor: "Alex Kumar",   action: "approved",  target: "LR-003 (Amy Rodriguez – Permission)", time: "10 min ago" },
    { actor: "Sarah Johnson", action: "submitted", target: "OT-001 (Mark Johnson – After shift OT)", time: "25 min ago" },
    { actor: "System",       action: "flagged",   target: "CR-001 (Alex Kumar – No check-in)", time: "1 h ago" },
    { actor: "David Park",   action: "approved",  target: "OT-004 (Emily White – After shift OT)", time: "2 h ago" },
    { actor: "Alex Kumar",   action: "approved",  target: "CR-002 (Maria Santos – Correction)", time: "3 h ago" },
    { actor: "Sarah Johnson", action: "rejected",  target: "LR-006 (James Kim – Sick Leave)", time: "Yesterday" },
  ],
};

// ── HELPER: STATUS CONFIG ─────────────────────────────────────────────────────
export const statusConfig: Record<RequestStatus, { label: string; pill: string; dot: string }> = {
  pending:        { label: "Pending",        pill: "bg-amber-50 text-amber-700 border border-amber-200",   dot: "bg-amber-500"  },
  approved:       { label: "Approved",       pill: "bg-green-50 text-green-700 border border-green-200",   dot: "bg-green-500"  },
  rejected:       { label: "Rejected",       pill: "bg-red-50 text-red-700 border border-red-200",         dot: "bg-red-500"    },
  draft:          { label: "Draft",          pill: "bg-gray-100 text-gray-500 border border-gray-200",     dot: "bg-gray-400"   },
  cancelled:      { label: "Cancelled",      pill: "bg-gray-100 text-gray-400 border border-gray-200",     dot: "bg-gray-300"   },
  needs_revision: { label: "Needs Revision", pill: "bg-orange-50 text-orange-700 border border-orange-200", dot: "bg-orange-500" },
};

export const leaveTypeConfig: Record<LeaveType, { pill: string; icon: string }> = {
  "Annual Leave":  { pill: "bg-blue-50 text-blue-700 border border-blue-200",   icon: "🏖️" },
  "Sick Leave":    { pill: "bg-red-50 text-red-700 border border-red-200",       icon: "🤒" },
  "Permission":    { pill: "bg-purple-50 text-purple-700 border border-purple-200", icon: "📋" },
  "Special Leave": { pill: "bg-indigo-50 text-indigo-700 border border-indigo-200", icon: "⭐" },
};
