import { useState } from "react";
import { X, ChevronRight, ChevronLeft, CheckCircle2, MapPin, User, FileText } from "lucide-react";
import { salesReps, activityTypeLabels, type ActivityType, type Priority } from "./salesData";

interface AssignActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (data: Record<string, unknown>) => void;
}

const inp = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all placeholder:text-gray-400";
const sel = `${inp} cursor-pointer appearance-none`;
const lbl = "block text-[11px] font-semibold text-gray-600 mb-1.5";

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className={lbl}>{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
      {children}
    </div>
  );
}
function Grid2({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3">{children}</div>;
}

// ── Step 1: Employee & Activity ──────────────────────────────────────────────
function Step1({ form, setForm }: { form: FormData; setForm: (f: FormData) => void }) {
  const u = (k: keyof FormData, v: unknown) => setForm({ ...form, [k]: v });
  const avatarColors = ["bg-blue-500","bg-emerald-500","bg-violet-500","bg-amber-500","bg-rose-500","bg-cyan-500","bg-orange-500"];
  const actTypes: ActivityType[] = ["client_visit","sales_meeting","field_work","delivery","site_inspection","business_trip","other"];

  return (
    <div className="space-y-4">
      <Field label="Assign To (Employee)" required>
        <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-1">
          {salesReps.map((rep, i) => (
            <button key={rep.id} onClick={() => u("employeeId", rep.id)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                form.employeeId === rep.id ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-blue-300 bg-white"
              }`}>
              <div className={`w-8 h-8 ${avatarColors[i % avatarColors.length]} rounded-full flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0`}>
                {rep.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-gray-800">{rep.name}</p>
                <p className="text-[10px] text-gray-400">{rep.role} · {rep.branch}</p>
              </div>
              {form.employeeId === rep.id && <CheckCircle2 size={14} className="text-blue-600 flex-shrink-0"/>}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Activity Type" required>
        <div className="grid grid-cols-2 gap-2">
          {actTypes.map(t => (
            <button key={t} onClick={() => u("activityType", t)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl border cursor-pointer transition-all text-left ${
                form.activityType === t ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-blue-300"
              }`}>
              {activityTypeLabels[t]}
            </button>
          ))}
        </div>
      </Field>

      <Grid2>
        <Field label="Client / Company Name" required>
          <input value={form.clientCompany} onChange={e => u("clientCompany", e.target.value)}
            placeholder="e.g. Apex Corp" className={inp}/>
        </Field>
        <Field label="Contact Person" required>
          <input value={form.contactPerson} onChange={e => u("contactPerson", e.target.value)}
            placeholder="e.g. John Smith" className={inp}/>
        </Field>
      </Grid2>

      <Field label="Contact Phone">
        <input value={form.contactPhone} onChange={e => u("contactPhone", e.target.value)}
          placeholder="+62 812 0000 0000" className={inp}/>
      </Field>

      <Field label="Tags">
        <input value={form.tags} onChange={e => u("tags", e.target.value)}
          placeholder="e.g. Enterprise, Biometric, Hot Lead (comma separated)" className={inp}/>
      </Field>
    </div>
  );
}

// ── Step 2: Location & Schedule ──────────────────────────────────────────────
function Step2({ form, setForm }: { form: FormData; setForm: (f: FormData) => void }) {
  const u = (k: keyof FormData, v: unknown) => setForm({ ...form, [k]: v });

  return (
    <div className="space-y-4">
      <Field label="Destination / Visit Location" required>
        <input value={form.location} onChange={e => u("location", e.target.value)}
          placeholder="e.g. Midtown Business Tower" className={inp}/>
      </Field>
      <Field label="Full Address" required>
        <input value={form.address} onChange={e => u("address", e.target.value)}
          placeholder="Street address" className={inp}/>
      </Field>
      <Grid2>
        <Field label="District / Area">
          <input value={form.district} onChange={e => u("district", e.target.value)}
            placeholder="e.g. Sudirman" className={inp}/>
        </Field>
        <Field label="Branch">
          <select value={form.branch} onChange={e => u("branch", e.target.value)} className={sel}>
            {["HQ – Jakarta","Branch – Surabaya","Branch – Bandung","Branch – Bali"].map(b => <option key={b}>{b}</option>)}
          </select>
        </Field>
      </Grid2>
      <Grid2>
        <Field label="Scheduled Date" required>
          <input type="date" value={form.date} onChange={e => u("date", e.target.value)} className={inp}/>
        </Field>
        <Field label="Scheduled Start Time" required>
          <input type="time" value={form.startTime} onChange={e => u("startTime", e.target.value)} className={inp}/>
        </Field>
      </Grid2>
      <Grid2>
        <Field label="Estimated End Time">
          <input type="time" value={form.endTime} onChange={e => u("endTime", e.target.value)} className={inp}/>
        </Field>
        <Field label="Estimated Duration">
          <select value={form.duration} onChange={e => u("duration", e.target.value)} className={sel}>
            {["30 min","1 hour","1.5 hours","2 hours","3 hours","4 hours","Half day","Full day"].map(d => <option key={d}>{d}</option>)}
          </select>
        </Field>
      </Grid2>

      <div className="bg-gray-50 border border-gray-200 rounded-xl p-3.5 space-y-3">
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Tracking Settings</p>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-700">GPS Tracking Required</p>
            <p className="text-[10px] text-gray-400">Employee location tracked during this activity</p>
          </div>
          <button onClick={() => u("gpsRequired", !form.gpsRequired)}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${form.gpsRequired ? "bg-blue-600" : "bg-gray-200"}`}>
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${form.gpsRequired ? "translate-x-4" : "translate-x-0.5"}`}/>
          </button>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-700">Allow Employee to Update Location</p>
            <p className="text-[10px] text-gray-400">Employee can add/edit their location during the activity</p>
          </div>
          <button onClick={() => u("allowLocationUpdate", !form.allowLocationUpdate)}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${form.allowLocationUpdate ? "bg-blue-600" : "bg-gray-200"}`}>
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${form.allowLocationUpdate ? "translate-x-4" : "translate-x-0.5"}`}/>
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Step 3: Instruction & Proof ───────────────────────────────────────────────
function Step3({ form, setForm }: { form: FormData; setForm: (f: FormData) => void }) {
  const u = (k: keyof FormData, v: unknown) => setForm({ ...form, [k]: v });
  const priorities: Priority[] = ["low","medium","high","urgent"];
  const priorityColors = { low:"border-gray-200 text-gray-600", medium:"border-blue-300 text-blue-700", high:"border-orange-300 text-orange-700", urgent:"border-red-400 text-red-700" };
  const priorityActive = { low:"bg-gray-100 border-gray-300", medium:"bg-blue-600 border-blue-600 text-white", high:"bg-orange-500 border-orange-500 text-white", urgent:"bg-red-600 border-red-600 text-white" };

  const proofOptions = [
    { id: "photo",     label: "Photo Proof",         desc: "Employee must upload at least 1 photo" },
    { id: "gps",       label: "GPS Check-in",         desc: "Must check in within geofence radius" },
    { id: "notes",     label: "Activity Notes",       desc: "Employee must add written notes" },
    { id: "signature", label: "Client Signature",     desc: "Optional — client sign-off on completion" },
  ];

  return (
    <div className="space-y-4">
      <Field label="Priority" required>
        <div className="grid grid-cols-4 gap-2">
          {priorities.map(p => (
            <button key={p} onClick={() => u("priority", p)}
              className={`text-xs font-bold py-2 rounded-xl border cursor-pointer capitalize transition-all ${
                form.priority === p ? priorityActive[p] : `bg-white ${priorityColors[p]} hover:bg-gray-50`
              }`}>
              {p}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Activity Objective / Instructions" required>
        <textarea value={form.objective} onChange={e => u("objective", e.target.value)} rows={3}
          placeholder="Describe what the employee needs to do, key talking points, or site inspection criteria…"
          className={`${inp} resize-none`}/>
      </Field>

      <Field label="Expected Outcome">
        <input value={form.expectedOutcome} onChange={e => u("expectedOutcome", e.target.value)}
          placeholder="e.g. Signed contract, completed demo, collected payment" className={inp}/>
      </Field>

      <Field label="Required Proof">
        <div className="space-y-2">
          {proofOptions.map(opt => (
            <label key={opt.id} onClick={() => {
              const curr = (form.requiredProof as string[]) ?? [];
              const next = curr.includes(opt.id) ? curr.filter(x => x !== opt.id) : [...curr, opt.id];
              u("requiredProof", next);
            }} className="flex items-start gap-3 p-3 rounded-xl border border-gray-200 hover:border-blue-300 cursor-pointer transition-all bg-white group">
              <div className={`mt-0.5 w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                ((form.requiredProof as string[]) ?? []).includes(opt.id)
                  ? "bg-blue-600 border-blue-600" : "border-gray-300 group-hover:border-blue-400"
              }`}>
                {((form.requiredProof as string[]) ?? []).includes(opt.id) && (
                  <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                    <path d="M1 4L3 6L7 2" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
              </div>
              <div>
                <p className="text-xs font-semibold text-gray-800">{opt.label}</p>
                <p className="text-[10px] text-gray-400">{opt.desc}</p>
              </div>
            </label>
          ))}
        </div>
      </Field>

      <Field label="Manager Notes (Internal)">
        <textarea value={form.managerNotes} onChange={e => u("managerNotes", e.target.value)} rows={2}
          placeholder="Internal notes not visible to employee (optional)…"
          className={`${inp} resize-none`}/>
      </Field>
    </div>
  );
}

// ── Form Data shape ──────────────────────────────────────────────────────────
interface FormData {
  employeeId: number | null;
  activityType: ActivityType;
  clientCompany: string;
  contactPerson: string;
  contactPhone: string;
  tags: string;
  location: string;
  address: string;
  district: string;
  branch: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: string;
  gpsRequired: boolean;
  allowLocationUpdate: boolean;
  priority: Priority;
  objective: string;
  expectedOutcome: string;
  requiredProof: string[];
  managerNotes: string;
}

const defaultForm: FormData = {
  employeeId: null,
  activityType: "client_visit",
  clientCompany: "", contactPerson: "", contactPhone: "", tags: "",
  location: "", address: "", district: "", branch: "HQ – Jakarta",
  date: "2026-05-11", startTime: "", endTime: "", duration: "1 hour",
  gpsRequired: true, allowLocationUpdate: true,
  priority: "medium",
  objective: "", expectedOutcome: "", requiredProof: ["photo","gps"], managerNotes: "",
};

// ── Main Modal ────────────────────────────────────────────────────────────────
export function LogVisitModal({ isOpen, onClose, onAssign }: AssignActivityModalProps) {
  const [step, setStep]       = useState(1);
  const [form, setForm]       = useState<FormData>(defaultForm);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const stepConfig = [
    { label: "Employee & Activity", icon: <User size={13}/>,    desc: "Who & what" },
    { label: "Location & Schedule",  icon: <MapPin size={13}/>,  desc: "Where & when" },
    { label: "Instructions & Proof", icon: <FileText size={13}/>,desc: "What's needed" },
  ];

  const canNext = () => {
    if (step === 1) return form.employeeId !== null && form.clientCompany.trim() !== "" && form.contactPerson.trim() !== "";
    if (step === 2) return form.location.trim() !== "" && form.address.trim() !== "" && form.date !== "" && form.startTime !== "";
    return form.objective.trim() !== "";
  };

  const handleAssign = () => {
    setSubmitted(true);
    setTimeout(() => {
      onAssign(form as unknown as Record<string, unknown>);
      setSubmitted(false);
      setStep(1);
      setForm(defaultForm);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[3px]" onClick={onClose}/>
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
          <div>
            <p className="text-sm font-bold text-gray-900">Assign Field Activity</p>
            <p className="text-xs text-gray-400 mt-0.5">Step {step} of 3 — {stepConfig[step-1].desc}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
            <X size={16} className="text-gray-500"/>
          </button>
        </div>

        {/* Stepper */}
        <div className="flex items-center gap-0 px-5 py-3.5 border-b border-gray-100 bg-gray-50 flex-shrink-0">
          {stepConfig.map((s, i) => {
            const n = i + 1;
            const done   = step > n;
            const active = step === n;
            return (
              <div key={n} className="flex items-center flex-1 last:flex-initial">
                <div className="flex items-center gap-2 min-w-0">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all text-[10px] font-bold ${
                    done ? "bg-green-500 text-white" : active ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-500"
                  }`}>
                    {done ? <CheckCircle2 size={12}/> : n}
                  </div>
                  <span className={`text-[10px] font-semibold whitespace-nowrap ${active ? "text-blue-700" : done ? "text-green-700" : "text-gray-400"}`}>
                    {s.label}
                  </span>
                </div>
                {i < 2 && <div className={`flex-1 h-0.5 mx-3 rounded ${step > n ? "bg-green-300" : "bg-gray-200"}`}/>}
              </div>
            );
          })}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5">
          {step === 1 && <Step1 form={form} setForm={setForm}/>}
          {step === 2 && <Step2 form={form} setForm={setForm}/>}
          {step === 3 && <Step3 form={form} setForm={setForm}/>}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 px-5 py-3.5 border-t border-gray-100 flex-shrink-0 bg-white">
          <button onClick={() => step > 1 ? setStep(s => s - 1) : onClose()}
            className="flex items-center gap-1.5 text-xs font-semibold px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer transition-colors">
            <ChevronLeft size={13}/>
            {step === 1 ? "Cancel" : "Back"}
          </button>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-400">{step}/3</span>
            {step < 3 ? (
              <button onClick={() => setStep(s => s + 1)} disabled={!canNext()}
                className={`flex items-center gap-1.5 text-xs font-bold px-5 py-2.5 rounded-xl cursor-pointer transition-all ${
                  canNext() ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}>
                Continue <ChevronRight size={13}/>
              </button>
            ) : (
              <button onClick={handleAssign} disabled={!canNext() || submitted}
                className={`flex items-center gap-1.5 text-xs font-bold px-5 py-2.5 rounded-xl cursor-pointer transition-all ${
                  submitted ? "bg-green-600 text-white" : canNext() ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}>
                {submitted ? <><CheckCircle2 size={13}/> Assigned!</> : <>Assign Activity <CheckCircle2 size={13}/></>}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
