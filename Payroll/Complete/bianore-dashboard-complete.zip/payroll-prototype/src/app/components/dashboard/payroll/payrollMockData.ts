// ─── Types aligned with backend database schema ───────────────────────────────

export type PayrollRunStatus =
  | "draft" | "calculating" | "calculated"
  | "pending_approval" | "approved"
  | "payment_processing" | "paid" | "partially_paid"
  | "failed" | "cancelled";

export type PaymentStatus =
  | "pending" | "validating" | "processing"
  | "success" | "failed" | "retried" | "reversed" | "manual_paid";

export type ApprovalStatus =
  | "draft" | "submitted" | "approved" | "rejected" | "need_revision" | "locked";

export type PayrollType = "monthly" | "bonus" | "thr" | "correction" | "final";

export type ComponentType = "earning" | "deduction" | "benefit" | "reimbursement";

export type CalculationType =
  | "fixed" | "percentage" | "formula" | "attendance_based" | "overtime_based";

export type SalaryType = "monthly" | "daily" | "hourly" | "commission";

export type PaymentProvider =
  | "manual" | "bank_file" | "doku" | "oy" | "xendit" | "bank_api" | "brick";

// ─── Payroll Run ───────────────────────────────────────────────────────────────
export interface PayrollRun {
  id: string;
  runCode: string;
  runName: string;
  payrollType: PayrollType;
  month: number;
  year: number;
  cutoffStartDate: string;
  cutoffEndDate: string;
  paymentDate: string;
  status: PayrollRunStatus;
  totalEmployees: number;
  totalGrossSalary: number;
  totalEarning: number;
  totalDeduction: number;
  totalBpjsEmployee: number;
  totalBpjsEmployer: number;
  totalPph21: number;
  totalNetSalary: number;
  totalPaid: number;
  totalFailedPayment: number;
  submittedAt?: string;
  submittedBy?: string;
  approvedAt?: string;
  approvedBy?: string;
  createdBy: string;
  createdAt: string;
}

// ─── Salary Component ─────────────────────────────────────────────────────────
export interface SalaryComponent {
  id: string;
  componentCode: string;
  componentName: string;
  componentType: ComponentType;
  calculationType: CalculationType;
  defaultAmount: number;
  defaultPercentage: number;
  formula?: string;
  isTaxable: boolean;
  isBpjsBase: boolean;
  isRecurring: boolean;
  isProrated: boolean;
  isVisibleOnPayslip: boolean;
  isActive: boolean;
  sortOrder: number;
}

// ─── Employee Payroll ─────────────────────────────────────────────────────────
export interface EmployeePayrollProfile {
  employeeId: string;
  name: string;
  avatar: string;
  dept: string;
  position: string;
  payrollStatus: "active" | "inactive" | "suspended";
  salaryType: SalaryType;
  baseSalary: number;
  dailyRate: number;
  overtimeEligible: boolean;
  attendanceDeductionEnabled: boolean;
  taxEnabled: boolean;
  bpjsEnabled: boolean;
  paymentMethod: "bank_transfer" | "cash";
  // Bank account
  bankName?: string;
  bankCode?: string;
  accountNumber?: string;
  accountHolderName?: string;
  bankValidationStatus: "validated" | "unvalidated" | "invalid";
  // Tax profile
  nik?: string;
  npwp?: string;
  ptkpStatus?: string;
  taxMethod?: "gross" | "nett" | "gross_up";
  taxEnabled2?: boolean;
  // BPJS profile
  bpjsKesehatanNumber?: string;
  bpjsKetenagakerjaanNumber?: string;
  bpjsKesehatanActive: boolean;
  jhtActive: boolean;
  jpActive: boolean;
  jkkActive: boolean;
  jkmActive: boolean;
}

// ─── Payslip ──────────────────────────────────────────────────────────────────
export interface Payslip {
  id: string;
  payslipNumber: string;
  employeeId: string;
  employeeName: string;
  avatar: string;
  dept: string;
  payrollRunId: string;
  periodMonth: number;
  periodYear: number;
  grossSalary: number;
  totalDeduction: number;
  netSalary: number;
  status: "draft" | "generated" | "sent";
  generatedAt?: string;
  sentAt?: string;
  downloadedAt?: string;
}

// ─── BPJS ─────────────────────────────────────────────────────────────────────
export interface BpjsRateSetting {
  id: string;
  programCode: string;
  programName: string;
  employeeRate: number;
  employerRate: number;
  salaryCap?: number;
  effectiveStartDate: string;
  isActive: boolean;
}

export interface BpjsCalculation {
  id: string;
  employeeId: string;
  employeeName: string;
  avatar: string;
  dept: string;
  payrollRunId: string;
  programCode: string;
  baseSalary: number;
  employeeRate: number;
  employerRate: number;
  employeeAmount: number;
  employerAmount: number;
  totalAmount: number;
}

// ─── Tax Settings ─────────────────────────────────────────────────────────────
export interface PtkpSetting {
  id: string;
  ptkpCode: string;
  ptkpName: string;
  amount: number;
  effectiveStartDate: string;
  isActive: boolean;
}

export interface TerSetting {
  id: string;
  terCategory: string;
  incomeMin: number;
  incomeMax?: number;
  rate: number;
  effectiveStartDate: string;
  isActive: boolean;
}

// ─── Payment Batch ────────────────────────────────────────────────────────────
export interface PaymentBatch {
  id: string;
  batchCode: string;
  payrollRunId: string;
  payrollRunName: string;
  provider: PaymentProvider;
  totalAmount: number;
  totalEmployees: number;
  successCount: number;
  failedCount: number;
  pendingCount: number;
  status: "pending" | "validating" | "processing" | "success" | "partial" | "failed";
  submittedAt?: string;
  completedAt?: string;
  createdAt: string;
}

export interface PaymentItem {
  id: string;
  batchId: string;
  employeeId: string;
  employeeName: string;
  avatar: string;
  bankName: string;
  bankCode: string;
  accountNumber: string;
  accountHolderName: string;
  amount: number;
  status: PaymentStatus;
  providerTransactionId?: string;
  failureCode?: string;
  failureReason?: string;
  paidAt?: string;
}

// ─── KPI / Overview ───────────────────────────────────────────────────────────
export interface PayrollKPI {
  id: string;
  label: string;
  value: string;
  rawValue: number;
  trendPct: string;
  trendType: "up" | "down" | "neutral";
  trendLabel: string;
  icon: string;
  color: string;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════════════════

export const fmtIDR = (n: number): string =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(n);

export const fmtIDRShort = (n: number): string => {
  if (n >= 1_000_000_000) return `Rp ${(n / 1_000_000_000).toFixed(1)}M`;
  if (n >= 1_000_000) return `Rp ${(n / 1_000_000).toFixed(1)}jt`;
  if (n >= 1_000) return `Rp ${(n / 1_000).toFixed(0)}rb`;
  return `Rp ${n}`;
};

// ─── Payroll Runs ─────────────────────────────────────────────────────────────
export const payrollRuns: PayrollRun[] = [
  {
    id: "run-001",
    runCode: "PR-2025-05-001",
    runName: "Payroll Mei 2025",
    payrollType: "monthly",
    month: 5, year: 2025,
    cutoffStartDate: "2025-05-01", cutoffEndDate: "2025-05-31",
    paymentDate: "2025-06-05",
    status: "pending_approval",
    totalEmployees: 287,
    totalGrossSalary: 4_820_000_000,
    totalEarning: 5_124_500_000,
    totalDeduction: 380_250_000,
    totalBpjsEmployee: 145_800_000,
    totalBpjsEmployer: 362_100_000,
    totalPph21: 210_450_000,
    totalNetSalary: 4_388_000_000,
    totalPaid: 0,
    totalFailedPayment: 0,
    submittedAt: "2025-06-01 09:30:00",
    submittedBy: "Alex Kumar",
    createdBy: "System", createdAt: "2025-05-31 08:00:00",
  },
  {
    id: "run-002",
    runCode: "PR-2025-04-001",
    runName: "Payroll April 2025",
    payrollType: "monthly",
    month: 4, year: 2025,
    cutoffStartDate: "2025-04-01", cutoffEndDate: "2025-04-30",
    paymentDate: "2025-05-05",
    status: "paid",
    totalEmployees: 283,
    totalGrossSalary: 4_750_000_000,
    totalEarning: 5_055_000_000,
    totalDeduction: 372_000_000,
    totalBpjsEmployee: 142_500_000,
    totalBpjsEmployer: 355_800_000,
    totalPph21: 205_200_000,
    totalNetSalary: 4_335_300_000,
    totalPaid: 4_335_300_000,
    totalFailedPayment: 0,
    submittedAt: "2025-05-01 09:00:00",
    submittedBy: "Alex Kumar",
    approvedAt: "2025-05-02 14:00:00",
    approvedBy: "Lisa Thompson",
    createdBy: "System", createdAt: "2025-04-30 08:00:00",
  },
  {
    id: "run-003",
    runCode: "PR-2025-04-THR",
    runName: "THR Lebaran 2025",
    payrollType: "thr",
    month: 4, year: 2025,
    cutoffStartDate: "2025-03-01", cutoffEndDate: "2025-03-31",
    paymentDate: "2025-04-01",
    status: "paid",
    totalEmployees: 283,
    totalGrossSalary: 4_750_000_000,
    totalEarning: 4_750_000_000,
    totalDeduction: 0,
    totalBpjsEmployee: 0,
    totalBpjsEmployer: 0,
    totalPph21: 475_000_000,
    totalNetSalary: 4_275_000_000,
    totalPaid: 4_275_000_000,
    totalFailedPayment: 0,
    submittedAt: "2025-03-28 09:00:00",
    submittedBy: "Alex Kumar",
    approvedAt: "2025-03-29 11:00:00",
    approvedBy: "Robert Chen",
    createdBy: "System", createdAt: "2025-03-27 08:00:00",
  },
  {
    id: "run-004",
    runCode: "PR-2025-03-001",
    runName: "Payroll Maret 2025",
    payrollType: "monthly",
    month: 3, year: 2025,
    cutoffStartDate: "2025-03-01", cutoffEndDate: "2025-03-31",
    paymentDate: "2025-04-05",
    status: "paid",
    totalEmployees: 280,
    totalGrossSalary: 4_680_000_000,
    totalEarning: 4_920_000_000,
    totalDeduction: 358_000_000,
    totalBpjsEmployee: 140_400_000,
    totalBpjsEmployer: 350_400_000,
    totalPph21: 198_600_000,
    totalNetSalary: 4_223_000_000,
    totalPaid: 4_185_000_000,
    totalFailedPayment: 38_000_000,
    submittedAt: "2025-04-01 09:00:00",
    submittedBy: "Alex Kumar",
    approvedAt: "2025-04-02 10:00:00",
    approvedBy: "Lisa Thompson",
    createdBy: "System", createdAt: "2025-03-31 08:00:00",
  },
  {
    id: "run-005",
    runCode: "PR-2025-02-001",
    runName: "Payroll Februari 2025",
    payrollType: "monthly",
    month: 2, year: 2025,
    cutoffStartDate: "2025-02-01", cutoffEndDate: "2025-02-28",
    paymentDate: "2025-03-05",
    status: "paid",
    totalEmployees: 278,
    totalGrossSalary: 4_620_000_000,
    totalEarning: 4_852_000_000,
    totalDeduction: 345_000_000,
    totalBpjsEmployee: 138_600_000,
    totalBpjsEmployer: 346_200_000,
    totalPph21: 194_400_000,
    totalNetSalary: 4_174_000_000,
    totalPaid: 4_174_000_000,
    totalFailedPayment: 0,
    createdBy: "System", createdAt: "2025-02-28 08:00:00",
  },
  {
    id: "run-006",
    runCode: "PR-2025-05-BONUS",
    runName: "Bonus Performance Q1 2025",
    payrollType: "bonus",
    month: 5, year: 2025,
    cutoffStartDate: "2025-01-01", cutoffEndDate: "2025-03-31",
    paymentDate: "2025-05-20",
    status: "draft",
    totalEmployees: 0,
    totalGrossSalary: 0,
    totalEarning: 0,
    totalDeduction: 0,
    totalBpjsEmployee: 0,
    totalBpjsEmployer: 0,
    totalPph21: 0,
    totalNetSalary: 0,
    totalPaid: 0,
    totalFailedPayment: 0,
    createdBy: "Lisa Thompson", createdAt: "2025-05-20 10:00:00",
  },
];

// ─── Salary Components ────────────────────────────────────────────────────────
export const salaryComponents: SalaryComponent[] = [
  { id: "sc-001", componentCode: "GAJI_POKOK", componentName: "Gaji Pokok", componentType: "earning", calculationType: "fixed", defaultAmount: 0, defaultPercentage: 0, isTaxable: true, isBpjsBase: true, isRecurring: true, isProrated: true, isVisibleOnPayslip: true, isActive: true, sortOrder: 1 },
  { id: "sc-002", componentCode: "TUNJANGAN_JABATAN", componentName: "Tunjangan Jabatan", componentType: "earning", calculationType: "fixed", defaultAmount: 500_000, defaultPercentage: 0, isTaxable: true, isBpjsBase: false, isRecurring: true, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 2 },
  { id: "sc-003", componentCode: "TUNJANGAN_TRANSPORT", componentName: "Tunjangan Transport", componentType: "earning", calculationType: "fixed", defaultAmount: 350_000, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: true, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 3 },
  { id: "sc-004", componentCode: "TUNJANGAN_MAKAN", componentName: "Tunjangan Makan", componentType: "earning", calculationType: "attendance_based", defaultAmount: 25_000, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: true, isProrated: true, isVisibleOnPayslip: true, isActive: true, sortOrder: 4 },
  { id: "sc-005", componentCode: "LEMBUR", componentName: "Upah Lembur", componentType: "earning", calculationType: "overtime_based", defaultAmount: 0, defaultPercentage: 0, formula: "(gaji_pokok / 173) * 1.5 * jam_lembur", isTaxable: true, isBpjsBase: false, isRecurring: false, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 5 },
  { id: "sc-006", componentCode: "BONUS_KINERJA", componentName: "Bonus Kinerja", componentType: "earning", calculationType: "fixed", defaultAmount: 0, defaultPercentage: 0, isTaxable: true, isBpjsBase: false, isRecurring: false, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 6 },
  { id: "sc-007", componentCode: "TUNJANGAN_KESEHATAN", componentName: "Tunjangan Kesehatan", componentType: "benefit", calculationType: "fixed", defaultAmount: 200_000, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: true, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 7 },
  { id: "sc-008", componentCode: "POTONGAN_TERLAMBAT", componentName: "Potongan Keterlambatan", componentType: "deduction", calculationType: "attendance_based", defaultAmount: 50_000, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: false, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 8 },
  { id: "sc-009", componentCode: "POTONGAN_ALPHA", componentName: "Potongan Tidak Masuk", componentType: "deduction", calculationType: "attendance_based", defaultAmount: 0, defaultPercentage: 0, formula: "(gaji_pokok / hari_kerja) * hari_alpha", isTaxable: false, isBpjsBase: false, isRecurring: false, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 9 },
  { id: "sc-010", componentCode: "POTONGAN_PINJAMAN", componentName: "Cicilan Pinjaman", componentType: "deduction", calculationType: "fixed", defaultAmount: 0, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: true, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 10 },
  { id: "sc-011", componentCode: "REIMBURSEMENT", componentName: "Reimbursement", componentType: "reimbursement", calculationType: "fixed", defaultAmount: 0, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: false, isProrated: false, isVisibleOnPayslip: true, isActive: true, sortOrder: 11 },
  { id: "sc-012", componentCode: "TUNJANGAN_PULSA", componentName: "Tunjangan Pulsa", componentType: "benefit", calculationType: "fixed", defaultAmount: 150_000, defaultPercentage: 0, isTaxable: false, isBpjsBase: false, isRecurring: true, isProrated: false, isVisibleOnPayslip: true, isActive: false, sortOrder: 12 },
];

// ─── Employee Payroll Profiles ────────────────────────────────────────────────
export const employeePayrollProfiles: EmployeePayrollProfile[] = [
  { employeeId: "EMP-001", name: "Budi Santoso", avatar: "BS", dept: "Engineering", position: "Senior Software Engineer", payrollStatus: "active", salaryType: "monthly", baseSalary: 18_000_000, dailyRate: 0, overtimeEligible: true, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BCA", bankCode: "014", accountNumber: "****4521", accountHolderName: "BUDI SANTOSO", bankValidationStatus: "validated", nik: "3171****0001", npwp: "12.345.678.9-001.000", ptkpStatus: "K1", taxMethod: "gross", bpjsKesehatanNumber: "0001234567", bpjsKetenagakerjaanNumber: "1234567890", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-002", name: "Dewi Rahayu", avatar: "DR", dept: "Marketing", position: "Marketing Manager", payrollStatus: "active", salaryType: "monthly", baseSalary: 14_000_000, dailyRate: 0, overtimeEligible: false, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "Mandiri", bankCode: "008", accountNumber: "****8832", accountHolderName: "DEWI RAHAYU", bankValidationStatus: "validated", nik: "3171****0002", npwp: "23.456.789.0-001.000", ptkpStatus: "K0", taxMethod: "gross", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-003", name: "Ahmad Fauzi", avatar: "AF", dept: "Finance", position: "Senior Accountant", payrollStatus: "active", salaryType: "monthly", baseSalary: 16_000_000, dailyRate: 0, overtimeEligible: false, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BNI", bankCode: "009", accountNumber: "****1195", accountHolderName: "AHMAD FAUZI", bankValidationStatus: "validated", nik: "3171****0003", npwp: "34.567.890.1-001.000", ptkpStatus: "K2", taxMethod: "gross", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-004", name: "Sari Putri", avatar: "SP", dept: "HR", position: "HR Specialist", payrollStatus: "active", salaryType: "monthly", baseSalary: 10_000_000, dailyRate: 0, overtimeEligible: false, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BRI", bankCode: "002", accountNumber: "****7743", accountHolderName: "SARI PUTRI", bankValidationStatus: "unvalidated", nik: "3171****0004", ptkpStatus: "TK0", taxMethod: "gross", bpjsKesehatanActive: true, jhtActive: true, jpActive: false, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-005", name: "Eko Prasetyo", avatar: "EP", dept: "Operations", position: "Operations Lead", payrollStatus: "active", salaryType: "monthly", baseSalary: 12_000_000, dailyRate: 0, overtimeEligible: true, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BCA", bankCode: "014", accountNumber: "****5520", accountHolderName: "EKO PRASETYO", bankValidationStatus: "validated", nik: "3171****0005", npwp: "56.789.012.3-001.000", ptkpStatus: "K1", taxMethod: "nett", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-006", name: "Rina Fitriani", avatar: "RF", dept: "Sales", position: "Sales Executive", payrollStatus: "active", salaryType: "monthly", baseSalary: 13_500_000, dailyRate: 0, overtimeEligible: false, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "Mandiri", bankCode: "008", accountNumber: "****9284", accountHolderName: "RINA FITRIANI", bankValidationStatus: "validated", nik: "3171****0006", npwp: "67.890.123.4-001.000", ptkpStatus: "TK0", taxMethod: "gross", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-007", name: "Hendra Wijaya", avatar: "HW", dept: "Operations", position: "Operations Coordinator", payrollStatus: "active", salaryType: "monthly", baseSalary: 9_500_000, dailyRate: 0, overtimeEligible: true, attendanceDeductionEnabled: true, taxEnabled: false, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BRI", bankCode: "002", accountNumber: "****3312", accountHolderName: "HENDRA WIJAYA", bankValidationStatus: "invalid", ptkpStatus: "TK0", bpjsKesehatanActive: true, jhtActive: true, jpActive: false, jkkActive: true, jkmActive: true },
  { employeeId: "EMP-008", name: "Maya Sari", avatar: "MS", dept: "Engineering", position: "Software Engineer", payrollStatus: "active", salaryType: "monthly", baseSalary: 17_500_000, dailyRate: 0, overtimeEligible: true, attendanceDeductionEnabled: true, taxEnabled: true, bpjsEnabled: true, paymentMethod: "bank_transfer", bankName: "BCA", bankCode: "014", accountNumber: "****6641", accountHolderName: "MAYA SARI", bankValidationStatus: "validated", nik: "3171****0008", npwp: "89.012.345.6-001.000", ptkpStatus: "K0", taxMethod: "gross_up", bpjsKesehatanActive: true, jhtActive: true, jpActive: true, jkkActive: true, jkmActive: true },
];

// ─── Payslips ─────────────────────────────────────────────────────────────────
export const payslips: Payslip[] = [
  { id: "ps-001", payslipNumber: "SLP-2025-05-001", employeeId: "EMP-001", employeeName: "Budi Santoso", avatar: "BS", dept: "Engineering", payrollRunId: "run-001", periodMonth: 5, periodYear: 2025, grossSalary: 21_350_000, totalDeduction: 2_698_000, netSalary: 18_652_000, status: "draft" },
  { id: "ps-002", payslipNumber: "SLP-2025-05-002", employeeId: "EMP-002", employeeName: "Dewi Rahayu", avatar: "DR", dept: "Marketing", payrollRunId: "run-001", periodMonth: 5, periodYear: 2025, grossSalary: 15_350_000, totalDeduction: 1_820_000, netSalary: 13_530_000, status: "draft" },
  { id: "ps-003", payslipNumber: "SLP-2025-04-001", employeeId: "EMP-001", employeeName: "Budi Santoso", avatar: "BS", dept: "Engineering", payrollRunId: "run-002", periodMonth: 4, periodYear: 2025, grossSalary: 20_850_000, totalDeduction: 2_598_000, netSalary: 18_252_000, status: "sent", generatedAt: "2025-05-03 09:00:00", sentAt: "2025-05-03 10:00:00" },
  { id: "ps-004", payslipNumber: "SLP-2025-04-002", employeeId: "EMP-002", employeeName: "Dewi Rahayu", avatar: "DR", dept: "Marketing", payrollRunId: "run-002", periodMonth: 4, periodYear: 2025, grossSalary: 14_850_000, totalDeduction: 1_780_000, netSalary: 13_070_000, status: "sent", generatedAt: "2025-05-03 09:00:00", sentAt: "2025-05-03 10:00:00" },
  { id: "ps-005", payslipNumber: "SLP-2025-04-003", employeeId: "EMP-003", employeeName: "Ahmad Fauzi", avatar: "AF", dept: "Finance", payrollRunId: "run-002", periodMonth: 4, periodYear: 2025, grossSalary: 18_450_000, totalDeduction: 2_350_000, netSalary: 16_100_000, status: "sent", generatedAt: "2025-05-03 09:00:00", sentAt: "2025-05-03 10:00:00" },
  { id: "ps-006", payslipNumber: "SLP-2025-04-004", employeeId: "EMP-004", employeeName: "Sari Putri", avatar: "SP", dept: "HR", payrollRunId: "run-002", periodMonth: 4, periodYear: 2025, grossSalary: 11_350_000, totalDeduction: 1_250_000, netSalary: 10_100_000, status: "generated", generatedAt: "2025-05-03 09:00:00" },
];

// ─── BPJS Rate Settings ───────────────────────────────────────────────────────
export const bpjsRateSettings: BpjsRateSetting[] = [
  { id: "bpjs-001", programCode: "bpjs_kesehatan", programName: "BPJS Kesehatan", employeeRate: 1, employerRate: 4, salaryCap: 12_000_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "bpjs-002", programCode: "jht", programName: "JHT (Jaminan Hari Tua)", employeeRate: 2, employerRate: 3.7, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "bpjs-003", programCode: "jp", programName: "JP (Jaminan Pensiun)", employeeRate: 1, employerRate: 2, salaryCap: 9_077_600, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "bpjs-004", programCode: "jkk", programName: "JKK (Jaminan Kecelakaan Kerja)", employeeRate: 0, employerRate: 0.24, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "bpjs-005", programCode: "jkm", programName: "JKM (Jaminan Kematian)", employeeRate: 0, employerRate: 0.3, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "bpjs-006", programCode: "jkp", programName: "JKP (Jaminan Kehilangan Pekerjaan)", employeeRate: 0, employerRate: 0.22, effectiveStartDate: "2024-01-01", isActive: true },
];

// ─── PTKP Settings ────────────────────────────────────────────────────────────
export const ptkpSettings: PtkpSetting[] = [
  { id: "ptkp-001", ptkpCode: "TK0", ptkpName: "Tidak Kawin, 0 Tanggungan", amount: 54_000_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-002", ptkpCode: "TK1", ptkpName: "Tidak Kawin, 1 Tanggungan", amount: 58_500_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-003", ptkpCode: "TK2", ptkpName: "Tidak Kawin, 2 Tanggungan", amount: 63_000_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-004", ptkpCode: "TK3", ptkpName: "Tidak Kawin, 3 Tanggungan", amount: 67_500_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-005", ptkpCode: "K0", ptkpName: "Kawin, 0 Tanggungan", amount: 58_500_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-006", ptkpCode: "K1", ptkpName: "Kawin, 1 Tanggungan", amount: 63_000_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-007", ptkpCode: "K2", ptkpName: "Kawin, 2 Tanggungan", amount: 67_500_000, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ptkp-008", ptkpCode: "K3", ptkpName: "Kawin, 3 Tanggungan", amount: 72_000_000, effectiveStartDate: "2024-01-01", isActive: true },
];

// ─── TER Settings ─────────────────────────────────────────────────────────────
export const terSettings: TerSetting[] = [
  { id: "ter-001", terCategory: "A", incomeMin: 0, incomeMax: 5_400_000, rate: 0, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-002", terCategory: "A", incomeMin: 5_400_001, incomeMax: 5_650_000, rate: 0.25, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-003", terCategory: "A", incomeMin: 5_650_001, incomeMax: 5_950_000, rate: 0.5, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-004", terCategory: "A", incomeMin: 5_950_001, incomeMax: 6_300_000, rate: 0.75, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-005", terCategory: "A", incomeMin: 6_300_001, incomeMax: 6_750_000, rate: 1, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-006", terCategory: "B", incomeMin: 0, incomeMax: 6_200_000, rate: 0, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-007", terCategory: "B", incomeMin: 6_200_001, incomeMax: 6_500_000, rate: 0.25, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-008", terCategory: "C", incomeMin: 0, incomeMax: 7_100_000, rate: 0, effectiveStartDate: "2024-01-01", isActive: true },
  { id: "ter-009", terCategory: "C", incomeMin: 7_100_001, incomeMax: 7_500_000, rate: 0.25, effectiveStartDate: "2024-01-01", isActive: true },
];

// ─── Payment Batches ──────────────────────────────────────────────────────────
export const paymentBatches: PaymentBatch[] = [
  {
    id: "batch-001",
    batchCode: "PAY-2025-04-001",
    payrollRunId: "run-002",
    payrollRunName: "Payroll April 2025",
    provider: "brick",
    totalAmount: 4_335_300_000,
    totalEmployees: 283,
    successCount: 283,
    failedCount: 0,
    pendingCount: 0,
    status: "success",
    submittedAt: "2025-05-04 10:00:00",
    completedAt: "2025-05-04 14:30:00",
    createdAt: "2025-05-04 09:00:00",
  },
  {
    id: "batch-002",
    batchCode: "PAY-2025-04-THR",
    payrollRunId: "run-003",
    payrollRunName: "THR Lebaran 2025",
    provider: "brick",
    totalAmount: 4_275_000_000,
    totalEmployees: 283,
    successCount: 283,
    failedCount: 0,
    pendingCount: 0,
    status: "success",
    submittedAt: "2025-04-01 08:00:00",
    completedAt: "2025-04-01 11:00:00",
    createdAt: "2025-04-01 07:00:00",
  },
  {
    id: "batch-003",
    batchCode: "PAY-2025-03-001",
    payrollRunId: "run-004",
    payrollRunName: "Payroll Maret 2025",
    provider: "brick",
    totalAmount: 4_223_000_000,
    totalEmployees: 280,
    successCount: 276,
    failedCount: 4,
    pendingCount: 0,
    status: "partial",
    submittedAt: "2025-04-04 10:00:00",
    completedAt: "2025-04-04 16:00:00",
    createdAt: "2025-04-04 09:00:00",
  },
];

export const paymentItems: PaymentItem[] = [
  { id: "pi-001", batchId: "batch-001", employeeId: "EMP-001", employeeName: "Budi Santoso", avatar: "BS", bankName: "BCA", bankCode: "014", accountNumber: "****4521", accountHolderName: "BUDI SANTOSO", amount: 18_252_000, status: "success", providerTransactionId: "TXN-20250504-001", paidAt: "2025-05-04 14:00:00" },
  { id: "pi-002", batchId: "batch-001", employeeId: "EMP-002", employeeName: "Dewi Rahayu", avatar: "DR", bankName: "Mandiri", bankCode: "008", accountNumber: "****8832", accountHolderName: "DEWI RAHAYU", amount: 13_070_000, status: "success", providerTransactionId: "TXN-20250504-002", paidAt: "2025-05-04 14:00:00" },
  { id: "pi-003", batchId: "batch-003", employeeId: "EMP-007", employeeName: "Hendra Wijaya", avatar: "HW", bankName: "BRI", bankCode: "002", accountNumber: "****3312", accountHolderName: "HENDRA WIJAYA", amount: 8_650_000, status: "failed", failureCode: "INVALID_ACCOUNT", failureReason: "Nomor rekening tidak ditemukan" },
];

// ─── Monthly trend data ───────────────────────────────────────────────────────
export const monthlyTrendIDR = [
  { month: "Jan", total: 4_620_000_000, deductions: 345_000_000, overtime: 185_000_000 },
  { month: "Feb", total: 4_680_000_000, deductions: 358_000_000, overtime: 198_000_000 },
  { month: "Mar", total: 4_752_000_000, deductions: 372_000_000, overtime: 215_000_000 },
  { month: "Apr", total: 4_750_000_000, deductions: 380_250_000, overtime: 224_000_000 },
  { month: "Mei", total: 4_820_000_000, deductions: 390_000_000, overtime: 235_000_000 },
  { month: "Jun", total: 0, deductions: 0, overtime: 0 },
];

// ─── Department cost ──────────────────────────────────────────────────────────
export const deptCostsIDR = [
  { dept: "Engineering", cost: 1_654_000_000, headcount: 48 },
  { dept: "Sales",       cost: 1_085_000_000, headcount: 52 },
  { dept: "Operations",  cost:   890_000_000, headcount: 61 },
  { dept: "Finance",     cost:   645_000_000, headcount: 22 },
  { dept: "Marketing",   cost:   380_000_000, headcount: 18 },
  { dept: "HR",          cost:   146_000_000, headcount: 8  },
];

// ─── Payroll Issues ───────────────────────────────────────────────────────────
export const payrollIssues = [
  { type: "warning", message: "3 karyawan belum memiliki rekening bank tervalidasi", count: 3 },
  { type: "error", message: "1 karyawan tidak memiliki profil BPJS aktif", count: 1 },
  { type: "info", message: "11 payslip menunggu approval Finance Director", count: 11 },
  { type: "warning", message: "2 karyawan profil pajak belum lengkap (NPWP kosong)", count: 2 },
];
