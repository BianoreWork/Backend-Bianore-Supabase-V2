import { useState } from "react";
import {
  BarChart2, Download, MoreHorizontal,
  TrendingUp, TrendingDown,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell,
} from "recharts";
import { deptCostsIDR, monthlyTrendIDR, fmtIDR, fmtIDRShort } from "./payrollMockData";

type ReportTab = "summary" | "employee" | "department" | "bpjs" | "tax" | "bank";

const tooltipStyle = {
  contentStyle: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px", fontSize: "11px", padding: "8px 12px" },
  cursor: { fill: "rgba(59,130,246,0.04)" },
};

const deptColors: Record<string, string> = {
  Engineering: "#3b82f6", Sales: "#10b981", Operations: "#f59e0b",
  Finance: "#06b6d4", Marketing: "#ec4899", HR: "#8b5cf6",
};

const PIE_COLORS = ["#3b82f6","#10b981","#f59e0b","#06b6d4","#ec4899","#8b5cf6"];

const employeeReport = [
  { name: "Budi Santoso",  dept: "Engineering", gross: 21_350_000, deduction: 2_698_000, net: 18_652_000, bpjs: 570_000, tax: 780_000 },
  { name: "Dewi Rahayu",   dept: "Marketing",   gross: 15_350_000, deduction: 1_820_000, net: 13_530_000, bpjs: 400_000, tax: 524_000 },
  { name: "Ahmad Fauzi",   dept: "Finance",     gross: 18_450_000, deduction: 2_350_000, net: 16_100_000, bpjs: 510_000, tax: 604_000 },
  { name: "Sari Putri",    dept: "HR",          gross: 11_350_000, deduction: 1_250_000, net: 10_100_000, bpjs: 300_000, tax: 137_000 },
  { name: "Eko Prasetyo",  dept: "Operations",  gross: 14_350_000, deduction: 1_920_000, net: 12_430_000, bpjs: 390_000, tax: 449_000 },
  { name: "Rina Fitriani", dept: "Sales",       gross: 17_350_000, deduction: 2_145_000, net: 15_205_000, bpjs: 480_000, tax: 672_000 },
];

const deptReport = deptCostsIDR.map((d) => ({
  ...d,
  avgSalary: Math.round(d.cost / d.headcount),
  bpjsTotal: Math.round(d.cost * 0.074),
  taxTotal: Math.round(d.cost * 0.045),
}));

const bankReport = [
  { bank: "BCA",     count: 98,  amount: 1_845_000_000 },
  { bank: "Mandiri", count: 72,  amount: 1_320_000_000 },
  { bank: "BNI",     count: 54,  amount: 920_000_000 },
  { bank: "BRI",     count: 45,  amount: 740_000_000 },
  { bank: "CIMB",    count: 18,  amount: 295_000_000 },
];

const deptColors2: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700", Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",     HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700", Sales: "bg-green-50 text-green-700",
};

export function PayrollReportsPage() {
  const [activeTab, setActiveTab] = useState<ReportTab>("summary");

  const reportTabs: { id: ReportTab; label: string }[] = [
    { id: "summary",    label: "Ringkasan" },
    { id: "employee",   label: "Per Karyawan" },
    { id: "department", label: "Per Departemen" },
    { id: "bpjs",       label: "BPJS" },
    { id: "tax",        label: "PPh21" },
    { id: "bank",       label: "Transfer Bank" },
  ];

  const validTrend = monthlyTrendIDR.filter((m) => m.total > 0);

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Laporan Payroll</h1>
          <p className="text-sm text-gray-500 mt-0.5">Analitik komprehensif — payroll, BPJS, PPh21, dan transfer bank</p>
        </div>
        <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
          <Download size={13} className="text-gray-400" /> Export Laporan
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0 border-b border-gray-200 overflow-x-auto">
        {reportTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── SUMMARY ── */}
      {activeTab === "summary" && (
        <div className="space-y-5">
          {/* KPI summary */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Total Payroll YTD",   value: fmtIDRShort(4_620_000_000 + 4_680_000_000 + 4_752_000_000 + 4_750_000_000 + 4_820_000_000), trend: "+4.3%", up: true, color: "blue" },
              { label: "Rata-rata / Karyawan", value: fmtIDRShort(Math.round(4_820_000_000 / 287)),     trend: "+1.8%", up: true,  color: "green" },
              { label: "Total BPJS (Mei)",     value: fmtIDRShort(145_800_000 + 362_100_000),           trend: "+1.5%", up: false, color: "teal" },
              { label: "Total PPh21 (Mei)",    value: fmtIDRShort(210_450_000),                         trend: "+2.4%", up: false, color: "amber" },
            ].map((card) => {
              const colorMap: Record<string, { bg: string; text: string }> = {
                blue:  { bg: "bg-blue-50",  text: "text-blue-600"  },
                green: { bg: "bg-green-50", text: "text-green-600" },
                teal:  { bg: "bg-teal-50",  text: "text-teal-600"  },
                amber: { bg: "bg-amber-50", text: "text-amber-600" },
              };
              const c = colorMap[card.color];
              return (
                <div key={card.label} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-9 h-9 rounded-xl ${c.bg} ${c.text} flex items-center justify-center`}>
                      <BarChart2 size={17} />
                    </div>
                    <span className={`flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${card.up ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
                      {card.up ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
                      {card.trend}
                    </span>
                  </div>
                  <p className="text-xl font-bold text-gray-900">{card.value}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{card.label}</p>
                </div>
              );
            })}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Tren Payroll Bulanan</h3>
                  <p className="text-xs text-gray-400 mt-0.5">5 bulan terakhir · IDR</p>
                </div>
                <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><MoreHorizontal size={15} /></button>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={validTrend}>
                  <defs>
                    <linearGradient id="rptGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1_000_000_000).toFixed(1)}M`} />
                  <Tooltip {...tooltipStyle} formatter={(v: number) => [fmtIDR(v), ""]} />
                  <Legend wrapperStyle={{ fontSize: "11px" }} />
                  <Area type="monotone" dataKey="total" name="Total Payroll" stroke="#3b82f6" strokeWidth={2} fill="url(#rptGrad)" dot={{ r: 3, fill: "#3b82f6" }} />
                  <Area type="monotone" dataKey="deductions" name="Total Potongan" stroke="#ef4444" strokeWidth={1.5} fill="none" strokeDasharray="4 2" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Pie chart */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Distribusi per Departemen</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Mei 2025</p>
                </div>
                <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><MoreHorizontal size={15} /></button>
              </div>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width="50%" height={170}>
                  <PieChart>
                    <Pie data={deptCostsIDR} dataKey="cost" cx="50%" cy="50%" outerRadius={70} innerRadius={35}>
                      {deptCostsIDR.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {deptCostsIDR.map((d, i) => {
                    const total = deptCostsIDR.reduce((s, x) => s + x.cost, 0);
                    const pct   = Math.round((d.cost / total) * 100);
                    return (
                      <div key={d.dept} className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <span className="text-[10px] text-gray-600 flex-1">{d.dept}</span>
                        <span className="text-[10px] font-semibold text-gray-800">{pct}%</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Overtime trend */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-gray-800">Biaya Lembur vs Total Potongan</h3>
                <p className="text-xs text-gray-400 mt-0.5">Perbandingan 5 bulan terakhir</p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={validTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1_000_000).toFixed(0)}jt`} />
                <Tooltip {...tooltipStyle} formatter={(v: number) => [fmtIDR(v), ""]} />
                <Legend wrapperStyle={{ fontSize: "11px" }} />
                <Bar dataKey="overtime" name="Lembur" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="deductions" name="Total Potongan" fill="#f87171" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ── PER KARYAWAN ── */}
      {activeTab === "employee" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-gray-800">Laporan Per Karyawan — Mei 2025</h3>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
              <Download size={12} /> Export CSV
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[700px]">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/60">
                  {["Karyawan", "Dept", "Gaji Bruto", "Total Potongan", "BPJS Emp", "PPh21", "Gaji Netto"].map((col) => (
                    <th key={col} className="text-left px-4 py-3">
                      <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {employeeReport.map((e, idx) => {
                  const dc = deptColors2[e.dept] || "bg-gray-100 text-gray-600";
                  return (
                    <tr key={e.name} className={`border-b border-gray-50 hover:bg-blue-50/20 ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                      <td className="px-4 py-3.5"><span className="text-xs font-semibold text-gray-800">{e.name}</span></td>
                      <td className="px-4 py-3.5"><span className={`text-xs font-medium px-2 py-0.5 rounded-md ${dc}`}>{e.dept}</span></td>
                      <td className="px-4 py-3.5"><span className="text-xs text-gray-700 tabular-nums">{fmtIDR(e.gross)}</span></td>
                      <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">({fmtIDR(e.deduction)})</span></td>
                      <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">{fmtIDR(e.bpjs)}</span></td>
                      <td className="px-4 py-3.5"><span className="text-xs text-red-600 tabular-nums">{fmtIDR(e.tax)}</span></td>
                      <td className="px-4 py-3.5"><span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(e.net)}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── PER DEPARTEMEN ── */}
      {activeTab === "department" && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">Cost per Departemen — Mei 2025</h3>
            <div className="space-y-3">
              {deptReport.map((d) => {
                const totalCost = deptReport.reduce((s, x) => s + x.cost, 0);
                const pct  = Math.round((d.cost / totalCost) * 100);
                const color = deptColors[d.dept] || "#6b7280";
                return (
                  <div key={d.dept} className="flex items-center gap-3">
                    <div className="w-24 text-xs text-gray-600 font-medium text-right flex-shrink-0">{d.dept}</div>
                    <div className="flex-1 h-6 bg-gray-100 rounded-lg overflow-hidden">
                      <div className="h-full rounded-lg flex items-center pl-2" style={{ width: `${pct}%`, backgroundColor: color }}>
                        <span className="text-[9px] text-white font-semibold">{pct}%</span>
                      </div>
                    </div>
                    <div className="w-36 text-right flex-shrink-0">
                      <p className="text-xs font-bold text-gray-800">{fmtIDRShort(d.cost)}</p>
                      <p className="text-[9px] text-gray-400">{d.headcount} org · avg {fmtIDRShort(d.avgSalary)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── BPJS REPORT ── */}
      {activeTab === "bpjs" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-gray-800">Laporan BPJS — Mei 2025</h3>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
              <Download size={12} /> Export File BPJS
            </button>
          </div>
          <div className="px-5 py-4 grid grid-cols-3 gap-4">
            {[
              { label: "Total Iuran Karyawan", value: fmtIDR(145_800_000), color: "text-red-700 bg-red-50" },
              { label: "Total Iuran Perusahaan", value: fmtIDR(362_100_000), color: "text-blue-700 bg-blue-50" },
              { label: "Total BPJS", value: fmtIDR(507_900_000), color: "text-green-700 bg-green-50" },
            ].map((s) => (
              <div key={s.label} className={`rounded-xl p-4 text-center ${s.color}`}>
                <p className="text-xl font-bold">{s.value}</p>
                <p className="text-xs font-semibold opacity-70 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── PPH21 REPORT ── */}
      {activeTab === "tax" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-gray-800">Laporan PPh21 — Mei 2025</h3>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
              <Download size={12} /> Export e-SPT
            </button>
          </div>
          <div className="px-5 py-4 grid grid-cols-3 gap-4">
            {[
              { label: "Total PPh21 Dipotong", value: fmtIDR(210_450_000), color: "text-red-700 bg-red-50" },
              { label: "Karyawan Kena Pajak", value: "267 karyawan", color: "text-amber-700 bg-amber-50" },
              { label: "Bebas Pajak (PTKP)", value: "20 karyawan", color: "text-green-700 bg-green-50" },
            ].map((s) => (
              <div key={s.label} className={`rounded-xl p-4 text-center ${s.color}`}>
                <p className="text-xl font-bold">{s.value}</p>
                <p className="text-xs font-semibold opacity-70 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── TRANSFER BANK ── */}
      {activeTab === "bank" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-gray-800">Laporan Transfer Bank — Mei 2025</h3>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
              <Download size={12} /> Export
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/60">
                  {["Bank Tujuan", "Jumlah Karyawan", "Total Transfer", "% dari Total"].map((col) => (
                    <th key={col} className="text-left px-5 py-3">
                      <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bankReport.map((b, idx) => {
                  const totalAmt = bankReport.reduce((s, x) => s + x.amount, 0);
                  const pct = Math.round((b.amount / totalAmt) * 100);
                  return (
                    <tr key={b.bank} className={`border-b border-gray-50 hover:bg-blue-50/20 ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                      <td className="px-5 py-3.5"><span className="text-xs font-semibold text-gray-800">{b.bank}</span></td>
                      <td className="px-5 py-3.5"><span className="text-xs text-gray-700">{b.count} karyawan</span></td>
                      <td className="px-5 py-3.5"><span className="text-xs font-bold text-gray-900 tabular-nums">{fmtIDR(b.amount)}</span></td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-24 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs text-gray-600">{pct}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="h-4" />
    </main>
  );
}
