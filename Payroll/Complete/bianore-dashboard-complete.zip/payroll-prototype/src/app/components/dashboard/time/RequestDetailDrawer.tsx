import { X, CheckCircle2, XCircle, Calendar, MapPin, Clock, User, Building2, Paperclip, FileText, ChevronRight } from "lucide-react";
import type { LeaveRequest, CorrectionRequest, OvertimeRequest } from "./timeMockData";
import { statusConfig, leaveTypeConfig } from "./timeMockData";

type AnyRequest = LeaveRequest | CorrectionRequest | OvertimeRequest;
type DrawerMode = "leave" | "correction" | "overtime";

interface RequestDetailDrawerProps {
  isOpen: boolean;
  mode: DrawerMode;
  request: AnyRequest | null;
  onClose: () => void;
}

function Row({ label, value, className = "" }: { label: string; value?: React.ReactNode; className?: string }) {
  return (
    <div className={`flex items-start justify-between gap-4 py-2.5 ${className}`}>
      <span className="text-xs text-gray-400 font-medium flex-shrink-0 min-w-[130px]">{label}</span>
      <span className="text-xs text-gray-800 font-medium text-right">{value ?? "—"}</span>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 px-5">{title}</p>
      <div className="bg-white mx-3 rounded-2xl border border-gray-100 divide-y divide-gray-50 px-4">
        {children}
      </div>
    </div>
  );
}

export function RequestDetailDrawer({ isOpen, mode, request, onClose }: RequestDetailDrawerProps) {
  if (!request) return null;

  const sc = statusConfig[(request as AnyRequest & { status: any }).status];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-[2px] z-30 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <aside
        className={`fixed right-0 top-0 h-full w-[420px] max-w-[95vw] bg-gray-50 z-40 shadow-2xl border-l border-gray-200 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 px-5 py-4 bg-white border-b border-gray-100 flex-shrink-0">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-sm font-bold text-gray-900">Request Detail</p>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${sc.pill}`}>
                {sc.label}
              </span>
            </div>
            <p className="text-xs text-gray-400">{(request as any).id}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer flex-shrink-0">
            <X size={16} className="text-gray-500"/>
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-1">

          {/* Employee Info */}
          <Section title="Employee">
            <Row label="Name"        value={(request as any).employee}/>
            <Row label="Employee ID" value={(request as any).employeeId}/>
            <Row label="Department"  value={(request as any).dept}/>
            <Row label="Branch"      value={(request as any).branch}/>
          </Section>

          {/* Leave-specific */}
          {mode === "leave" && (() => {
            const r = request as LeaveRequest;
            const lc = leaveTypeConfig[r.type];
            return (
              <>
                <Section title="Request Details">
                  <Row label="Request Type" value={
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${lc.pill}`}>{lc.icon} {r.type}</span>
                  }/>
                  <Row label="Start Date"   value={r.startDate}/>
                  <Row label="End Date"     value={r.endDate}/>
                  <Row label="Duration"     value={`${r.duration} day${r.duration > 1 ? "s" : ""}${r.halfDay ? " (Half day)" : ""}`}/>
                  {r.halfDay && <Row label="Half Day Part" value={r.halfDayPart === "first" ? "First half" : "Second half"}/>}
                  <Row label="Reason"       value={<span className="text-right max-w-[200px] break-words">{r.reason}</span>}/>
                  {r.attachment && <Row label="Attachment" value={<span className="flex items-center gap-1 text-blue-600"><Paperclip size={11}/> View attachment</span>}/>}
                </Section>

                <Section title="Sick Leave Details (if applicable)">
                  <Row label="Doctor's Note" value={r.sickNote ? "✓ Submitted" : "Not required / Not provided"}/>
                  <Row label="Mandatory"     value="Policy: Required for 2+ days sick leave"/>
                </Section>

                <Section title="Approval">
                  <Row label="Approver"         value={r.approver}/>
                  <Row label="Submitted At"     value={r.submittedAt}/>
                  <Row label="Last Updated"     value={r.updatedAt}/>
                  {r.adminNote && <Row label="Admin Note" value={r.adminNote}/>}
                  {r.rejectionReason && <Row label="Rejection Reason" value={<span className="text-red-600">{r.rejectionReason}</span>}/>}
                </Section>

                {r.attendanceImpact && (
                  <div className="mx-3">
                    <div className="bg-blue-50 border border-blue-200 rounded-2xl px-4 py-3">
                      <p className="text-[10px] font-bold text-blue-700 uppercase tracking-wider mb-1">Attendance Impact</p>
                      <p className="text-xs text-blue-800">{r.attendanceImpact}</p>
                    </div>
                  </div>
                )}
              </>
            );
          })()}

          {/* Correction-specific */}
          {mode === "correction" && (() => {
            const r = request as CorrectionRequest;
            return (
              <>
                <Section title="Attendance Record">
                  <Row label="Date"              value={r.attendanceDate}/>
                  <Row label="Correction Type"   value={r.correctionType}/>
                  <Row label="Original Check-in" value={r.originalCheckIn}/>
                  <Row label="Original Check-out" value={r.originalCheckOut}/>
                  {r.requestedCheckIn  && <Row label="Requested Check-in"  value={<span className="text-blue-700 font-bold">{r.requestedCheckIn}</span>}/>}
                  {r.requestedCheckOut && <Row label="Requested Check-out" value={<span className="text-blue-700 font-bold">{r.requestedCheckOut}</span>}/>}
                  {r.requestedStatus   && <Row label="Requested Status"    value={<span className="text-blue-700 font-bold">{r.requestedStatus}</span>}/>}
                </Section>

                <Section title="Request Details">
                  <Row label="Reason"    value={<span className="text-right max-w-[200px] break-words">{r.reason}</span>}/>
                  {r.attachment && <Row label="Attachment" value={<span className="flex items-center gap-1 text-blue-600"><Paperclip size={11}/> View attachment</span>}/>}
                </Section>

                {r.relatedFlags && r.relatedFlags.length > 0 && (
                  <Section title="Related Flags">
                    <div className="py-2 flex flex-wrap gap-1.5">
                      {r.relatedFlags.map(f => (
                        <span key={f} className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-red-50 text-red-700 border border-red-200">{f}</span>
                      ))}
                    </div>
                  </Section>
                )}

                <Section title="Approval">
                  <Row label="Approver"     value={r.approver}/>
                  <Row label="Submitted At" value={r.submittedAt}/>
                  <Row label="Last Updated" value={r.updatedAt}/>
                  {r.approvedBy  && <Row label="Approved By"  value={r.approvedBy}/>}
                  {r.approvedAt  && <Row label="Approved At"  value={r.approvedAt}/>}
                  {r.reviewerNote && <Row label="Reviewer Note" value={r.reviewerNote}/>}
                </Section>
              </>
            );
          })()}

          {/* Overtime-specific */}
          {mode === "overtime" && (() => {
            const r = request as OvertimeRequest;
            return (
              <>
                <Section title="Overtime Details">
                  <Row label="Date"           value={r.overtimeDate}/>
                  <Row label="Type"           value={r.overtimeType}/>
                  <Row label="Scheduled Shift" value={r.scheduledShift}/>
                  <Row label="OT Start"       value={r.overtimeStart}/>
                  <Row label="OT End"         value={r.overtimeEnd}/>
                  <Row label="Total Duration" value={`${r.duration} hr${r.duration !== 1 ? "s" : ""}`}/>
                  {r.project && <Row label="Project / Task" value={r.project}/>}
                </Section>

                <Section title="Request Details">
                  <Row label="Reason"    value={<span className="text-right max-w-[200px] break-words">{r.reason}</span>}/>
                  {r.attachment && <Row label="Attachment" value={<span className="flex items-center gap-1 text-blue-600"><Paperclip size={11}/> View attachment</span>}/>}
                </Section>

                <Section title="Approval">
                  <Row label="Approver"     value={r.approver}/>
                  <Row label="Submitted At" value={r.submittedAt}/>
                  <Row label="Last Updated" value={r.updatedAt}/>
                  {r.approvedBy   && <Row label="Approved By"   value={r.approvedBy}/>}
                  {r.approvedAt   && <Row label="Approved At"   value={r.approvedAt}/>}
                  {r.approverNote && <Row label="Approver Note" value={r.approverNote}/>}
                </Section>
              </>
            );
          })()}

        </div>

        {/* Footer Actions */}
        {(request as any).status === "pending" && (
          <div className="flex items-center gap-2 px-4 py-3.5 bg-white border-t border-gray-100 flex-shrink-0">
            <button className="flex-1 flex items-center justify-center gap-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-colors">
              <CheckCircle2 size={13}/> Approve
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 bg-white border border-gray-200 hover:bg-red-50 hover:border-red-300 text-gray-600 hover:text-red-600 text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-colors">
              <XCircle size={13}/> Reject
            </button>
          </div>
        )}
        {(request as any).status === "needs_revision" && (
          <div className="px-4 py-3.5 bg-white border-t border-gray-100 flex-shrink-0">
            <button className="w-full flex items-center justify-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-colors">
              <FileText size={13}/> Request Revision
            </button>
          </div>
        )}
      </aside>
    </>
  );
}
