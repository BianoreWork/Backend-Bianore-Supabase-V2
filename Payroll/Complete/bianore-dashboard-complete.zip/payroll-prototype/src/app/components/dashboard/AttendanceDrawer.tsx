import { useState } from "react";
import {
  X,
  MapPin,
  Camera,
  Shield,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ChevronDown,
  ExternalLink,
  Fingerprint,
  CalendarDays,
  Building2,
  Pencil,
  Check,
} from "lucide-react";
import type { EmployeeLog, FlagCode } from "./mockData";
import { employeeDetailData } from "./mockData";

interface AttendanceDrawerProps {
  isOpen: boolean;
  employee: EmployeeLog | null;
  onClose: () => void;
}

const flagConfig: Record<FlagCode, { label: string; color: string; icon: React.ReactNode }> = {
  location_mismatch: {
    label: "Location Mismatch",
    color: "bg-red-50 text-red-700 border-red-200",
    icon: <MapPin size={11} />,
  },
  face_not_matched: {
    label: "Face Not Matched",
    color: "bg-red-50 text-red-700 border-red-200",
    icon: <Camera size={11} />,
  },
  camera_failure: {
    label: "Camera Failure",
    color: "bg-orange-50 text-orange-700 border-orange-200",
    icon: <Camera size={11} />,
  },
  suspicious_time: {
    label: "Suspicious Time",
    color: "bg-yellow-50 text-yellow-700 border-yellow-200",
    icon: <Clock size={11} />,
  },
  overtime: {
    label: "Overtime Logged",
    color: "bg-purple-50 text-purple-700 border-purple-200",
    icon: <Clock size={11} />,
  },
  late: {
    label: "Late Check-in",
    color: "bg-yellow-50 text-yellow-700 border-yellow-200",
    icon: <Clock size={11} />,
  },
};

const statusConfig: Record<string, { bg: string; text: string; dot: string }> = {
  Present: { bg: "bg-green-50", text: "text-green-700", dot: "bg-green-500" },
  Late: { bg: "bg-yellow-50", text: "text-yellow-700", dot: "bg-yellow-500" },
  Absent: { bg: "bg-red-50", text: "text-red-600", dot: "bg-red-500" },
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",
  HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700",
  Sales: "bg-green-50 text-green-700",
};

const avatarGradients = [
  "from-blue-500 to-indigo-600",
  "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600",
  "from-rose-500 to-pink-600",
  "from-amber-500 to-orange-600",
];

const overrideOptions = [
  { value: "on-time", label: "Mark as On-time" },
  { value: "approve-late", label: "Approve Late" },
  { value: "ignore-flag", label: "Ignore All Flags" },
  { value: "mark-absent", label: "Mark as Absent" },
];

export function AttendanceDrawer({ isOpen, employee, onClose }: AttendanceDrawerProps) {
  const [overrideOpen, setOverrideOpen] = useState(false);
  const [overrideValue, setOverrideValue] = useState("on-time");
  const [overrideNote, setOverrideNote] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [overrideApplied, setOverrideApplied] = useState(false);
  const [appliedLabel, setAppliedLabel] = useState("");

  const detail = employee ? employeeDetailData[employee.id] : null;
  const sc = employee ? statusConfig[employee.status] : null;
  const dc = employee ? (deptColors[employee.dept] || "bg-gray-50 text-gray-600") : "";
  const grad = employee ? avatarGradients[employee.id % avatarGradients.length] : avatarGradients[0];

  const handleOverrideConfirm = () => {
    const label = overrideOptions.find((o) => o.value === overrideValue)?.label || "";
    setAppliedLabel(label);
    setOverrideApplied(true);
    setShowModal(false);
    setOverrideOpen(false);
    setOverrideNote("");
  };

  const handleClose = () => {
    setOverrideOpen(false);
    setShowModal(false);
    setOverrideApplied(false);
    setAppliedLabel("");
    setOverrideNote("");
    onClose();
  };

  const biometricColor =
    !detail ? "bg-gray-200" :
    detail.biometricScore >= 95 ? "bg-green-500" :
    detail.biometricScore >= 80 ? "bg-yellow-500" :
    detail.biometricScore >= 60 ? "bg-orange-500" : "bg-red-500";

  const biometricLabel =
    !detail ? "" :
    detail.biometricScore >= 95 ? "Verified" :
    detail.biometricScore >= 80 ? "Good Match" :
    detail.biometricScore >= 60 ? "Weak Match" : "No Match";

  const biometricTextColor =
    !detail ? "text-gray-400" :
    detail.biometricScore >= 95 ? "text-green-700" :
    detail.biometricScore >= 80 ? "text-yellow-700" :
    detail.biometricScore >= 60 ? "text-orange-700" : "text-red-700";

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40 transition-opacity duration-300 ${
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={handleClose}
      />

      {/* Drawer Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-[460px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {employee && detail ? (
          <>
            {/* ── HEADER ── */}
            <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}
                >
                  {employee.avatar}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-bold text-gray-900">{employee.name}</p>
                    {overrideApplied ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                        <Check size={9} /> Overridden
                      </span>
                    ) : sc ? (
                      <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {employee.status}
                      </span>
                    ) : null}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>
                      {employee.dept}
                    </span>
                    <span className="text-[10px] text-gray-400">EMP#{String(employee.id).padStart(4, "0")}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer flex-shrink-0"
              >
                <X size={16} />
              </button>
            </div>

            {/* ── SCROLLABLE BODY ── */}
            <div className="flex-1 overflow-y-auto">
              {/* Date & Shift Strip */}
              <div className="flex items-center gap-4 px-5 py-3 bg-gray-50 border-b border-gray-100">
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <CalendarDays size={12} className="text-gray-400" />
                  <span>Thursday, Apr 30, 2026</span>
                </div>
                <div className="w-px h-3 bg-gray-300" />
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <Clock size={12} className="text-gray-400" />
                  <span>{detail.shiftType}</span>
                </div>
                <div className="w-px h-3 bg-gray-300" />
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <Building2 size={12} className="text-gray-400" />
                  <span className="truncate">{detail.locationZone !== "—" ? detail.locationZone : "Unknown"}</span>
                </div>
              </div>

              <div className="px-5 py-4 space-y-4">
                {/* ── OVERRIDE APPLIED BANNER ── */}
                {overrideApplied && (
                  <div className="flex items-center gap-2.5 px-4 py-3 bg-blue-50 rounded-xl border border-blue-200">
                    <CheckCircle size={15} className="text-blue-600 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-semibold text-blue-800">{appliedLabel} — Override Applied</p>
                      {overrideNote && (
                        <p className="text-[10px] text-blue-600 mt-0.5">Note: {overrideNote}</p>
                      )}
                    </div>
                  </div>
                )}

                {/* ── ATTENDANCE SUMMARY ── */}
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Check-in", value: employee.checkIn, color: employee.checkIn === "—" ? "text-gray-300" : "text-gray-800" },
                    { label: "Check-out", value: employee.checkOut, color: employee.checkOut === "—" ? "text-gray-300" : "text-gray-800" },
                    { label: "Duration", value: employee.hours, color: employee.hours === "0h" ? "text-gray-300" : "text-gray-800" },
                  ].map((item) => (
                    <div key={item.label} className="bg-gray-50 rounded-xl px-3 py-3 text-center">
                      <p className={`text-sm font-bold ${item.color}`}>{item.value}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{item.label}</p>
                    </div>
                  ))}
                </div>

                {/* ── ATTENDANCE PROOF ── */}
                <div>
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2.5">
                    Attendance Proof
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {/* Selfie Capture */}
                    <div className="bg-slate-800 rounded-xl overflow-hidden relative aspect-square flex flex-col items-center justify-center">
                      {/* Grid overlay */}
                      <div
                        className="absolute inset-0 opacity-10"
                        style={{
                          backgroundImage:
                            "linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)",
                          backgroundSize: "20px 20px",
                        }}
                      />
                      {/* Corner brackets */}
                      {[
                        "top-2 left-2 border-t-2 border-l-2",
                        "top-2 right-2 border-t-2 border-r-2",
                        "bottom-2 left-2 border-b-2 border-l-2",
                        "bottom-2 right-2 border-b-2 border-r-2",
                      ].map((pos, i) => (
                        <div key={i} className={`absolute w-4 h-4 ${pos} border-blue-400 rounded-sm`} />
                      ))}

                      {detail.cameraStatus === "failed" ? (
                        <div className="flex flex-col items-center gap-2 relative z-10">
                          <XCircle size={28} className="text-red-400" />
                          <p className="text-red-300 text-xs font-medium">Camera Failed</p>
                        </div>
                      ) : (
                        <>
                          <div
                            className={`w-14 h-14 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white font-bold text-lg relative z-10 ring-2 ring-blue-400/50`}
                          >
                            {employee.avatar}
                          </div>
                          <div className="mt-2 relative z-10 text-center px-2">
                            <p className="text-[9px] text-blue-300 font-semibold tracking-widest uppercase">
                              System Capture
                            </p>
                            <p className="text-[9px] text-slate-400 mt-0.5">{detail.capturedAt}</p>
                          </div>
                        </>
                      )}
                      <div className="absolute bottom-2 right-2 flex items-center gap-1">
                        <div className={`w-1.5 h-1.5 rounded-full ${detail.cameraStatus === "ok" ? "bg-green-400 animate-pulse" : "bg-red-400"}`} />
                        <span className="text-[8px] text-slate-400 uppercase tracking-wider">
                          {detail.cameraStatus === "ok" ? "Live" : "Error"}
                        </span>
                      </div>
                    </div>

                    {/* GPS & Info */}
                    <div className="flex flex-col gap-2.5">
                      {/* GPS */}
                      <div className="bg-gray-50 rounded-xl p-3">
                        <div className="flex items-center gap-1.5 mb-1.5">
                          <MapPin size={12} className="text-blue-500" />
                          <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wider">GPS Location</p>
                        </div>
                        {detail.gps === "—" ? (
                          <p className="text-xs text-gray-300">Not captured</p>
                        ) : (
                          <>
                            <p className="text-[11px] font-semibold text-gray-800 leading-tight">{detail.gps}</p>
                            <p className="text-[10px] text-gray-500 mt-0.5 leading-tight">{detail.gpsAddress}</p>
                            <div className="flex items-center gap-1 mt-2">
                              <div className={`w-1.5 h-1.5 rounded-full ${detail.locationMatch ? "bg-green-500" : "bg-red-500"}`} />
                              <span className={`text-[10px] font-semibold ${detail.locationMatch ? "text-green-700" : "text-red-600"}`}>
                                {detail.locationMatch ? "Zone Matched" : "Zone Mismatch"}
                              </span>
                            </div>
                            <button className="mt-1.5 flex items-center gap-1 text-[10px] text-blue-600 hover:text-blue-800 transition-colors cursor-pointer">
                              <ExternalLink size={9} /> View on Maps
                            </button>
                          </>
                        )}
                      </div>

                      {/* Timestamp */}
                      <div className="bg-gray-50 rounded-xl p-3">
                        <div className="flex items-center gap-1.5 mb-1">
                          <Clock size={12} className="text-blue-500" />
                          <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wider">Timestamp</p>
                        </div>
                        <p className="text-[11px] font-semibold text-gray-800">
                          {detail.capturedAt === "—" ? "Not recorded" : detail.capturedAt}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">
                          Shift start: {detail.shiftStart}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── BIOMETRIC ── */}
                <div>
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2.5">
                    Biometric Verification
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${detail.biometricMatch ? "bg-green-50" : "bg-red-50"}`}>
                          <Fingerprint size={16} className={detail.biometricMatch ? "text-green-600" : "text-red-500"} />
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-gray-800">Face Recognition</p>
                          <p className={`text-[10px] font-semibold ${biometricTextColor}`}>{biometricLabel}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-lg font-bold ${biometricTextColor}`}>
                          {detail.biometricScore > 0 ? `${detail.biometricScore}%` : "—"}
                        </p>
                        <p className="text-[10px] text-gray-400">match score</p>
                      </div>
                    </div>
                    {/* Progress bar */}
                    <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${biometricColor}`}
                        style={{ width: `${detail.biometricScore}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-1.5">
                      <span className="text-[9px] text-gray-400">0%</span>
                      <span className="text-[9px] text-gray-400">Threshold: 85%</span>
                      <span className="text-[9px] text-gray-400">100%</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-2.5 pt-2.5 border-t border-gray-200">
                      {detail.biometricMatch ? (
                        <CheckCircle size={12} className="text-green-500" />
                      ) : (
                        <XCircle size={12} className="text-red-500" />
                      )}
                      <span className={`text-[10px] font-semibold ${detail.biometricMatch ? "text-green-700" : "text-red-600"}`}>
                        {detail.biometricMatch ? "Identity Verified" : "Verification Failed"}
                      </span>
                      <div className="flex items-center gap-1 ml-auto">
                        <Shield size={10} className="text-gray-400" />
                        <span className="text-[9px] text-gray-400">Auto-system</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── FLAGS ── */}
                {detail.flags.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2.5">
                      Flags &amp; Warnings
                    </p>
                    <div className="space-y-2">
                      {detail.flags.map((flag) => {
                        const cfg = flagConfig[flag];
                        return (
                          <div
                            key={flag}
                            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl border ${cfg.color}`}
                          >
                            <AlertTriangle size={13} className="flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-semibold">{cfg.label}</p>
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              {cfg.icon}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* ── OVERRIDE SECTION ── */}
                <div className="border-t border-gray-100 pt-4">
                  {!overrideApplied ? (
                    <>
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="text-xs font-semibold text-gray-800">Admin Override</p>
                          <p className="text-[10px] text-gray-400 mt-0.5">Manually adjust status or dismiss flags</p>
                        </div>
                        <button
                          onClick={() => setOverrideOpen(!overrideOpen)}
                          className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                            overrideOpen
                              ? "bg-gray-100 text-gray-600 border-gray-200"
                              : "bg-blue-600 text-white border-blue-600 hover:bg-blue-700"
                          }`}
                        >
                          <Pencil size={11} />
                          {overrideOpen ? "Cancel" : "Override Status"}
                          <ChevronDown
                            size={11}
                            className={`transition-transform ${overrideOpen ? "rotate-180" : ""}`}
                          />
                        </button>
                      </div>

                      {overrideOpen && (
                        <div className="bg-gray-50 rounded-xl p-4 space-y-3">
                          {/* Override Select */}
                          <div>
                            <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">
                              Action
                            </label>
                            <div className="relative">
                              <select
                                value={overrideValue}
                                onChange={(e) => setOverrideValue(e.target.value)}
                                className="w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 appearance-none cursor-pointer"
                              >
                                {overrideOptions.map((opt) => (
                                  <option key={opt.value} value={opt.value}>
                                    {opt.label}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                            </div>
                          </div>

                          {/* Note */}
                          <div>
                            <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">
                              Note (Optional)
                            </label>
                            <textarea
                              value={overrideNote}
                              onChange={(e) => setOverrideNote(e.target.value)}
                              placeholder="Add a reason for this override..."
                              rows={2}
                              className="w-full text-xs text-gray-700 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 resize-none placeholder:text-gray-400"
                            />
                          </div>

                          {/* Confirm Button */}
                          <button
                            onClick={() => setShowModal(true)}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2.5 rounded-lg transition-colors cursor-pointer"
                          >
                            Apply Override
                          </button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-gray-500">Override applied by Alex Kumar</p>
                      <button
                        onClick={() => { setOverrideApplied(false); setAppliedLabel(""); }}
                        className="text-xs text-gray-400 hover:text-gray-600 underline cursor-pointer"
                      >
                        Undo
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-300">
            <p className="text-sm">Select an employee</p>
          </div>
        )}

        {/* ── CONFIRM MODAL (overlay on drawer) ── */}
        {showModal && employee && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-10 flex items-center justify-center p-6">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[340px] overflow-hidden">
              <div className="px-5 pt-5 pb-4">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
                  <Pencil size={18} className="text-blue-600" />
                </div>
                <p className="text-sm font-bold text-gray-900">Confirm Override</p>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  You are about to override the attendance status for{" "}
                  <span className="font-semibold text-gray-700">{employee.name}</span>.
                </p>
                <div className="mt-3 p-3 bg-gray-50 rounded-xl space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Action</span>
                    <span className="font-semibold text-gray-800">
                      {overrideOptions.find((o) => o.value === overrideValue)?.label}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Employee</span>
                    <span className="font-semibold text-gray-800">{employee.name}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Authorized by</span>
                    <span className="font-semibold text-gray-800">Alex Kumar (HR)</span>
                  </div>
                  {overrideNote && (
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Note</span>
                      <span className="font-semibold text-gray-700 text-right max-w-[180px] truncate">{overrideNote}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-2 px-5 pb-5">
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 text-xs text-gray-600 py-2.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleOverrideConfirm}
                  className="flex-1 text-xs text-white bg-blue-600 hover:bg-blue-700 py-2.5 rounded-lg transition-colors cursor-pointer font-semibold"
                >
                  Confirm Override
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
