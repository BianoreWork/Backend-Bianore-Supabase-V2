import { motion } from "motion/react";
import { Search, Bell, ChevronDown, SlidersHorizontal, LogOut } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import type { PageId } from "./mockData";
import type { AuthUser } from "../auth/authData";
import { roleConfig } from "../auth/authData";

interface HeaderProps {
  activePage: PageId;
  onMenuToggle: () => void;
  isFilterOpen?: boolean;
  user: AuthUser | null;
  onLogout: () => void;
}

const pageInfo: Record<PageId, { crumb: string; section: string }> = {
  dashboard:  { crumb: "Dashboard",            section: "Analytics"         },
  attendance: { crumb: "Attendance",           section: "Time & Attendance" },
  time:       { crumb: "Time",                 section: "Time & Attendance" },
  payroll:    { crumb: "Payroll",              section: "Finance"           },
  employees:  { crumb: "Employees",            section: "HR"                },
  reports:    { crumb: "Reports & Analytics",  section: "Analytics"         },
  sales:      { crumb: "Field Activity",        section: "Field Tracking"    },
  finance:    { crumb: "Finance",              section: "Finance"           },
  settings:   { crumb: "Settings",            section: "System"            },
};

export function Header({ activePage, onMenuToggle, isFilterOpen, user, onLogout }: HeaderProps) {
  const [notifications]            = useState(4);
  const [searchValue, setSearch]   = useState("");
  const [profileOpen, setProfile]  = useState(false);
  const profileRef                 = useRef<HTMLDivElement>(null);
  const info                       = pageInfo[activePage];

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfile(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const rc = user ? roleConfig[user.role] : null;

  return (
    <motion.header
      initial={{ y: -14, opacity: 0 }}
      animate={{ y: 0,   opacity: 1 }}
      transition={{ duration: 0.36, delay: 0.06, ease: [0.22, 1, 0.36, 1] }}
      className="bg-white border-b border-gray-100 px-5 py-0 flex items-center justify-between gap-4 sticky top-0 z-20 h-[53px]"
    >

      {/* Left: Filter toggle + Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        {/* Filter toggle — Dashboard only */}
        {activePage === "dashboard" && (
          <button
            onClick={onMenuToggle}
            title={isFilterOpen ? "Hide filters" : "Show filters"}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all cursor-pointer flex-shrink-0 ${
              isFilterOpen
                ? "bg-blue-50 border-blue-200 text-blue-700"
                : "bg-white border-gray-200 text-gray-500 hover:bg-gray-50 hover:text-gray-700"
            }`}
          >
            <SlidersHorizontal size={13}/>
            <span className="hidden sm:inline">Filters</span>
          </button>
        )}

        {/* Breadcrumb */}
        <div className="hidden sm:flex items-center gap-1.5 text-gray-400 text-xs">
          <span>HRIS</span>
          <span>›</span>
          <span>{info.section}</span>
          <span>›</span>
          <span className="text-gray-700 font-semibold">{info.crumb}</span>
        </div>
        <span className="sm:hidden text-sm font-semibold text-gray-800">{info.crumb}</span>
      </div>

      {/* Right: Search + Notifications + Profile */}
      <div className="flex items-center gap-2.5 flex-shrink-0">

        {/* Search */}
        <div className="relative hidden md:block">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input
            type="text"
            placeholder="Search employees..."
            value={searchValue}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 pr-4 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg w-52 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
          />
        </div>

        {/* Notifications */}
        <button className="relative p-1.5 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
          <Bell size={17} className="text-gray-500"/>
          {notifications > 0 && (
            <span className="absolute top-0.5 right-0.5 w-3.5 h-3.5 bg-red-500 text-white rounded-full flex items-center justify-center text-[8px] font-bold">
              {notifications}
            </span>
          )}
        </button>

        {/* Profile dropdown */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setProfile(!profileOpen)}
            className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
          >
            {/* Avatar */}
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0 ${rc?.avatarBg ?? "bg-gradient-to-br from-blue-500 to-indigo-600"}`}>
              {user?.avatar ?? "?"}
            </div>
            {/* Name + role */}
            <div className="hidden lg:block text-left">
              <p className="text-xs font-semibold text-gray-800 leading-tight">{user?.name ?? "Guest"}</p>
              <p className="text-[10px] text-gray-400 leading-tight">{user?.dept ?? ""}</p>
            </div>
            {/* Role badge */}
            {rc && (
              <span className={`hidden xl:inline text-[9px] font-bold px-1.5 py-0.5 rounded-md ${rc.pill}`}>
                {user?.role}
              </span>
            )}
            <ChevronDown size={13} className={`text-gray-400 hidden lg:block transition-transform ${profileOpen ? "rotate-180" : ""}`}/>
          </button>

          {/* Dropdown */}
          {profileOpen && (
            <div className="absolute right-0 top-full mt-2 w-60 bg-white border border-gray-100 rounded-2xl shadow-xl z-50 overflow-hidden">
              {/* User info */}
              <div className="px-4 py-3.5 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold ${rc?.avatarBg ?? "bg-blue-600"}`}>
                    {user?.avatar ?? "?"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-900 truncate">{user?.name}</p>
                    <p className="text-[11px] text-gray-500 truncate">{user?.email}</p>
                    {rc && (
                      <span className={`inline-block mt-1 text-[9px] font-bold px-2 py-0.5 rounded-md border ${rc.pill}`}>
                        {rc.icon} {user?.role}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              {/* Menu items */}
              <div className="px-2 py-1.5">
                {[
                  { label: "My Profile",    icon: "👤" },
                  { label: "Account Settings", icon: "⚙️" },
                  { label: "Security",      icon: "🔒" },
                ].map(item => (
                  <button key={item.label}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-gray-600 hover:bg-gray-50 cursor-pointer transition-colors text-left">
                    <span>{item.icon}</span> {item.label}
                  </button>
                ))}
              </div>
              {/* Logout */}
              <div className="px-2 py-1.5 border-t border-gray-100">
                <button
                  onClick={() => { setProfile(false); onLogout(); }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 cursor-pointer transition-colors"
                >
                  <LogOut size={13}/> Sign out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.header>
  );
}