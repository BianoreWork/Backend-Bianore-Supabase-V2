import { useState } from "react";
import {
  X, Mail, Phone, MapPin, Building2, CalendarDays, Clock, DollarSign,
  FileText, Star, CheckCircle, AlertTriangle, Edit2, UserX, ChevronRight,
  RefreshCw, Shield, Award, Fingerprint, ExternalLink,
} from "lucide-react";
import type { FullEmployee } from "./employeeData";
import { workScheduleLabels, onboardingStepLabels } from "./employeeData";
import { employeeLogs } from "../mockData";
import { payrollRecords } from "../payroll/payrollData";

interface EmployeeProfileDrawerProps {
  isOpen: boolean;
  employee: FullEmployee | null;
  onClose: () => void;
  onEdit?: (emp: FullEmployee) => void;
}

type ProfileTab = "profile" | "attendance" | "payroll" | "documents" | "performance";

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600",
  "from-amber-500 to-orange-600", "from-cyan-500 to-blue-600",
];

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",   Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",        HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700", Sales: "bg-green-50 text-green-700",
  Executive: "bg-gray-100 text-gray-700",
};

const statusConfig: Record<string, { bg: string; text: string; dot: string; label: string }> = {
  "active":     { bg: "bg-green-50",  text: "text-green-700",  dot: "bg-green-500",  label: "Active" },
  "on-leave":   { bg: "bg-yellow-50", text: "text-yellow-700", dot: "bg-yellow-500", label: "On Leave" },
  "resigned":   { bg: "bg-gray-100",  text: "text-gray-600",   dot: "bg-gray-400",   label: "Resigned" },
  "terminated": { bg: "bg-red-50",    text: "text-red-600",    dot: "bg-red-500",    label: "Terminated" },
};

const empTypeColors: Record<string, string> = {
  "full-time": "bg-blue-50 text-blue-700",
  "part-time": "bg-purple-50 text-purple-700",
  "contract":  "bg-amber-50 text-amber-700",
  "intern":    "bg-green-50 text-green-700",
};

const docTypeIcon: Record<string, React.ReactNode> = {
  contract:      <FileText size={12} />,
  id:            <Shield size={12} />,
  certification: <Award size={12} />,
  other:         <FileText size={12} />,
};

const docStatusColor: Record<string, string> = {
  uploaded: "text-green-700 bg-green-50",
  pending:  "text-yellow-700 bg-yellow-50",
  expired:  "text-red-600 bg-red-50",
};

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

function InfoRow({ icon, label, value, muted }: { icon: React.ReactNode; label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-gray-50 last:border-0">
      <div className="w-6 h-6 rounded-lg bg-gray-50 flex items-center justify-center text-gray-400 flex-shrink-0 mt-0.5">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] text-gray-400 uppercase tracking-wider">{label}</p>
        <p className={`text-xs font-semibold mt-0.5 ${muted ? "text-gray-300" : "text-gray-800"}`}>{value}</p>
      </div>
    </div>
  );
}

function StarRating({ score }: { score: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star key={s} size={12} className={s <= Math.round(score) ? "text-amber-400 fill-amber-400" : "text-gray-200"} />
      ))}
      <span className="ml-1.5 text-xs font-bold text-gray-700">{score > 0 ? score.toFixed(1) : "—"}</span>
    </div>
  );
}

export function EmployeeProfileDrawer({ isOpen, employee, onClose, onEdit }: EmployeeProfileDrawerProps) {
  const [activeTab, setActiveTab] = useState<ProfileTab>("profile");

  const grad = employee ? avatarGradients[employee.id % avatarGradients.length] : avatarGradients[0];
  const sc = employee ? statusConfig[employee.status] : null;
  const dc = employee ? (deptColors[employee.dept] || "bg-gray-50 text-gray-600") : "";
  const ws = employee ? workScheduleLabels[employee.schedule] : null;

  // Linked data from other modules
  const attendanceData = employee ? employeeLogs.find((l) => l.id === employee.id) : null;
  const payrollData = employee ? payrollRecords.find((r) => r.id === employee.id) : null;

  const tabs: { id: ProfileTab; label: string; icon: React.ReactNode }[] = [
    { id: "profile",     label: "Profile",     icon: <Shield size={12} /> },
    { id: "attendance",  label: "Attendance",  icon: <Clock size={12} /> },
    { id: "payroll",     label: "Payroll",     icon: <DollarSign size={12} /> },
    { id: "documents",   label: "Documents",   icon: <FileText size={12} /> },
    { id: "performance", label: "Performance", icon: <Star size={12} /> },
  ];

  const handleClose = () => { setActiveTab("profile"); onClose(); };

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40 transition-opacity duration-300 ${isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`}
        onClick={handleClose}
      />

      {/* Drawer */}
      <div className={`fixed top-0 right-0 h-full w-[540px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col transition-transform duration-300 ease-in-out ${isOpen ? "translate-x-0" : "translate-x-full"}`}>
        {employee ? (
          <>
            {/* ── PROFILE HEADER ── */}
            <div className="px-5 pt-5 pb-0 flex-shrink-0">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center text-white font-bold text-lg flex-shrink-0 shadow-lg`}>
                    {employee.avatar}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-base font-bold text-gray-900">{employee.name}</p>
                      {sc && (
                        <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                          {sc.label}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{employee.role}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>{employee.dept}</span>
                      <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded capitalize ${empTypeColors[employee.employmentType] || "bg-gray-50 text-gray-600"}`}>
                        {employee.employmentType}
                      </span>
                      <span className="text-[10px] text-gray-400">{employee.empId}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {onEdit && (
                    <button onClick={() => onEdit(employee)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer" title="Edit">
                      <Edit2 size={15} />
                    </button>
                  )}
                  <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer">
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* Quick Stats Strip */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {[
                  { label: "Join Date", value: new Date(employee.joinDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) },
                  { label: "Performance", value: employee.performanceScore > 0 ? `${employee.performanceScore}/5.0` : "Not reviewed" },
                  { label: "Schedule", value: ws?.label || "—" },
                ].map((s) => (
                  <div key={s.label} className="bg-gray-50 rounded-xl px-3 py-2.5 text-center">
                    <p className="text-[10px] text-gray-400">{s.label}</p>
                    <p className="text-xs font-bold text-gray-800 mt-0.5">{s.value}</p>
                  </div>
                ))}
              </div>

              {/* Tabs */}
              <div className="flex items-center border-b border-gray-100 -mx-5 px-5">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-3 py-2.5 text-[11px] font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
                    }`}
                  >
                    {tab.icon}{tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* ── TAB CONTENT ── */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">

              {/* PROFILE TAB */}
              {activeTab === "profile" && (
                <div className="space-y-4">
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Contact Information</p>
                    <InfoRow icon={<Mail size={12} />} label="Email" value={employee.email} />
                    <InfoRow icon={<Phone size={12} />} label="Phone" value={employee.phone || "—"} muted={!employee.phone} />
                    <InfoRow icon={<MapPin size={12} />} label="Location" value={employee.city || "—"} muted={!employee.city} />
                    <InfoRow icon={<MapPin size={12} />} label="Address" value={employee.address || "—"} muted={employee.address === "—"} />
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Employment Details</p>
                    <InfoRow icon={<Building2 size={12} />} label="Department" value={employee.dept} />
                    <InfoRow icon={<Shield size={12} />} label="Role / Position" value={employee.role} />
                    <InfoRow icon={<Fingerprint size={12} />} label="Access Level" value={employee.accessRole.charAt(0).toUpperCase() + employee.accessRole.slice(1)} />
                    <InfoRow icon={<CalendarDays size={12} />} label="Join Date" value={new Date(employee.joinDate).toLocaleDateString("en-US", { day: "numeric", month: "long", year: "numeric" })} />
                    {employee.contractEnd && (
                      <InfoRow icon={<CalendarDays size={12} />} label="Contract End" value={new Date(employee.contractEnd).toLocaleDateString("en-US", { day: "numeric", month: "long", year: "numeric" })} />
                    )}
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Work Setup</p>
                    {ws && (
                      <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs ${ws.color} border-current/20`}>
                        <Clock size={12} />
                        <div>
                          <p className="font-semibold">{ws.label}</p>
                          <p className="text-[10px] opacity-70 mt-0.5">{ws.hours}</p>
                        </div>
                      </div>
                    )}
                  </div>
                  {employee.onboardingStep > 0 && (
                    <div className="px-4 py-3 bg-amber-50 rounded-xl border border-amber-200">
                      <p className="text-xs font-semibold text-amber-800">Onboarding in Progress</p>
                      <p className="text-[10px] text-amber-700 mt-0.5">
                        Currently on Step {employee.onboardingStep}: {onboardingStepLabels[employee.onboardingStep]}
                      </p>
                      <div className="mt-2 h-1.5 bg-amber-200 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(employee.onboardingStep / 5) * 100}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ATTENDANCE TAB */}
              {activeTab === "attendance" && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-blue-50 rounded-xl border border-blue-100">
                    <RefreshCw size={12} className="text-blue-500" />
                    <p className="text-xs text-blue-700 font-medium">Live data synced from Attendance Module</p>
                    <button className="ml-auto text-[10px] text-blue-600 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer">
                      View all <ExternalLink size={9} />
                    </button>
                  </div>

                  {attendanceData ? (
                    <>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { label: "Check-in Time", value: attendanceData.checkIn, color: "text-gray-800" },
                          { label: "Check-out Time", value: attendanceData.checkOut, color: "text-gray-800" },
                          { label: "Status", value: attendanceData.status, color: attendanceData.status === "Present" ? "text-green-700" : attendanceData.status === "Late" ? "text-yellow-700" : "text-red-600" },
                          { label: "Work Duration", value: attendanceData.hours, color: "text-gray-800" },
                        ].map((s) => (
                          <div key={s.label} className="bg-gray-50 rounded-xl p-3">
                            <p className="text-[10px] text-gray-400">{s.label}</p>
                            <p className={`text-sm font-bold mt-0.5 ${s.color}`}>{s.value}</p>
                          </div>
                        ))}
                      </div>
                      <div>
                        <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Today's Record</p>
                        <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-500">Department</span>
                            <span className="font-semibold text-gray-800">{attendanceData.dept}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-500">Record date</span>
                            <span className="font-semibold text-gray-800">April 30, 2026</span>
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="py-8 text-center">
                      <Clock size={28} className="text-gray-200 mx-auto mb-2" />
                      <p className="text-xs text-gray-400">No attendance data available for this employee.</p>
                      <p className="text-[10px] text-gray-300 mt-1">Data will appear once check-in is recorded.</p>
                    </div>
                  )}
                </div>
              )}

              {/* PAYROLL TAB */}
              {activeTab === "payroll" && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-blue-50 rounded-xl border border-blue-100">
                    <RefreshCw size={12} className="text-blue-500" />
                    <p className="text-xs text-blue-700 font-medium">Read-only data synced from Payroll Module</p>
                    <button className="ml-auto text-[10px] text-blue-600 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer">
                      View full payroll <ExternalLink size={9} />
                    </button>
                  </div>

                  {payrollData ? (
                    <>
                      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4 flex items-center justify-between">
                        <div>
                          <p className="text-xs text-blue-100">Net Salary · {payrollData.payPeriod}</p>
                          <span className={`text-[10px] font-semibold mt-1 px-2 py-0.5 rounded-full ${
                            payrollData.status === "paid" ? "bg-green-400/30 text-green-100" :
                            payrollData.status === "approved" ? "bg-blue-400/30 text-blue-100" : "bg-white/20 text-white"
                          }`}>
                            {payrollData.status.charAt(0).toUpperCase() + payrollData.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-2xl font-bold text-white">{fmt(payrollData.netSalary)}</p>
                      </div>

                      <div>
                        <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Salary Breakdown</p>
                        <div className="space-y-1">
                          {[
                            { label: "Base Salary", value: fmt(payrollData.baseSalary) },
                            { label: "Allowances", value: fmt(payrollData.positionAllowance + payrollData.transportAllowance + payrollData.mealAllowance) },
                            { label: "Overtime", value: payrollData.overtimeHours > 0 ? fmt(payrollData.overtime) : "—", muted: payrollData.overtimeHours === 0 },
                            { label: "Total Deductions", value: `(${fmt(payrollData.totalDeductions)})`, negative: true },
                          ].map((row) => (
                            <div key={row.label} className="flex justify-between py-2 px-3 rounded-lg hover:bg-gray-50 text-xs">
                              <span className="text-gray-500">{row.label}</span>
                              <span className={`font-semibold ${(row as any).muted ? "text-gray-300" : (row as any).negative ? "text-red-600" : "text-gray-800"}`}>
                                {row.value}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-xs px-3 py-2.5 bg-gray-50 rounded-xl">
                        <span className="text-gray-500">Bank · Account</span>
                        <span className="font-semibold text-gray-700">{payrollData.bankName} · {payrollData.bankAccount}</span>
                      </div>
                    </>
                  ) : (
                    <div className="py-8 text-center">
                      <DollarSign size={28} className="text-gray-200 mx-auto mb-2" />
                      <p className="text-xs text-gray-400">No payroll data available for this employee.</p>
                    </div>
                  )}
                </div>
              )}

              {/* DOCUMENTS TAB */}
              {activeTab === "documents" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-gray-700">{employee.documents.length} document{employee.documents.length !== 1 ? "s" : ""}</p>
                    <button className="text-xs text-blue-600 hover:text-blue-800 font-medium cursor-pointer flex items-center gap-1">
                      Upload <ExternalLink size={10} />
                    </button>
                  </div>

                  {employee.documents.length > 0 ? (
                    <div className="space-y-2">
                      {employee.documents.map((doc, i) => (
                        <div key={i} className="flex items-center gap-3 px-4 py-3 bg-white border border-gray-100 rounded-xl hover:border-blue-200 hover:bg-blue-50/30 transition-all cursor-pointer group">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
                            {docTypeIcon[doc.type]}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-gray-800 truncate group-hover:text-blue-700">{doc.name}</p>
                            <p className="text-[10px] text-gray-400 mt-0.5 capitalize">{doc.type} · {doc.date}</p>
                          </div>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md capitalize ${docStatusColor[doc.status]}`}>
                            {doc.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-10 text-center bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                      <FileText size={28} className="text-gray-300 mx-auto mb-2" />
                      <p className="text-xs text-gray-400 font-medium">No documents uploaded</p>
                      <p className="text-[10px] text-gray-300 mt-1">Upload contracts, ID docs, or certifications</p>
                      <button className="mt-3 text-xs text-blue-600 font-semibold hover:text-blue-800 cursor-pointer">
                        Upload First Document
                      </button>
                    </div>
                  )}

                  {/* Warning for pending */}
                  {employee.documents.some((d) => d.status === "pending") && (
                    <div className="flex items-center gap-2 px-3 py-2.5 bg-yellow-50 rounded-xl border border-yellow-200">
                      <AlertTriangle size={12} className="text-yellow-600" />
                      <p className="text-[10px] text-yellow-700 font-medium">
                        {employee.documents.filter((d) => d.status === "pending").length} document(s) pending verification
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* PERFORMANCE TAB */}
              {activeTab === "performance" && (
                <div className="space-y-4">
                  {/* Score Card */}
                  <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-100 rounded-2xl p-4 flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex flex-col items-center justify-center">
                      <p className="text-lg font-bold text-amber-600">{employee.performanceScore > 0 ? employee.performanceScore.toFixed(1) : "—"}</p>
                      <p className="text-[9px] text-gray-400">/ 5.0</p>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-800">Overall Performance</p>
                      <div className="mt-1">
                        <StarRating score={employee.performanceScore} />
                      </div>
                      <p className="text-[10px] text-gray-500 mt-1.5">
                        Last reviewed: {employee.lastReviewDate
                          ? new Date(employee.lastReviewDate).toLocaleDateString("en-US", { month: "long", year: "numeric" })
                          : "Not yet reviewed"}
                      </p>
                    </div>
                  </div>

                  {/* Next Review */}
                  <div className="flex items-center gap-2 px-4 py-3 bg-blue-50 rounded-xl border border-blue-100">
                    <CalendarDays size={12} className="text-blue-500 flex-shrink-0" />
                    <div>
                      <p className="text-[10px] text-blue-700 font-semibold">Next Review Scheduled</p>
                      <p className="text-xs font-bold text-blue-900">
                        {new Date(employee.nextReviewDate).toLocaleDateString("en-US", { day: "numeric", month: "long", year: "numeric" })}
                      </p>
                    </div>
                  </div>

                  {/* Review History */}
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Review History</p>
                    {employee.reviews.length > 0 ? (
                      <div className="space-y-2">
                        {employee.reviews.map((review, i) => (
                          <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <p className="text-xs font-bold text-gray-800">{review.period}</p>
                                <p className="text-[10px] text-gray-400 mt-0.5">
                                  {new Date(review.date).toLocaleDateString("en-US", { day: "numeric", month: "short", year: "numeric" })} · by {review.reviewer}
                                </p>
                              </div>
                              <StarRating score={review.score} />
                            </div>
                            <p className="text-[11px] text-gray-600 leading-relaxed">{review.comment}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-8 text-center bg-gray-50 rounded-xl">
                        <Star size={24} className="text-gray-200 mx-auto mb-2" />
                        <p className="text-xs text-gray-400">No performance reviews yet.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* ── BOTTOM BAR ── */}
            <div className="flex items-center gap-2 px-5 py-3.5 border-t border-gray-100 bg-white flex-shrink-0">
              <button
                onClick={() => onEdit?.(employee)}
                className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors cursor-pointer"
              >
                <Edit2 size={12} /> Edit Profile
              </button>
              <div className="flex-1" />
              {employee.status === "active" && (
                <button className="flex items-center gap-1.5 text-xs text-red-600 border border-red-200 hover:bg-red-50 px-3 py-2 rounded-lg transition-colors cursor-pointer">
                  <UserX size={12} /> Deactivate
                </button>
              )}
              {employee.status === "on-leave" && (
                <button className="flex items-center gap-1.5 text-xs text-green-700 border border-green-200 hover:bg-green-50 px-3 py-2 rounded-lg transition-colors cursor-pointer">
                  <CheckCircle size={12} /> Return from Leave
                </button>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-300">
            <p className="text-sm">Select an employee</p>
          </div>
        )}
      </div>
    </>
  );
}
