import { useState } from "react";
import {
  X, MapPin, Clock, Camera, Phone, MessageSquare, RotateCcw,
  RefreshCw, UserX, CheckCircle2, Navigation, Wifi, WifiOff,
  ChevronRight, FileText, Star, AlertTriangle,
} from "lucide-react";
import {
  statusLabels, statusColors, statusDot, activityTypeLabels, activityTypeColors,
  outcomeLabels, outcomeColors, priorityColors,
  type FieldActivity, type ActivityStatus,
} from "./salesData";

const avatarColors = ["bg-blue-500","bg-emerald-500","bg-violet-500","bg-amber-500","bg-rose-500","bg-cyan-500","bg-orange-500"];

// ── Activity progress stepper ─────────────────────────────────────────────────
const STEPS: { id: ActivityStatus; label: string }[] = [
  { id: "assigned",    label: "Assigned" },
  { id: "on_the_way",  label: "On the Way" },
  { id: "arrived",     label: "Arrived" },
  { id: "in_progress", label: "In Progress" },
  { id: "completed",   label: "Completed" },
];
const stepOrder = STEPS.map(s => s.id);

function Stepper({ status }: { status: ActivityStatus }) {
  const abnormal = ["missed","cancelled","delayed","gps_inactive"].includes(status);
  const currentIdx = abnormal ? -1 : stepOrder.indexOf(status);

  return (
    <div className="relative flex items-start gap-0 py-1">
      {/* connecting line */}
      <div className="absolute top-3 left-3 right-3 h-0.5 bg-gray-100 z-0"/>
      {STEPS.map((step, i) => {
        const done   = !abnormal && i < currentIdx;
        const active = !abnormal && i === currentIdx;
        return (
          <div key={step.id} className="flex flex-col items-center flex-1 z-10 gap-1">
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
              done   ? "bg-green-500 border-green-500" :
              active ? "bg-blue-600 border-blue-600 ring-2 ring-blue-200" :
                       "bg-white border-gray-200"
            }`}>
              {done  ? <CheckCircle2 size={11} className="text-white"/> :
               active ? <span className="w-2 h-2 rounded-full bg-white"/> :
                        <span className="w-1.5 h-1.5 rounded-full bg-gray-300"/>}
            </div>
            <p className={`text-[9px] font-semibold text-center leading-tight whitespace-nowrap ${
              done ? "text-green-600" : active ? "text-blue-700" : "text-gray-400"
            }`}>{step.label}</p>
          </div>
        );
      })}
      {abnormal && (
        <div className="absolute inset-x-0 top-7 flex justify-center">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColors[status]}`}>
            {statusLabels[status]}
          </span>
        </div>
      )}
    </div>
  );
}

// ── Fake mini-map ─────────────────────────────────────────────────────────────
function MiniMap({ activity }: { activity: FieldActivity }) {
  const isActive = activity.gpsActive;
  return (
    <div className="relative h-32 rounded-xl overflow-hidden border border-gray-200">
      {/* Map background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-100 via-slate-50 to-blue-50">
        {/* Grid lines */}
        <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="mm-grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#94a3b8" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#mm-grid)"/>
        </svg>
        {/* Road lines */}
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#cbd5e1" strokeWidth="3"/>
          <line x1="35%" y1="0" x2="35%" y2="100%" stroke="#cbd5e1" strokeWidth="3"/>
          <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#e2e8f0" strokeWidth="2"/>
          <line x1="0" y1="30%" x2="100%" y2="30%" stroke="#e2e8f0" strokeWidth="1.5"/>
          <line x1="0" y1="75%" x2="100%" y2="75%" stroke="#e2e8f0" strokeWidth="1.5"/>
        </svg>
      </div>
      {/* Destination pin */}
      <div className="absolute" style={{ left: `${activity.mapX}%`, top: `${activity.mapY * 0.7}%`, transform: "translate(-50%,-100%)" }}>
        <div className="w-5 h-5 rounded-full bg-red-500 border-2 border-white shadow flex items-center justify-center">
          <MapPin size={9} className="text-white"/>
        </div>
      </div>
      {/* Employee pin */}
      {isActive && (
        <div className="absolute" style={{ left: `${Math.min(90, activity.mapX + 12)}%`, top: `${Math.max(10, activity.mapY * 0.7 - 15)}%`, transform: "translate(-50%,-100%)" }}>
          <div className="relative">
            <div className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow flex items-center justify-center">
              <Navigation size={9} className="text-white"/>
            </div>
            <div className="absolute inset-0 rounded-full bg-blue-400 opacity-40 animate-ping"/>
          </div>
        </div>
      )}
      {/* Labels */}
      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
          {isActive
            ? <><Wifi size={9} className="text-green-500"/><span className="text-[9px] text-green-700 font-bold">GPS Live</span></>
            : <><WifiOff size={9} className="text-gray-400"/><span className="text-[9px] text-gray-500">No GPS</span></>
          }
        </div>
        {activity.gpsAccuracy > 0 && (
          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-2 py-1">
            <span className="text-[9px] text-gray-600 font-medium">±{activity.gpsAccuracy}m</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Drawer ──────────────────────────────────────────────────────────────────
interface VisitDetailDrawerProps {
  activity: FieldActivity | null;
  repIdx: number;
  onClose: () => void;
  onStatusChange: (id: string, status: ActivityStatus) => void;
}

export function VisitDetailDrawer({ activity, repIdx, onClose, onStatusChange }: VisitDetailDrawerProps) {
  const [tab, setTab] = useState<"detail"|"timeline"|"proof">("detail");
  const [reviewed, setReviewed] = useState(false);

  if (!activity) return null;

  const statusTimeline: { status: ActivityStatus; time: string; note: string }[] = [
    { status: "assigned",    time: `${activity.date} · 08:00`, note: `Assigned by ${activity.assignedBy}` },
    ...(["on_the_way","arrived","in_progress","completed","delayed","missed"].includes(activity.status)
      ? [{ status: "on_the_way" as ActivityStatus, time: `${activity.date} · ${activity.scheduledTime}`, note: "Employee started trip" }]
      : []),
    ...( ["arrived","in_progress","completed"].includes(activity.status)
      ? [{ status: "arrived" as ActivityStatus, time: `${activity.date} · ${activity.checkIn ?? "—"}`, note: "Arrived at destination" }]
      : []),
    ...( ["in_progress","completed"].includes(activity.status)
      ? [{ status: "in_progress" as ActivityStatus, time: `${activity.date} · ${activity.checkIn ?? "—"}`, note: "Activity started" }]
      : []),
    ...( activity.status === "completed"
      ? [{ status: "completed" as ActivityStatus, time: `${activity.date} · ${activity.checkOut ?? "—"}`, note: "Activity completed" }]
      : []),
    ...( activity.status === "delayed"
      ? [{ status: "delayed" as ActivityStatus, time: `${activity.date} · ${activity.gpsLastUpdate}`, note: "Delay reported by employee" }]
      : []),
    ...( activity.status === "missed"
      ? [{ status: "missed" as ActivityStatus, time: `${activity.date} · ${activity.scheduledTime}`, note: "Employee did not check in" }]
      : []),
  ];

  return (
    <>
      <div className="fixed inset-0 bg-black/25 backdrop-blur-[2px] z-30" onClick={onClose}/>
      <aside className="fixed right-0 top-0 h-full w-[440px] max-w-[96vw] bg-gray-50 z-40 shadow-2xl border-l border-gray-200 flex flex-col">

        {/* Header */}
        <div className="bg-white border-b border-gray-100 px-5 py-4 flex-shrink-0">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-3">
              <div className={`w-9 h-9 ${avatarColors[repIdx % avatarColors.length]} rounded-full flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0`}>
                {activity.rep.avatar}
              </div>
              <div>
                <p className="text-sm font-bold text-gray-900">{activity.rep.name}</p>
                <p className="text-[10px] text-gray-400">{activity.rep.role} · {activity.rep.department}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${statusColors[activity.status]}`}>
                <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1 ${statusDot[activity.status]}`}/>
                {statusLabels[activity.status]}
              </span>
              <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer">
                <X size={15} className="text-gray-500"/>
              </button>
            </div>
          </div>

          {/* ID + type + priority */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-[10px] text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{activity.id}</span>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-lg ${activityTypeColors[activity.activityType]}`}>
              {activityTypeLabels[activity.activityType]}
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg capitalize ${priorityColors[activity.priority]}`}>
              {activity.priority} priority
            </span>
            {activity.gpsActive
              ? <span className="flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-lg"><Wifi size={8}/> GPS Live</span>
              : <span className="flex items-center gap-1 text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-lg"><WifiOff size={8}/> GPS Off</span>
            }
          </div>
        </div>

        {/* Stepper */}
        <div className="bg-white border-b border-gray-100 px-5 py-3 flex-shrink-0">
          <Stepper status={activity.status}/>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-0 border-b border-gray-100 bg-white flex-shrink-0">
          {(["detail","timeline","proof"] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 px-3 py-2.5 text-xs font-semibold capitalize cursor-pointer border-b-2 transition-all ${
                tab === t ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>
              {t === "detail" ? "Details" : t === "timeline" ? "Timeline" : "Proof & Notes"}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">

          {tab === "detail" && (
            <>
              {/* Mini map */}
              <MiniMap activity={activity}/>

              {/* Assignment info */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50 bg-gray-50">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Assignment</p>
                </div>
                <div className="divide-y divide-gray-50">
                  <div className="flex items-start gap-3 px-4 py-3">
                    <MapPin size={13} className="text-gray-400 mt-0.5 flex-shrink-0"/>
                    <div>
                      <p className="text-xs font-semibold text-gray-800">{activity.location}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{activity.address}</p>
                      <p className="text-[10px] text-gray-400">{activity.district}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 divide-x divide-gray-50">
                    <div className="px-4 py-3">
                      <p className="text-[10px] text-gray-400">Scheduled</p>
                      <p className="text-xs font-semibold text-gray-800">{activity.date}</p>
                      <p className="text-xs text-gray-600">{activity.scheduledTime} → {activity.estimatedEnd}</p>
                    </div>
                    <div className="px-4 py-3">
                      <p className="text-[10px] text-gray-400">Actual Time</p>
                      <p className="text-xs font-semibold text-gray-800">
                        {activity.checkIn ?? "—"} → {activity.checkOut ?? "—"}
                      </p>
                      {activity.duration && <p className="text-xs text-gray-500">{Math.floor(activity.duration/60)}h {activity.duration%60}m</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 px-4 py-3">
                    <div className="flex-1">
                      <p className="text-[10px] text-gray-400">Assigned by</p>
                      <p className="text-xs font-semibold text-gray-700">{activity.assignedBy}</p>
                    </div>
                    <div className="flex-1">
                      <p className="text-[10px] text-gray-400">GPS last update</p>
                      <p className="text-xs font-semibold text-gray-700">{activity.gpsLastUpdate}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Client info */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50 bg-gray-50">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Client / Destination</p>
                </div>
                <div className="px-4 py-3 space-y-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-[9px] font-bold">{activity.clientCompany.slice(0,2).toUpperCase()}</span>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-800">{activity.clientCompany}</p>
                      <p className="text-[10px] text-gray-400">{activity.contactPerson}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Phone size={11} className="text-gray-400 flex-shrink-0"/>
                    <span>{activity.clientPhone}</span>
                  </div>
                  {activity.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {activity.tags.map(tag => (
                        <span key={tag} className="text-[9px] font-semibold px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md">{tag}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Objective */}
              {activity.objective && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5">
                  <p className="text-[10px] font-bold text-amber-700 uppercase tracking-wide mb-1.5">Objective</p>
                  <p className="text-xs text-amber-900 leading-relaxed">{activity.objective}</p>
                </div>
              )}

              {/* Outcome */}
              {activity.outcome && activity.outcome !== "" && activity.outcome !== "pending" && (
                <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${
                  activity.outcome === "deal_closed" ? "bg-green-50 border-green-200" : "bg-blue-50 border-blue-200"
                }`}>
                  <Star size={12} className={activity.outcome === "deal_closed" ? "text-green-600" : "text-blue-600"}/>
                  <div>
                    <p className="text-[10px] font-bold text-gray-700 uppercase tracking-wide">Outcome</p>
                    <p className={`text-xs font-bold ${activity.outcome === "deal_closed" ? "text-green-700" : "text-blue-700"}`}>
                      {outcomeLabels[activity.outcome]}
                    </p>
                  </div>
                </div>
              )}
            </>
          )}

          {tab === "timeline" && (
            <div className="relative pl-7">
              <div className="absolute left-3 top-2 bottom-2 w-0.5 bg-gray-100"/>
              <div className="space-y-4">
                {statusTimeline.map((entry, i) => (
                  <div key={i} className="relative flex items-start gap-3">
                    <div className={`absolute -left-4 w-3 h-3 rounded-full border-2 border-white mt-1 shadow-sm ${statusDot[entry.status]}`}/>
                    <div className="bg-white border border-gray-100 rounded-xl p-3 flex-1 shadow-sm">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${statusColors[entry.status]}`}>
                          {statusLabels[entry.status]}
                        </span>
                        <span className="text-[9px] text-gray-400">{entry.time}</span>
                      </div>
                      <p className="text-[11px] text-gray-600">{entry.note}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "proof" && (
            <div className="space-y-4">
              {/* Photos */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50 bg-gray-50 flex items-center justify-between">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Photo Proof</p>
                  <span className="text-[10px] font-bold text-gray-600">{activity.photoCount} photos</span>
                </div>
                <div className="p-4">
                  {activity.photoCount > 0 ? (
                    <div className="grid grid-cols-3 gap-2">
                      {Array.from({ length: activity.photoCount }).map((_, i) => (
                        <div key={i} className="aspect-square rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
                          <Camera size={16} className="text-gray-400"/>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-4 text-center">
                      <Camera size={24} className="text-gray-300 mb-2"/>
                      <p className="text-xs text-gray-400">No photos uploaded yet</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Notes */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50 bg-gray-50">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Activity Notes</p>
                </div>
                <div className="px-4 py-3">
                  {activity.notes ? (
                    <p className="text-xs text-gray-700 leading-relaxed">{activity.notes}</p>
                  ) : (
                    <p className="text-xs text-gray-400 italic">No notes added yet.</p>
                  )}
                </div>
              </div>

              {/* GPS */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50 bg-gray-50">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">GPS Record</p>
                </div>
                <div className="px-4 py-3 space-y-2">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] text-gray-400">Latitude</p>
                      <p className="text-xs font-mono font-semibold text-gray-700">{activity.gpsLat.toFixed(4)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400">Longitude</p>
                      <p className="text-xs font-mono font-semibold text-gray-700">{activity.gpsLng.toFixed(4)}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] text-gray-400">GPS Accuracy</p>
                      <p className="text-xs font-semibold text-gray-700">
                        {activity.gpsAccuracy > 0 ? `±${activity.gpsAccuracy}m` : "—"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400">Last Update</p>
                      <p className="text-xs font-semibold text-gray-700">{activity.gpsLastUpdate}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Manager Action Buttons */}
        <div className="bg-white border-t border-gray-100 px-4 py-3.5 flex-shrink-0">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide mb-2.5">Manager Actions</p>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 cursor-pointer transition-all">
              <Navigation size={12}/> View Full Map
            </button>
            <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-green-50 hover:border-green-300 hover:text-green-700 cursor-pointer transition-all">
              <Phone size={12}/> Call Employee
            </button>
            <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-700 cursor-pointer transition-all">
              <MessageSquare size={12}/> Message
            </button>
            <button className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-amber-50 hover:border-amber-300 hover:text-amber-700 cursor-pointer transition-all">
              <RefreshCw size={12}/> Request Update
            </button>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setReviewed(true); }}
              className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-all border ${
                reviewed ? "bg-green-50 border-green-300 text-green-700" : "border-gray-200 text-gray-600 hover:bg-green-50 hover:border-green-300 hover:text-green-700"
              }`}>
              <CheckCircle2 size={12}/> {reviewed ? "Reviewed ✓" : "Mark as Reviewed"}
            </button>
            <button className="flex items-center justify-center gap-1.5 text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-orange-50 hover:border-orange-300 hover:text-orange-700 cursor-pointer transition-all">
              <RotateCcw size={12}/> Reassign
            </button>
            <button className="flex items-center justify-center gap-1.5 text-xs font-semibold px-3 py-2.5 rounded-xl border border-red-200 text-red-400 hover:bg-red-50 hover:text-red-600 cursor-pointer transition-all">
              <UserX size={12}/> Cancel
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
