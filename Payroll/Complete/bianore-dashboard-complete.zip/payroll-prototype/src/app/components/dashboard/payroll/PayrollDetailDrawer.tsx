import { useState } from "react";
import {
  X,
  FileText,
  Clock,
  DollarSign,
  Shield,
  CheckCircle,
  XCircle,
  ChevronRight,
  AlertTriangle,
  Users,
  MessageSquare,
  Send,
  RefreshCw,
  Lock,
} from "lucide-react";
import type { PayrollRecord } from "./payrollData";

interface PayrollDetailDrawerProps {
  isOpen: boolean;
  employee: PayrollRecord | null;
  onClose: () => void;
  onViewSlip: (emp: PayrollRecord) => void;
}

type DrawerTab = "salary" | "attendance" | "tax" | "approval";

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

const statusConfig: Record<string, { bg: string; text: string; dot: string; label: string }> = {
  draft:    { bg: "bg-gray-100",   text: "text-gray-600",   dot: "bg-gray-400",   label: "Draft" },
  pending:  { bg: "bg-amber-50",   text: "text-amber-700",  dot: "bg-amber-500",  label: "Pending" },
  approved: { bg: "bg-blue-50",    text: "text-blue-700",   dot: "bg-blue-500",   label: "Approved" },
  paid:     { bg: "bg-green-50",   text: "text-green-700",  dot: "bg-green-500",  label: "Paid" },
};

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing:   "bg-pink-50 text-pink-700",
  Finance:     "bg-cyan-50 text-cyan-700",
  HR:          "bg-purple-50 text-purple-700",
  Operations:  "bg-orange-50 text-orange-700",
  Sales:       "bg-green-50 text-green-700",
};

const avatarGradients = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600",
  "from-violet-500 to-purple-600", "from-rose-500 to-pink-600", "from-amber-500 to-orange-600",
];

const approvalFlow = [
  { role: "HR Manager", name: "Alex Kumar", status: "approved" as const, time: "Apr 29, 2:30 PM", comment: "Attendance data verified. Overtime hours confirmed." },
  { role: "Finance Director", name: "Lisa Thompson", status: "current" as const, time: null, comment: null },
  { role: "CEO / Owner", name: "Robert Chen", status: "waiting" as const, time: null, comment: null },
];

function SectionRow({ label, value, highlight, negative, muted }: { label: string; value: string; highlight?: boolean; negative?: boolean; muted?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-2.5 px-3 rounded-lg ${highlight ? "bg-blue-50" : muted ? "" : "hover:bg-gray-50"}`}>
      <span className={`text-xs ${highlight ? "font-bold text-blue-800" : muted ? "text-gray-400" : "text-gray-600"}`}>
        {label}
      </span>
      <span className={`text-xs font-semibold tabular-nums ${highlight ? "text-blue-800" : negative ? "text-red-600" : muted ? "text-gray-300" : "text-gray-800"}`}>
        {negative ? `(${value})` : value}
      </span>
    </div>
  );
}

function Divider({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 py-1">
      <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider whitespace-nowrap">{label}</p>
      <div className="flex-1 h-px bg-gray-100" />
    </div>
  );
}

export function PayrollDetailDrawer({ isOpen, employee, onClose, onViewSlip }: PayrollDetailDrawerProps) {
  const [activeTab, setActiveTab] = useState<DrawerTab>("salary");
  const [comment, setComment] = useState("");
  const [approveApplied, setApproveApplied] = useState(false);
  const [approveAction, setApproveAction] = useState<"approve" | "reject" | null>(null);

  const grad = employee ? avatarGradients[employee.id % avatarGradients.length] : avatarGradients[0];
  const sc = employee ? statusConfig[employee.status] : null;
  const dc = employee ? (deptColors[employee.dept] || "bg-gray-50 text-gray-600") : "";

  const tabs: { id: DrawerTab; label: string; icon: React.ReactNode }[] = [
    { id: "salary",     label: "Salary",     icon: <DollarSign size={13} /> },
    { id: "attendance", label: "Attendance", icon: <Clock size={13} /> },
    { id: "tax",        label: "Tax & BPJS", icon: <Shield size={13} /> },
    { id: "approval",   label: "Approval",   icon: <Users size={13} /> },
  ];

  const handleAction = (action: "approve" | "reject") => {
    setApproveAction(action);
    setApproveApplied(true);
  };

  const handleClose = () => {
    setApproveApplied(false);
    setApproveAction(null);
    setComment("");
    setActiveTab("salary");
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40 transition-opacity duration-300 ${
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={handleClose}
      />

      {/* Drawer */}
      <div
        className={`fixed top-0 right-0 h-full w-[520px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {employee ? (
          <>
            {/* ── HEADER ── */}
            <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}>
                  {employee.avatar}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-bold text-gray-900">{employee.name}</p>
                    {sc && (
                      <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${dc}`}>{employee.dept}</span>
                    <span className="text-[10px] text-gray-400">{employee.position}</span>
                  </div>
                </div>
              </div>
              <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer">
                <X size={16} />
              </button>
            </div>

            {/* ── PAY PERIOD STRIP ── */}
            <div className="flex items-center gap-4 px-5 py-2.5 bg-gray-50 border-b border-gray-100 flex-shrink-0">
              <div className="flex items-center gap-1.5 text-xs text-gray-600">
                <FileText size={11} className="text-gray-400" />
                <span>{employee.payPeriod}</span>
              </div>
              <div className="w-px h-3 bg-gray-300" />
              <div className="flex items-center gap-1.5 text-xs text-gray-600">
                <RefreshCw size={11} className="text-blue-400" />
                <span className="text-blue-600 font-medium">Attendance Synced</span>
              </div>
              <div className="w-px h-3 bg-gray-300" />
              <div className="flex items-center gap-1.5 text-xs text-gray-600">
                <Lock size={11} className="text-gray-400" />
                <span>EMP{String(employee.id).padStart(4, "0")}</span>
              </div>
            </div>

            {/* ── TABS ── */}
            <div className="flex items-center gap-0 px-5 border-b border-gray-100 flex-shrink-0">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-3 text-xs font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? "border-blue-600 text-blue-700"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>

            {/* ── TAB CONTENT ── */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-2">

              {/* ── SALARY TAB ── */}
              {activeTab === "salary" && (
                <div className="space-y-3">
                  {/* Net Salary Hero */}
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4 flex items-center justify-between mb-4">
                    <div>
                      <p className="text-xs text-blue-100 font-medium">NET SALARY</p>
                      <p className="text-[10px] text-blue-200 mt-0.5">{employee.payPeriod}</p>
                    </div>
                    <p className="text-2xl font-bold text-white">{fmt(employee.netSalary)}</p>
                  </div>

                  <Divider label="Earnings" />
                  <SectionRow label="Base Salary" value={fmt(employee.baseSalary)} />
                  <SectionRow label="Position Allowance" value={fmt(employee.positionAllowance)} />
                  <SectionRow label="Transport Allowance" value={fmt(employee.transportAllowance)} />
                  <SectionRow label="Meal Allowance" value={fmt(employee.mealAllowance)} />
                  {employee.overtime > 0 && (
                    <SectionRow label={`Overtime (${employee.overtimeHours}h × rate)`} value={fmt(employee.overtime)} />
                  )}
                  {employee.bonus > 0 && (
                    <SectionRow label="Bonus / Incentive" value={fmt(employee.bonus)} />
                  )}
                  {employee.reimbursements > 0 && (
                    <SectionRow label="Reimbursements" value={fmt(employee.reimbursements)} />
                  )}
                  <SectionRow label="Total Earnings" value={fmt(employee.totalEarnings)} highlight />

                  <div className="h-1" />
                  <Divider label="Deductions" />
                  {employee.lateDeduction > 0 && (
                    <SectionRow label="Late Penalty" value={fmt(employee.lateDeduction)} negative />
                  )}
                  {employee.absenceDeduction > 0 && (
                    <SectionRow label="Absence Deduction" value={fmt(employee.absenceDeduction)} negative />
                  )}
                  {employee.loanDeduction > 0 && (
                    <SectionRow label="Loan Repayment" value={fmt(employee.loanDeduction)} negative />
                  )}
                  <SectionRow label="PPh 21 Tax" value={fmt(employee.tax)} negative />
                  <SectionRow label="BPJS Health (3%)" value={fmt(employee.bpjsHealth)} negative />
                  <SectionRow label="BPJS Employment (1%)" value={fmt(employee.bpjsEmployment)} negative />
                  <SectionRow label="Total Deductions" value={fmt(employee.totalDeductions)} highlight />

                  {/* Bank Info */}
                  <div className="mt-4 bg-gray-50 rounded-xl p-3">
                    <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-2">Disbursement</p>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{employee.bankName}</p>
                        <p className="text-[10px] text-gray-400">{employee.bankAccount}</p>
                      </div>
                      {employee.status === "paid" ? (
                        <span className="flex items-center gap-1 text-[10px] font-semibold text-green-700 bg-green-50 px-2 py-1 rounded-lg">
                          <CheckCircle size={10} /> Disbursed
                        </span>
                      ) : (
                        <span className="text-[10px] text-gray-400">Pending disbursement</span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* ── ATTENDANCE TAB ── */}
              {activeTab === "attendance" && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-blue-50 rounded-xl border border-blue-100 mb-2">
                    <RefreshCw size={13} className="text-blue-500" />
                    <p className="text-xs text-blue-700 font-medium">Data automatically synced from Attendance Module</p>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { label: "Present", value: employee.presentDays, color: "bg-green-50 text-green-700" },
                      { label: "Late", value: employee.lateDays, color: "bg-yellow-50 text-yellow-700" },
                      { label: "Absent", value: employee.absentDays, color: "bg-red-50 text-red-600" },
                      { label: "OT Days", value: employee.overtimeDays, color: "bg-purple-50 text-purple-700" },
                    ].map((s) => (
                      <div key={s.label} className={`rounded-xl p-3 text-center ${s.color}`}>
                        <p className="text-lg font-bold">{s.value}</p>
                        <p className="text-[9px] font-semibold uppercase tracking-wider opacity-70 mt-0.5">{s.label}</p>
                      </div>
                    ))}
                  </div>

                  <Divider label="Attendance Impact on Payroll" />

                  {/* Deductions derived from attendance */}
                  {employee.lateDeduction > 0 && (
                    <div className="flex items-start gap-2.5 px-3 py-3 bg-yellow-50 rounded-xl border border-yellow-200">
                      <AlertTriangle size={13} className="text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-yellow-800">Late Penalty Applied</p>
                        <p className="text-[10px] text-yellow-700 mt-0.5">
                          {employee.lateDays} late check-in{employee.lateDays > 1 ? "s" : ""} · {fmt(employee.lateDeduction)} deducted
                        </p>
                      </div>
                    </div>
                  )}
                  {employee.absenceDeduction > 0 && (
                    <div className="flex items-start gap-2.5 px-3 py-3 bg-red-50 rounded-xl border border-red-200">
                      <AlertTriangle size={13} className="text-red-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-red-800">Absence Deduction Applied</p>
                        <p className="text-[10px] text-red-700 mt-0.5">
                          {employee.absentDays} absent day{employee.absentDays > 1 ? "s" : ""} · {fmt(employee.absenceDeduction)} deducted
                        </p>
                      </div>
                    </div>
                  )}
                  {employee.overtimeHours > 0 && (
                    <div className="flex items-start gap-2.5 px-3 py-3 bg-purple-50 rounded-xl border border-purple-200">
                      <CheckCircle size={13} className="text-purple-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-purple-800">Overtime Compensation</p>
                        <p className="text-[10px] text-purple-700 mt-0.5">
                          {employee.overtimeHours}h overtime · {fmt(employee.overtime)} added to earnings
                        </p>
                      </div>
                    </div>
                  )}
                  {employee.lateDeduction === 0 && employee.absenceDeduction === 0 && employee.overtimeHours === 0 && (
                    <div className="flex items-center gap-2 px-3 py-3 bg-green-50 rounded-xl border border-green-200">
                      <CheckCircle size={13} className="text-green-600" />
                      <p className="text-xs font-semibold text-green-700">Perfect attendance — no deductions applied</p>
                    </div>
                  )}

                  <Divider label="Work Summary" />
                  <SectionRow label="Work Days in Period" value="22 days" />
                  <SectionRow label="Attended" value={`${employee.presentDays} days`} />
                  <SectionRow label="Total Overtime Hours" value={`${employee.overtimeHours}h`} muted={employee.overtimeHours === 0} />
                </div>
              )}

              {/* ── TAX TAB ── */}
              {activeTab === "tax" && (
                <div className="space-y-3">
                  {/* Compliance Status */}
                  <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border ${
                    employee.taxStatus === "valid"
                      ? "bg-green-50 border-green-200"
                      : "bg-yellow-50 border-yellow-200"
                  }`}>
                    {employee.taxStatus === "valid" ? (
                      <CheckCircle size={14} className="text-green-600 flex-shrink-0" />
                    ) : (
                      <AlertTriangle size={14} className="text-yellow-600 flex-shrink-0" />
                    )}
                    <div>
                      <p className={`text-xs font-semibold ${employee.taxStatus === "valid" ? "text-green-800" : "text-yellow-800"}`}>
                        {employee.taxStatus === "valid" ? "Tax Compliance Valid" : "Tax Compliance Warning"}
                      </p>
                      <p className={`text-[10px] mt-0.5 ${employee.taxStatus === "valid" ? "text-green-600" : "text-yellow-700"}`}>
                        {employee.taxStatus === "valid" ? "All calculations verified for this period" : "Review required — data may be incomplete"}
                      </p>
                    </div>
                  </div>

                  <Divider label="PPh 21 Income Tax" />
                  <SectionRow label="Gross Income" value={fmt(employee.totalEarnings)} />
                  <SectionRow label="PTKP Allowance" value="($4,500)" muted />
                  <SectionRow label="Taxable Income" value={fmt(employee.totalEarnings - 4500)} />
                  <SectionRow label="Tax Rate Applied" value="15%" />
                  <SectionRow label="PPh 21 Total" value={fmt(employee.tax)} highlight />

                  <div className="h-1" />
                  <Divider label="BPJS Contributions" />
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                    {[
                      { label: "BPJS Kesehatan (Health)", sub: "3% of base salary", emp: fmt(employee.bpjsHealth), company: fmt(Math.round(employee.baseSalary * 0.04)) },
                      { label: "BPJS Ketenagakerjaan (JHT)", sub: "1% of base salary", emp: fmt(employee.bpjsEmployment), company: fmt(Math.round(employee.baseSalary * 0.037)) },
                    ].map((row) => (
                      <div key={row.label} className="pb-2.5 border-b border-gray-200 last:border-0 last:pb-0">
                        <p className="text-xs font-semibold text-gray-700">{row.label}</p>
                        <p className="text-[10px] text-gray-400 mb-1.5">{row.sub}</p>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-white rounded-lg px-3 py-2">
                            <p className="text-[9px] text-gray-400 uppercase tracking-wider">Employee</p>
                            <p className="text-xs font-bold text-red-600 mt-0.5">{row.emp}</p>
                          </div>
                          <div className="bg-white rounded-lg px-3 py-2">
                            <p className="text-[9px] text-gray-400 uppercase tracking-wider">Company</p>
                            <p className="text-xs font-bold text-blue-600 mt-0.5">{row.company}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── APPROVAL TAB ── */}
              {activeTab === "approval" && (
                <div className="space-y-4">
                  {approveApplied && (
                    <div className={`flex items-center gap-2 px-4 py-3 rounded-xl border ${
                      approveAction === "approve" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }`}>
                      {approveAction === "approve" ? (
                        <CheckCircle size={14} className="text-green-600" />
                      ) : (
                        <XCircle size={14} className="text-red-500" />
                      )}
                      <p className={`text-xs font-semibold ${approveAction === "approve" ? "text-green-800" : "text-red-700"}`}>
                        {approveAction === "approve" ? "Approved by you (Finance Director)" : "Rejected — Sent back to HR for review"}
                      </p>
                    </div>
                  )}

                  {/* Approval Timeline */}
                  <div className="relative">
                    {approvalFlow.map((step, idx) => (
                      <div key={step.role} className="flex gap-3 mb-4">
                        {/* Line + dot */}
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            step.status === "approved" || (approveApplied && approveAction === "approve" && idx === 1)
                              ? "bg-green-500"
                              : step.status === "current" && !approveApplied
                              ? "bg-blue-500 ring-4 ring-blue-100"
                              : "bg-gray-200"
                          }`}>
                            {step.status === "approved" || (approveApplied && approveAction === "approve" && idx === 1) ? (
                              <CheckCircle size={14} className="text-white" />
                            ) : step.status === "waiting" ? (
                              <Clock size={14} className="text-gray-400" />
                            ) : (
                              <Users size={14} className="text-white" />
                            )}
                          </div>
                          {idx < approvalFlow.length - 1 && (
                            <div className={`w-0.5 h-full min-h-[32px] mt-1 ${
                              step.status === "approved" ? "bg-green-300" : "bg-gray-200"
                            }`} />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 pb-4">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-xs font-bold text-gray-800">{step.name}</p>
                            <span className="text-[10px] text-gray-400">{step.role}</span>
                            {step.status === "approved" || (approveApplied && approveAction === "approve" && idx === 1) ? (
                              <span className="text-[10px] font-semibold text-green-700 bg-green-50 px-1.5 py-0.5 rounded">Approved</span>
                            ) : step.status === "current" && !approveApplied ? (
                              <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded animate-pulse">Pending</span>
                            ) : (
                              <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">Waiting</span>
                            )}
                          </div>
                          {step.time && (
                            <p className="text-[10px] text-gray-400 mt-0.5">{step.time}</p>
                          )}
                          {step.comment && (
                            <div className="mt-1.5 px-3 py-2 bg-gray-50 rounded-lg border border-gray-100">
                              <div className="flex items-center gap-1 mb-1">
                                <MessageSquare size={9} className="text-gray-400" />
                                <span className="text-[9px] text-gray-400 uppercase tracking-wider">Comment</span>
                              </div>
                              <p className="text-[11px] text-gray-600 leading-relaxed">{step.comment}</p>
                            </div>
                          )}
                          {step.status === "current" && !approveApplied && (
                            <div className="mt-2 space-y-2">
                              <textarea
                                placeholder="Add a comment (optional)..."
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                rows={2}
                                className="w-full text-xs text-gray-700 bg-white border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-blue-400 resize-none placeholder:text-gray-400"
                              />
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => handleAction("reject")}
                                  className="flex items-center gap-1 text-xs text-red-600 border border-red-200 hover:bg-red-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer font-medium"
                                >
                                  <XCircle size={12} /> Reject
                                </button>
                                <button
                                  onClick={() => handleAction("approve")}
                                  className="flex items-center gap-1 text-xs text-white bg-green-600 hover:bg-green-700 px-3 py-1.5 rounded-lg transition-colors cursor-pointer font-medium"
                                >
                                  <CheckCircle size={12} /> Approve
                                </button>
                                {comment && (
                                  <button className="flex items-center gap-1 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ml-auto">
                                    <Send size={11} /> Comment only
                                  </button>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* ── BOTTOM ACTION BAR ── */}
            <div className="flex items-center gap-2 px-5 py-3.5 border-t border-gray-100 bg-white flex-shrink-0">
              <button
                onClick={() => onViewSlip(employee)}
                className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors cursor-pointer"
              >
                <FileText size={13} />
                View Payslip
              </button>
              <div className="flex-1" />
              {employee.status === "pending" && !approveApplied && (
                <>
                  <button
                    onClick={() => { setActiveTab("approval"); handleAction("reject"); }}
                    className="text-xs text-red-600 border border-red-200 hover:bg-red-50 px-3 py-2 rounded-lg transition-colors cursor-pointer font-medium"
                  >
                    Reject
                  </button>
                  <button
                    onClick={() => { setActiveTab("approval"); handleAction("approve"); }}
                    className="text-xs text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors cursor-pointer font-medium flex items-center gap-1.5"
                  >
                    <CheckCircle size={12} /> Approve
                  </button>
                </>
              )}
              {employee.status === "approved" && !approveApplied && (
                <button className="text-xs text-white bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors cursor-pointer font-medium flex items-center gap-1.5">
                  <Send size={12} /> Send Payslip
                </button>
              )}
              {employee.status === "paid" && (
                <span className="text-xs font-semibold text-green-700 bg-green-50 border border-green-200 px-3 py-2 rounded-lg flex items-center gap-1.5">
                  <CheckCircle size={12} /> Paid & Disbursed
                </span>
              )}
              {(employee.status === "draft" || approveApplied) && (
                <button className="text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight size={13} /> Next Step
                </button>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-300">
            <p className="text-sm">Select an employee</p>
          </div>
        )}
      </div>
    </>
  );
}
