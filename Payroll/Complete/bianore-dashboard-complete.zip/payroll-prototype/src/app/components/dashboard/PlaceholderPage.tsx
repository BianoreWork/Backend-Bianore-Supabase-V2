import { DollarSign, Users, BarChart2, Construction } from "lucide-react";
import type { PageId } from "./mockData";

const config: Record<string, { icon: React.ElementType; label: string; desc: string; color: string; bg: string }> = {
  payroll: {
    icon: DollarSign,
    label: "Payroll Management",
    desc: "Manage payroll runs, salary disbursements, deductions, and tax compliance in one place.",
    color: "text-green-600",
    bg: "bg-green-50",
  },
  employees: {
    icon: Users,
    label: "Employee Directory",
    desc: "Full employee profiles, org charts, contract management, and onboarding workflows.",
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  reports: {
    icon: BarChart2,
    label: "Reports & Analytics",
    desc: "Custom report builder, scheduled exports, and advanced workforce analytics.",
    color: "text-blue-600",
    bg: "bg-blue-50",
  },
};

const comingSoonFeatures: Record<string, string[]> = {
  payroll: [
    "Automated payroll processing",
    "Tax calculation & filing",
    "Salary adjustment workflows",
    "Payslip generation & distribution",
    "Compliance reports",
  ],
  employees: [
    "Employee profile management",
    "Organizational hierarchy",
    "Onboarding & offboarding flows",
    "Contract & document storage",
    "Performance review tracking",
  ],
  reports: [
    "Custom report builder",
    "Attendance analytics",
    "Payroll expense summaries",
    "Department performance metrics",
    "Scheduled PDF/Excel exports",
  ],
};

interface PlaceholderPageProps {
  page: PageId;
}

export function PlaceholderPage({ page }: PlaceholderPageProps) {
  const cfg = config[page];
  if (!cfg) return null;
  const Icon = cfg.icon;
  const features = comingSoonFeatures[page] || [];

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5">
      <div className="max-w-xl mx-auto mt-16 text-center">
        {/* Icon */}
        <div className={`w-16 h-16 ${cfg.bg} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
          <Icon size={28} className={cfg.color} />
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 rounded-full text-xs font-semibold mb-3 border border-amber-200">
          <Construction size={11} />
          Coming Soon
        </div>

        <h1 className="text-xl font-bold text-gray-900 mb-2">{cfg.label}</h1>
        <p className="text-sm text-gray-500 leading-relaxed mb-8">{cfg.desc}</p>

        {/* Features preview */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-left">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
            Planned Features
          </p>
          <ul className="space-y-2.5">
            {features.map((feat) => (
              <li key={feat} className="flex items-center gap-2.5 text-sm text-gray-600">
                <div className={`w-1.5 h-1.5 rounded-full ${cfg.color.replace("text-", "bg-")}`} />
                {feat}
              </li>
            ))}
          </ul>
        </div>

        <p className="mt-6 text-xs text-gray-400">
          This module is currently under development. Check back in a future release.
        </p>
      </div>
    </main>
  );
}
