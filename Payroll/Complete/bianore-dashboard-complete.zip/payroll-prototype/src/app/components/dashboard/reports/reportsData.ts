// ── Types ──────────────────────────────────────────────────────────────────
export interface DailyAttendance {
  date: string; label: string; weekday: string;
  present: number; late: number; absent: number; rate: number;
}

export interface HeatmapCell {
  week: number; day: string; date: string; rate: number; present: number; late: number; absent: number;
}

export interface DeptMetric {
  dept: string; headcount: number; attendanceRate: number;
  avgNetSalary: number; totalPayroll: number; lateRate: number;
  overtimeHours: number; performanceScore: number; color: string;
}

export interface InsightCard {
  id: string; type: "success" | "warning" | "info" | "alert";
  title: string; body: string; metric?: string;
}

// ── Summary KPI Sparklines ─────────────────────────────────────────────────
export const attendanceRateSparkline   = [92.1, 93.4, 94.2, 93.1, 95.0, 94.8];
export const lateIncidentsSparkline    = [58,   52,   61,   49,   50,   47];
export const absentDaysSparkline       = [34,   29,   38,   31,   30,   28];
export const payrollSparkline          = [268000, 275400, 271200, 280100, 277600, 284500];
export const avgSalarySparkline        = [5920, 6010, 5980, 6100, 6080, 6210];
export const overtimeSparkline         = [41,   44,   38,   46,   45,   58];

// ── 30-day Daily Attendance Trend ──────────────────────────────────────────
export const dailyTrend: DailyAttendance[] = [
  { date: "Apr 1",  label: "1",  weekday: "Wed", present: 328, late: 18, absent: 6,  rate: 95.1 },
  { date: "Apr 2",  label: "2",  weekday: "Thu", present: 331, late: 12, absent: 9,  rate: 95.9 },
  { date: "Apr 3",  label: "3",  weekday: "Fri", present: 320, late: 22, absent: 10, rate: 92.6 },
  { date: "Apr 6",  label: "6",  weekday: "Mon", present: 335, late: 15, absent: 2,  rate: 97.1 },
  { date: "Apr 7",  label: "7",  weekday: "Tue", present: 338, late: 9,  absent: 5,  rate: 97.7 },
  { date: "Apr 8",  label: "8",  weekday: "Wed", present: 330, late: 16, absent: 6,  rate: 95.7 },
  { date: "Apr 9",  label: "9",  weekday: "Thu", present: 340, late: 8,  absent: 4,  rate: 98.3 },
  { date: "Apr 10", label: "10", weekday: "Fri", present: 315, late: 24, absent: 13, rate: 91.3 },
  { date: "Apr 13", label: "13", weekday: "Mon", present: 332, late: 14, absent: 6,  rate: 96.2 },
  { date: "Apr 14", label: "14", weekday: "Tue", present: 336, late: 11, absent: 5,  rate: 97.2 },
  { date: "Apr 15", label: "15", weekday: "Wed", present: 341, late: 7,  absent: 4,  rate: 98.6 },
  { date: "Apr 16", label: "16", weekday: "Thu", present: 334, late: 13, absent: 5,  rate: 96.8 },
  { date: "Apr 17", label: "17", weekday: "Fri", present: 328, late: 19, absent: 5,  rate: 95.1 },
  { date: "Apr 20", label: "20", weekday: "Mon", present: 337, late: 13, absent: 2,  rate: 97.4 },
  { date: "Apr 21", label: "21", weekday: "Tue", present: 330, late: 16, absent: 6,  rate: 95.7 },
  { date: "Apr 22", label: "22", weekday: "Wed", present: 333, late: 14, absent: 5,  rate: 96.5 },
  { date: "Apr 23", label: "23", weekday: "Thu", present: 339, late: 9,  absent: 4,  rate: 98.0 },
  { date: "Apr 24", label: "24", weekday: "Fri", present: 342, late: 6,  absent: 4,  rate: 98.8 },
  { date: "Apr 27", label: "27", weekday: "Mon", present: 335, late: 14, absent: 3,  rate: 97.1 },
  { date: "Apr 28", label: "28", weekday: "Tue", present: 338, late: 11, absent: 3,  rate: 97.7 },
  { date: "Apr 29", label: "29", weekday: "Wed", present: 329, late: 17, absent: 6,  rate: 95.4 },
  { date: "Apr 30", label: "30", weekday: "Thu", present: 312, late: 24, absent: 16, rate: 90.4 },
];

// ── Attendance Heatmap (5 weeks × 5 days) ──────────────────────────────────
export const heatmapData: HeatmapCell[] = [
  { week: 1, day: "Mon", date: "Mar 30", rate: 94, present: 328, late: 16, absent: 8 },
  { week: 1, day: "Tue", date: "Mar 31", rate: 91, present: 312, late: 24, absent: 16 },
  { week: 1, day: "Wed", date: "Apr 1",  rate: 95, present: 328, late: 18, absent: 6 },
  { week: 1, day: "Thu", date: "Apr 2",  rate: 97, present: 331, late: 12, absent: 9 },
  { week: 1, day: "Fri", date: "Apr 3",  rate: 92, present: 320, late: 22, absent: 10 },
  { week: 2, day: "Mon", date: "Apr 6",  rate: 96, present: 335, late: 15, absent: 2 },
  { week: 2, day: "Tue", date: "Apr 7",  rate: 97, present: 338, late: 9,  absent: 5 },
  { week: 2, day: "Wed", date: "Apr 8",  rate: 95, present: 330, late: 16, absent: 6 },
  { week: 2, day: "Thu", date: "Apr 9",  rate: 98, present: 340, late: 8,  absent: 4 },
  { week: 2, day: "Fri", date: "Apr 10", rate: 91, present: 315, late: 24, absent: 13 },
  { week: 3, day: "Mon", date: "Apr 13", rate: 94, present: 332, late: 14, absent: 6 },
  { week: 3, day: "Tue", date: "Apr 14", rate: 95, present: 336, late: 11, absent: 5 },
  { week: 3, day: "Wed", date: "Apr 15", rate: 97, present: 341, late: 7,  absent: 4 },
  { week: 3, day: "Thu", date: "Apr 16", rate: 96, present: 334, late: 13, absent: 5 },
  { week: 3, day: "Fri", date: "Apr 17", rate: 95, present: 328, late: 19, absent: 5 },
  { week: 4, day: "Mon", date: "Apr 20", rate: 96, present: 337, late: 13, absent: 2 },
  { week: 4, day: "Tue", date: "Apr 21", rate: 94, present: 330, late: 16, absent: 6 },
  { week: 4, day: "Wed", date: "Apr 22", rate: 95, present: 333, late: 14, absent: 5 },
  { week: 4, day: "Thu", date: "Apr 23", rate: 97, present: 339, late: 9,  absent: 4 },
  { week: 4, day: "Fri", date: "Apr 24", rate: 98, present: 342, late: 6,  absent: 4 },
  { week: 5, day: "Mon", date: "Apr 27", rate: 95, present: 335, late: 14, absent: 3 },
  { week: 5, day: "Tue", date: "Apr 28", rate: 97, present: 338, late: 11, absent: 3 },
  { week: 5, day: "Wed", date: "Apr 29", rate: 95, present: 329, late: 17, absent: 6 },
  { week: 5, day: "Thu", date: "Apr 30", rate: 90, present: 312, late: 24, absent: 16 },
  { week: 5, day: "Fri", date: "May 1",  rate: 93, present: 324, late: 18, absent: 10 },
];

// ── Late Incidents by Day of Week ──────────────────────────────────────────
export const lateByDow = [
  { day: "Mon", lates: 68, absences: 18 },
  { day: "Tue", lates: 42, absences: 12 },
  { day: "Wed", lates: 38, absences: 10 },
  { day: "Thu", lates: 29, absences: 8 },
  { day: "Fri", lates: 52, absences: 14 },
];

// ── Department Metrics ─────────────────────────────────────────────────────
export const deptMetrics: DeptMetric[] = [
  { dept: "Engineering", headcount: 48, attendanceRate: 97.2, avgNetSalary: 7800, totalPayroll: 98400, lateRate: 2.1, overtimeHours: 38, performanceScore: 4.5, color: "#3b82f6" },
  { dept: "Finance",     headcount: 22, attendanceRate: 96.1, avgNetSalary: 6200, totalPayroll: 38100, lateRate: 3.1, overtimeHours: 8,  performanceScore: 4.3, color: "#06b6d4" },
  { dept: "Executive",   headcount: 7,  attendanceRate: 100,  avgNetSalary: 11200, totalPayroll: 42000, lateRate: 0,   overtimeHours: 0,  performanceScore: 4.7, color: "#8b5cf6" },
  { dept: "Operations",  headcount: 61, attendanceRate: 95.0, avgNetSalary: 4900, totalPayroll: 52800, lateRate: 4.2, overtimeHours: 28, performanceScore: 3.8, color: "#f97316" },
  { dept: "HR",          headcount: 8,  attendanceRate: 93.8, avgNetSalary: 5200, totalPayroll: 10500, lateRate: 5.2, overtimeHours: 4,  performanceScore: 4.1, color: "#a855f7" },
  { dept: "Sales",       headcount: 52, attendanceRate: 91.4, avgNetSalary: 5400, totalPayroll: 64200, lateRate: 7.2, overtimeHours: 12, performanceScore: 3.9, color: "#10b981" },
  { dept: "Marketing",   headcount: 18, attendanceRate: 88.6, avgNetSalary: 5100, totalPayroll: 22400, lateRate: 8.4, overtimeHours: 6,  performanceScore: 3.6, color: "#ec4899" },
];

// ── Salary Distribution (Histogram) ───────────────────────────────────────
export const salaryDistribution = [
  { range: "$4k–5k",  count: 4,  fill: "#e0e7ff" },
  { range: "$5k–6k",  count: 8,  fill: "#bfdbfe" },
  { range: "$6k–7k",  count: 7,  fill: "#93c5fd" },
  { range: "$7k–8k",  count: 6,  fill: "#60a5fa" },
  { range: "$8k–9k",  count: 5,  fill: "#3b82f6" },
  { range: "$9k+",    count: 6,  fill: "#1d4ed8" },
];

// ── Payroll Cost by Dept (for donut/bar) ───────────────────────────────────
export const payrollByDept = [
  { name: "Engineering", value: 98400,  fill: "#3b82f6" },
  { name: "Sales",       value: 64200,  fill: "#10b981" },
  { name: "Executive",   value: 42000,  fill: "#8b5cf6" },
  { name: "Operations",  value: 52800,  fill: "#f97316" },
  { name: "Finance",     value: 38100,  fill: "#06b6d4" },
  { name: "Marketing",   value: 22400,  fill: "#ec4899" },
  { name: "HR",          value: 10500,  fill: "#a855f7" },
];

// ── Monthly Payroll Trend (extended 12 months) ─────────────────────────────
export const monthlyPayrollTrend = [
  { month: "May '25",  total: 258000, deductions: 15400, overtime: 9200 },
  { month: "Jun '25",  total: 261000, deductions: 15800, overtime: 9800 },
  { month: "Jul '25",  total: 264000, deductions: 16100, overtime: 10400 },
  { month: "Aug '25",  total: 260000, deductions: 15600, overtime: 8900 },
  { month: "Sep '25",  total: 265000, deductions: 16400, overtime: 11200 },
  { month: "Oct '25",  total: 268000, deductions: 16200, overtime: 10800 },
  { month: "Nov '25",  total: 272000, deductions: 16800, overtime: 11600 },
  { month: "Dec '25",  total: 278000, deductions: 17200, overtime: 12400 },
  { month: "Jan '26",  total: 271200, deductions: 15800, overtime: 9600 },
  { month: "Feb '26",  total: 280100, deductions: 18000, overtime: 13100 },
  { month: "Mar '26",  total: 277600, deductions: 17400, overtime: 11800 },
  { month: "Apr '26",  total: 284500, deductions: 18240, overtime: 14040 },
];

// ── Workforce Distribution (for donut) ────────────────────────────────────
export const workforceDistribution = [
  { name: "Full-time", value: 30, fill: "#3b82f6" },
  { name: "Contract",  value: 8,  fill: "#f59e0b" },
  { name: "Part-time", value: 4,  fill: "#8b5cf6" },
  { name: "Intern",    value: 2,  fill: "#10b981" },
];

// ── Insight Cards ──────────────────────────────────────────────────────────
export const insights: InsightCard[] = [
  { id: "i1", type: "warning", title: "Overtime Spike", body: "Overtime costs rose 16.4% in April — the highest in 6 months. Engineering and Operations are the top contributors.", metric: "+16.4%" },
  { id: "i2", type: "alert",   title: "Marketing Attendance", body: "Marketing dept late rate is 8.4%, exceeding the 5% company threshold. Sarah Chen & Mei Lin account for most incidents.", metric: "8.4% rate" },
  { id: "i3", type: "success", title: "Engineering Perfect Week", body: "Engineering maintained 97.2% attendance in April — the highest across all departments.", metric: "97.2%" },
  { id: "i4", type: "info",    title: "2 On Extended Leave", body: "Priya Sharma and Aisha Johnson are on extended leave. Payroll adjustments have been applied for April.", metric: "2 employees" },
  { id: "i5", type: "alert",   title: "Contract Expiring", body: "Carlos Rivera's contract expires May 22, 2026. Consider renewal or offboarding process.", metric: "22 days left" },
];

// ── Top Late Employees (for drill-down) ───────────────────────────────────
export const topLateEmployees = [
  { name: "Carlos Rivera",  dept: "Sales",     lates: 6, absences: 0, impact: "$590" },
  { name: "Sarah Chen",     dept: "Marketing", lates: 5, absences: 0, impact: "$310" },
  { name: "Omar Faruk",     dept: "Operations",lates: 2, absences: 0, impact: "$0"   },
  { name: "Priya Sharma",   dept: "HR",        lates: 0, absences: 1, impact: "$264" },
  { name: "Aisha Johnson",  dept: "Engineering",lates: 0, absences: 1, impact: "$341" },
];

// ── Report Builder Field Definitions ──────────────────────────────────────
export const builderSources = {
  attendance: {
    label: "Attendance Logs",
    icon: "clock",
    fields: [
      { key: "name",      label: "Employee Name", defaultOn: true },
      { key: "dept",      label: "Department",    defaultOn: true },
      { key: "date",      label: "Date",          defaultOn: true },
      { key: "checkIn",   label: "Check-in Time", defaultOn: true },
      { key: "checkOut",  label: "Check-out",     defaultOn: true },
      { key: "status",    label: "Status",        defaultOn: true },
      { key: "hours",     label: "Work Hours",    defaultOn: false },
    ],
  },
  payroll: {
    label: "Payroll Records",
    icon: "dollar-sign",
    fields: [
      { key: "name",       label: "Employee Name",   defaultOn: true },
      { key: "dept",       label: "Department",      defaultOn: true },
      { key: "baseSalary", label: "Base Salary",     defaultOn: true },
      { key: "netSalary",  label: "Net Salary",      defaultOn: true },
      { key: "overtime",   label: "Overtime Pay",    defaultOn: false },
      { key: "tax",        label: "Tax (PPh 21)",    defaultOn: false },
      { key: "status",     label: "Status",          defaultOn: true },
    ],
  },
  employees: {
    label: "Employee Directory",
    icon: "users",
    fields: [
      { key: "empId",           label: "Employee ID",    defaultOn: true },
      { key: "name",            label: "Full Name",      defaultOn: true },
      { key: "dept",            label: "Department",     defaultOn: true },
      { key: "role",            label: "Role",           defaultOn: true },
      { key: "employmentType",  label: "Type",           defaultOn: false },
      { key: "status",          label: "Status",         defaultOn: true },
      { key: "joinDate",        label: "Join Date",      defaultOn: false },
      { key: "performanceScore",label: "Performance",    defaultOn: false },
    ],
  },
};
