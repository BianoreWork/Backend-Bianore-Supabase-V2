import { useState } from "react";
import { X, CalendarDays, Mail, Clock, CheckCircle, Bell } from "lucide-react";

interface ScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const inputClass = "w-full text-xs text-gray-800 bg-white border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-all placeholder:text-gray-400";

export function ScheduleModal({ isOpen, onClose }: ScheduleModalProps) {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "Monthly Payroll + Attendance Report",
    frequency: "monthly",
    dayOfMonth: "1",
    time: "08:00",
    email: "admin@workforce.app",
    format: "pdf",
    includePreview: true,
  });

  if (!isOpen) return null;

  const handleSubmit = () => setSubmitted(true);

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-[2px] z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[480px] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
              <Bell size={13} className="text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">Schedule Report</p>
              <p className="text-[10px] text-gray-400">Auto-send via email on schedule</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer">
            <X size={15} />
          </button>
        </div>

        {submitted ? (
          <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
            <div className="w-14 h-14 bg-green-50 rounded-full flex items-center justify-center mb-4">
              <CheckCircle size={28} className="text-green-500" />
            </div>
            <p className="text-sm font-bold text-gray-900 mb-1">Report Scheduled!</p>
            <p className="text-xs text-gray-500 mb-6">
              <span className="font-semibold">{form.name}</span> will be sent to{" "}
              <span className="font-semibold">{form.email}</span>{" "}
              {form.frequency === "daily" ? "every day" : form.frequency === "weekly" ? "every week" : `on the ${form.dayOfMonth}st of each month`} at {form.time}.
            </p>
            <button onClick={() => { setSubmitted(false); onClose(); }}
              className="text-xs text-white bg-blue-600 hover:bg-blue-700 px-5 py-2.5 rounded-lg transition-colors cursor-pointer font-semibold">
              Done
            </button>
          </div>
        ) : (
          <div className="px-5 py-4 space-y-4">
            {/* Report Name */}
            <div>
              <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Report Name</label>
              <input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className={inputClass} placeholder="e.g. Monthly Attendance Report" />
            </div>

            {/* Frequency */}
            <div>
              <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Frequency</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { val: "daily",   label: "Daily",   icon: <Clock size={13} /> },
                  { val: "weekly",  label: "Weekly",  icon: <CalendarDays size={13} /> },
                  { val: "monthly", label: "Monthly", icon: <CalendarDays size={13} /> },
                ].map((opt) => (
                  <button key={opt.val} onClick={() => setForm((f) => ({ ...f, frequency: opt.val }))}
                    className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                      form.frequency === opt.val ? "border-blue-400 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-600 hover:border-gray-300"
                    }`}>
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Time + Format */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Send Time</label>
                <input type="time" value={form.time} onChange={(e) => setForm((f) => ({ ...f, time: e.target.value }))} className={inputClass} />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Format</label>
                <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
                  {["pdf", "csv"].map((fmt) => (
                    <button key={fmt} onClick={() => setForm((f) => ({ ...f, format: fmt }))}
                      className={`flex-1 py-1.5 rounded-md text-xs font-semibold uppercase transition-all cursor-pointer ${
                        form.format === fmt ? "bg-white text-gray-800 shadow-sm" : "text-gray-500"
                      }`}>
                      {fmt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Send to (Email)</label>
              <div className="relative">
                <Mail size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  placeholder="email@company.com" className={`${inputClass} pl-8`} />
              </div>
              <p className="text-[10px] text-gray-400 mt-1">Separate multiple emails with commas</p>
            </div>

            {/* Include Preview */}
            <div className="flex items-center gap-3 px-3 py-2.5 bg-gray-50 rounded-xl">
              <input type="checkbox" checked={form.includePreview} onChange={(e) => setForm((f) => ({ ...f, includePreview: e.target.checked }))}
                className="w-4 h-4 rounded accent-blue-600 cursor-pointer" />
              <div>
                <p className="text-xs font-semibold text-gray-700">Include inline preview</p>
                <p className="text-[10px] text-gray-400">Embed a summary table in the email body</p>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center gap-2 pt-1 border-t border-gray-100">
              <button onClick={onClose} className="flex-1 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 py-2.5 rounded-lg transition-colors cursor-pointer font-medium">
                Cancel
              </button>
              <button onClick={handleSubmit} className="flex-1 text-xs text-white bg-blue-600 hover:bg-blue-700 py-2.5 rounded-lg transition-colors cursor-pointer font-semibold flex items-center justify-center gap-1.5">
                <Bell size={12} /> Activate Schedule
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
