import { useState } from "react";
import {
  Play, Plus, Search, SlidersHorizontal, Download,
  MoreHorizontal, CheckCircle, X, ChevronRight,
  CalendarDays, Users, FileText, RefreshCw, Lock, Send,
  AlertTriangle, Clock, DollarSign, ChevronLeft,
  XCircle, MessageSquare,
} from "lucide-react";
import {
  payrollRuns, fmtIDRShort, fmtIDR,
  type PayrollRun, type PayrollRunStatus, type PayrollType,
} from "./payrollMockData";

const statusConfig: Record<PayrollRunStatus, { bg: string; text: string; dot: string; label: string }> = {
  draft:              { bg: "bg-gray-100",   text: "text-gray-600",   dot: "bg-gray-400",   label: "Draft" },
  calculating:        { bg: "bg-sky-50",     text: "text-sky-700",    dot: "bg-sky-400",    label: "Menghitung" },
  calculated:         { bg: "bg-blue-50",    text: "text-blue-700",   dot: "bg-blue-400",   label: "Terhitung" },
  pending_approval:   { bg: "bg-amber-50",   text: "text-amber-700",  dot: "bg-amber-500",  label: "Menunggu Approval" },
  approved:           { bg: "bg-violet-50",  text: "text-violet-700", dot: "bg-violet-500", label: "Disetujui" },
  payment_processing: { bg: "bg-indigo-50",  text: "text-indigo-700", dot: "bg-indigo-500", label: "Proses Bayar" },
  paid:               { bg: "bg-green-50",   text: "text-green-700",  dot: "bg-green-500",  label: "Lunas" },
  partially_paid:     { bg: "bg-orange-50",  text: "text-orange-700", dot: "bg-orange-500", label: "Sebagian Lunas" },
  failed:             { bg: "bg-red-50",     text: "text-red-600",    dot: "bg-red-500",    label: "Gagal" },
  cancelled:          { bg: "bg-gray-100",   text: "text-gray-500",   dot: "bg-gray-300",   label: "Dibatalkan" },
};

const typeLabel: Record<PayrollType, string> = {
  monthly: "Bulanan", bonus: "Bonus", thr: "THR",
  correction: "Koreksi", final: "Final",
};
const typeColor: Record<PayrollType, string> = {
  monthly:    "bg-blue-50 text-blue-700",
  bonus:      "bg-green-50 text-green-700",
  thr:        "bg-amber-50 text-amber-700",
  correction: "bg-orange-50 text-orange-700",
  final:      "bg-gray-100 text-gray-600",
};

const filterTabs: { key: string; label: string }[] = [
  { key: "all", label: "Semua" },
  { key: "draft", label: "Draft" },
  { key: "pending_approval", label: "Approval" },
  { key: "approved", label: "Disetujui" },
  { key: "paid", label: "Lunas" },
];

// ── Create Run Modal ──────────────────────────────────────────────────────────
function CreateRunModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({
    runName: "", payrollType: "monthly" as PayrollType,
    month: "5", year: "2025",
    cutoffStart: "2025-05-01", cutoffEnd: "2025-05-31", paymentDate: "2025-06-05",
  });
  return (
    <>
      <div className="fixed inset-0 bg-black/30 backdrop-blur-[2px] z-40" onClick={onClose} />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Buat Payroll Run Baru</h3>
              <p className="text-xs text-gray-400 mt-0.5">Tentukan periode dan tipe payroll</p>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
              <X size={16} />
            </button>
          </div>
          {/* Body */}
          <div className="px-5 py-4 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nama Run *</label>
              <input
                value={form.runName}
                onChange={(e) => setForm({ ...form, runName: e.target.value })}
                placeholder="Contoh: Payroll Mei 2025"
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tipe Payroll *</label>
              <select
                value={form.payrollType}
                onChange={(e) => setForm({ ...form, payrollType: e.target.value as PayrollType })}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
              >
                <option value="monthly">Bulanan</option>
                <option value="bonus">Bonus</option>
                <option value="thr">THR</option>
                <option value="correction">Koreksi</option>
                <option value="final">Final</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Bulan *</label>
                <select
                  value={form.month}
                  onChange={(e) => setForm({ ...form, month: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i + 1} value={String(i + 1)}>
                      {new Date(0, i).toLocaleString("id-ID", { month: "long" })}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tahun *</label>
                <select
                  value={form.year}
                  onChange={(e) => setForm({ ...form, year: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all cursor-pointer"
                >
                  {[2024, 2025, 2026].map((y) => <option key={y} value={String(y)}>{y}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Cutoff Mulai</label>
                <input type="date" value={form.cutoffStart}
                  onChange={(e) => setForm({ ...form, cutoffStart: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Cutoff Akhir</label>
                <input type="date" value={form.cutoffEnd}
                  onChange={(e) => setForm({ ...form, cutoffEnd: e.target.value })}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tanggal Bayar</label>
              <input type="date" value={form.paymentDate}
                onChange={(e) => setForm({ ...form, paymentDate: e.target.value })}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-blue-400 focus:bg-white transition-all" />
            </div>
          </div>
          {/* Footer */}
          <div className="px-5 py-4 border-t border-gray-100 flex items-center justify-end gap-2">
            <button onClick={onClose} className="text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-4 py-2 rounded-lg cursor-pointer transition-colors">
              Batal
            </button>
            <button
              onClick={onClose}
              className="text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <Plus size={12} /> Buat Run
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Run Detail Drawer ─────────────────────────────────────────────────────────
function RunDetailDrawer({ run, onClose }: { run: PayrollRun; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<"summary" | "employees" | "approval">("summary");
  const sc = statusConfig[run.status];

  const approvalSteps = [
    { role: "HR Manager", name: "Alex Kumar", status: run.status !== "draft" ? "approved" : "waiting", time: "01 Jun 2025, 09:30" },
    { role: "Finance Director", name: "Lisa Thompson", status: run.status === "pending_approval" ? "current" : run.status === "approved" || run.status === "paid" ? "approved" : "waiting", time: run.status === "approved" || run.status === "paid" ? "02 Jun 2025, 14:00" : null },
    { role: "CEO / Owner", name: "Robert Chen", status: run.status === "paid" ? "approved" : "waiting", time: null },
  ];

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-[1px] z-40" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full w-[540px] max-w-[95vw] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-bold text-gray-900">{run.runName}</p>
              <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${sc.bg} ${sc.text}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                {sc.label}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5 font-mono">{run.runCode}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer">
            <X size={16} />
          </button>
        </div>

        {/* Meta strip */}
        <div className="flex items-center gap-4 px-5 py-2.5 bg-gray-50 border-b border-gray-100 flex-shrink-0 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-gray-600">
            <CalendarDays size={11} className="text-gray-400" />
            Cutoff: {run.cutoffStartDate} s/d {run.cutoffEndDate}
          </div>
          <div className="w-px h-3 bg-gray-300" />
          <div className="flex items-center gap-1.5 text-xs text-gray-600">
            <DollarSign size={11} className="text-gray-400" />
            Bayar: {run.paymentDate}
          </div>
          <div className="w-px h-3 bg-gray-300" />
          <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${typeColor[run.payrollType]}`}>
            {typeLabel[run.payrollType]}
          </span>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-0 px-5 border-b border-gray-100 flex-shrink-0">
          {(["summary", "employees", "approval"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-xs font-medium border-b-2 transition-all cursor-pointer capitalize whitespace-nowrap ${
                activeTab === tab ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              {tab === "summary" ? "Ringkasan" : tab === "employees" ? "Karyawan" : "Approval"}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          {/* Summary */}
          {activeTab === "summary" && (
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-blue-100">Total Gaji Netto</p>
                    <p className="text-xl font-bold text-white mt-0.5">{run.totalNetSalary > 0 ? fmtIDRShort(run.totalNetSalary) : "—"}</p>
                  </div>
                  <div>
                    <p className="text-xs text-blue-100">Total Karyawan</p>
                    <p className="text-xl font-bold text-white mt-0.5">{run.totalEmployees > 0 ? run.totalEmployees : "—"}</p>
                  </div>
                </div>
              </div>

              {run.totalNetSalary > 0 && (
                <>
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                    {[
                      { label: "Total Gaji Bruto",        value: run.totalGrossSalary,   color: "text-gray-800" },
                      { label: "Total Penghasilan",       value: run.totalEarning,       color: "text-green-700" },
                      { label: "Total Potongan",          value: run.totalDeduction,     color: "text-red-600", prefix: "(" },
                      { label: "BPJS Karyawan",           value: run.totalBpjsEmployee,  color: "text-red-600", prefix: "(" },
                      { label: "BPJS Perusahaan",         value: run.totalBpjsEmployer,  color: "text-blue-600" },
                      { label: "PPh21",                   value: run.totalPph21,         color: "text-red-600", prefix: "(" },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center justify-between">
                        <span className="text-xs text-gray-600">{row.label}</span>
                        <span className={`text-xs font-semibold tabular-nums ${row.color}`}>
                          {row.prefix ? `(${fmtIDR(row.value)})` : fmtIDR(row.value)}
                        </span>
                      </div>
                    ))}
                    <div className="pt-2 border-t border-gray-200 flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-800">Total Netto Dibayarkan</span>
                      <span className="text-sm font-bold text-blue-800 tabular-nums">{fmtIDR(run.totalNetSalary)}</span>
                    </div>
                  </div>

                  {run.status === "partially_paid" && run.totalFailedPayment > 0 && (
                    <div className="flex items-start gap-2.5 px-3 py-3 bg-orange-50 rounded-xl border border-orange-200">
                      <AlertTriangle size={13} className="text-orange-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-xs font-semibold text-orange-800">Pembayaran Gagal Sebagian</p>
                        <p className="text-[10px] text-orange-700 mt-0.5">{fmtIDR(run.totalFailedPayment)} gagal dikirim. Silakan cek tab Disbursement.</p>
                      </div>
                    </div>
                  )}
                </>
              )}

              {run.status === "draft" && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <p className="text-xs font-semibold text-blue-800 mb-3">Langkah Selanjutnya</p>
                  <div className="space-y-2">
                    {[
                      { step: 1, label: "Pilih karyawan untuk dimasukkan dalam run ini" },
                      { step: 2, label: "Sync data absensi dari periode cutoff" },
                      { step: 3, label: "Hitung gaji semua karyawan" },
                      { step: 4, label: "Review & submit untuk approval" },
                    ].map((s) => (
                      <div key={s.step} className="flex items-center gap-2">
                        <div className="w-5 h-5 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center flex-shrink-0">{s.step}</div>
                        <p className="text-xs text-blue-700">{s.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Employees */}
          {activeTab === "employees" && (
            <div className="space-y-2">
              {run.totalEmployees === 0 ? (
                <div className="py-12 text-center">
                  <Users size={32} className="text-gray-200 mx-auto mb-3" />
                  <p className="text-sm font-semibold text-gray-400">Belum ada karyawan dipilih</p>
                  <p className="text-xs text-gray-400 mt-1">Klik tombol "Pilih Karyawan" di bawah</p>
                </div>
              ) : (
                <div className="bg-gray-50 rounded-xl p-3">
                  <div className="grid grid-cols-3 gap-3 mb-3">
                    {[
                      { label: "Total Karyawan", value: run.totalEmployees, color: "text-blue-700 bg-blue-50" },
                      { label: "Sudah Dihitung", value: run.status !== "draft" ? run.totalEmployees : 0, color: "text-green-700 bg-green-50" },
                      { label: "Ada Masalah", value: 2, color: "text-amber-700 bg-amber-50" },
                    ].map((s) => (
                      <div key={s.label} className={`rounded-xl p-2.5 text-center ${s.color}`}>
                        <p className="text-lg font-bold">{s.value}</p>
                        <p className="text-[9px] font-semibold uppercase tracking-wider opacity-70">{s.label}</p>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 text-center">Lihat detail karyawan di halaman Employee Payroll</p>
                </div>
              )}
            </div>
          )}

          {/* Approval */}
          {activeTab === "approval" && (
            <div className="space-y-4">
              <div className="relative">
                {approvalSteps.map((step, idx) => (
                  <div key={step.role} className="flex gap-3 mb-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        step.status === "approved"  ? "bg-green-500"
                        : step.status === "current" ? "bg-amber-500 ring-4 ring-amber-100"
                        : "bg-gray-200"
                      }`}>
                        {step.status === "approved"  ? <CheckCircle size={14} className="text-white" /> :
                         step.status === "current"   ? <Clock size={14} className="text-white" /> :
                         <Users size={14} className="text-gray-400" />}
                      </div>
                      {idx < approvalSteps.length - 1 && (
                        <div className={`w-0.5 min-h-[28px] mt-1 ${step.status === "approved" ? "bg-green-300" : "bg-gray-200"}`} />
                      )}
                    </div>
                    <div className="flex-1 pb-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-xs font-bold text-gray-800">{step.name}</p>
                        <span className="text-[10px] text-gray-400">{step.role}</span>
                        <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                          step.status === "approved" ? "text-green-700 bg-green-50" :
                          step.status === "current"  ? "text-amber-700 bg-amber-50 animate-pulse" :
                          "text-gray-400 bg-gray-100"
                        }`}>
                          {step.status === "approved" ? "Disetujui" : step.status === "current" ? "Menunggu" : "Belum"}
                        </span>
                      </div>
                      {step.time && <p className="text-[10px] text-gray-400 mt-0.5">{step.time}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom actions */}
        <div className="flex items-center gap-2 px-5 py-3.5 border-t border-gray-100 bg-white flex-shrink-0 flex-wrap">
          {run.status === "draft" && (
            <>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <Users size={12} /> Pilih Karyawan
              </button>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <RefreshCw size={12} /> Sync Absensi
              </button>
              <div className="flex-1" />
              <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
                <Play size={12} /> Hitung Gaji
              </button>
            </>
          )}
          {run.status === "calculated" && (
            <>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <FileText size={12} /> Review Detail
              </button>
              <div className="flex-1" />
              <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
                <Send size={12} /> Submit Approval
              </button>
            </>
          )}
          {run.status === "pending_approval" && (
            <>
              <button className="flex items-center gap-1.5 text-xs text-red-600 border border-red-200 hover:bg-red-50 px-3 py-2 rounded-lg cursor-pointer">
                <XCircle size={12} /> Tolak
              </button>
              <div className="flex-1" />
              <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg cursor-pointer">
                <CheckCircle size={12} /> Setujui
              </button>
            </>
          )}
          {run.status === "approved" && (
            <>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 hover:bg-gray-50 px-3 py-2 rounded-lg cursor-pointer">
                <Lock size={12} /> Kunci
              </button>
              <div className="flex-1" />
              <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer">
                <DollarSign size={12} /> Buat Batch Bayar
              </button>
            </>
          )}
          {(run.status === "paid" || run.status === "partially_paid") && (
            <span className="text-xs font-semibold text-green-700 bg-green-50 border border-green-200 px-3 py-2 rounded-lg flex items-center gap-1.5">
              <CheckCircle size={12} /> {run.status === "paid" ? "Dibayarkan Semua" : "Sebagian Dibayarkan"}
            </span>
          )}
        </div>
      </div>
    </>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export function PayrollRunsPage() {
  const [search, setSearch]           = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreate, setShowCreate]   = useState(false);
  const [selected, setSelected]       = useState<PayrollRun | null>(null);

  const filtered = payrollRuns.filter((r) => {
    const matchSearch = r.runName.toLowerCase().includes(search.toLowerCase()) ||
                        r.runCode.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const counts: Record<string, number> = {
    all: payrollRuns.length,
    draft: payrollRuns.filter((r) => r.status === "draft").length,
    pending_approval: payrollRuns.filter((r) => r.status === "pending_approval").length,
    approved: payrollRuns.filter((r) => r.status === "approved").length,
    paid: payrollRuns.filter((r) => r.status === "paid" || r.status === "partially_paid").length,
  };

  return (
    <main className="px-6 py-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Payroll Runs</h1>
          <p className="text-sm text-gray-500 mt-0.5">Kelola semua payroll run — dari draft hingga pembayaran</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 cursor-pointer">
            <Download size={13} className="text-gray-400" /> Export
          </button>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg cursor-pointer"
          >
            <Plus size={13} /> Buat Payroll Run
          </button>
        </div>
      </div>

      {/* Summary chips */}
      <div className="flex items-center gap-3 flex-wrap">
        {[
          { label: "Total Run Aktif", value: "2", color: "bg-blue-50 text-blue-700" },
          { label: "Menunggu Approval", value: "1", color: "bg-amber-50 text-amber-700" },
          { label: "Dibayarkan (YTD)", value: fmtIDRShort(4_335_300_000 + 4_275_000_000 + 4_223_000_000 + 4_174_000_000), color: "bg-green-50 text-green-700" },
          { label: "Gagal Bayar", value: fmtIDRShort(38_000_000), color: "bg-red-50 text-red-600" },
        ].map((c) => (
          <div key={c.label} className={`px-4 py-2 rounded-xl text-xs font-semibold ${c.color}`}>
            <span className="opacity-60">{c.label}: </span>{c.value}
          </div>
        ))}
      </div>

      {/* Table card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 gap-3 flex-wrap">
          <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-1">
            {filterTabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`text-xs px-3 py-1.5 rounded-md transition-all cursor-pointer font-medium whitespace-nowrap ${
                  statusFilter === tab.key ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab.label}
                <span className="ml-1 opacity-50">{counts[tab.key] ?? 0}</span>
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Cari run payroll..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-7 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg w-48 outline-none focus:border-blue-400 focus:bg-white transition-all placeholder:text-gray-400"
              />
            </div>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer">
              <SlidersHorizontal size={12} /> Filter
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/60">
                {["Kode Run", "Nama", "Tipe", "Periode", "Karyawan", "Total Gaji Netto", "Tgl Bayar", "Status", "Dibuat Oleh", ""].map((col) => (
                  <th key={col} className="text-left px-4 py-3">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((run, idx) => {
                const sc = statusConfig[run.status];
                const tc = typeColor[run.payrollType];
                return (
                  <tr
                    key={run.id}
                    onClick={() => setSelected(run)}
                    className={`border-b border-gray-50 cursor-pointer hover:bg-blue-50/30 transition-colors ${idx % 2 !== 0 ? "bg-gray-50/20" : ""}`}
                  >
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-mono font-semibold text-gray-700">{run.runCode}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-semibold text-gray-800">{run.runName}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-md ${tc}`}>{typeLabel[run.payrollType]}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-600">
                        {new Date(0, run.month - 1).toLocaleString("id-ID", { month: "short" })} {run.year}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-700 font-medium">{run.totalEmployees > 0 ? run.totalEmployees : "—"}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs font-bold text-gray-900 tabular-nums">
                        {run.totalNetSalary > 0 ? fmtIDRShort(run.totalNetSalary) : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-500">{run.paymentDate}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-gray-500">{run.createdBy}</span>
                    </td>
                    <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setSelected(run)}
                        className="p-1.5 rounded-lg text-gray-300 hover:text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors"
                      >
                        <ChevronRight size={14} />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={10} className="py-16 text-center text-sm text-gray-400">
                    Tidak ada payroll run yang cocok dengan filter
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">
            Menampilkan <span className="font-semibold text-gray-600">{filtered.length}</span> dari{" "}
            <span className="font-semibold text-gray-600">{payrollRuns.length}</span> run
          </p>
          <div className="flex items-center gap-1">
            <button className="w-7 h-7 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center cursor-pointer"><ChevronLeft size={13} /></button>
            <button className="w-7 h-7 rounded-lg bg-blue-600 text-white text-xs font-semibold flex items-center justify-center">1</button>
            <button className="w-7 h-7 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center cursor-pointer"><ChevronRight size={13} /></button>
          </div>
        </div>
      </div>

      <div className="h-4" />

      {showCreate && <CreateRunModal onClose={() => setShowCreate(false)} />}
      {selected && <RunDetailDrawer run={selected} onClose={() => setSelected(null)} />}
    </main>
  );
}
