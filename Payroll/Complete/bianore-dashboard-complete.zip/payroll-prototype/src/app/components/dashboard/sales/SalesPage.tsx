import { useState, useMemo } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, AreaChart, Area,
} from "recharts";
import {
  MapPin, Plus, Search, MoreHorizontal, TrendingUp, TrendingDown, Minus,
  Camera, CheckCircle, Clock, Calendar, Users, ChevronDown, Zap, Building2,
  Target, AlertTriangle, Star, ChevronRight, Navigation, Wifi, WifiOff,
  AlertCircle, Activity, Filter,
} from "lucide-react";
import {
  visits as allVisits, topPerformers, weeklyActivity, monthlyVisitTrend,
  salesReps, statusColors, statusDot, statusLabels, outcomeLabels, outcomeColors,
  activityTypeLabels, activityTypeColors, priorityColors, liveActivities, fieldAlerts,
  type FieldActivity, type ActivityStatus, type ActivityType,
} from "./salesData";
import { VisitDetailDrawer } from "./VisitDetailDrawer";
import { LogVisitModal } from "./LogVisitModal";

const cardClass = "bg-white rounded-2xl border border-gray-100 shadow-sm p-5";
const tooltipStyle = {
  contentStyle: {
    background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)", fontSize: "11px", padding: "8px 12px",
  },
  labelStyle: { color: "#374151", fontWeight: 600, marginBottom: 4 },
};

type FieldTab = "overview" | "activity-log" | "timeline";

const avatarColors = ["bg-blue-500","bg-emerald-500","bg-violet-500","bg-amber-500","bg-rose-500","bg-cyan-500","bg-orange-500"];
function Avatar({ initials, idx, size = "md" }: { initials: string; idx: number; size?: "sm"|"md" }) {
  const dim = size === "sm" ? "w-7 h-7 text-[9px]" : "w-8 h-8 text-[10px]";
  return (
    <div className={`${dim} ${avatarColors[idx % avatarColors.length]} rounded-full flex items-center justify-center text-white font-bold flex-shrink-0`}>
      {initials}
    </div>
  );
}

function StatusBadge({ status }: { status: ActivityStatus }) {
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg ${statusColors[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${statusDot[status]}`}/>
      {statusLabels[status]}
    </span>
  );
}

function KpiCard({ label, value, trend, trendType, sparkData, sparkColor, icon, iconBg }: {
  label: string; value: string; trend: string; trendType: "up"|"down"|"neutral";
  sparkData: number[]; sparkColor: string; icon: React.ReactNode; iconBg: string;
}) {
  const isUp = trendType === "up", isNeutral = trendType === "neutral";
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 hover:shadow-md hover:-translate-y-0.5 transition-all">
      <div className="flex items-start justify-between mb-1.5">
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${iconBg}`}>{icon}</div>
        <span className={`flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
          isNeutral ? "bg-gray-100 text-gray-500" : isUp ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"
        }`}>
          {isNeutral ? <Minus size={8}/> : isUp ? <TrendingUp size={8}/> : <TrendingDown size={8}/>} {trend}
        </span>
      </div>
      <div className="h-8 -mx-1 mb-0.5">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={sparkData.map((v,i) => ({v,i}))}>
            <defs>
              <linearGradient id={`sg-${label}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={sparkColor} stopOpacity={0.2}/>
                <stop offset="95%" stopColor={sparkColor} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="v" stroke={sparkColor} strokeWidth={1.5} fill={`url(#sg-${label})`} dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <p className="text-xl font-bold text-gray-900">{value}</p>
      <p className="text-[10px] text-gray-400 mt-0.5">{label}</p>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// REAL-TIME FIELD MAP
// ══════════════════════════════════════════════════════════════════
function RealTimeFieldMap({ onSelect }: { onSelect: (a: FieldActivity) => void }) {
  const [hovered, setHovered] = useState<string|null>(null);
  const live = allVisits.filter(v => ["on_the_way","arrived","in_progress","delayed","gps_inactive"].includes(v.status));

  const markerColor: Record<string, string> = {
    on_the_way:  "bg-sky-500",
    arrived:     "bg-blue-500",
    in_progress: "bg-amber-500",
    delayed:     "bg-orange-500",
    gps_inactive:"bg-rose-500",
  };
  const pulseColor: Record<string, string> = {
    on_the_way:  "bg-sky-400",
    arrived:     "bg-blue-400",
    in_progress: "bg-amber-400",
    delayed:     "bg-orange-400",
    gps_inactive:"bg-rose-400",
  };

  return (
    <div className={cardClass}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold text-gray-800">Real-Time Field Map</h3>
          <p className="text-xs text-gray-400 mt-0.5">{live.length} employees currently on field · Live tracking</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 text-[10px] font-semibold text-green-700 bg-green-50 px-2 py-1 rounded-lg">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"/> Live
          </span>
          <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer transition-colors">
            <MoreHorizontal size={15}/>
          </button>
        </div>
      </div>

      {/* Map area */}
      <div className="relative h-64 rounded-2xl overflow-hidden border border-gray-200">
        {/* Background — satellite-style */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-200 via-slate-100 to-blue-100">
          {/* Grid */}
          <svg className="absolute inset-0 w-full h-full opacity-25">
            <defs>
              <pattern id="map-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#94a3b8" strokeWidth="0.6"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#map-grid)"/>
          </svg>
          {/* Road network */}
          <svg className="absolute inset-0 w-full h-full">
            <line x1="0"   y1="45%" x2="100%" y2="45%" stroke="#cbd5e1" strokeWidth="5"/>
            <line x1="0"   y1="70%" x2="100%" y2="70%" stroke="#e2e8f0" strokeWidth="3"/>
            <line x1="30%" y1="0"   x2="30%"  y2="100%" stroke="#cbd5e1" strokeWidth="5"/>
            <line x1="60%" y1="0"   x2="60%"  y2="100%" stroke="#e2e8f0" strokeWidth="3"/>
            <line x1="80%" y1="0"   x2="80%"  y2="100%" stroke="#e2e8f0" strokeWidth="2"/>
            <line x1="0"   y1="20%" x2="100%" y2="20%" stroke="#e2e8f0" strokeWidth="2"/>
            {/* city blocks */}
            <rect x="32%" y="22%" width="26%" height="21%" fill="#e8ecf0" opacity="0.5" rx="4"/>
            <rect x="62%" y="22%" width="16%" height="21%" fill="#e8ecf0" opacity="0.5" rx="4"/>
            <rect x="32%" y="47%" width="26%" height="21%" fill="#e8ecf0" opacity="0.5" rx="4"/>
            <rect x="3%"  y="22%" width="24%" height="42%" fill="#e8ecf0" opacity="0.5" rx="4"/>
          </svg>
          {/* Water-like area */}
          <div className="absolute bottom-0 right-0 w-24 h-20 rounded-tl-3xl bg-blue-200 opacity-40"/>
        </div>

        {/* Employee markers */}
        {live.map((act, i) => {
          const repIdx = salesReps.findIndex(r => r.id === act.rep.id);
          const isHov = hovered === act.id;
          return (
            <div key={act.id}
              className="absolute cursor-pointer group"
              style={{ left: `${act.mapX}%`, top: `${act.mapY * 0.85}%`, transform: "translate(-50%,-100%)", zIndex: isHov ? 20 : 10 }}
              onMouseEnter={() => setHovered(act.id)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onSelect(act)}
            >
              {/* Pulse ring */}
              {act.gpsActive && (
                <div className={`absolute -inset-1.5 rounded-full ${pulseColor[act.status]} opacity-30 animate-ping`}/>
              )}
              {/* Avatar badge */}
              <div className={`relative w-8 h-8 ${avatarColors[repIdx % avatarColors.length]} rounded-full border-2 border-white shadow-md flex items-center justify-center`}>
                <span className="text-white text-[9px] font-bold">{act.rep.avatar}</span>
                {/* status dot */}
                <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${markerColor[act.status] ?? "bg-gray-400"} rounded-full border-2 border-white`}/>
              </div>
              {/* Tooltip on hover */}
              {isHov && (
                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-gray-900 text-white rounded-xl px-3 py-2.5 min-w-40 shadow-xl pointer-events-none z-30">
                  <p className="text-[11px] font-bold">{act.rep.name}</p>
                  <p className="text-[9px] text-gray-300 mt-0.5">{act.location}</p>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${statusColors[act.status]}`}>{statusLabels[act.status]}</span>
                    {act.gpsActive ? <Wifi size={8} className="text-green-400"/> : <WifiOff size={8} className="text-gray-400"/>}
                  </div>
                  <p className="text-[9px] text-gray-400 mt-1">{act.clientCompany}</p>
                  <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-900"/>
                </div>
              )}
            </div>
          );
        })}

        {/* Legend */}
        <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center gap-3">
          {[
            { color: "bg-sky-500",    label: "On the Way" },
            { color: "bg-amber-500",  label: "In Progress" },
            { color: "bg-orange-500", label: "Delayed" },
            { color: "bg-rose-500",   label: "GPS Off" },
          ].map(l => (
            <div key={l.label} className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${l.color}`}/>
              <span className="text-[9px] text-gray-600">{l.label}</span>
            </div>
          ))}
        </div>

        {/* Live badge */}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-xl px-2.5 py-1.5 flex items-center gap-2">
          <span className="text-[10px] font-bold text-gray-600">{live.length} on field</span>
          <span className="text-[9px] text-gray-400">Updated 14:47</span>
        </div>
      </div>

      {/* Employee strip */}
      <div className="mt-3 flex items-center gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {live.map((act, i) => {
          const repIdx = salesReps.findIndex(r => r.id === act.rep.id);
          return (
            <button key={act.id} onClick={() => onSelect(act)}
              className="flex-shrink-0 flex items-center gap-2 bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-blue-300 rounded-xl px-3 py-2 cursor-pointer transition-all group">
              <Avatar initials={act.rep.avatar} idx={repIdx} size="sm"/>
              <div className="text-left">
                <p className="text-[10px] font-semibold text-gray-800 whitespace-nowrap">{act.rep.name.split(" ")[0]}</p>
                <div className="flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${statusDot[act.status]}`}/>
                  <p className="text-[9px] text-gray-400 whitespace-nowrap">{statusLabels[act.status]}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// ACTIVITY LOG TABLE ROW
// ══════════════════════════════════════════════════════════════════
function ActivityRow({ activity, repIdx, onClick }: { activity: FieldActivity; repIdx: number; onClick: () => void }) {
  return (
    <tr className="border-b border-gray-50 hover:bg-blue-50/30 transition-colors cursor-pointer group" onClick={onClick}>
      <td className="px-3 py-3">
        <div className="flex items-center gap-2">
          <Avatar initials={activity.rep.avatar} idx={repIdx} size="sm"/>
          <div>
            <p className="text-xs font-semibold text-gray-800">{activity.rep.name}</p>
            <p className="text-[9px] text-gray-400">{activity.rep.department}</p>
          </div>
        </div>
      </td>
      <td className="px-3 py-3">
        <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-md ${activityTypeColors[activity.activityType]}`}>
          {activityTypeLabels[activity.activityType]}
        </span>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs font-semibold text-gray-800">{activity.clientCompany}</p>
        <p className="text-[9px] text-gray-400 flex items-center gap-1"><Building2 size={8}/> {activity.contactPerson}</p>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs text-gray-700 flex items-center gap-1"><MapPin size={9} className="text-gray-400"/> {activity.location}</p>
        <p className="text-[9px] text-gray-400">{activity.district}</p>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs text-gray-600">{activity.assignedBy}</p>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs text-gray-700">{new Date(activity.date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</p>
        <p className="text-[9px] text-gray-400">{activity.scheduledTime}</p>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs text-gray-600">{activity.checkIn ?? "—"}</p>
      </td>
      <td className="px-3 py-3">
        <p className="text-xs text-gray-600">{activity.checkOut ?? "—"}</p>
      </td>
      <td className="px-3 py-3"><StatusBadge status={activity.status}/></td>
      <td className="px-3 py-3">
        {activity.gpsActive
          ? <span className="flex items-center gap-1 text-[10px] text-green-600 font-bold"><Wifi size={10}/> Live</span>
          : <span className="flex items-center gap-1 text-[10px] text-gray-400"><WifiOff size={10}/> Off</span>
        }
      </td>
      <td className="px-3 py-3">
        {activity.photoCount > 0
          ? <span className="flex items-center gap-1 text-[10px] text-blue-600 font-semibold"><Camera size={10}/> {activity.photoCount}</span>
          : <span className="text-[10px] text-gray-300">—</span>
        }
      </td>
      <td className="px-3 py-3">
        {activity.outcome
          ? <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${outcomeColors[activity.outcome]}`}>{outcomeLabels[activity.outcome]}</span>
          : <span className="text-[10px] text-gray-300">—</span>
        }
      </td>
      <td className="px-3 py-3">
        <ChevronRight size={13} className="text-gray-300 group-hover:text-blue-500 transition-colors"/>
      </td>
    </tr>
  );
}

// ══════════════════════════════════════════════════════════════════
// TIMELINE VIEW
// ══════════════════════════════════════════════════════════════════
function TimelineView({ activities, onSelect }: { activities: FieldActivity[]; onSelect: (a: FieldActivity) => void }) {
  const grouped: Record<string, FieldActivity[]> = {};
  activities.forEach(v => {
    if (!grouped[v.date]) grouped[v.date] = [];
    grouped[v.date].push(v);
  });
  const sortedDates = Object.keys(grouped).sort((a,b) => b.localeCompare(a));

  return (
    <div className="space-y-6">
      {sortedDates.map(date => (
        <div key={date}>
          <div className="flex items-center gap-3 mb-3">
            <div className="px-3 py-1.5 bg-gray-100 rounded-xl">
              <p className="text-xs font-bold text-gray-600">
                {new Date(date).toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
              </p>
            </div>
            <div className="flex-1 h-px bg-gray-100"/>
            <span className="text-[10px] text-gray-400">{grouped[date].length} activit{grouped[date].length>1?"ies":"y"}</span>
          </div>
          <div className="relative pl-8">
            <div className="absolute left-3.5 top-0 bottom-0 w-0.5 bg-gray-100"/>
            <div className="space-y-3">
              {grouped[date].map(act => {
                const repIdx = salesReps.findIndex(r => r.id === act.rep.id);
                return (
                  <div key={act.id} className="relative flex items-start gap-3">
                    <div className={`absolute -left-5 w-3 h-3 rounded-full border-2 border-white flex-shrink-0 mt-1.5 shadow ${statusDot[act.status]}`}/>
                    <div
                      className="bg-white border border-gray-100 rounded-xl p-3.5 flex-1 hover:shadow-sm hover:border-blue-200 transition-all cursor-pointer"
                      onClick={() => onSelect(act)}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5 flex-1 min-w-0">
                          <Avatar initials={act.rep.avatar} idx={repIdx} size="sm"/>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="text-xs font-bold text-gray-800">{act.rep.name}</p>
                              <ChevronRight size={10} className="text-gray-400"/>
                              <p className="text-xs font-semibold text-gray-600">{act.clientCompany}</p>
                            </div>
                            <p className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                              <MapPin size={8}/> {act.location} · {act.district}
                            </p>
                            {/* Activity type + priority */}
                            <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                              <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-md ${activityTypeColors[act.activityType]}`}>
                                {activityTypeLabels[act.activityType]}
                              </span>
                              <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-md capitalize ${priorityColors[act.priority]}`}>
                                {act.priority}
                              </span>
                              {act.gpsActive && (
                                <span className="flex items-center gap-0.5 text-[9px] font-bold text-green-700 bg-green-50 px-1.5 py-0.5 rounded-md">
                                  <Wifi size={7}/> GPS
                                </span>
                              )}
                              {act.photoCount > 0 && (
                                <span className="flex items-center gap-0.5 text-[9px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded-md">
                                  <Camera size={7}/> {act.photoCount}
                                </span>
                              )}
                            </div>
                            {act.notes && <p className="text-[10px] text-gray-500 mt-1.5 line-clamp-1">{act.notes}</p>}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                          <StatusBadge status={act.status}/>
                          <p className="text-[9px] text-gray-400">{act.checkIn ?? act.scheduledTime}</p>
                          {act.duration && <p className="text-[9px] text-gray-400">{Math.floor(act.duration/60)}h {act.duration%60}m</p>}
                        </div>
                      </div>
                      {act.outcome && act.outcome !== "pending" && act.outcome !== "" && (
                        <div className="mt-2 pt-2 border-t border-gray-50 flex items-center justify-between">
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${outcomeColors[act.outcome]}`}>
                            {outcomeLabels[act.outcome]}
                          </span>
                          <span className="text-[9px] text-blue-500 font-medium">View details →</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// MAIN PAGE
// ══════════════════════════════════════════════════════════════════
export function SalesPage() {
  const [tab, setTab]                     = useState<FieldTab>("overview");
  const [selectedActivity, setSelectedActivity] = useState<FieldActivity | null>(null);
  const [logOpen, setLogOpen]             = useState(false);
  const [search, setSearch]               = useState("");
  const [statusFilter, setStatusFilter]   = useState<ActivityStatus | "all">("all");
  const [typeFilter, setTypeFilter]       = useState<ActivityType | "all">("all");
  const [deptFilter, setDeptFilter]       = useState("all");
  const [branchFilter, setBranchFilter]   = useState("all");
  const [dateFrom, setDateFrom]           = useState("");
  const [dateTo, setDateTo]               = useState("");
  const [visits, setVisits]               = useState(allVisits);

  const handleStatusChange = (id: string, status: ActivityStatus) => {
    setVisits(prev => prev.map(v => v.id === id ? {...v, status} : v));
    setSelectedActivity(prev => prev?.id === id ? {...prev, status} : prev);
  };

  const filteredActivities = useMemo(() => {
    return visits.filter(v => {
      const q = search.toLowerCase();
      const matchSearch = !q
        || v.clientCompany.toLowerCase().includes(q)
        || v.rep.name.toLowerCase().includes(q)
        || v.location.toLowerCase().includes(q)
        || activityTypeLabels[v.activityType].toLowerCase().includes(q);
      const matchStatus = statusFilter === "all" || v.status === statusFilter;
      const matchType   = typeFilter   === "all" || v.activityType === typeFilter;
      const matchDept   = deptFilter   === "all" || v.rep.department === deptFilter;
      const matchBranch = branchFilter === "all" || v.rep.branch === branchFilter;
      const matchFrom   = !dateFrom || v.date >= dateFrom;
      const matchTo     = !dateTo   || v.date <= dateTo;
      return matchSearch && matchStatus && matchType && matchDept && matchBranch && matchFrom && matchTo;
    });
  }, [visits, search, statusFilter, typeFilter, deptFilter, branchFilter, dateFrom, dateTo]);

  const today = "2026-05-11";
  const todayActs      = visits.filter(v => v.date === today);
  const onField        = visits.filter(v => ["on_the_way","arrived","in_progress"].includes(v.status)).length;
  const activeActs     = visits.filter(v => ["on_the_way","arrived","in_progress"].includes(v.status)).length;
  const completedToday = todayActs.filter(v => v.status === "completed").length;
  const delayedActs    = visits.filter(v => v.status === "delayed").length;
  const gpsOff         = visits.filter(v => v.status === "gps_inactive").length;
  const pending        = visits.filter(v => v.status === "assigned").length;
  const completionRate = Math.round((visits.filter(v => v.status === "completed").length / visits.length) * 100);
  const avgDuration    = Math.round(visits.filter(v => v.duration).reduce((s,v) => s+(v.duration??0),0) / visits.filter(v=>v.duration).length);

  const tabs: { id: FieldTab; label: string; badge?: number }[] = [
    { id: "overview",      label: "Overview" },
    { id: "activity-log",  label: "Activity Log",  badge: filteredActivities.length },
    { id: "timeline",      label: "Timeline" },
  ];

  const departments = ["all", ...Array.from(new Set(salesReps.map(r => r.department)))];
  const branches    = ["all", ...Array.from(new Set(salesReps.map(r => r.branch)))];
  const actTypes    = ["all", ...Object.keys(activityTypeLabels)] as (ActivityType | "all")[];

  return (
    <main className="flex-1 overflow-y-auto px-6 py-5 space-y-5">

      {/* PAGE HEADER */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Field Activity & Client Visits</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Assign, track, and monitor employees on field duty — real-time GPS & activity visibility
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setLogOpen(true)}
            className="flex items-center gap-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2.5 rounded-xl transition-colors cursor-pointer shadow-sm">
            <Plus size={14}/> Assign Field Activity
          </button>
        </div>
      </div>

      {/* TABS */}
      <div className="flex items-center gap-0 border-b border-gray-200">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              tab === t.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            {t.label}
            {t.badge !== undefined && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                tab === t.id ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"
              }`}>{t.badge}</span>
            )}
          </button>
        ))}
      </div>

      {/* ══════════════ OVERVIEW ══════════════ */}
      {tab === "overview" && (
        <>
          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            <KpiCard label="On Field Now"      value={String(onField)}        trend="+2"  trendType="up"      sparkData={[2,3,4,3,5,4,onField]}         sparkColor="#3b82f6"  icon={<Navigation size={12}/>}   iconBg="bg-blue-50 text-blue-600"/>
            <KpiCard label="Active Activities" value={String(activeActs)}     trend="+1"  trendType="up"      sparkData={[1,2,2,3,3,2,activeActs]}      sparkColor="#06b6d4"  icon={<Activity size={12}/>}     iconBg="bg-cyan-50 text-cyan-600"/>
            <KpiCard label="Completed Today"   value={String(completedToday)} trend="+1"  trendType="up"      sparkData={[3,4,5,4,5,6,completedToday]}  sparkColor="#10b981"  icon={<CheckCircle size={12}/>}  iconBg="bg-green-50 text-green-600"/>
            <KpiCard label="Delayed"           value={String(delayedActs)}    trend="—"   trendType="neutral" sparkData={[1,0,2,1,2,1,delayedActs]}     sparkColor="#f97316"  icon={<Clock size={12}/>}        iconBg="bg-orange-50 text-orange-600"/>
            <KpiCard label="GPS Inactive"      value={String(gpsOff)}         trend="—"   trendType="neutral" sparkData={[0,1,0,0,1,0,gpsOff]}          sparkColor="#f43f5e"  icon={<WifiOff size={12}/>}      iconBg="bg-rose-50 text-rose-600"/>
            <KpiCard label="Pending Assign."   value={String(pending)}        trend="-1"  trendType="down"    sparkData={[4,3,4,5,4,3,pending]}         sparkColor="#8b5cf6"  icon={<Calendar size={12}/>}     iconBg="bg-purple-50 text-purple-600"/>
            <KpiCard label="Completion Rate"   value={`${completionRate}%`}   trend="+4%" trendType="up"      sparkData={[74,76,78,79,80,81,completionRate]} sparkColor="#6366f1" icon={<Target size={12}/>}      iconBg="bg-indigo-50 text-indigo-600"/>
            <KpiCard label="Avg Duration"      value={`${avgDuration}m`}      trend="-5m" trendType="up"      sparkData={[88,85,82,80,79,78,avgDuration]} sparkColor="#f59e0b" icon={<Zap size={12}/>}          iconBg="bg-amber-50 text-amber-600"/>
          </div>

          {/* Real-Time Field Map */}
          <RealTimeFieldMap onSelect={act => { setSelectedActivity(act); }}/>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className={`${cardClass} lg:col-span-2`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Weekly Field Activity</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Mon–Fri this week · by status</p>
                </div>
                <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><MoreHorizontal size={15}/></button>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={weeklyActivity} barSize={20} barGap={3}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false}/>
                  <XAxis dataKey="day" tick={{fontSize:11,fill:"#9ca3af"}} axisLine={false} tickLine={false}/>
                  <YAxis tick={{fontSize:10,fill:"#9ca3af"}} axisLine={false} tickLine={false} width={22}/>
                  <Tooltip {...tooltipStyle}/>
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{fontSize:"11px",paddingTop:"10px"}}/>
                  <Bar dataKey="completed" name="Completed" fill="#10b981" radius={[4,4,0,0]} stackId="a"/>
                  <Bar dataKey="ongoing"   name="Active"    fill="#f59e0b" radius={[0,0,0,0]} stackId="a"/>
                  <Bar dataKey="assigned"  name="Assigned"  fill="#3b82f6" radius={[4,4,0,0]} stackId="a"/>
                  <Bar dataKey="missed"    name="Missed"    fill="#ef4444" radius={[0,0,0,0]} stackId="a"/>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className={cardClass}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Activity Trend</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Past 7 months</p>
                </div>
                <button className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 cursor-pointer"><MoreHorizontal size={15}/></button>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={monthlyVisitTrend}>
                  <defs>
                    <linearGradient id="faGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false}/>
                  <XAxis dataKey="month" tick={{fontSize:11,fill:"#9ca3af"}} axisLine={false} tickLine={false}/>
                  <YAxis tick={{fontSize:10,fill:"#9ca3af"}} axisLine={false} tickLine={false} width={26}/>
                  <Tooltip {...tooltipStyle}/>
                  <Area type="monotone" dataKey="total" name="Total" stroke="#3b82f6" strokeWidth={2} fill="url(#faGrad)" dot={{r:3,fill:"#3b82f6"}}/>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Performers + Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className={`${cardClass} lg:col-span-2`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Top Field Performers</h3>
                  <p className="text-xs text-gray-400 mt-0.5">This month · ranked by completed activities</p>
                </div>
                <button onClick={() => setTab("activity-log")} className="text-[10px] text-blue-600 hover:text-blue-800 font-medium cursor-pointer">
                  View all →
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-100">
                      {["#","Employee","Dept","Total","Done","Active","Missed","Rate"].map(h => (
                        <th key={h} className="pb-2.5 pr-3 text-left">
                          <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{h}</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {topPerformers.map((p, i) => (
                      <tr key={p.rep.id} className="border-b border-gray-50 hover:bg-gray-50/60 transition-colors">
                        <td className="py-3 pr-3">
                          {i === 0 ? <Star size={13} className="text-amber-500" fill="#f59e0b"/> : <span className="text-xs text-gray-400">{i+1}</span>}
                        </td>
                        <td className="py-3 pr-3">
                          <div className="flex items-center gap-2">
                            <Avatar initials={p.rep.avatar} idx={i} size="sm"/>
                            <div>
                              <p className="text-xs font-semibold text-gray-800">{p.rep.name}</p>
                              <p className="text-[9px] text-gray-400">{p.rep.branch}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 pr-3 text-[10px] text-gray-500">{p.rep.department}</td>
                        <td className="py-3 pr-3 text-xs font-bold text-gray-700">{p.total}</td>
                        <td className="py-3 pr-3 text-xs font-bold text-green-600">{p.completed}</td>
                        <td className="py-3 pr-3 text-xs font-semibold text-amber-600">{p.ongoing}</td>
                        <td className="py-3 pr-3 text-xs font-semibold text-red-500">{p.missed}</td>
                        <td className="py-3">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className="h-full rounded-full bg-green-500" style={{width:`${p.completionRate}%`}}/>
                            </div>
                            <span className={`text-xs font-bold ${p.completionRate >= 80 ? "text-green-600" : "text-yellow-600"}`}>
                              {p.completionRate}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Alerts */}
            <div className={cardClass}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Alerts & Monitoring</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Action required</p>
                </div>
                <span className="text-[10px] font-bold bg-red-50 text-red-600 px-2 py-0.5 rounded-full">
                  {fieldAlerts.filter(a => a.type === "alert").length} urgent
                </span>
              </div>
              <div className="space-y-2.5">
                {fieldAlerts.map((alert, i) => (
                  <div key={i} className={`flex items-start gap-2.5 px-3 py-2.5 rounded-xl border ${
                    alert.type === "success" ? "bg-green-50 border-green-100" :
                    alert.type === "alert"   ? "bg-red-50 border-red-100" :
                    alert.type === "warning" ? "bg-amber-50 border-amber-100" : "bg-blue-50 border-blue-100"
                  }`}>
                    <div className="mt-0.5 flex-shrink-0">
                      {alert.type === "success" ? <CheckCircle size={12} className="text-green-500"/>
                       : alert.type === "alert"  ? <AlertTriangle size={12} className="text-red-500"/>
                       : alert.type === "warning"? <Clock size={12} className="text-amber-500"/>
                       : <AlertCircle size={12} className="text-blue-500"/>}
                    </div>
                    <div>
                      <p className="text-[11px] font-semibold text-gray-800 leading-tight">{alert.msg}</p>
                      <p className="text-[9px] text-gray-500 mt-0.5">{alert.sub}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* ══════════════ ACTIVITY LOG ══════════════ */}
      {tab === "activity-log" && (
        <div className={cardClass}>
          {/* Filters */}
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 min-w-44">
              <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Search by employee, client, location…"
                className="w-full text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded-xl pl-8 pr-3 py-2.5 outline-none focus:border-blue-400 placeholder:text-gray-400"/>
            </div>
            {/* Status */}
            <div className="relative">
              <Filter size={10} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"/>
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as ActivityStatus | "all")}
                className="text-xs bg-white border border-gray-200 pl-7 pr-7 py-2.5 rounded-xl outline-none appearance-none cursor-pointer focus:border-blue-400 text-gray-600">
                <option value="all">All Statuses</option>
                {(Object.keys(statusLabels) as ActivityStatus[]).map(s => <option key={s} value={s}>{statusLabels[s]}</option>)}
              </select>
              <ChevronDown size={10} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
            </div>
            {/* Activity type */}
            <div className="relative">
              <select value={typeFilter} onChange={e => setTypeFilter(e.target.value as ActivityType | "all")}
                className="text-xs bg-white border border-gray-200 px-3 py-2.5 rounded-xl outline-none appearance-none cursor-pointer focus:border-blue-400 text-gray-600 pr-7">
                <option value="all">All Types</option>
                {(Object.keys(activityTypeLabels) as ActivityType[]).map(t => <option key={t} value={t}>{activityTypeLabels[t]}</option>)}
              </select>
              <ChevronDown size={10} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
            </div>
            {/* Department */}
            <div className="relative">
              <Users size={10} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"/>
              <select value={deptFilter} onChange={e => setDeptFilter(e.target.value)}
                className="text-xs bg-white border border-gray-200 pl-7 pr-7 py-2.5 rounded-xl outline-none appearance-none cursor-pointer focus:border-blue-400 text-gray-600">
                {departments.map(d => <option key={d} value={d}>{d === "all" ? "All Departments" : d}</option>)}
              </select>
              <ChevronDown size={10} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
            </div>
            {/* Branch */}
            <div className="relative">
              <MapPin size={10} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"/>
              <select value={branchFilter} onChange={e => setBranchFilter(e.target.value)}
                className="text-xs bg-white border border-gray-200 pl-7 pr-7 py-2.5 rounded-xl outline-none appearance-none cursor-pointer focus:border-blue-400 text-gray-600">
                {branches.map(b => <option key={b} value={b}>{b === "all" ? "All Branches" : b}</option>)}
              </select>
              <ChevronDown size={10} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
            </div>
            {/* Date range */}
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 text-gray-700 cursor-pointer"/>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 outline-none focus:border-blue-400 text-gray-700 cursor-pointer"/>
            <span className="text-xs text-gray-400 whitespace-nowrap">{filteredActivities.length} records</span>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1200px]">
              <thead>
                <tr className="border-b border-gray-100">
                  {["Employee","Type","Client / Company","Location","Assigned By","Date","Check-in","Check-out","Status","GPS","Photos","Outcome",""].map(h => (
                    <th key={h} className="pb-3 px-3 text-left">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{h}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredActivities.map(act => {
                  const repIdx = salesReps.findIndex(r => r.id === act.rep.id);
                  return (
                    <ActivityRow key={act.id} activity={act} repIdx={repIdx}
                      onClick={() => setSelectedActivity(act)}/>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ══════════════ TIMELINE ══════════════ */}
      {tab === "timeline" && (
        <>
          {/* Rep filter */}
          <div className="flex items-center gap-2 flex-wrap">
            {salesReps.map((rep, i) => (
              <button key={rep.id}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50 transition-all cursor-pointer text-xs font-medium text-gray-600">
                <Avatar initials={rep.avatar} idx={i} size="sm"/>
                {rep.name.split(" ")[0]}
              </button>
            ))}
          </div>
          <TimelineView activities={visits} onSelect={act => setSelectedActivity(act)}/>
        </>
      )}

      {/* Detail Drawer */}
      {selectedActivity && (
        <VisitDetailDrawer
          activity={selectedActivity}
          repIdx={salesReps.findIndex(r => r.id === selectedActivity.rep.id)}
          onClose={() => setSelectedActivity(null)}
          onStatusChange={handleStatusChange}
        />
      )}

      {/* Assign Activity Modal */}
      <LogVisitModal
        isOpen={logOpen}
        onClose={() => setLogOpen(false)}
        onAssign={() => setLogOpen(false)}
      />
    </main>
  );
}
