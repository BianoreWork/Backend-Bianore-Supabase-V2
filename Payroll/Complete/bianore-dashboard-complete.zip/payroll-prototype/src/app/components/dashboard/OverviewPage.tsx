import { CalendarDays, RefreshCw, ArrowRight } from "lucide-react";
import { motion } from "motion/react";
import { KPICards } from "./KPICards";
import { AlertsSection } from "./AlertsSection";
import {
  AttendanceByDeptChart,
  AttendanceTrendChart,
  PayrollBreakdownChart,
  OvertimeTrendChart,
} from "./ChartsSection";
import { ActivityFeed } from "./ActivityFeed";
import { AttendanceTable } from "./AttendanceTable";

interface OverviewPageProps {
  onKpiClick: (filterId: string, filterStatus: string | null) => void;
  onViewAllLogs: () => void;
}

const EASE = [0.22, 1, 0.36, 1] as const;

// Section wrapper — fade up with a configurable delay
function Section({ children, delay = 0, className = "" }: {
  children: React.ReactNode; delay?: number; className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.48, delay, ease: EASE }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function OverviewPage({ onKpiClick, onViewAllLogs }: OverviewPageProps) {
  return (
    <main className="flex-1 overflow-y-auto px-6 py-5 space-y-5">

      {/* Page Title */}
      <Section delay={0.13}>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl font-bold text-gray-900">
              Attendance &amp; Payroll Dashboard
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Monitor employee activity, payroll insights, and real-time attendance
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg">
              <CalendarDays size={13} className="text-gray-400" />
              <span>Thursday, Apr 30, 2026</span>
            </div>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 bg-white border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
              <RefreshCw size={13} className="text-gray-400" />
              Refresh
            </button>
          </div>
        </div>
      </Section>

      {/* KPI Cards — each card has its own stagger via KPICards */}
      <KPICards onKpiClick={onKpiClick} />

      {/* Alerts + Activity */}
      <Section delay={0.55}>
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2">
            <AlertsSection />
          </div>
          <div className="xl:col-span-1 min-h-[300px]">
            <ActivityFeed />
          </div>
        </div>
      </Section>

      {/* Primary Charts */}
      <Section delay={0.63}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <AttendanceByDeptChart />
          <AttendanceTrendChart />
        </div>
      </Section>

      {/* Secondary Charts */}
      <Section delay={0.70}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <PayrollBreakdownChart />
          <OvertimeTrendChart />
        </div>
      </Section>

      {/* Attendance Preview Table */}
      <Section delay={0.77}>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div>
              <h3 className="text-sm font-semibold text-gray-800">Recent Attendance Logs</h3>
              <p className="text-xs text-gray-400 mt-0.5">Latest 5 records · Today</p>
            </div>
            <button
              onClick={onViewAllLogs}
              className="flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-800 font-medium transition-colors cursor-pointer"
            >
              View all logs <ArrowRight size={13} />
            </button>
          </div>
          <AttendanceTable previewMode />
        </div>
      </Section>

      <div className="h-4" />
    </main>
  );
}
