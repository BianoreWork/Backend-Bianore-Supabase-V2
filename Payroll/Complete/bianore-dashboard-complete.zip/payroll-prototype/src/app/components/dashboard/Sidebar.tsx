import { useState } from "react";
import { Filter, ChevronDown, X } from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const departments = ["Engineering", "Sales", "HR", "Finance", "Marketing", "Operations"];
const locations = ["HQ - Downtown", "Branch A - Eastside", "Branch B - Westside", "Remote"];
const statuses = ["Present", "Late", "Absent"];

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [dateFilter, setDateFilter] = useState("today");
  const [selectedDepts, setSelectedDepts] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [deptOpen, setDeptOpen] = useState(true);
  const [locOpen, setLocOpen] = useState(true);
  const [statusOpen, setStatusOpen] = useState(true);

  const toggleItem = (
    list: string[],
    setList: (v: string[]) => void,
    item: string
  ) => {
    setList(list.includes(item) ? list.filter((i) => i !== item) : [...list, item]);
  };

  const clearAll = () => {
    setSelectedDepts([]);
    setSelectedLocations([]);
    setSelectedStatuses([]);
    setDateFilter("today");
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          fixed lg:relative top-0 left-0 h-full z-40 lg:z-auto
          bg-white border-r border-gray-100 flex flex-col flex-shrink-0
          transition-all duration-300 overflow-hidden
          ${isOpen
            ? "w-64 translate-x-0"
            : "w-64 -translate-x-full lg:translate-x-0 lg:w-0 lg:border-r-0"
          }
        `}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Filter size={15} className="text-blue-600" />
            <span className="text-sm font-semibold text-gray-800">Filters</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={clearAll}
              className="text-xs text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
            >
              Clear all
            </button>
            <button onClick={onClose} className="lg:hidden text-gray-400 hover:text-gray-600 cursor-pointer">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5">
          {/* Date Range */}
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Date Range</p>
            <div className="flex flex-col gap-1">
              {[
                { id: "today", label: "Today" },
                { id: "week", label: "This Week" },
                { id: "month", label: "This Month" },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setDateFilter(opt.id)}
                  className={`text-left text-sm px-3 py-2 rounded-lg transition-all cursor-pointer ${
                    dateFilter === opt.id
                      ? "bg-blue-50 text-blue-700 font-semibold"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="h-px bg-gray-100" />

          {/* Department */}
          <div>
            <button
              onClick={() => setDeptOpen(!deptOpen)}
              className="flex items-center justify-between w-full mb-2 cursor-pointer"
            >
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Department</p>
              <ChevronDown
                size={14}
                className={`text-gray-400 transition-transform ${deptOpen ? "rotate-180" : ""}`}
              />
            </button>
            {deptOpen && (
              <div className="space-y-1">
                {departments.map((dept) => (
                  <label
                    key={dept}
                    className="flex items-center gap-2.5 px-1 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer group"
                  >
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center border transition-all ${
                        selectedDepts.includes(dept)
                          ? "bg-blue-600 border-blue-600"
                          : "border-gray-300 group-hover:border-blue-400"
                      }`}
                      onClick={() => toggleItem(selectedDepts, setSelectedDepts, dept)}
                    >
                      {selectedDepts.includes(dept) && (
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                          <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      )}
                    </div>
                    <span
                      className="text-sm text-gray-700"
                      onClick={() => toggleItem(selectedDepts, setSelectedDepts, dept)}
                    >
                      {dept}
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>

          <div className="h-px bg-gray-100" />

          {/* Location */}
          <div>
            <button
              onClick={() => setLocOpen(!locOpen)}
              className="flex items-center justify-between w-full mb-2 cursor-pointer"
            >
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Location</p>
              <ChevronDown
                size={14}
                className={`text-gray-400 transition-transform ${locOpen ? "rotate-180" : ""}`}
              />
            </button>
            {locOpen && (
              <div className="space-y-1">
                {locations.map((loc) => (
                  <label
                    key={loc}
                    className="flex items-center gap-2.5 px-1 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer group"
                  >
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center border transition-all flex-shrink-0 ${
                        selectedLocations.includes(loc)
                          ? "bg-blue-600 border-blue-600"
                          : "border-gray-300 group-hover:border-blue-400"
                      }`}
                      onClick={() => toggleItem(selectedLocations, setSelectedLocations, loc)}
                    >
                      {selectedLocations.includes(loc) && (
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                          <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      )}
                    </div>
                    <span
                      className="text-xs text-gray-700 leading-tight"
                      onClick={() => toggleItem(selectedLocations, setSelectedLocations, loc)}
                    >
                      {loc}
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>

          <div className="h-px bg-gray-100" />

          {/* Employee Status */}
          <div>
            <button
              onClick={() => setStatusOpen(!statusOpen)}
              className="flex items-center justify-between w-full mb-2 cursor-pointer"
            >
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Employee Status</p>
              <ChevronDown
                size={14}
                className={`text-gray-400 transition-transform ${statusOpen ? "rotate-180" : ""}`}
              />
            </button>
            {statusOpen && (
              <div className="space-y-1">
                {statuses.map((status) => {
                  const colors: Record<string, string> = {
                    Present: "bg-green-500",
                    Late: "bg-yellow-500",
                    Absent: "bg-red-500",
                  };
                  return (
                    <label
                      key={status}
                      className="flex items-center gap-2.5 px-1 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer group"
                    >
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border transition-all ${
                          selectedStatuses.includes(status)
                            ? "bg-blue-600 border-blue-600"
                            : "border-gray-300 group-hover:border-blue-400"
                        }`}
                        onClick={() => toggleItem(selectedStatuses, setSelectedStatuses, status)}
                      >
                        {selectedStatuses.includes(status) && (
                          <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                            <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        )}
                      </div>
                      <div className="flex items-center gap-2" onClick={() => toggleItem(selectedStatuses, setSelectedStatuses, status)}>
                        <div className={`w-2 h-2 rounded-full ${colors[status]}`} />
                        <span className="text-sm text-gray-700">{status}</span>
                      </div>
                    </label>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Apply Button */}
        <div className="px-4 py-4 border-t border-gray-100">
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm py-2.5 rounded-xl transition-colors cursor-pointer font-medium">
            Apply Filters
          </button>
        </div>
      </aside>
    </>
  );
}