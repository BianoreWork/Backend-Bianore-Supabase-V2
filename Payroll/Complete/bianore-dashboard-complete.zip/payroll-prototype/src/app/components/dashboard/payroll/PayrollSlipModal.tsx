import { X, Download, Mail, Printer, CheckCircle, LayoutDashboard } from "lucide-react";
import type { PayrollRecord } from "./payrollData";

interface PayrollSlipModalProps {
  isOpen: boolean;
  employee: PayrollRecord | null;
  onClose: () => void;
}

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

const deptColors: Record<string, string> = {
  Engineering: "bg-blue-50 text-blue-700",
  Marketing: "bg-pink-50 text-pink-700",
  Finance: "bg-cyan-50 text-cyan-700",
  HR: "bg-purple-50 text-purple-700",
  Operations: "bg-orange-50 text-orange-700",
  Sales: "bg-green-50 text-green-700",
};

export function PayrollSlipModal({ isOpen, employee, onClose }: PayrollSlipModalProps) {
  if (!isOpen || !employee) return null;

  const earnings = [
    { label: "Base Salary", amount: employee.baseSalary },
    { label: "Position Allowance", amount: employee.positionAllowance },
    { label: "Transport Allowance", amount: employee.transportAllowance },
    { label: "Meal Allowance", amount: employee.mealAllowance },
    ...(employee.overtime > 0 ? [{ label: `Overtime (${employee.overtimeHours}h)`, amount: employee.overtime }] : []),
    ...(employee.bonus > 0 ? [{ label: "Bonus / Incentive", amount: employee.bonus }] : []),
    ...(employee.reimbursements > 0 ? [{ label: "Reimbursements", amount: employee.reimbursements }] : []),
  ];

  const deductions = [
    ...(employee.lateDeduction > 0 ? [{ label: "Late Penalty", amount: employee.lateDeduction }] : []),
    ...(employee.absenceDeduction > 0 ? [{ label: "Absence Deduction", amount: employee.absenceDeduction }] : []),
    ...(employee.loanDeduction > 0 ? [{ label: "Loan Repayment", amount: employee.loanDeduction }] : []),
    { label: "PPh 21 Tax", amount: employee.tax },
    { label: "BPJS Health", amount: employee.bpjsHealth },
    { label: "BPJS Employment", amount: employee.bpjsEmployment },
  ];

  const dc = deptColors[employee.dept] || "bg-gray-50 text-gray-600";

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <div
          className="bg-white rounded-2xl shadow-2xl w-full max-w-[520px] max-h-[90vh] overflow-hidden flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard size={13} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-900">Pay Slip</p>
                <p className="text-[10px] text-gray-400">{employee.payPeriod}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer">
                <Printer size={12} /> Print
              </button>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer">
                <Mail size={12} /> Email
              </button>
              <button className="flex items-center gap-1.5 text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
                <Download size={12} /> PDF
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer ml-1"
              >
                <X size={15} />
              </button>
            </div>
          </div>

          {/* Payslip Content */}
          <div className="flex-1 overflow-y-auto">
            {/* Company + Employee Header */}
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 px-6 py-5 text-white">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-semibold opacity-70 uppercase tracking-wider mb-1">WorkForce HRIS</p>
                  <p className="text-lg font-bold">PAYSLIP</p>
                  <p className="text-xs opacity-80 mt-0.5">{employee.payPeriod} · {employee.payPeriod === "April 2026" ? "Apr 1 – Apr 30, 2026" : ""}</p>
                </div>
                <div className="text-right">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-white font-bold text-sm ml-auto">
                    {employee.avatar}
                  </div>
                  <p className="text-sm font-bold mt-1.5">{employee.name}</p>
                  <p className="text-[10px] opacity-80">{employee.position}</p>
                  <span className={`text-[9px] font-semibold mt-0.5 inline-block px-1.5 py-0.5 rounded bg-white/20`}>
                    {employee.dept}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-white/20">
                <div>
                  <p className="text-[9px] opacity-60 uppercase tracking-wider">Employee ID</p>
                  <p className="text-xs font-semibold mt-0.5">EMP{String(employee.id).padStart(4, "0")}</p>
                </div>
                <div>
                  <p className="text-[9px] opacity-60 uppercase tracking-wider">Bank</p>
                  <p className="text-xs font-semibold mt-0.5">{employee.bankName}</p>
                </div>
                <div>
                  <p className="text-[9px] opacity-60 uppercase tracking-wider">Account</p>
                  <p className="text-xs font-semibold mt-0.5">{employee.bankAccount}</p>
                </div>
              </div>
            </div>

            <div className="px-6 py-5 space-y-4">
              {/* Earnings Table */}
              <div>
                <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-2">Earnings</p>
                <div className="rounded-xl overflow-hidden border border-gray-100">
                  {earnings.map((row, i) => (
                    <div
                      key={row.label}
                      className={`flex items-center justify-between px-4 py-2.5 ${i % 2 === 0 ? "bg-white" : "bg-gray-50/50"}`}
                    >
                      <span className="text-xs text-gray-600">{row.label}</span>
                      <span className="text-xs font-semibold text-gray-800">{fmt(row.amount)}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between px-4 py-2.5 bg-blue-50 border-t border-blue-100">
                    <span className="text-xs font-bold text-blue-800">Total Earnings</span>
                    <span className="text-xs font-bold text-blue-800">{fmt(employee.totalEarnings)}</span>
                  </div>
                </div>
              </div>

              {/* Deductions Table */}
              <div>
                <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-2">Deductions</p>
                <div className="rounded-xl overflow-hidden border border-gray-100">
                  {deductions.map((row, i) => (
                    <div
                      key={row.label}
                      className={`flex items-center justify-between px-4 py-2.5 ${i % 2 === 0 ? "bg-white" : "bg-gray-50/50"}`}
                    >
                      <span className="text-xs text-gray-600">{row.label}</span>
                      <span className="text-xs font-semibold text-red-600">({fmt(row.amount)})</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between px-4 py-2.5 bg-red-50 border-t border-red-100">
                    <span className="text-xs font-bold text-red-700">Total Deductions</span>
                    <span className="text-xs font-bold text-red-700">({fmt(employee.totalDeductions)})</span>
                  </div>
                </div>
              </div>

              {/* Net Salary */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl px-5 py-4 flex items-center justify-between">
                <div>
                  <p className="text-xs text-blue-100 font-medium">NET SALARY</p>
                  <p className="text-[10px] text-blue-200 mt-0.5">After all deductions & taxes</p>
                </div>
                <p className="text-2xl font-bold text-white tracking-tight">
                  {fmt(employee.netSalary)}
                </p>
              </div>

              {/* Status */}
              <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 rounded-xl">
                <CheckCircle size={14} className="text-green-500" />
                <div>
                  <p className="text-xs font-semibold text-gray-800">
                    {employee.status === "paid" ? "Payment Disbursed" : employee.status === "approved" ? "Approved — Pending Disbursement" : "Awaiting Approval"}
                  </p>
                  <p className="text-[10px] text-gray-400 mt-0.5">
                    Generated by WorkForce HRIS · {employee.payPeriod}
                  </p>
                </div>
              </div>

              {/* Footer note */}
              <p className="text-[10px] text-gray-400 text-center pb-2">
                This payslip is system-generated and does not require a physical signature.
                <br />
                For inquiries, contact hr@workforce.app
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
