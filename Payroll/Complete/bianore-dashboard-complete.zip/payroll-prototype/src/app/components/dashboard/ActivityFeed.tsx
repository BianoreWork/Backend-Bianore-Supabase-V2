import {
  LogIn,
  Clock,
  LogOut,
  AlertTriangle,
  Zap,
  MapPin,
  ChevronRight,
} from "lucide-react";
import { activityFeed } from "./mockData";

const iconMap: Record<string, React.ReactNode> = {
  login: <LogIn size={13} />,
  clock: <Clock size={13} />,
  logout: <LogOut size={13} />,
  alert: <AlertTriangle size={13} />,
  zap: <Zap size={13} />,
  "map-pin": <MapPin size={13} />,
};

const statusConfig: Record<
  string,
  { dot: string; iconBg: string; iconColor: string; label: string; labelColor: string }
> = {
  present: {
    dot: "bg-green-500",
    iconBg: "bg-green-50",
    iconColor: "text-green-600",
    label: "Check-in",
    labelColor: "text-green-600",
  },
  late: {
    dot: "bg-yellow-500",
    iconBg: "bg-yellow-50",
    iconColor: "text-yellow-600",
    label: "Late",
    labelColor: "text-yellow-600",
  },
  alert: {
    dot: "bg-red-500",
    iconBg: "bg-red-50",
    iconColor: "text-red-600",
    label: "Alert",
    labelColor: "text-red-600",
  },
  overtime: {
    dot: "bg-purple-500",
    iconBg: "bg-purple-50",
    iconColor: "text-purple-600",
    label: "Overtime",
    labelColor: "text-purple-600",
  },
  out: {
    dot: "bg-gray-400",
    iconBg: "bg-gray-100",
    iconColor: "text-gray-500",
    label: "Check-out",
    labelColor: "text-gray-500",
  },
};

export function ActivityFeed() {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <h3 className="text-sm font-semibold text-gray-800">Live Activity</h3>
        </div>
        <button className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-0.5 transition-colors cursor-pointer">
          View all <ChevronRight size={12} />
        </button>
      </div>

      {/* Feed Items */}
      <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
        {activityFeed.map((item) => {
          const config = statusConfig[item.status];
          return (
            <div
              key={item.id}
              className="flex items-start gap-3 px-5 py-3.5 hover:bg-gray-50 transition-colors cursor-pointer"
            >
              {/* Icon */}
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${config.iconBg} ${config.iconColor}`}
              >
                {iconMap[item.icon]}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <p className="text-xs font-semibold text-gray-800">{item.name}</p>
                  <span className={`text-[10px] font-semibold ${config.labelColor}`}>
                    • {config.label}
                  </span>
                </div>
                <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed truncate">
                  {item.action}
                </p>
                <p className="text-[10px] text-gray-400 mt-0.5">{item.dept}</p>
              </div>

              {/* Time */}
              <div className="flex-shrink-0 text-right">
                <p className="text-[10px] text-gray-400 whitespace-nowrap">{item.time}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="px-5 py-3 border-t border-gray-100">
        <p className="text-[10px] text-gray-400 text-center">Updated just now · Auto-refreshes every 30s</p>
      </div>
    </div>
  );
}
