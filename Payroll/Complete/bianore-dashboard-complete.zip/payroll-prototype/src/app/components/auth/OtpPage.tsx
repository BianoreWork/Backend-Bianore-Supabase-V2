import { useState, useRef, useEffect, useCallback } from "react";
import { ArrowLeft, LayoutDashboard, ShieldCheck, RotateCcw } from "lucide-react";
import { roleConfig, type AuthUser } from "./authData";

interface OtpPageProps {
  user: AuthUser;
  onVerified: () => void;
  onBack: () => void;
}

const OTP_LENGTH = 6;
const VALID_OTP  = "123456"; // demo
const RESEND_SEC = 60;

const maskEmail = (email: string) => {
  const [user, domain] = email.split("@");
  return user.slice(0, 2) + "·".repeat(Math.max(user.length - 2, 3)) + "@" + domain;
};

export function OtpPage({ user, onVerified, onBack }: OtpPageProps) {
  const [digits, setDigits]     = useState<string[]>(Array(OTP_LENGTH).fill(""));
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [verified, setVerified] = useState(false);
  const [countdown, setCountdown] = useState(RESEND_SEC);
  const [resendSent, setResendSent] = useState(false);

  const inputRefs = useRef<(HTMLInputElement | null)[]>(Array(OTP_LENGTH).fill(null));

  // Focus first input on mount
  useEffect(() => { inputRefs.current[0]?.focus(); }, []);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) return;
    const id = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(id);
  }, [countdown]);

  const focusAt = (idx: number) => inputRefs.current[Math.max(0, Math.min(idx, OTP_LENGTH - 1))]?.focus();

  const handleChange = (idx: number, val: string) => {
    // Only accept single digit
    const digit = val.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[idx] = digit;
    setDigits(next);
    setError("");
    if (digit && idx < OTP_LENGTH - 1) focusAt(idx + 1);
  };

  const handleKeyDown = (idx: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      e.preventDefault();
      if (digits[idx]) {
        const next = [...digits]; next[idx] = ""; setDigits(next);
      } else {
        focusAt(idx - 1);
      }
    } else if (e.key === "ArrowLeft")  { e.preventDefault(); focusAt(idx - 1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); focusAt(idx + 1); }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, OTP_LENGTH);
    const next = Array(OTP_LENGTH).fill("");
    for (let i = 0; i < pasted.length; i++) next[i] = pasted[i];
    setDigits(next);
    setError("");
    focusAt(Math.min(pasted.length, OTP_LENGTH - 1));
  };

  const handleVerify = useCallback(async () => {
    const entered = digits.join("");
    if (entered.length < OTP_LENGTH) {
      setError("Please enter all 6 digits.");
      focusAt(digits.findIndex(d => !d));
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 900));

    if (entered === VALID_OTP) {
      setVerified(true);
      await new Promise(r => setTimeout(r, 700));
      onVerified();
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setError(
        newAttempts >= 3
          ? "Too many incorrect attempts. Please request a new code."
          : `Incorrect code. ${3 - newAttempts} attempt${3 - newAttempts === 1 ? "" : "s"} remaining.`
      );
      setDigits(Array(OTP_LENGTH).fill(""));
      focusAt(0);
    }
    setLoading(false);
  }, [digits, attempts, onVerified]);

  // Auto-submit when all digits filled
  useEffect(() => {
    if (digits.every(d => d) && !loading && !verified) {
      handleVerify();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [digits]);

  const handleResend = () => {
    if (countdown > 0) return;
    setDigits(Array(OTP_LENGTH).fill(""));
    setError("");
    setAttempts(0);
    setCountdown(RESEND_SEC);
    setResendSent(true);
    setTimeout(() => setResendSent(false), 3000);
    focusAt(0);
  };

  const rc = roleConfig[user.role];
  const filled = digits.filter(Boolean).length;

  return (
    <div
      className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4 py-10"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Top nav bar */}
      <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-6 h-[56px] bg-white border-b border-gray-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center">
            <LayoutDashboard size={14} className="text-white"/>
          </div>
          <div>
            <p className="text-sm font-bold text-gray-900">WorkForce</p>
            <p className="text-[10px] text-gray-400">HRIS Platform</p>
          </div>
        </div>
        <button onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 hover:text-gray-700 cursor-pointer transition-colors">
          <ArrowLeft size={14}/> Back to login
        </button>
      </div>

      {/* Main card */}
      <div className="w-full max-w-[420px] mt-14">
        <div className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">

          {/* Card header band */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-8 pt-8 pb-10 text-center relative overflow-hidden">
            <div className="absolute inset-0" style={{
              backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.05) 1px, transparent 1px)",
              backgroundSize: "20px 20px",
            }}/>
            <div className="relative z-10">
              {/* User avatar */}
              <div className="relative inline-block mb-3">
                <div className={`w-16 h-16 ${rc.avatarBg} rounded-2xl flex items-center justify-center text-white text-xl font-bold shadow-lg mx-auto`}>
                  {user.avatar}
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow">
                  <div className={`w-3 h-3 rounded-full ${rc.dot}`}/>
                </div>
              </div>
              <p className="text-white font-bold text-base">{user.name}</p>
              <p className="text-blue-200 text-xs mt-0.5">{user.dept}</p>
              <span className={`inline-block mt-2 text-[10px] font-bold px-2.5 py-1 rounded-lg bg-white/20 text-white border border-white/25`}>
                {rc.icon} {user.role}
              </span>
            </div>
          </div>

          {/* Overlap shield icon */}
          <div className="flex justify-center -mt-6 relative z-10">
            <div className={`w-12 h-12 rounded-2xl ${verified ? "bg-green-500" : "bg-white"} shadow-lg flex items-center justify-center border-4 border-white transition-colors duration-500`}>
              {verified
                ? <ShieldCheck size={22} className="text-white"/>
                : <ShieldCheck size={22} className="text-blue-600"/>
              }
            </div>
          </div>

          {/* Body */}
          <div className="px-8 pt-5 pb-8">
            <div className="text-center mb-6">
              <h2 className="text-lg font-bold text-gray-900">Two-Factor Authentication</h2>
              <p className="text-xs text-gray-500 mt-1.5 leading-relaxed">
                We sent a 6-digit verification code to<br/>
                <span className="font-semibold text-gray-700">{maskEmail(user.email)}</span>
              </p>
            </div>

            {/* OTP demo hint */}
            <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-xl px-3.5 py-2.5 mb-5">
              <span className="text-blue-500 flex-shrink-0">💡</span>
              <p className="text-[11px] text-blue-700">
                <span className="font-bold">Demo OTP:</span> The code is{" "}
                <span className="font-mono font-bold tracking-widest">1 2 3 4 5 6</span>
              </p>
            </div>

            {/* OTP digit inputs */}
            <div className="flex items-center gap-2.5 justify-center mb-2">
              {digits.map((digit, idx) => (
                <input
                  key={idx}
                  ref={el => { inputRefs.current[idx] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={e => handleChange(idx, e.target.value)}
                  onKeyDown={e => handleKeyDown(idx, e)}
                  onPaste={handlePaste}
                  disabled={loading || verified || attempts >= 3}
                  className={`
                    w-11 h-14 text-center text-lg font-bold rounded-xl border-2 outline-none
                    transition-all duration-200 caret-transparent
                    ${verified
                      ? "border-green-400 bg-green-50 text-green-700"
                      : error
                      ? "border-red-300 bg-red-50 text-red-700"
                      : digit
                      ? "border-blue-500 bg-blue-50 text-blue-700 shadow-sm"
                      : "border-gray-200 bg-gray-50 text-gray-900 focus:border-blue-400 focus:bg-white focus:shadow-sm"
                    }
                  `}
                />
              ))}
            </div>

            {/* Progress indicator */}
            <div className="flex items-center justify-center gap-1.5 mb-4 h-4">
              {digits.map((d, i) => (
                <div key={i} className={`h-1 rounded-full transition-all duration-200 ${
                  d
                    ? verified ? "w-4 bg-green-500" : error ? "w-4 bg-red-400" : "w-4 bg-blue-500"
                    : "w-4 bg-gray-200"
                }`}/>
              ))}
            </div>

            {/* Status messages */}
            {verified && (
              <div className="flex items-center gap-2 bg-green-50 border border-green-200 text-green-700 text-xs px-3.5 py-3 rounded-xl mb-4 justify-center">
                <ShieldCheck size={14}/> <span className="font-bold">Verified! Signing you in…</span>
              </div>
            )}
            {error && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 text-xs px-3.5 py-3 rounded-xl mb-4">
                <span className="font-bold flex-shrink-0 mt-0.5">⚠</span>
                <span>{error}</span>
              </div>
            )}
            {resendSent && !error && (
              <div className="flex items-center gap-2 bg-green-50 border border-green-200 text-green-700 text-xs px-3.5 py-3 rounded-xl mb-4">
                <span className="font-bold">✓</span> New OTP sent to your email.
              </div>
            )}

            {/* Verify button */}
            <button
              onClick={handleVerify}
              disabled={loading || verified || filled < OTP_LENGTH || attempts >= 3}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white text-sm font-bold py-3.5 rounded-xl cursor-pointer transition-all shadow-sm hover:shadow-md mb-4"
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity=".25"/>
                    <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
                  </svg>
                  Verifying…
                </>
              ) : verified ? (
                <><ShieldCheck size={16}/> Verified!</>
              ) : (
                <><ShieldCheck size={16}/> Verify & Sign In</>
              )}
            </button>

            {/* Resend */}
            <div className="text-center">
              <p className="text-xs text-gray-500">
                Didn't receive the code?{" "}
                {countdown > 0 ? (
                  <span className="text-gray-400">
                    Resend in <span className="font-bold tabular-nums text-gray-600">{countdown}s</span>
                  </span>
                ) : (
                  <button
                    onClick={handleResend}
                    className="text-blue-600 font-semibold hover:text-blue-700 cursor-pointer inline-flex items-center gap-1 transition-colors"
                  >
                    <RotateCcw size={11}/> Resend OTP
                  </button>
                )}
              </p>
            </div>
          </div>
        </div>

        {/* Security note */}
        <p className="text-center text-[11px] text-gray-400 mt-5 leading-relaxed">
          🔒 This code expires in 10 minutes and can only be used once.<br/>
          Never share your OTP with anyone.
        </p>
      </div>
    </div>
  );
}
