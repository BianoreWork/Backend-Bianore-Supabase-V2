import { useState } from "react";
import {
  Eye, EyeOff, ArrowRight, LayoutDashboard,
  Users, BarChart3, Shield, Zap, CheckCircle2,
} from "lucide-react";
import { mockAccounts, roleConfig, type AuthUser } from "./authData";

interface LoginPageProps {
  onLoginSuccess: (user: AuthUser) => void;
}

const features = [
  { icon: <Users size={16}/>,      label: "Real-time Attendance Tracking",   desc: "Monitor clock-ins, leaves & absences live"   },
  { icon: <Zap size={16}/>,        label: "Automated Payroll Processing",     desc: "Generate payslips with one click"             },
  { icon: <BarChart3 size={16}/>,  label: "Advanced Analytics & Reports",     desc: "Insights on workforce cost & performance"     },
  { icon: <Shield size={16}/>,     label: "Multi-role Access Control",        desc: "Owner, Super Admin & Admin permission tiers"  },
];

const stats = [
  { value: "500+",  label: "Companies" },
  { value: "100K+", label: "Employees" },
  { value: "99.9%", label: "Uptime" },
];

const maskEmail = (email: string) => {
  const [user, domain] = email.split("@");
  return user.slice(0, 2) + "···@" + domain;
};

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);

  const autoFill = (acc: AuthUser) => {
    setEmail(acc.email);
    setPassword(acc.password);
    setError("");
  };

  const matchedRole = mockAccounts.find(a => a.email === email)?.role;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) { setError("Please enter your email and password."); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 900));
    const account = mockAccounts.find(a => a.email === email && a.password === password);
    if (account) {
      onLoginSuccess(account);
    } else {
      setError("Invalid email or password. Use one of the demo accounts below.");
    }
    setLoading(false);
  };

  const inp = "w-full text-sm text-gray-800 bg-white border rounded-xl px-4 py-3 outline-none transition-all placeholder:text-gray-400";

  return (
    <div className="flex h-screen overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── LEFT BRANDING PANEL ─────────────────────────────────── */}
      <div className="hidden lg:flex lg:w-[460px] xl:w-[540px] flex-col flex-shrink-0 relative overflow-hidden bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900">

        {/* Decorative layers */}
        <div className="absolute inset-0" style={{
          backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.04) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}/>
        <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-blue-500/20 blur-3xl"/>
        <div className="absolute -bottom-24 -left-16 w-96 h-96 rounded-full bg-indigo-600/30 blur-3xl"/>
        <div className="absolute top-1/2 right-0 w-48 h-48 rounded-full bg-sky-400/10 blur-2xl"/>

        {/* Content */}
        <div className="relative z-10 flex flex-col h-full px-10 py-10">

          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/15 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20">
              <LayoutDashboard size={18} className="text-white"/>
            </div>
            <div>
              <p className="text-white font-bold text-lg leading-tight">WorkForce</p>
              <p className="text-blue-300 text-xs">HRIS Platform</p>
            </div>
          </div>

          {/* Hero text */}
          <div className="flex-1 flex flex-col justify-center mt-2">
            <div className="inline-flex items-center gap-2 bg-white/10 text-blue-200 text-xs font-semibold px-3 py-1.5 rounded-full w-fit mb-6 border border-white/15">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"/>
              All systems operational
            </div>
            <h1 className="text-3xl xl:text-4xl font-bold text-white leading-tight mb-4">
              Manage your<br/>workforce,<br/>
              <span className="text-blue-300">effortlessly.</span>
            </h1>
            <p className="text-blue-200 text-sm leading-relaxed max-w-xs">
              The all-in-one HRIS platform for attendance, payroll, and employee management — built for modern enterprises.
            </p>

            {/* Features */}
            <div className="space-y-3 mt-8">
              {features.map((f, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-xl bg-white/10 flex items-center justify-center text-blue-200 flex-shrink-0 border border-white/10">
                    {f.icon}
                  </div>
                  <div>
                    <p className="text-white text-xs font-semibold">{f.label}</p>
                    <p className="text-blue-300 text-[11px] mt-0.5">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-10 pt-8 border-t border-white/15">
              {stats.map((s, i) => (
                <div key={i}>
                  <p className="text-white text-xl font-bold">{s.value}</p>
                  <p className="text-blue-300 text-xs mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Floating dashboard preview card */}
            <div className="mt-8 bg-white/10 backdrop-blur-sm border border-white/15 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-white text-xs font-semibold">Today's Summary</p>
                <span className="text-[10px] text-blue-300">Live</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Present", value: "312", color: "text-green-400" },
                  { label: "On Leave", value: "18",  color: "text-amber-400" },
                  { label: "Absent",  value: "9",   color: "text-red-400"   },
                ].map(s => (
                  <div key={s.label} className="bg-white/8 rounded-xl p-2.5 text-center">
                    <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                    <p className="text-blue-300 text-[10px] mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer */}
          <p className="text-blue-500 text-[11px]">© 2026 WorkForce HRIS · All rights reserved.</p>
        </div>
      </div>

      {/* ── RIGHT FORM PANEL ────────────────────────────────────── */}
      <div className="flex-1 bg-gray-50 flex items-center justify-center px-6 py-8 overflow-y-auto">
        <div className="w-full max-w-[420px]">

          {/* Mobile logo */}
          <div className="flex items-center gap-2.5 mb-8 lg:hidden">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center">
              <LayoutDashboard size={17} className="text-white"/>
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">WorkForce</p>
              <p className="text-[10px] text-gray-400">HRIS Platform</p>
            </div>
          </div>

          {/* Heading */}
          <div className="mb-7">
            <h2 className="text-2xl font-bold text-gray-900">Welcome back</h2>
            <p className="text-sm text-gray-500 mt-1">Sign in to continue to WorkForce HRIS</p>
          </div>

          {/* Demo account quick-select */}
          <div className="mb-6">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2.5">Quick Sign-in · Demo Accounts</p>
            <div className="grid grid-cols-3 gap-2">
              {mockAccounts.map((acc) => {
                const rc = roleConfig[acc.role];
                const isSelected = email === acc.email;
                return (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => autoFill(acc)}
                    className={`relative flex flex-col items-center gap-1.5 p-3 rounded-2xl border-2 text-center cursor-pointer transition-all ${
                      isSelected
                        ? "border-blue-400 bg-blue-50 shadow-sm"
                        : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm"
                    }`}
                  >
                    {isSelected && (
                      <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                        <CheckCircle2 size={10} className="text-white"/>
                      </div>
                    )}
                    <div className={`w-9 h-9 rounded-xl ${rc.avatarBg} flex items-center justify-center text-white text-xs font-bold`}>
                      {acc.avatar}
                    </div>
                    <p className="text-[11px] font-bold text-gray-800 leading-tight">{acc.name.split(" ")[0]}</p>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${rc.pill}`}>
                      {acc.role}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 h-px bg-gray-200"/>
            <span className="text-[11px] text-gray-400 font-medium">or enter credentials</span>
            <div className="flex-1 h-px bg-gray-200"/>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Email */}
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-1.5 block">Email address</label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setError(""); }}
                  placeholder="you@company.com"
                  autoComplete="email"
                  className={`${inp} pr-10 ${error ? "border-red-300 focus:border-red-400" : "border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-50"}`}
                />
                {matchedRole && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${roleConfig[matchedRole].pill}`}>
                      {matchedRole}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-gray-600">Password</label>
                <button type="button" className="text-xs text-blue-600 hover:text-blue-700 cursor-pointer">
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(""); }}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  className={`${inp} pr-11 ${error ? "border-red-300 focus:border-red-400" : "border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-50"}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer transition-colors"
                >
                  {showPw ? <EyeOff size={16}/> : <Eye size={16}/>}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 text-xs px-3.5 py-3 rounded-xl">
                <span className="font-bold flex-shrink-0">⚠</span>
                <span>{error}</span>
              </div>
            )}

            {/* Hint for demo credentials */}
            {email && password && !mockAccounts.find(a => a.email === email) && !error && (
              <div className="flex items-start gap-2 bg-blue-50 border border-blue-200 text-blue-700 text-xs px-3.5 py-3 rounded-xl">
                <span className="flex-shrink-0">ℹ</span>
                <span>Use one of the demo accounts above or a valid credential.</span>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-sm font-bold py-3.5 rounded-xl cursor-pointer transition-all shadow-sm hover:shadow-md mt-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity=".25"/>
                    <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
                  </svg>
                  Signing in…
                </>
              ) : (
                <>Sign in <ArrowRight size={16}/></>
              )}
            </button>
          </form>

          {/* Credential hint */}
          <div className="mt-5 bg-gray-100 rounded-2xl p-4">
            <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Demo Credentials</p>
            <div className="space-y-1.5">
              {mockAccounts.map(acc => (
                <div key={acc.email} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${roleConfig[acc.role].dot}`}/>
                    <span className="text-[11px] text-gray-600">{maskEmail(acc.email)}</span>
                  </div>
                  <span className="text-[11px] font-mono text-gray-500">{acc.password}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
