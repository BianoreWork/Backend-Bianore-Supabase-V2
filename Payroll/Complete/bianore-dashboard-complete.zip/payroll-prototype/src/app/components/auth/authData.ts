export type UserRole = "Owner" | "Super Admin" | "Admin";

export interface AuthUser {
  email: string;
  password: string;
  name: string;
  role: UserRole;
  dept: string;
  avatar: string;
  otp: string;
  phone: string;
}

export const mockAccounts: AuthUser[] = [
  {
    email: "owner@workforce.com",
    password: "owner123",
    name: "David Park",
    role: "Owner",
    dept: "Executive",
    avatar: "DP",
    otp: "123456",
    phone: "+1 ···· ···4821",
  },
  {
    email: "superadmin@workforce.com",
    password: "super123",
    name: "Sarah Johnson",
    role: "Super Admin",
    dept: "IT Department",
    avatar: "SJ",
    otp: "123456",
    phone: "+1 ···· ···7302",
  },
  {
    email: "admin@workforce.com",
    password: "admin123",
    name: "Alex Kumar",
    role: "Admin",
    dept: "Human Resources",
    avatar: "AK",
    otp: "123456",
    phone: "+1 ···· ···5590",
  },
];

export const roleConfig: Record<UserRole, {
  pill: string; badge: string; avatarBg: string; dot: string; icon: string;
}> = {
  Owner: {
    pill:     "bg-purple-50 text-purple-700 border border-purple-200",
    badge:    "bg-purple-600",
    avatarBg: "bg-gradient-to-br from-purple-500 to-violet-600",
    dot:      "bg-purple-500",
    icon:     "👑",
  },
  "Super Admin": {
    pill:     "bg-blue-50 text-blue-700 border border-blue-200",
    badge:    "bg-blue-600",
    avatarBg: "bg-gradient-to-br from-blue-500 to-indigo-600",
    dot:      "bg-blue-500",
    icon:     "⚡",
  },
  Admin: {
    pill:     "bg-green-50 text-green-700 border border-green-200",
    badge:    "bg-green-600",
    avatarBg: "bg-gradient-to-br from-emerald-500 to-green-600",
    dot:      "bg-green-500",
    icon:     "🛡️",
  },
};
