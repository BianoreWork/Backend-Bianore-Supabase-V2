import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { LoginPage } from "./components/auth/LoginPage";
import { OtpPage }   from "./components/auth/OtpPage";
import { Dashboard } from "./components/dashboard/Dashboard";
import type { AuthUser } from "./components/auth/authData";
import "../styles/fonts.css";

type AuthStep = "login" | "otp" | "dashboard";

const slide = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0,  transition: { duration: 0.22, ease: "easeOut" } },
  exit:    { opacity: 0, y: -8, transition: { duration: 0.18, ease: "easeIn"  } },
};

const DEV_USER: AuthUser = {
  email: "owner@workforce.com", password: "owner123",
  name: "David Park", role: "Owner", dept: "Executive",
  avatar: "DP", otp: "123456", phone: "+62 ···· ···4821",
};

export default function App() {
  const [step, setStep]           = useState<AuthStep>("dashboard");
  const [pendingUser, setPending] = useState<AuthUser | null>(null);
  const [currentUser, setUser]    = useState<AuthUser | null>(DEV_USER);

  const handleLoginSuccess = (user: AuthUser) => { setPending(user); setStep("otp"); };
  const handleOtpVerified  = () => { setUser(pendingUser); setStep("dashboard"); };
  const handleLogout       = () => { setUser(null); setPending(null); setStep("login"); };

  return (
    <AnimatePresence mode="wait">
      {step === "login" && (
        <motion.div key="login" {...slide} className="w-full">
          <LoginPage onLoginSuccess={handleLoginSuccess}/>
        </motion.div>
      )}

      {step === "otp" && pendingUser && (
        <motion.div key="otp" {...slide} className="w-full">
          <OtpPage user={pendingUser} onVerified={handleOtpVerified} onBack={() => setStep("login")}/>
        </motion.div>
      )}

      {step === "dashboard" && (
        <motion.div
          key="dashboard"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.18 }}
          className="w-full"
        >
          <Dashboard user={currentUser} onLogout={handleLogout}/>
        </motion.div>
      )}
    </AnimatePresence>
  );
}