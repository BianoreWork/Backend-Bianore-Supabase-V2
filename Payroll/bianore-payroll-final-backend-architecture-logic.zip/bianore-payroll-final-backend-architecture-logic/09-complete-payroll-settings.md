# 09 — Complete Payroll Settings

## Payroll Settings — Final Complete Structure

```text
Payroll Settings
├── General Payroll Settings
├── Payroll Period & Cut-off
├── Payroll Type Defaults
├── Employee Selection Rules
├── Salary Calculation Rules
├── Salary Component Rules
├── Attendance Impact Rules
├── Overtime Rules
├── Proration Rules
├── BPJS Settings
├── PPh21 / Tax Settings
├── Payslip Settings
├── Payslip Delivery Settings
├── Payment / Disbursement Settings
├── Brick Funding VA Settings
├── Bank Account Validation Settings
├── Approval Flow Settings
├── Reminder & Employee Completion Settings
├── Report Export Settings
├── Security & Access Settings
└── Audit Log Settings
```

---

## 1. General Payroll Settings

```text
General Payroll Settings
├── Default currency
├── Payroll timezone
├── Payroll numbering format
├── Default payroll status
├── Default payment day
├── Default working days
├── Default working hours
├── Company payroll identity
└── Payroll rounding behavior
```

## 2. Payroll Period & Cut-off

```text
Payroll Period & Cut-off
├── Default cut-off start day
├── Default cut-off end day
├── Default payroll month rule
├── Default payment date rule
├── Auto create payroll period
├── Lock period after payroll paid
└── Allow correction after period locked
```

## 3. Payroll Type Defaults

```text
Payroll Type Defaults
├── Monthly Payroll
├── Correction Payroll
├── THR Payroll
├── Bonus Payroll
├── Final Payroll
└── Failed Payment Retry Payroll
```

## 4. Employee Selection Rules

```text
Employee Selection Rules
├── Include active employees
├── Include employee by salary type
├── Include by employment type
├── Include by branch
├── Include by department
├── Exclude inactive employees
├── Exclude resign employees
├── Exclude employees with incomplete payroll data
├── Allow manual add/remove employee
└── Pull failed payment employee for correction payroll
```

## 5. Salary Calculation Rules

```text
Salary Calculation Rules
├── Base salary calculation method
├── Daily rate formula
├── Hourly rate formula
├── Working day basis
├── Calendar day basis
├── Fixed salary rule
├── Daily worker rule
├── Hourly worker rule
├── Minimum payable amount
└── Rounding rule
```

## 6. Salary Component Rules

```text
Salary Component Rules
├── Default earnings
├── Default deductions
├── Default benefits
├── Taxable component mapping
├── Non-taxable component mapping
├── BPJS base component mapping
├── Visible on payslip rule
├── Recurring component rule
├── One-time component rule
├── Component effective date
└── Prevent delete if component already used
```

## 7. Attendance Impact Rules

```text
Attendance Impact Rules
├── Attendance sync required
├── Late deduction enabled
├── Absent deduction enabled
├── Unpaid leave deduction enabled
├── No checkout impact
├── Attendance bonus rule
├── Meal allowance based on attendance
├── Transport allowance based on attendance
├── Attendance issue blocking payroll
└── Attendance override impact
```

## 8. Overtime Rules

```text
Overtime Rules
├── Overtime enabled
├── Overtime eligible employees
├── Overtime formula
├── Overtime approval required
├── Overtime rounding
├── Maximum overtime per day
├── Maximum overtime per month
├── Weekday overtime rate
├── Weekend overtime rate
└── Holiday overtime rate
```

## 9. Proration Rules

```text
Proration Rules
├── Calendar days method
├── Working days method
├── Fixed divisor method
├── Join date proration
├── Resign date proration
├── Unpaid leave proration
├── Component prorated/non-prorated
└── Minimum working days rule
```

## 10. BPJS Settings

```text
BPJS Settings
├── BPJS Kesehatan rate
├── BPJS Ketenagakerjaan rate
├── JHT rate
├── JP rate
├── JKK risk level rate
├── JKM rate
├── JKP rate if used
├── Salary cap
├── Employer contribution
├── Employee contribution
├── Effective date
├── System default
├── Company override
└── BPJS report format
```

## 11. PPh21 / Tax Settings

```text
PPh21 / Tax Settings
├── PTKP table
├── TER table
├── Tax method default
├── Gross method
├── Nett method
├── Gross up method
├── Taxable component mapping
├── Non-taxable component mapping
├── Final month adjustment
├── Yearly tax summary
├── Effective date
├── Government default
└── Company override permission
```

## 12. Payslip Settings

```text
Payslip Settings
├── Payslip numbering format
├── Payslip template
├── Show earnings breakdown
├── Show deductions breakdown
├── Show BPJS detail
├── Show PPh21 detail
├── Show payment status
├── Show company logo
├── Show signature
├── Allow employee download
├── Allow regenerate payslip
└── Require regenerate reason
```

## 13. Payslip Delivery Settings

```text
Payslip Delivery Settings
├── Enable email delivery
├── Enable WhatsApp delivery
├── Enable employee app notification
├── Send after payroll paid
├── Send after payslip generated
├── Manual send only
├── Attach PDF
├── Message template
├── Skip employee without email/phone
├── Retry failed delivery
└── Delivery log
```

## 14. Payment / Disbursement Settings

```text
Payment / Disbursement Settings
├── Payment mode
│   ├── Manual
│   ├── Bank file export
│   └── Auto disbursement API
├── Active provider
├── Source bank account
├── Payment approval required
├── Allow manual paid
├── Allow retry failed payment
├── Allow switch employee bank account
├── Export bank file format
├── Payment receipt format
└── Payment webhook setting
```

## 15. Brick Funding VA Settings

```text
Brick Funding VA Settings
├── Brick enabled
├── Brick mode: sandbox / production
├── Funding method: virtual account
├── Default VA bank
├── VA expiry duration
├── Auto generate VA after approval
├── Auto send disbursement after funding paid
├── Retry failed disbursement enabled
├── Max retry attempts
├── Brick webhook URL
├── Brick connection status
├── Brick credential health
└── Masked API key display
```

## 16. Bank Account Validation Settings

```text
Bank Account Validation Settings
├── Allow employee submit bank account
├── Require admin approval
├── Allow primary bank
├── Allow secondary bank
├── Validate via Brick account inquiry
├── Name matching tolerance
├── Allow name mismatch with approval
├── Allow switch bank after failed payment
└── Require validation before payroll
```

## 17. Approval Flow Settings

```text
Approval Flow Settings
├── Approval flow list
├── Applies to payroll type
├── Add approval step
├── Edit approval step
├── Delete approval step
├── Reorder approval step
├── Select approver role
├── Select specific approver person
├── Conditional approval
├── Amount threshold approval
├── Branch/department condition
├── Require checkbox confirmation
├── Require drag-to-confirm
├── Allow request revision
├── Auto lock after final approval
└── Auto create payment batch after final approval
```

## 18. Reminder & Employee Completion Settings

```text
Reminder & Employee Completion Settings
├── Missing bank reminder
├── Missing tax reminder
├── Missing BPJS reminder
├── Invalid bank reminder
├── Send to employee app
├── Send to email
├── Send to WhatsApp
├── Auto reminder before payroll date
├── Reminder template
├── Employee submission requires approval
└── Completion tracking
```

## 19. Report Export Settings

```text
Report Export Settings
├── Enable PDF export
├── Enable Excel export
├── Enable CSV export
├── Enable ZIP payslip export
├── Default report format
├── Report watermark
├── Include company signature
├── Include audit metadata
├── Export scope default
└── Async export for large report
```

## 20. Security & Access Settings

```text
Security & Access Settings
├── Payroll access roles
├── Who can create payroll run
├── Who can calculate payroll
├── Who can approve payroll
├── Who can lock payroll
├── Who can generate Brick VA
├── Who can send disbursement
├── Who can mark manual paid
├── Who can edit employee salary
├── Who can edit bank account
├── Who can export reports
└── Sensitive data masking
```

## 21. Audit Log Settings

```text
Audit Log Settings
├── Track salary changes
├── Track bank changes
├── Track tax profile changes
├── Track BPJS profile changes
├── Track payroll calculation
├── Track approval action
├── Track payment action
├── Track manual paid action
├── Track export action
├── Track setting changes
└── Audit retention period
```
