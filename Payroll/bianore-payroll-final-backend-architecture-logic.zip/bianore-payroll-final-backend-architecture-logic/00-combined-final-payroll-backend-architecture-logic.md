# Bianore Teladan — Final Payroll Backend Architecture & Logic Combined



---

# 01 — Final Payroll Menu Structure

## Struktur Utama Payroll — Jangan Diubah

```text
Payroll
├── Payroll Overview
├── Payroll Run
├── Salary Components
├── Employee Payroll Info
├── Payslip
├── BPJS
├── Tax / PPh 21
├── Payroll Reports
└── Payroll Settings
```

---

# 1. Payroll Overview

```text
Payroll Overview
├── Payroll Monthly Summary
│   ├── Total gross salary
│   ├── Total deduction
│   ├── Total net salary
│   ├── Total employees
│   ├── Total BPJS
│   ├── Total PPh21
│   └── Three-dot action menu
│       ├── View payroll detail
│       ├── Continue payroll process
│       ├── View approval status
│       ├── View disbursement status
│       ├── Export summary
│       └── View audit log
│
├── Department Cost Widget
│   ├── Department payroll cost
│   ├── Overtime cost
│   ├── Allowance cost
│   ├── Deduction cost
│   └── Three-dot action menu
│       ├── View department breakdown
│       ├── Compare with last month
│       ├── Export department cost
│       ├── View employees in department
│       └── View overtime cost
│
├── Payroll Process Step Widget
│   ├── Step 1: Setup Payroll
│   ├── Step 2: Sync Attendance
│   ├── Step 3: Calculate Salary
│   ├── Step 4: Approval
│   └── Step 5: Disbursement
│
├── Step Detail Popup / Right Sheet
│   ├── Setup Payroll Detail
│   ├── Attendance Sync Detail
│   ├── Salary Calculation Detail
│   ├── Approval Detail
│   └── Disbursement Detail
│
├── Payroll Alerts
│   ├── Missing bank account
│   ├── Invalid bank account
│   ├── Missing tax profile
│   ├── Missing BPJS profile
│   ├── Pending approval
│   ├── Waiting Brick VA payment
│   └── Failed disbursement
│
└── Quick Actions
    ├── Create payroll run
    ├── Continue current payroll
    ├── Review issues
    ├── Export report
    └── Open disbursement detail
```

---

# 2. Payroll Run

```text
Payroll Run
├── Payroll Run List
│   ├── Payroll code
│   ├── Payroll name
│   ├── Payroll type
│   ├── Period
│   ├── Total employees
│   ├── Total net salary
│   ├── Status
│   ├── Issue count
│   └── Export action
│       ├── Export PDF
│       ├── Export Excel
│       ├── Export CSV
│       ├── Export payslip ZIP
│       └── Export audit log
│
├── Create Payroll Run CTA
│   ├── Payroll type selection
│   │   ├── Monthly Payroll
│   │   ├── Correction Payroll
│   │   ├── THR Payroll
│   │   ├── Bonus Payroll
│   │   ├── Final Payroll
│   │   └── Failed Payment Retry Payroll
│   │
│   ├── Monthly Payroll Default
│   │   ├── Auto include active monthly employees
│   │   ├── Use default cut-off
│   │   ├── Require attendance sync
│   │   ├── Require BPJS
│   │   ├── Require PPh21
│   │   └── Require approval and disbursement
│   │
│   ├── Correction Payroll Default
│   │   ├── Manual employee selection
│   │   ├── Pull failed transfer employees from Disbursement
│   │   ├── Allow manual adjustment
│   │   └── Allow correction payslip
│   │
│   └── THR Payroll Default
│       ├── Include eligible employees
│       ├── Use THR formula
│       ├── Attendance optional
│       └── Tax calculation required
│
├── Payroll Run Right Sheet
│   ├── Summary Tab
│   ├── Employees Tab
│   ├── Calculation Tab
│   ├── Approval Tab
│   ├── Payment Tab
│   └── Audit Log Tab
│
├── Employees Tab
│   ├── Employee list
│   ├── Base salary
│   ├── Gross salary
│   ├── Deduction
│   ├── BPJS
│   ├── PPh21
│   ├── Net salary
│   ├── Payment status
│   ├── Issue badge
│   └── Resolve action
│       ├── Edit bank
│       ├── Switch bank
│       ├── Request employee update
│       ├── Mark as manual paid
│       ├── Exclude employee
│       └── Recalculate employee
│
├── Draft Status Actions
│   ├── Select employees
│   ├── Add employee
│   ├── Remove employee
│   ├── Include department
│   ├── Exclude employee
│   └── Fix missing payroll data
│
├── Calculate Salary Action
│   └── Calculation Progress Modal
│       ├── Load employee payroll profile
│       ├── Apply salary components
│       ├── Sync attendance deduction
│       ├── Calculate BPJS
│       ├── Calculate PPh21
│       └── Finalize net salary
│
├── Approval Action
│   ├── Submit approval
│   ├── Approve
│   ├── Reject
│   ├── Request revision
│   └── Approval Confirmation Modal
│       ├── Show approver role
│       ├── Show payroll amount
│       ├── Show employee count
│       ├── Required checkbox
│       └── Drag to confirm approval
│
└── Payment Action
    ├── Lock payroll
    ├── Create payment batch
    ├── Generate Brick VA
    └── Open disbursement detail
```

---

# 3. Salary Components

```text
Salary Components
├── Earnings
│   ├── Basic salary
│   ├── Fixed allowance
│   ├── Position allowance
│   ├── Transport allowance
│   ├── Meal allowance
│   ├── Attendance allowance
│   ├── Overtime pay
│   ├── Bonus
│   ├── Commission
│   └── THR
│
├── Deductions
│   ├── Late deduction
│   ├── Absent deduction
│   ├── Unpaid leave deduction
│   ├── Loan deduction
│   ├── Cash advance
│   ├── BPJS employee contribution
│   ├── PPh21
│   └── Other deduction
│
├── Benefits
│   ├── BPJS employer contribution
│   ├── Insurance
│   └── Company benefit
│
├── Component Settings
│   ├── Fixed amount
│   ├── Percentage
│   ├── Formula based
│   ├── Taxable / non-taxable
│   ├── BPJS base / not BPJS base
│   ├── Recurring / one-time
│   ├── Prorated / non-prorated
│   └── Visible on payslip
│
└── Small Addition
    ├── Effective start date
    ├── Effective end date
    ├── Used by employee count
    └── Deactivate instead of delete
```

---

# 4. Employee Payroll Info

```text
Employee Payroll Info
├── Employee Payroll List
│   ├── Employee name
│   ├── Department
│   ├── Position
│   ├── Salary type
│   ├── Base salary
│   ├── Bank status
│   ├── Tax status
│   ├── BPJS status
│   ├── Payroll eligibility
│   └── Reminder action
│
├── Employee Payroll Right Sheet
│   ├── Tab 1: Profil Payroll
│   ├── Tab 2: Rekening Bank
│   ├── Tab 3: Profil Pajak
│   └── Tab 4: Profil BPJS
│
├── Profil Payroll Tab
│   ├── Salary type
│   ├── Base salary
│   ├── Daily rate
│   ├── Hourly rate
│   ├── Payroll status
│   ├── Effective date
│   ├── Overtime eligible
│   ├── Attendance deduction enabled
│   ├── Salary components
│   ├── Fixed allowance
│   ├── Benefits
│   ├── Deductions
│   ├── BPJS included
│   ├── Tax method
│   └── Actions
│       ├── Edit salary
│       ├── Override salary
│       ├── Add salary component
│       ├── Set effective date
│       └── View salary history
│
├── Rekening Bank Tab
│   ├── Primary Bank Account
│   ├── Secondary Bank Account
│   └── Actions
│       ├── Add bank
│       ├── Edit bank
│       ├── Set as primary
│       ├── Validate bank account
│       └── Request employee update
│
├── Profil Pajak Tab
│   ├── NIK
│   ├── NPWP
│   ├── PTKP status
│   ├── Tax method
│   ├── TER category
│   ├── Tax enabled
│   ├── Employee submitted data
│   └── HR approval status
│
├── Profil BPJS Tab
│   ├── BPJS Kesehatan number
│   ├── BPJS Ketenagakerjaan number
│   ├── BPJS Kesehatan active
│   ├── JHT active
│   ├── JP active
│   ├── JKK active
│   ├── JKM active
│   ├── JKP active
│   ├── BPJS base salary
│   ├── Employee submitted data
│   └── HR approval status
│
└── Reminder Action
    ├── Missing bank reminder
    ├── Missing tax reminder
    ├── Missing BPJS reminder
    ├── Invalid bank reminder
    ├── Send to employee app
    ├── Send to email
    └── Send to WhatsApp
```

---

# 5. Payslip

```text
Payslip
├── Payslip List
│   ├── Employee name
│   ├── Period
│   ├── Gross salary
│   ├── Deduction
│   ├── Net salary
│   ├── Payment status
│   ├── Payslip status
│   └── Delivery status
│
├── Payslip Right Sheet
│   ├── Summary Tab
│   ├── Earnings Tab
│   ├── Deductions Tab
│   ├── BPJS Tab
│   ├── PPh21 Tab
│   ├── Payment Status Tab
│   ├── Send History Tab
│   └── Download History Tab
│
├── Actions
│   ├── Preview payslip
│   ├── Download PDF
│   ├── Regenerate payslip
│   ├── Send to email
│   ├── Send to WhatsApp
│   └── Send employee app notification
│
├── Send Payslip Form
│   ├── Period
│   ├── Recipient scope
│   │   ├── All paid employees
│   │   ├── Selected department
│   │   ├── Selected employees
│   │   └── Not sent yet
│   │
│   ├── Channels
│   │   ├── Email
│   │   ├── WhatsApp
│   │   └── Employee app notification
│   │
│   ├── Options
│   │   ├── Attach PDF
│   │   ├── Include payment status
│   │   ├── Send only if paid
│   │   └── Skip missing contact
│   │
│   └── Actions
│       ├── Preview message
│       └── Send payslip
│
└── Delivery Logs
    ├── Channel
    ├── Recipient
    ├── Status
    ├── Sent at
    └── Failed reason
```

---

# 6. BPJS

```text
BPJS
├── BPJS Settings
├── BPJS Rate
├── Employee BPJS Profile
├── BPJS Calculation
└── BPJS Reports
```

Updated detail:

```text
BPJS
├── Tarif BPJS
├── Kalkulasi BPJS
├── BPJS Calculation Right Sheet
└── Laporan BPJS
```

---

# 7. Tax / PPh 21

```text
Tax / PPh 21
├── Tax Settings
├── PTKP Settings
├── TER Settings
├── Employee Tax Profile
├── PPh21 Calculation
└── Tax Reports
```

Updated detail:

```text
Tax / PPh 21
├── PTKP
├── TER
├── Kalkulasi PPh21
├── PPh21 Calculation Right Sheet
└── Laporan PPh21
```

---

# 8. Payroll Reports

```text
Payroll Reports
├── Payroll Summary Report
├── Employee Payroll Report
├── Department Payroll Cost Report
├── Branch Payroll Cost Report
├── BPJS Report
├── PPh21 Report
├── Payslip Report
├── Bank Transfer Report
├── Failed Payment Report
├── Overtime Cost Report
├── Attendance Deduction Report
├── Payroll Journal Report
└── Export History
```

---

# 9. Payroll Settings

```text
Payroll Settings
├── General Payroll Settings
├── Payroll Period & Cut-off
├── Payroll Type Defaults
├── Employee Selection Rules
├── Salary Calculation Rules
├── Salary Component Rules
├── Attendance Impact Rules
├── Overtime Rules
├── Proration Rules
├── BPJS Settings
├── PPh21 / Tax Settings
├── Payslip Settings
├── Payslip Delivery Settings
├── Payment / Disbursement Settings
├── Brick Funding VA Settings
├── Bank Account Validation Settings
├── Approval Flow Settings
├── Reminder & Employee Completion Settings
├── Report Export Settings
├── Security & Access Settings
└── Audit Log Settings
```


---

# 02 — Supabase vs Laravel by Payroll Submenu

## Prinsip Utama

```text
Supabase = database utama, tenant isolation, payroll data, view/RPC query, calculation result, report data, payslip/payment metadata.

Laravel = business service layer, payroll logic, approval workflow, payslip PDF, Brick VA/disbursement, webhook, BPJS/PPh21 engine, export, queue, audit, security validation.
```

---

# 1. Payroll Overview

## Supabase

- [ ] payroll_runs.
- [ ] payroll_run_employees.
- [ ] payroll_calculations.
- [ ] payroll_payment_batches.
- [ ] payroll_payment_items.
- [ ] payroll_issues.
- [ ] payroll_run_steps.
- [ ] report views/RPC.
- [ ] admin_payroll_overview RPC.

## Laravel

- [ ] PayrollOverviewService.
- [ ] Widget action resolver.
- [ ] Payroll step detail resolver.
- [ ] Issue summary resolver.
- [ ] Department cost detail resolver.
- [ ] Permission validation.
- [ ] Export summary trigger.

## Kesimpulan

```text
Supabase dominan untuk data summary.
Laravel untuk action, permission, dan response orchestration.
```

---

# 2. Payroll Run

## Supabase

- [ ] payroll_periods.
- [ ] payroll_runs.
- [ ] payroll_run_employees.
- [ ] payroll_run_steps.
- [ ] payroll_calculations.
- [ ] payroll_calculation_items.
- [ ] payroll_issues.
- [ ] payroll_issue_resolutions.
- [ ] payroll_approval_histories.
- [ ] payroll_audit_logs.

## Laravel

- [ ] PayrollRunService.
- [ ] PayrollRunStepService.
- [ ] PayrollCalculationService.
- [ ] AttendancePayrollSyncService.
- [ ] PayrollApprovalService.
- [ ] PayrollIssueService.
- [ ] PayrollIssueResolutionService.
- [ ] PayrollAuditService.
- [ ] PayrollValidationService.

## Kesimpulan

```text
Laravel dominan untuk proses.
Supabase dominan untuk penyimpanan, status, dan query.
```

---

# 3. Salary Components

## Supabase

- [ ] salary_components.
- [ ] employee_salary_components.
- [ ] component effective date.
- [ ] taxable/BPJS/payslip flags.

## Laravel

- [ ] SalaryComponentService.
- [ ] Formula validation.
- [ ] Apply component saat payroll calculation.
- [ ] Prevent hard delete if component already used.
- [ ] Deactivate component.

## Kesimpulan

```text
Supabase untuk master data.
Laravel untuk validation dan apply logic.
```

---

# 4. Employee Payroll Info

## Supabase

- [ ] employee_payroll_profiles.
- [ ] employee_bank_accounts.
- [ ] employee_tax_profiles.
- [ ] employee_bpjs_profiles.
- [ ] employee_salary_components.
- [ ] employee_profile_submission_requests.
- [ ] employee_profile_submissions.

## Laravel

- [ ] EmployeePayrollService.
- [ ] BankAccountValidationService / PayrollValidationService.
- [ ] PayrollReminderService.
- [ ] Employee submission approval logic.
- [ ] Salary override logic.
- [ ] Bank primary/secondary switch logic.

## Kesimpulan

```text
Supabase untuk profil dan histori.
Laravel untuk validation, approval, reminder, dan sensitive action.
```

---

# 5. Payslip

## Supabase

- [ ] payslips.
- [ ] payslip_items.
- [ ] payslip_delivery_logs.
- [ ] Supabase Storage for PDF.

## Laravel

- [ ] PayslipService.
- [ ] PayslipDeliveryService.
- [ ] PDF generator.
- [ ] Email/WhatsApp/employee app delivery.
- [ ] Regenerate validation.
- [ ] Delivery logs.
- [ ] Secure download link.

## Kesimpulan

```text
Laravel dominan untuk PDF dan delivery.
Supabase untuk metadata, item snapshot, dan file path.
```

---

# 6. BPJS

## Supabase

- [ ] bpjs_rate_settings.
- [ ] employee_bpjs_profiles.
- [ ] bpjs_employee_calculations.
- [ ] bpjs_company_calculations.
- [ ] BPJS report source.

## Laravel

- [ ] BPJSCalculationService.
- [ ] Rate effective date validation.
- [ ] System default vs company override resolver.
- [ ] BPJS report export.
- [ ] Recalculate employee BPJS.

## Kesimpulan

```text
Supabase untuk rate/profile/result.
Laravel untuk calculation engine dan export.
```

---

# 7. Tax / PPh21

## Supabase

- [ ] tax_ptkp_settings.
- [ ] tax_ter_settings.
- [ ] employee_tax_profiles.
- [ ] tax_pph21_calculations.
- [ ] tax_yearly_summaries.

## Laravel

- [ ] Pph21CalculationService.
- [ ] TER/PTKP effective date resolver.
- [ ] Gross/nett/gross-up logic.
- [ ] Final month adjustment.
- [ ] Tax report export.

## Kesimpulan

```text
Supabase untuk settings/profile/result.
Laravel untuk tax engine dan export.
```

---

# 8. Payroll Reports

## Supabase

- [ ] report views.
- [ ] payroll_report_exports.
- [ ] payroll source data.
- [ ] BPJS/tax/payment report source data.

## Laravel

- [ ] PayrollReportService.
- [ ] PayrollExportService.
- [ ] PDF generator.
- [ ] Excel generator.
- [ ] CSV generator.
- [ ] ZIP payslip generator.
- [ ] Async export job.

## Kesimpulan

```text
Supabase untuk query/report source.
Laravel untuk generation/download workflow.
```

---

# 9. Payroll Settings

## Supabase

- [ ] payroll_settings.
- [ ] payroll_provider_settings.
- [ ] payroll_approval_flows.
- [ ] payroll_approval_steps.
- [ ] bpjs_rate_settings.
- [ ] tax_ptkp_settings.
- [ ] tax_ter_settings.

## Laravel

- [ ] PayrollSettingService.
- [ ] Approval flow validation.
- [ ] Brick credential handling.
- [ ] Secret management.
- [ ] Setting permission validation.
- [ ] Test provider connection.
- [ ] Audit log for setting changes.

## Kesimpulan

```text
Supabase untuk setting non-secret.
Laravel untuk validation, secret, provider connection, dan sensitive permission.
```


---

# 03 — Final Backend Architecture

## Final Architecture

```text
Frontend React / Next.js
        ↓
Laravel API
        ↓
Payroll Domain Services
        ↓
Supabase PostgreSQL
        ↓
Supabase Storage
        ↓
External Providers
        ├── Brick Funding VA
        ├── Brick Disbursement
        ├── Email Provider
        ├── WhatsApp Provider
        └── Export Generator
```

---

## Main Backend Responsibilities

## Supabase

```text
- Database utama payroll
- Tenant isolation
- Payroll period/run data
- Payroll employee data
- Salary components
- Employee payroll profile
- Bank/tax/BPJS profile
- Payroll calculation result
- Payslip metadata
- Payment batch and item status
- Brick VA metadata
- Approval history
- Audit logs
- Report export records
- RPC/view for dashboard and reports
```

## Laravel

```text
- API layer for frontend
- JWT auth and permission validation
- Payroll process orchestration
- Payroll calculation engine
- Attendance sync trigger
- BPJS engine
- PPh21 engine
- Approval workflow
- Approval confirmation validation
- Issue resolution
- Payslip PDF generator
- Payslip delivery
- Brick Funding VA service
- Brick Disbursement service
- Brick webhook handler
- Report export generation
- Queue jobs
- Audit log writing
```

---

## Final Payroll Flow

```text
Create Payroll Period
→ Create Payroll Run
→ Select Payroll Type
→ Apply Payroll Type Defaults
→ Select Employees
→ Validate Employee Payroll Data
→ Sync Attendance
→ Calculate Salary
→ Calculate Allowance & Deduction
→ Calculate BPJS
→ Calculate PPh21
→ Review Payroll
→ Resolve Issues
→ Submit Approval
→ Approval Confirmation
→ Final Approval
→ Lock Payroll
→ Create Payment Batch
→ Generate Brick Funding VA
→ Company Pays VA
→ Brick Confirms Funding Paid
→ Send Brick Disbursement
→ Receive Webhook Status
→ Retry / Resolve Failed Payment
→ Generate Payslip
→ Send Payslip
→ Export Reports
```

---

## Final Status Lifecycle

## Payroll Run Status

```text
draft
employee_selection
attendance_synced
calculating
calculated
needs_attention
pending_approval
approved
locked
payment_batch_created
waiting_va_payment
funding_paid
disbursement_processing
paid
partially_paid
failed
cancelled
```

## Payment Batch Status

```text
draft
ready_for_funding
waiting_va_payment
funding_paid
funding_expired
funding_failed
ready_for_disbursement
disbursement_processing
paid
partially_paid
failed
cancelled
```

## Payment Item Status

```text
pending
validating
processing
success
failed
retried
manual_paid
reversed
```

## Approval Status

```text
draft
submitted
approved
rejected
need_revision
locked
```

## Issue Status

```text
open
in_progress
resolved
ignored
excluded
```

---

## Final Role Access

```text
super_admin
admin
hr
finance
manager
employee
```

## Sensitive Actions

```text
- edit salary
- approve payroll
- lock payroll
- generate Brick VA
- send disbursement
- mark manual paid
- switch employee bank
- export payroll report
- change payroll settings
```


---

# 04 — Final Supabase Tables and Migration Tasks

## Final Supabase Tables

```text
payroll_periods
payroll_runs
payroll_run_employees
payroll_run_steps
payroll_calculations
payroll_calculation_items
salary_components
employee_salary_components
employee_payroll_profiles
employee_bank_accounts
employee_tax_profiles
employee_bpjs_profiles
bpjs_rate_settings
bpjs_employee_calculations
bpjs_company_calculations
tax_ptkp_settings
tax_ter_settings
tax_pph21_calculations
tax_yearly_summaries
payslips
payslip_items
payslip_delivery_logs
payroll_payment_batches
payroll_payment_items
payroll_payment_webhooks
payroll_payment_attempts
payroll_approval_flows
payroll_approval_steps
payroll_approval_histories
payroll_audit_logs
payroll_settings
payroll_report_exports
payroll_provider_settings
payroll_issues
payroll_issue_resolutions
employee_profile_submission_requests
employee_profile_submissions
```

---

# A. Core Payroll Tables

## payroll_periods

- [ ] Create payroll_periods table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add period_name varchar.
- [ ] Add month integer.
- [ ] Add year integer.
- [ ] Add cutoff_start_date date.
- [ ] Add cutoff_end_date date.
- [ ] Add payment_date date.
- [ ] Add status varchar default 'open'.
- [ ] Add is_locked boolean default false.
- [ ] Add locked_at timestamp nullable.
- [ ] Add locked_by UUID/bigint nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + month + year.
- [ ] Add index tenant_id + year + month.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_runs

- [ ] Create payroll_runs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_period_id UUID references payroll_periods(id).
- [ ] Add run_code varchar unique per tenant.
- [ ] Add run_name varchar.
- [ ] Add payroll_type varchar: monthly, correction, thr, bonus, final, failed_retry.
- [ ] Add month integer.
- [ ] Add year integer.
- [ ] Add cutoff_start_date date.
- [ ] Add cutoff_end_date date.
- [ ] Add payment_date date.
- [ ] Add status varchar default 'draft'.
- [ ] Add total_employees integer default 0.
- [ ] Add total_gross_salary numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add total_bpjs_employee numeric default 0.
- [ ] Add total_bpjs_employer numeric default 0.
- [ ] Add total_pph21 numeric default 0.
- [ ] Add total_net_salary numeric default 0.
- [ ] Add total_paid numeric default 0.
- [ ] Add total_failed_payment numeric default 0.
- [ ] Add submitted_at timestamp nullable.
- [ ] Add submitted_by UUID/bigint nullable.
- [ ] Add approved_at timestamp nullable.
- [ ] Add approved_by UUID/bigint nullable.
- [ ] Add locked_at timestamp nullable.
- [ ] Add locked_by UUID/bigint nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + month + year.
- [ ] Add index tenant_id + payment_date.
- [ ] Add RLS policy for tenant isolation.

## payroll_run_employees

- [ ] Create payroll_run_employees table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add employment_type varchar.
- [ ] Add department_id UUID/bigint nullable.
- [ ] Add branch_id UUID/bigint nullable.
- [ ] Add position_id UUID/bigint nullable.
- [ ] Add base_salary numeric default 0.
- [ ] Add prorated_salary numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add total_bpjs_employee numeric default 0.
- [ ] Add total_bpjs_employer numeric default 0.
- [ ] Add total_pph21 numeric default 0.
- [ ] Add gross_salary numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add payment_status varchar default 'pending'.
- [ ] Add calculation_status varchar default 'pending'.
- [ ] Add issue_status varchar default 'none'.
- [ ] Add issue_count integer default 0.
- [ ] Add is_excluded boolean default false.
- [ ] Add exclusion_reason text nullable.
- [ ] Add reviewed_at timestamp nullable.
- [ ] Add reviewed_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint payroll_run_id + employee_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + payment_status.
- [ ] Add index tenant_id + calculation_status.
- [ ] Add RLS policy for tenant isolation.

## payroll_run_steps

- [ ] Create payroll_run_steps table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add step_code varchar.
- [ ] Add step_name varchar.
- [ ] Add status varchar default 'pending'.
- [ ] Add progress_percentage integer default 0.
- [ ] Add started_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add error_count integer default 0.
- [ ] Add warning_count integer default 0.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint payroll_run_id + step_code.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + step_code.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

---

# B. Salary and Employee Payroll Tables

## salary_components

- [ ] Create salary_components table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add component_code varchar.
- [ ] Add component_name varchar.
- [ ] Add component_type varchar: earning, deduction, benefit, reimbursement.
- [ ] Add calculation_type varchar: fixed, percentage, formula, attendance_based, overtime_based.
- [ ] Add default_amount numeric default 0.
- [ ] Add default_percentage numeric default 0.
- [ ] Add formula text nullable.
- [ ] Add is_taxable boolean default true.
- [ ] Add is_bpjs_base boolean default false.
- [ ] Add is_recurring boolean default true.
- [ ] Add is_prorated boolean default false.
- [ ] Add is_visible_on_payslip boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add sort_order integer default 0.
- [ ] Add effective_start_date date nullable.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + component_code.
- [ ] Add index tenant_id + component_type.
- [ ] Add index tenant_id + is_active.
- [ ] Add RLS policy for tenant isolation.

## employee_salary_components

- [ ] Create employee_salary_components table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add salary_component_id UUID references salary_components(id).
- [ ] Add amount numeric default 0.
- [ ] Add percentage numeric default 0.
- [ ] Add formula_override text nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + salary_component_id.
- [ ] Add index tenant_id + effective_start_date + effective_end_date.
- [ ] Add RLS policy for tenant isolation.

## employee_payroll_profiles

- [ ] Create employee_payroll_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add payroll_status varchar default 'active'.
- [ ] Add salary_type varchar: monthly, daily, hourly, commission.
- [ ] Add base_salary numeric default 0.
- [ ] Add daily_rate numeric default 0.
- [ ] Add hourly_rate numeric default 0.
- [ ] Add prorate_method varchar default 'calendar_days'.
- [ ] Add overtime_eligible boolean default true.
- [ ] Add attendance_deduction_enabled boolean default true.
- [ ] Add tax_enabled boolean default true.
- [ ] Add bpjs_enabled boolean default true.
- [ ] Add payment_method varchar default 'bank_transfer'.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add override_reason text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + payroll_status.
- [ ] Add index tenant_id + salary_type.
- [ ] Add RLS policy for tenant isolation.

## employee_bank_accounts

- [ ] Create employee_bank_accounts table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bank_name varchar.
- [ ] Add bank_code varchar.
- [ ] Add account_number varchar.
- [ ] Add account_holder_name varchar.
- [ ] Add slot_type varchar: primary, secondary.
- [ ] Add is_primary boolean default false.
- [ ] Add validation_status varchar default 'unvalidated'.
- [ ] Add validation_provider varchar nullable.
- [ ] Add validated_at timestamp nullable.
- [ ] Add validation_response jsonb nullable.
- [ ] Add submission_source varchar: admin, employee.
- [ ] Add approval_status varchar: pending_review, approved, rejected.
- [ ] Add approved_by UUID/bigint nullable.
- [ ] Add approved_at timestamp nullable.
- [ ] Add name_match_status varchar nullable.
- [ ] Add name_match_score numeric nullable.
- [ ] Add last_used_for_payment_at timestamp nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + bank_code.
- [ ] Add index tenant_id + validation_status.
- [ ] Add index tenant_id + approval_status.
- [ ] Add RLS policy for tenant isolation.
- [ ] Add masking strategy for account_number in frontend response.

## employee_tax_profiles

- [ ] Create employee_tax_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add nik varchar nullable.
- [ ] Add npwp varchar nullable.
- [ ] Add ptkp_status varchar.
- [ ] Add tax_method varchar: gross, nett, gross_up.
- [ ] Add tax_enabled boolean default true.
- [ ] Add ter_category varchar nullable.
- [ ] Add submission_source varchar nullable.
- [ ] Add approval_status varchar nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + ptkp_status.
- [ ] Add index tenant_id + tax_method.
- [ ] Add RLS policy for tenant isolation.

## employee_bpjs_profiles

- [ ] Create employee_bpjs_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bpjs_kesehatan_number varchar nullable.
- [ ] Add bpjs_ketenagakerjaan_number varchar nullable.
- [ ] Add bpjs_kesehatan_active boolean default false.
- [ ] Add jht_active boolean default false.
- [ ] Add jp_active boolean default false.
- [ ] Add jkk_active boolean default false.
- [ ] Add jkm_active boolean default false.
- [ ] Add jkp_active boolean default false.
- [ ] Add jkk_risk_level varchar nullable.
- [ ] Add bpjs_base_salary numeric default 0.
- [ ] Add submission_source varchar nullable.
- [ ] Add approval_status varchar nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + bpjs_kesehatan_active.
- [ ] Add index tenant_id + jht_active.
- [ ] Add RLS policy for tenant isolation.

---

# C. Calculation Tables

## payroll_calculations

- [ ] Create payroll_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add attendance_summary jsonb.
- [ ] Add base_salary numeric default 0.
- [ ] Add prorated_salary numeric default 0.
- [ ] Add gross_salary numeric default 0.
- [ ] Add taxable_income numeric default 0.
- [ ] Add non_taxable_income numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add bpjs_employee_total numeric default 0.
- [ ] Add bpjs_employer_total numeric default 0.
- [ ] Add pph21_amount numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add calculation_status varchar default 'success'.
- [ ] Add calculation_note text nullable.
- [ ] Add calculation_snapshot jsonb nullable.
- [ ] Add calculated_at timestamp nullable.
- [ ] Add calculated_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_calculation_items

- [ ] Create payroll_calculation_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_calculation_id UUID references payroll_calculations(id).
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add salary_component_id UUID nullable.
- [ ] Add item_code varchar.
- [ ] Add item_name varchar.
- [ ] Add item_type varchar: earning, deduction, benefit, tax, bpjs.
- [ ] Add amount numeric default 0.
- [ ] Add quantity numeric default 1.
- [ ] Add rate numeric default 0.
- [ ] Add calculation_source varchar.
- [ ] Add is_taxable boolean default true.
- [ ] Add is_visible_on_payslip boolean default true.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_calculation_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

---

# D. BPJS and Tax Tables

## bpjs_rate_settings

- [ ] Create bpjs_rate_settings table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID nullable for tenant override or null for system default.
- [ ] Add program_code varchar.
- [ ] Add program_name varchar.
- [ ] Add employee_rate numeric default 0.
- [ ] Add employer_rate numeric default 0.
- [ ] Add salary_cap numeric nullable.
- [ ] Add risk_level varchar nullable for JKK.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_company_override boolean default false.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index program_code + effective_start_date.
- [ ] Add index tenant_id + program_code.

## bpjs_employee_calculations

- [ ] Create bpjs_employee_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add program_code varchar.
- [ ] Add base_salary numeric default 0.
- [ ] Add employee_rate numeric default 0.
- [ ] Add employer_rate numeric default 0.
- [ ] Add employee_amount numeric default 0.
- [ ] Add employer_amount numeric default 0.
- [ ] Add total_amount numeric default 0.
- [ ] Add calculation_note text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + program_code.
- [ ] Add RLS policy for tenant isolation.

## tax_ptkp_settings

- [ ] Create tax_ptkp_settings table.
- [ ] Add id UUID primary key.
- [ ] Add ptkp_code varchar.
- [ ] Add ptkp_name varchar.
- [ ] Add amount numeric.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().

## tax_ter_settings

- [ ] Create tax_ter_settings table.
- [ ] Add id UUID primary key.
- [ ] Add ter_category varchar.
- [ ] Add income_min numeric.
- [ ] Add income_max numeric nullable.
- [ ] Add rate numeric.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index ter_category + income_min + income_max.

## tax_pph21_calculations

- [ ] Create tax_pph21_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add ptkp_status varchar.
- [ ] Add tax_method varchar.
- [ ] Add ter_category varchar nullable.
- [ ] Add gross_income numeric default 0.
- [ ] Add taxable_income numeric default 0.
- [ ] Add tax_rate numeric default 0.
- [ ] Add pph21_amount numeric default 0.
- [ ] Add gross_up_allowance numeric default 0.
- [ ] Add final_tax_adjustment numeric default 0.
- [ ] Add calculation_detail jsonb nullable.
- [ ] Add calculated_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

---

# E. Payslip Tables

## payslips

- [ ] Create payslips table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add payslip_number varchar.
- [ ] Add period_month integer.
- [ ] Add period_year integer.
- [ ] Add gross_salary numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add file_path text nullable.
- [ ] Add file_url text nullable.
- [ ] Add status varchar default 'draft'.
- [ ] Add generated_at timestamp nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add downloaded_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + payslip_number.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

## payslip_items

- [ ] Create payslip_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payslip_id UUID references payslips(id).
- [ ] Add item_code varchar.
- [ ] Add item_name varchar.
- [ ] Add item_type varchar.
- [ ] Add amount numeric default 0.
- [ ] Add sort_order integer default 0.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payslip_id.
- [ ] Add RLS policy for tenant isolation.

## payslip_delivery_logs

- [ ] Create payslip_delivery_logs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payslip_id UUID references payslips(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add channel varchar: email, whatsapp, employee_app.
- [ ] Add recipient varchar.
- [ ] Add status varchar: pending, sent, failed.
- [ ] Add message_template text nullable.
- [ ] Add provider varchar nullable.
- [ ] Add provider_message_id varchar nullable.
- [ ] Add failed_reason text nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payslip_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + channel + status.
- [ ] Add RLS policy for tenant isolation.

---

# F. Payment and Brick Tables

## payroll_payment_batches

- [ ] Create payroll_payment_batches table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add batch_code varchar.
- [ ] Add provider varchar: manual, bank_file, doku, oy, xendit, bank_api, brick.
- [ ] Add source_bank_account_id UUID/bigint nullable.
- [ ] Add total_amount numeric default 0.
- [ ] Add total_employees integer default 0.
- [ ] Add success_count integer default 0.
- [ ] Add failed_count integer default 0.
- [ ] Add pending_count integer default 0.
- [ ] Add status varchar default 'pending'.
- [ ] Add provider_batch_id varchar nullable.
- [ ] Add provider_response jsonb nullable.
- [ ] Add funding_status varchar default 'not_created'.
- [ ] Add funding_method varchar nullable.
- [ ] Add funding_va_bank varchar nullable.
- [ ] Add funding_va_bank_code varchar nullable.
- [ ] Add funding_va_number varchar nullable.
- [ ] Add funding_va_name varchar nullable.
- [ ] Add funding_amount numeric default 0.
- [ ] Add funding_expired_at timestamp nullable.
- [ ] Add funding_paid_at timestamp nullable.
- [ ] Add disbursement_status varchar default 'not_started'.
- [ ] Add brick_batch_id varchar nullable.
- [ ] Add brick_reference_id varchar nullable.
- [ ] Add brick_status varchar nullable.
- [ ] Add brick_response jsonb nullable.
- [ ] Add submitted_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + batch_code.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + funding_status.
- [ ] Add index tenant_id + disbursement_status.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_items

- [ ] Create payroll_payment_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payment_batch_id UUID references payroll_payment_batches(id).
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bank_name varchar.
- [ ] Add bank_code varchar.
- [ ] Add account_number varchar.
- [ ] Add account_holder_name varchar.
- [ ] Add amount numeric default 0.
- [ ] Add transfer_note text nullable.
- [ ] Add status varchar default 'pending'.
- [ ] Add provider_transaction_id varchar nullable.
- [ ] Add provider_reference varchar nullable.
- [ ] Add brick_transaction_id varchar nullable.
- [ ] Add brick_reference_id varchar nullable.
- [ ] Add brick_status varchar nullable.
- [ ] Add failure_code varchar nullable.
- [ ] Add failure_reason text nullable.
- [ ] Add manual_paid boolean default false.
- [ ] Add manual_paid_at timestamp nullable.
- [ ] Add manual_paid_by UUID/bigint nullable.
- [ ] Add manual_paid_reference varchar nullable.
- [ ] Add manual_paid_note text nullable.
- [ ] Add resolution_status varchar nullable.
- [ ] Add resolution_note text nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add resolved_at timestamp nullable.
- [ ] Add switched_bank_account_id UUID nullable.
- [ ] Add retry_count integer default 0.
- [ ] Add last_retry_at timestamp nullable.
- [ ] Add paid_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + payment_batch_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + resolution_status.
- [ ] Add index tenant_id + manual_paid.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_attempts

- [ ] Create payroll_payment_attempts table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payment_item_id UUID references payroll_payment_items(id).
- [ ] Add attempt_number integer default 1.
- [ ] Add provider varchar.
- [ ] Add request_payload jsonb nullable.
- [ ] Add response_payload jsonb nullable.
- [ ] Add status varchar.
- [ ] Add error_code varchar nullable.
- [ ] Add error_message text nullable.
- [ ] Add attempted_at timestamp default now().
- [ ] Add index tenant_id + payment_item_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_webhooks

- [ ] Create payroll_payment_webhooks table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID nullable.
- [ ] Add provider varchar.
- [ ] Add event_type varchar.
- [ ] Add provider_transaction_id varchar nullable.
- [ ] Add provider_batch_id varchar nullable.
- [ ] Add raw_payload jsonb not null.
- [ ] Add signature_valid boolean default false.
- [ ] Add processed boolean default false.
- [ ] Add processed_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index provider + provider_transaction_id.
- [ ] Add index provider + provider_batch_id.
- [ ] Add index processed.

---

# G. Approval, Audit, Issues, Settings

## payroll_approval_flows

- [ ] Create payroll_approval_flows table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add flow_name varchar.
- [ ] Add applies_to_payroll_type varchar nullable.
- [ ] Add amount_threshold numeric nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + is_active.
- [ ] Add RLS policy for tenant isolation.

## payroll_approval_steps

- [ ] Create payroll_approval_steps table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add approval_flow_id UUID references payroll_approval_flows(id).
- [ ] Add step_order integer.
- [ ] Add role_required varchar.
- [ ] Add specific_approver_id UUID/bigint nullable.
- [ ] Add approval_type varchar default 'single'.
- [ ] Add is_required boolean default true.
- [ ] Add can_request_revision boolean default true.
- [ ] Add can_approve_payment boolean default false.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + approval_flow_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_approval_histories

- [ ] Create payroll_approval_histories table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add approval_step_id UUID nullable.
- [ ] Add action varchar: submitted, approved, rejected, revision_requested.
- [ ] Add note text nullable.
- [ ] Add acted_by UUID/bigint nullable.
- [ ] Add acted_at timestamp default now().
- [ ] Add approver_role_snapshot varchar nullable.
- [ ] Add payroll_amount_snapshot numeric nullable.
- [ ] Add total_employee_snapshot integer nullable.
- [ ] Add checkbox_confirmed boolean default false.
- [ ] Add drag_confirmed boolean default false.
- [ ] Add confirmation_text text nullable.
- [ ] Add ip_address varchar nullable.
- [ ] Add user_agent text nullable.
- [ ] Add approval_device jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_issues

- [ ] Create payroll_issues table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID nullable references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID nullable references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint nullable.
- [ ] Add issue_code varchar.
- [ ] Add issue_title varchar.
- [ ] Add issue_description text nullable.
- [ ] Add severity varchar: info, warning, blocking.
- [ ] Add status varchar default 'open'.
- [ ] Add source varchar.
- [ ] Add suggested_actions jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add resolved_at timestamp nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + issue_code.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_issue_resolutions

- [ ] Create payroll_issue_resolutions table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_issue_id UUID references payroll_issues(id).
- [ ] Add resolution_action varchar.
- [ ] Add resolution_note text nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add resolved_at timestamp default now().
- [ ] Add old_values jsonb nullable.
- [ ] Add new_values jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add index tenant_id + payroll_issue_id.
- [ ] Add RLS policy for tenant isolation.

## employee_profile_submission_requests

- [ ] Create employee_profile_submission_requests table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint not null.
- [ ] Add request_type varchar: bank, tax, bpjs, payroll_profile.
- [ ] Add title varchar.
- [ ] Add message text.
- [ ] Add status varchar default 'pending'.
- [ ] Add due_date date nullable.
- [ ] Add sent_by UUID/bigint nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + request_type + status.
- [ ] Add RLS policy for tenant isolation.

## employee_profile_submissions

- [ ] Create employee_profile_submissions table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint not null.
- [ ] Add request_id UUID nullable references employee_profile_submission_requests(id).
- [ ] Add submission_type varchar: bank, tax, bpjs.
- [ ] Add payload jsonb not null.
- [ ] Add status varchar default 'pending_review'.
- [ ] Add reviewed_by UUID/bigint nullable.
- [ ] Add reviewed_at timestamp nullable.
- [ ] Add rejection_reason text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + submission_type + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_settings

- [ ] Create payroll_settings table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add setting_group varchar.
- [ ] Add setting_key varchar.
- [ ] Add setting_value jsonb.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + setting_group + setting_key.
- [ ] Add index tenant_id + setting_group.
- [ ] Add RLS policy for tenant isolation.

## payroll_report_exports

- [ ] Create payroll_report_exports table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add report_type varchar.
- [ ] Add period_type varchar: monthly, yearly, custom.
- [ ] Add month integer nullable.
- [ ] Add year integer nullable.
- [ ] Add start_date date nullable.
- [ ] Add end_date date nullable.
- [ ] Add scope_type varchar: all, department, branch, selected_employees, single_employee.
- [ ] Add scope_payload jsonb nullable.
- [ ] Add format varchar: pdf, excel, csv, zip.
- [ ] Add status varchar default 'pending'.
- [ ] Add file_path text nullable.
- [ ] Add file_url text nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add completed_at timestamp nullable.
- [ ] Add failed_reason text nullable.
- [ ] Add index tenant_id + report_type.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_audit_logs

- [ ] Create payroll_audit_logs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID nullable.
- [ ] Add employee_id UUID/bigint nullable.
- [ ] Add actor_id UUID/bigint nullable.
- [ ] Add event_type varchar.
- [ ] Add description text.
- [ ] Add old_values jsonb nullable.
- [ ] Add new_values jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add ip_address varchar nullable.
- [ ] Add user_agent text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + event_type.
- [ ] Add RLS policy for tenant isolation.


---

# 05 — Final Laravel Structure, Services, Jobs

## Laravel Controllers

```text
app/Http/Controllers/Payroll/
├── PayrollOverviewController.php
├── PayrollRunController.php
├── SalaryComponentController.php
├── EmployeePayrollController.php
├── PayslipController.php
├── BPJSController.php
├── TaxPph21Controller.php
├── PayrollReportController.php
├── PayrollSettingController.php
├── PayrollPaymentController.php
├── PayrollIssueController.php
├── PayrollRunStepController.php
└── PayrollReminderController.php

app/Http/Controllers/Webhook/
├── PayrollPaymentWebhookController.php
└── BrickPaymentWebhookController.php
```

---

## Laravel Requests

```text
app/Http/Requests/Payroll/
├── CreatePayrollRunRequest.php
├── UpdatePayrollRunRequest.php
├── SelectPayrollEmployeesRequest.php
├── CalculatePayrollRequest.php
├── SubmitPayrollApprovalRequest.php
├── ApprovePayrollRequest.php
├── RejectPayrollRequest.php
├── ResolvePayrollIssueRequest.php
├── CreateSalaryComponentRequest.php
├── UpdateEmployeePayrollInfoRequest.php
├── UpdateEmployeeBankAccountRequest.php
├── ValidateEmployeeBankAccountRequest.php
├── GeneratePayslipRequest.php
├── SendPayslipRequest.php
├── CreatePaymentBatchRequest.php
├── SendPayrollPaymentRequest.php
├── MarkManualPaidRequest.php
├── SwitchBankAccountRequest.php
├── ExportPayrollReportRequest.php
└── UpdatePayrollSettingsRequest.php
```

---

## Laravel Resources

```text
app/Http/Resources/Payroll/
├── PayrollOverviewResource.php
├── PayrollRunResource.php
├── PayrollRunStepResource.php
├── PayrollEmployeeResource.php
├── SalaryComponentResource.php
├── EmployeePayrollProfileResource.php
├── EmployeeBankAccountResource.php
├── PayslipResource.php
├── BPJSCalculationResource.php
├── Pph21CalculationResource.php
├── PayrollPaymentBatchResource.php
├── PayrollPaymentItemResource.php
├── PayrollIssueResource.php
└── PayrollReportExportResource.php
```

---

## Laravel Payroll Services

```text
app/Services/Payroll/
├── PayrollOverviewService.php
├── PayrollRunService.php
├── PayrollCalculationService.php
├── SalaryComponentService.php
├── AttendancePayrollSyncService.php
├── BPJSCalculationService.php
├── Pph21CalculationService.php
├── PayrollApprovalService.php
├── PayslipService.php
├── PayrollReportService.php
├── PayrollPaymentService.php
├── PayrollValidationService.php
├── PayrollAuditService.php
├── PayrollIssueService.php
├── PayrollIssueResolutionService.php
├── PayrollRunStepService.php
├── PayrollReminderService.php
├── PayslipDeliveryService.php
├── PayrollExportService.php
└── EmployeePayrollProfileService.php
```

---

## Laravel Payment Services

```text
app/Services/Payment/
├── DisbursementProviderInterface.php
├── ManualPaymentProvider.php
├── BankFileExportProvider.php
├── DokuDisbursementProvider.php
├── OyDisbursementProvider.php
├── BrickDisbursementProvider.php
├── BrickFundingVirtualAccountService.php
├── BrickWebhookService.php
└── PaymentWebhookService.php
```

---

## Laravel Supabase Services

```text
app/Services/Supabase/
├── SupabasePayrollRepository.php
├── SupabaseRpcService.php
├── SupabaseStorageService.php
└── SupabaseReportRepository.php
```

---

## Laravel Jobs

```text
app/Jobs/Payroll/
├── CalculatePayrollJob.php
├── CalculateEmployeePayrollJob.php
├── SyncPayrollAttendanceJob.php
├── GeneratePayslipPdfJob.php
├── SendPayslipDeliveryJob.php
├── CreatePaymentBatchJob.php
├── CreateBrickFundingVaJob.php
├── CheckBrickFundingStatusJob.php
├── SendBrickDisbursementBatchJob.php
├── RetryBrickFailedDisbursementJob.php
├── ExportPayrollReportJob.php
└── SendEmployeePayrollReminderJob.php
```

---

## Laravel Enums

```text
app/Enums/
├── PayrollStatus.php
├── PayrollType.php
├── PayrollRunStepStatus.php
├── PayrollPaymentStatus.php
├── PayrollFundingStatus.php
├── SalaryComponentType.php
├── ApprovalStatus.php
├── TaxMethod.php
├── BpjsProgram.php
├── PayrollIssueStatus.php
├── PayrollIssueSeverity.php
└── PayslipDeliveryChannel.php
```

---

# Service Logic Tasks

## PayrollOverviewService

- [ ] Build getOverview method.
- [ ] Build getWidgetActions method.
- [ ] Build getDepartmentCostDetail method.
- [ ] Build getPayrollAlerts method.
- [ ] Build getPayrollProcessSteps method.
- [ ] Build getStepDetail method.
- [ ] Validate tenant access.
- [ ] Validate user role permission.

## PayrollRunService

- [ ] Build createPayrollRun method.
- [ ] Apply payroll type defaults.
- [ ] Initialize payroll run steps.
- [ ] Select default employees if monthly payroll.
- [ ] Pull failed payment employees if correction payroll.
- [ ] Update payroll status lifecycle.
- [ ] Lock payroll after final approval.
- [ ] Create payment batch after lock if setting enabled.

## PayrollRunStepService

- [ ] Initialize default steps.
- [ ] Update step status.
- [ ] Update progress percentage.
- [ ] Save step metadata.
- [ ] Return step detail for popup/right sheet.
- [ ] Track warnings and errors.

## PayrollCalculationService

- [ ] Calculate base salary.
- [ ] Calculate prorated salary.
- [ ] Apply salary components.
- [ ] Calculate attendance impact.
- [ ] Calculate overtime.
- [ ] Calculate BPJS.
- [ ] Calculate PPh21.
- [ ] Calculate gross salary.
- [ ] Calculate total deduction.
- [ ] Calculate net salary.
- [ ] Save calculation snapshot.
- [ ] Create issues if calculation fails.

## PayrollApprovalService

- [ ] Submit approval.
- [ ] Load approval flow.
- [ ] Validate current approver.
- [ ] Validate approval step order.
- [ ] Require checkbox confirmation.
- [ ] Require drag-to-confirm if setting enabled.
- [ ] Save approval metadata.
- [ ] Allow reject with reason.
- [ ] Allow request revision.
- [ ] Lock payroll after final approval.
- [ ] Trigger payment batch creation after final approval.

## PayrollIssueService

- [ ] Create payroll issue.
- [ ] Group issue by payroll run.
- [ ] Group issue by employee.
- [ ] Return suggested actions.
- [ ] Support missing bank account.
- [ ] Support invalid bank account.
- [ ] Support tax/BPJS missing.
- [ ] Support calculation failed.
- [ ] Support payment failed.
- [ ] Support Brick funding expired.

## PayrollIssueResolutionService

- [ ] Resolve issue by edit bank.
- [ ] Resolve issue by switch bank.
- [ ] Resolve issue by request employee update.
- [ ] Resolve issue by mark manual paid.
- [ ] Resolve issue by exclude employee.
- [ ] Resolve issue by retry payment.
- [ ] Resolve issue by recalculate.
- [ ] Save resolution note.
- [ ] Save audit log.

## PayslipService

- [ ] Generate payslip record.
- [ ] Generate payslip items snapshot.
- [ ] Generate PDF.
- [ ] Upload PDF to Supabase Storage.
- [ ] Regenerate payslip with reason.
- [ ] Return payslip right sheet detail.

## PayslipDeliveryService

- [ ] Send payslip to email.
- [ ] Send payslip to WhatsApp.
- [ ] Send employee app notification.
- [ ] Support recipient scope.
- [ ] Save delivery logs.
- [ ] Retry failed delivery.

## PayrollPaymentService

- [ ] Create payment batch.
- [ ] Validate employee bank accounts.
- [ ] Create payment items.
- [ ] Mark manual paid.
- [ ] Retry failed payment.
- [ ] Switch employee bank account.
- [ ] Generate receipt.
- [ ] Export transfer detail.

## BrickFundingVirtualAccountService

- [ ] Generate Brick Funding VA.
- [ ] Save VA number.
- [ ] Save VA bank.
- [ ] Save VA name.
- [ ] Save funding amount.
- [ ] Save expiry time.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.

## BrickDisbursementProvider

- [ ] Prepare disbursement batch payload.
- [ ] Send disbursement to Brick.
- [ ] Save Brick batch ID.
- [ ] Save Brick transaction IDs.
- [ ] Query transaction status.
- [ ] Retry failed transaction.

## BrickWebhookService

- [ ] Validate webhook signature.
- [ ] Save raw payload.
- [ ] Process funding event.
- [ ] Process disbursement event.
- [ ] Update payment item.
- [ ] Update payment batch.
- [ ] Update payroll run status.
- [ ] Trigger payslip delivery if payment success.

## PayrollExportService

- [ ] Generate PDF report.
- [ ] Generate Excel report.
- [ ] Generate CSV report.
- [ ] Generate ZIP payslip.
- [ ] Upload export file.
- [ ] Save export history.
- [ ] Support async export for large data.

## PayrollReminderService

- [ ] Send missing bank reminder.
- [ ] Send missing tax reminder.
- [ ] Send missing BPJS reminder.
- [ ] Create employee submission request.
- [ ] Track reminder completion.
- [ ] Notify admin after employee submission.


---

# 06 — Final API Routes

## Payroll Overview

```text
GET /api/payroll/overview
GET /api/payroll/overview/widgets/{widgetKey}/actions
GET /api/payroll/overview/department-cost-detail
GET /api/payroll/issues/summary
```

## Payroll Run

```text
GET /api/payroll/runs
POST /api/payroll/runs
GET /api/payroll/runs/{id}
PUT /api/payroll/runs/{id}
DELETE /api/payroll/runs/{id}
GET /api/payroll/runs/{id}/steps
GET /api/payroll/runs/{id}/steps/{stepCode}
GET /api/payroll/runs/{id}/employees
GET /api/payroll/runs/{id}/eligible-employees
POST /api/payroll/runs/{id}/select-employees
POST /api/payroll/runs/{id}/sync-attendance
POST /api/payroll/runs/{id}/calculate
GET /api/payroll/runs/{id}/calculation-progress
POST /api/payroll/runs/{id}/recalculate
POST /api/payroll/runs/{id}/employees/{employeeId}/recalculate
POST /api/payroll/runs/{id}/submit-approval
POST /api/payroll/runs/{id}/approve
POST /api/payroll/runs/{id}/reject
POST /api/payroll/runs/{id}/request-revision
POST /api/payroll/runs/{id}/lock
POST /api/payroll/runs/{id}/payment-batch
POST /api/payroll/runs/{id}/cancel
```

## Salary Components

```text
GET /api/payroll/salary-components
POST /api/payroll/salary-components
GET /api/payroll/salary-components/{id}
PUT /api/payroll/salary-components/{id}
DELETE /api/payroll/salary-components/{id}
POST /api/payroll/salary-components/{id}/activate
POST /api/payroll/salary-components/{id}/deactivate
```

## Employee Payroll Info

```text
GET /api/payroll/employees
GET /api/payroll/employees/{employeeId}
PUT /api/payroll/employees/{employeeId}/profile
GET /api/payroll/employees/{employeeId}/salary-history
POST /api/payroll/employees/{employeeId}/salary-components
DELETE /api/payroll/employees/{employeeId}/salary-components/{componentId}
GET /api/payroll/employees/{employeeId}/bank-accounts
POST /api/payroll/employees/{employeeId}/bank-accounts
PUT /api/payroll/employees/{employeeId}/bank-accounts/{bankId}
DELETE /api/payroll/employees/{employeeId}/bank-accounts/{bankId}
POST /api/payroll/employees/{employeeId}/bank-accounts/{bankId}/validate
POST /api/payroll/employees/{employeeId}/bank-accounts/{bankId}/set-primary
PUT /api/payroll/employees/{employeeId}/tax-profile
PUT /api/payroll/employees/{employeeId}/bpjs-profile
POST /api/payroll/employees/{employeeId}/send-reminder
```

## Employee Self-Service Payroll Data

```text
GET /api/employee/payroll/profile
POST /api/employee/payroll/bank-accounts
POST /api/employee/payroll/tax-profile
POST /api/employee/payroll/bpjs-profile
GET /api/employee/payroll/submission-requests
POST /api/employee/payroll/submission-requests/{requestId}/complete
```

## Payslip

```text
GET /api/payroll/payslips
GET /api/payroll/payslips/{id}
GET /api/payroll/payslips/{id}/detail
POST /api/payroll/runs/{id}/generate-payslips
POST /api/payroll/payslips/{id}/regenerate
POST /api/payroll/payslips/send
GET /api/payroll/payslips/{id}/delivery-logs
GET /api/payroll/payslips/{id}/download
GET /api/employee/payslips
GET /api/employee/payslips/{id}
GET /api/employee/payslips/{id}/download
```

## BPJS

```text
GET /api/payroll/bpjs/settings
POST /api/payroll/bpjs/settings
PUT /api/payroll/bpjs/settings/{id}
GET /api/payroll/bpjs/calculations
GET /api/payroll/bpjs/calculations/{employeeId}
POST /api/payroll/bpjs/recalculate/{employeeId}
GET /api/payroll/bpjs/reports
POST /api/payroll/bpjs/reports/export
```

## Tax / PPh21

```text
GET /api/payroll/tax/settings/ptkp
POST /api/payroll/tax/settings/ptkp
GET /api/payroll/tax/settings/ter
POST /api/payroll/tax/settings/ter
GET /api/payroll/tax/calculations
GET /api/payroll/tax/calculations/{employeeId}
POST /api/payroll/tax/recalculate/{employeeId}
GET /api/payroll/tax/reports
POST /api/payroll/tax/reports/export
```

## Payroll Reports

```text
GET /api/payroll/reports/summary
GET /api/payroll/reports/employee
GET /api/payroll/reports/department
GET /api/payroll/reports/branch
GET /api/payroll/reports/bpjs
GET /api/payroll/reports/pph21
GET /api/payroll/reports/bank-transfer
GET /api/payroll/reports/failed-payment
GET /api/payroll/reports/overtime-cost
GET /api/payroll/reports/attendance-deduction
GET /api/payroll/reports/journal
POST /api/payroll/reports/export
GET /api/payroll/reports/exports/{exportId}
GET /api/payroll/reports/exports/{exportId}/download
```

## Payment / Disbursement / Brick

```text
GET /api/payroll/payments/batches
POST /api/payroll/runs/{id}/payment-batch
GET /api/payroll/payments/batches/{batchId}
POST /api/payroll/payments/batches/{batchId}/validate
POST /api/payroll/runs/{id}/brick/funding-va
GET /api/payroll/runs/{id}/brick/funding-status
POST /api/payroll/payments/batches/{batchId}/brick/send-disbursement
GET /api/payroll/payments/batches/{batchId}/brick/status
POST /api/payroll/payments/items/{itemId}/brick/retry
POST /api/payroll/payments/items/{itemId}/retry
POST /api/payroll/payments/items/{itemId}/switch-bank
POST /api/payroll/payments/items/{itemId}/manual-paid
POST /api/payroll/payments/items/{itemId}/request-bank-update
GET /api/payroll/payments/batches/{batchId}/receipt
GET /api/payroll/payments/batches/{batchId}/export-detail
GET /api/payroll/payments/batches/{batchId}/payslip-zip
POST /api/webhooks/payroll/payments/brick
POST /api/webhooks/payroll/payments/{provider}
```

## Payroll Issues

```text
GET /api/payroll/runs/{id}/issues
GET /api/payroll/issues/{issueId}
POST /api/payroll/issues/{issueId}/resolve
POST /api/payroll/issues/{issueId}/request-employee-update
POST /api/payroll/issues/bulk-resolve
```

## Payroll Settings

```text
GET /api/payroll/settings
PUT /api/payroll/settings
GET /api/payroll/settings/general
PUT /api/payroll/settings/general
GET /api/payroll/settings/cutoff
PUT /api/payroll/settings/cutoff
GET /api/payroll/settings/payroll-type-defaults
PUT /api/payroll/settings/payroll-type-defaults
GET /api/payroll/settings/employee-selection-rules
PUT /api/payroll/settings/employee-selection-rules
GET /api/payroll/settings/salary-calculation-rules
PUT /api/payroll/settings/salary-calculation-rules
GET /api/payroll/settings/attendance-impact-rules
PUT /api/payroll/settings/attendance-impact-rules
GET /api/payroll/settings/overtime-rules
PUT /api/payroll/settings/overtime-rules
GET /api/payroll/settings/proration-rules
PUT /api/payroll/settings/proration-rules
GET /api/payroll/settings/payslip
PUT /api/payroll/settings/payslip
GET /api/payroll/settings/payslip-delivery
PUT /api/payroll/settings/payslip-delivery
GET /api/payroll/settings/payment-provider
PUT /api/payroll/settings/payment-provider
POST /api/payroll/settings/payment-provider/test-connection
GET /api/payroll/settings/brick
PUT /api/payroll/settings/brick
POST /api/payroll/settings/brick/test-connection
GET /api/payroll/settings/approval-flows
POST /api/payroll/settings/approval-flows
PUT /api/payroll/settings/approval-flows/{id}
DELETE /api/payroll/settings/approval-flows/{id}
POST /api/payroll/settings/approval-flows/{id}/steps
PUT /api/payroll/settings/approval-flows/{id}/steps/{stepId}
DELETE /api/payroll/settings/approval-flows/{id}/steps/{stepId}
GET /api/payroll/settings/reminders
PUT /api/payroll/settings/reminders
GET /api/payroll/settings/report-export
PUT /api/payroll/settings/report-export
GET /api/payroll/settings/security-access
PUT /api/payroll/settings/security-access
GET /api/payroll/settings/audit-log
PUT /api/payroll/settings/audit-log
```


---

# 07 — Main Payroll Logic

## Final End-to-End Logic

```text
Create Payroll Period
→ Create Payroll Run
→ Select Payroll Type
→ Apply Payroll Type Defaults
→ Select Employees
→ Validate Employee Payroll Data
→ Sync Attendance
→ Calculate Salary
→ Calculate Allowance & Deduction
→ Calculate BPJS
→ Calculate PPh21
→ Review Payroll
→ Resolve Issues
→ Submit Approval
→ Approval Confirmation
→ Final Approval
→ Lock Payroll
→ Create Payment Batch
→ Generate Brick Funding VA
→ Company Pays VA
→ Brick Confirms Funding Paid
→ Send Brick Disbursement
→ Receive Webhook Status
→ Retry / Resolve Failed Payment
→ Generate Payslip
→ Send Payslip
→ Export Reports
```

---

## Payroll Type Logic

## Monthly Payroll

```text
- Auto include active monthly employees.
- Use default cut-off.
- Require attendance sync.
- Require BPJS if enabled.
- Require PPh21 if enabled.
- Require approval.
- Require payment batch.
- Require disbursement.
```

## Correction Payroll

```text
- Flexible employee selection.
- Can pull failed transfer employees from payment items.
- Can add manual earning/deduction adjustment.
- Can regenerate correction payslip.
- Can use approval based on settings.
```

## THR Payroll

```text
- Include eligible employees.
- Use THR formula.
- Attendance sync optional.
- Tax calculation required.
- Approval required.
- Disbursement enabled if setting active.
```

## Failed Payment Retry Payroll

```text
- Pull failed payment items.
- Does not recalculate salary unless correction needed.
- Allows switch bank account.
- Allows retry transfer.
- Allows mark manual paid.
```

---

## Payroll Run Step Logic

## Step 1 — Setup Payroll

```text
- Create period/run.
- Apply payroll type defaults.
- Initialize run steps.
- Validate cut-off and payment date.
```

## Step 2 — Select Employees

```text
- Auto select employees if monthly payroll.
- Manual select if correction/bonus.
- Pull failed payment employees if failed retry/correction.
- Validate payroll profile, bank, tax, BPJS.
- Create issues for missing data.
```

## Step 3 — Sync Attendance

```text
- Pull attendance between cut-off dates.
- Count present/late/absent/leave/sick/unpaid leave.
- Count overtime/no checkout/attendance flags.
- Save attendance_summary snapshot.
```

## Step 4 — Calculate Salary

```text
- Load payroll profile.
- Load salary components.
- Calculate base salary.
- Calculate prorated salary.
- Calculate earnings.
- Calculate deductions.
- Calculate overtime.
- Calculate attendance deduction.
- Calculate BPJS.
- Calculate PPh21.
- Save calculation result and items.
```

## Step 5 — Review and Resolve Issues

```text
- Show employee list.
- Show calculation result.
- Show issue badges.
- Allow resolve: edit bank, switch bank, request update, exclude, recalculate.
```

## Step 6 — Approval

```text
- Submit approval.
- Load approval flow.
- Approver confirms with checkbox and drag-to-confirm.
- Save role, amount, employee count, IP, user agent.
- Final approval locks payroll.
```

## Step 7 — Payment Batch

```text
- Create payment batch after lock.
- Create payment item per employee.
- Validate bank account.
- Mark invalid payments as issue.
```

## Step 8 — Brick Funding VA

```text
- Generate VA.
- Company pays VA.
- Brick webhook confirms funding.
```

## Step 9 — Brick Disbursement

```text
- Send disbursement after funding paid.
- Track status per employee.
- Retry/switch/manual paid if failed.
```

## Step 10 — Payslip

```text
- Generate payslip snapshot.
- Generate PDF.
- Send by email/WhatsApp/app.
- Save delivery logs.
```

---

## Calculation Formula

```text
Gross Salary
= Base Salary
+ Fixed Earnings
+ Variable Earnings
+ Overtime
+ Bonus
+ Reimbursement
+ THR/Commission if applicable
```

```text
Total Deduction
= Attendance Deduction
+ Unpaid Leave Deduction
+ Loan Deduction
+ BPJS Employee Contribution
+ PPh21
+ Other Deduction
```

```text
Net Salary
= Gross Salary - Total Deduction
```

---

## Snapshot Rule

Every payroll calculation must save snapshot:

```text
- employee payroll profile
- salary components
- attendance summary
- BPJS rate
- tax rate
- calculation result
```

Reason:

```text
Changes in future salary/profile/settings must not change old payroll result.
```


---

# 08 — Brick VA and Disbursement Logic

## Correct Brick Flow

```text
Payroll Approved
→ Payroll Locked
→ Payment Batch Created
→ Generate Brick Funding VA
→ Company pays VA
→ Brick confirms funding via webhook
→ Bianore sends disbursement batch
→ Brick transfers salary to employee bank accounts
→ Brick sends payment status webhook
→ Bianore updates statuses
→ Failed payments can be retried/resolved
→ Payslip is sent
```

---

## Funding vs Disbursement

```text
Funding VA = company pays total payroll amount into Brick funding VA.
Disbursement = Brick sends salary to each employee bank account.
```

---

## Funding Status

```text
not_created
waiting_va_payment
funding_paid
funding_expired
funding_failed
```

## Disbursement Status

```text
not_started
pending
processing
success
partially_paid
failed
```

---

## Brick Funding VA Right Sheet

When status = waiting_va_payment:

```text
Brick Virtual Account Payment
├── VA Bank
├── VA Number
├── VA Name
├── Amount
├── Expired At
├── Copy VA Number
├── Download Payment Instruction
├── Check Funding Status
└── Regenerate VA if expired
```

---

## Success Payment Detail

When status = success:

```text
Payment Batch Success Detail
├── Payroll Type
├── Period
├── Total Employees
├── Total Amount
├── Provider: Brick
├── Funding Paid At
├── Disbursement Completed At
├── Success Count
├── Failed Count
├── Payment Reference
├── Download Payment Receipt
├── Download Employee Transfer Report
└── Download Payslip Batch
```

---

## Failed Transfer Resolution

When some transfers fail:

```text
Failed Transfers
├── Employee Name
├── Bank
├── Account Number Masked
├── Amount
├── Failure Reason
├── Retry Selected
├── Retry All Failed
├── Switch Bank Account
├── Request Employee Update Bank
└── Mark as Manual Paid
```

---

## Brick Service Tasks

- [ ] Generate Brick Funding VA.
- [ ] Save VA detail to payroll_payment_batches.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.
- [ ] Send disbursement batch after funding paid.
- [ ] Save Brick batch ID.
- [ ] Save Brick transaction IDs.
- [ ] Process transfer success webhook.
- [ ] Process transfer failed webhook.
- [ ] Retry failed transfer.
- [ ] Switch bank and retry.
- [ ] Mark as manual paid.
- [ ] Generate payment receipt.
- [ ] Export transfer detail.

---

## Brick Webhook Handler

```text
POST /api/webhooks/payroll/payments/brick
```

- [ ] Validate webhook signature.
- [ ] Save raw webhook payload.
- [ ] Identify event type.
- [ ] Identify funding reference or transaction reference.
- [ ] Update funding status if funding event.
- [ ] Update payment item status if transfer event.
- [ ] Update batch summary counts.
- [ ] Update payroll run status.
- [ ] Trigger payslip delivery if payment success.
- [ ] Mark webhook as processed.
- [ ] Add audit log.


---

# 09 — Complete Payroll Settings

## Payroll Settings — Final Complete Structure

```text
Payroll Settings
├── General Payroll Settings
├── Payroll Period & Cut-off
├── Payroll Type Defaults
├── Employee Selection Rules
├── Salary Calculation Rules
├── Salary Component Rules
├── Attendance Impact Rules
├── Overtime Rules
├── Proration Rules
├── BPJS Settings
├── PPh21 / Tax Settings
├── Payslip Settings
├── Payslip Delivery Settings
├── Payment / Disbursement Settings
├── Brick Funding VA Settings
├── Bank Account Validation Settings
├── Approval Flow Settings
├── Reminder & Employee Completion Settings
├── Report Export Settings
├── Security & Access Settings
└── Audit Log Settings
```

---

## 1. General Payroll Settings

```text
General Payroll Settings
├── Default currency
├── Payroll timezone
├── Payroll numbering format
├── Default payroll status
├── Default payment day
├── Default working days
├── Default working hours
├── Company payroll identity
└── Payroll rounding behavior
```

## 2. Payroll Period & Cut-off

```text
Payroll Period & Cut-off
├── Default cut-off start day
├── Default cut-off end day
├── Default payroll month rule
├── Default payment date rule
├── Auto create payroll period
├── Lock period after payroll paid
└── Allow correction after period locked
```

## 3. Payroll Type Defaults

```text
Payroll Type Defaults
├── Monthly Payroll
├── Correction Payroll
├── THR Payroll
├── Bonus Payroll
├── Final Payroll
└── Failed Payment Retry Payroll
```

## 4. Employee Selection Rules

```text
Employee Selection Rules
├── Include active employees
├── Include employee by salary type
├── Include by employment type
├── Include by branch
├── Include by department
├── Exclude inactive employees
├── Exclude resign employees
├── Exclude employees with incomplete payroll data
├── Allow manual add/remove employee
└── Pull failed payment employee for correction payroll
```

## 5. Salary Calculation Rules

```text
Salary Calculation Rules
├── Base salary calculation method
├── Daily rate formula
├── Hourly rate formula
├── Working day basis
├── Calendar day basis
├── Fixed salary rule
├── Daily worker rule
├── Hourly worker rule
├── Minimum payable amount
└── Rounding rule
```

## 6. Salary Component Rules

```text
Salary Component Rules
├── Default earnings
├── Default deductions
├── Default benefits
├── Taxable component mapping
├── Non-taxable component mapping
├── BPJS base component mapping
├── Visible on payslip rule
├── Recurring component rule
├── One-time component rule
├── Component effective date
└── Prevent delete if component already used
```

## 7. Attendance Impact Rules

```text
Attendance Impact Rules
├── Attendance sync required
├── Late deduction enabled
├── Absent deduction enabled
├── Unpaid leave deduction enabled
├── No checkout impact
├── Attendance bonus rule
├── Meal allowance based on attendance
├── Transport allowance based on attendance
├── Attendance issue blocking payroll
└── Attendance override impact
```

## 8. Overtime Rules

```text
Overtime Rules
├── Overtime enabled
├── Overtime eligible employees
├── Overtime formula
├── Overtime approval required
├── Overtime rounding
├── Maximum overtime per day
├── Maximum overtime per month
├── Weekday overtime rate
├── Weekend overtime rate
└── Holiday overtime rate
```

## 9. Proration Rules

```text
Proration Rules
├── Calendar days method
├── Working days method
├── Fixed divisor method
├── Join date proration
├── Resign date proration
├── Unpaid leave proration
├── Component prorated/non-prorated
└── Minimum working days rule
```

## 10. BPJS Settings

```text
BPJS Settings
├── BPJS Kesehatan rate
├── BPJS Ketenagakerjaan rate
├── JHT rate
├── JP rate
├── JKK risk level rate
├── JKM rate
├── JKP rate if used
├── Salary cap
├── Employer contribution
├── Employee contribution
├── Effective date
├── System default
├── Company override
└── BPJS report format
```

## 11. PPh21 / Tax Settings

```text
PPh21 / Tax Settings
├── PTKP table
├── TER table
├── Tax method default
├── Gross method
├── Nett method
├── Gross up method
├── Taxable component mapping
├── Non-taxable component mapping
├── Final month adjustment
├── Yearly tax summary
├── Effective date
├── Government default
└── Company override permission
```

## 12. Payslip Settings

```text
Payslip Settings
├── Payslip numbering format
├── Payslip template
├── Show earnings breakdown
├── Show deductions breakdown
├── Show BPJS detail
├── Show PPh21 detail
├── Show payment status
├── Show company logo
├── Show signature
├── Allow employee download
├── Allow regenerate payslip
└── Require regenerate reason
```

## 13. Payslip Delivery Settings

```text
Payslip Delivery Settings
├── Enable email delivery
├── Enable WhatsApp delivery
├── Enable employee app notification
├── Send after payroll paid
├── Send after payslip generated
├── Manual send only
├── Attach PDF
├── Message template
├── Skip employee without email/phone
├── Retry failed delivery
└── Delivery log
```

## 14. Payment / Disbursement Settings

```text
Payment / Disbursement Settings
├── Payment mode
│   ├── Manual
│   ├── Bank file export
│   └── Auto disbursement API
├── Active provider
├── Source bank account
├── Payment approval required
├── Allow manual paid
├── Allow retry failed payment
├── Allow switch employee bank account
├── Export bank file format
├── Payment receipt format
└── Payment webhook setting
```

## 15. Brick Funding VA Settings

```text
Brick Funding VA Settings
├── Brick enabled
├── Brick mode: sandbox / production
├── Funding method: virtual account
├── Default VA bank
├── VA expiry duration
├── Auto generate VA after approval
├── Auto send disbursement after funding paid
├── Retry failed disbursement enabled
├── Max retry attempts
├── Brick webhook URL
├── Brick connection status
├── Brick credential health
└── Masked API key display
```

## 16. Bank Account Validation Settings

```text
Bank Account Validation Settings
├── Allow employee submit bank account
├── Require admin approval
├── Allow primary bank
├── Allow secondary bank
├── Validate via Brick account inquiry
├── Name matching tolerance
├── Allow name mismatch with approval
├── Allow switch bank after failed payment
└── Require validation before payroll
```

## 17. Approval Flow Settings

```text
Approval Flow Settings
├── Approval flow list
├── Applies to payroll type
├── Add approval step
├── Edit approval step
├── Delete approval step
├── Reorder approval step
├── Select approver role
├── Select specific approver person
├── Conditional approval
├── Amount threshold approval
├── Branch/department condition
├── Require checkbox confirmation
├── Require drag-to-confirm
├── Allow request revision
├── Auto lock after final approval
└── Auto create payment batch after final approval
```

## 18. Reminder & Employee Completion Settings

```text
Reminder & Employee Completion Settings
├── Missing bank reminder
├── Missing tax reminder
├── Missing BPJS reminder
├── Invalid bank reminder
├── Send to employee app
├── Send to email
├── Send to WhatsApp
├── Auto reminder before payroll date
├── Reminder template
├── Employee submission requires approval
└── Completion tracking
```

## 19. Report Export Settings

```text
Report Export Settings
├── Enable PDF export
├── Enable Excel export
├── Enable CSV export
├── Enable ZIP payslip export
├── Default report format
├── Report watermark
├── Include company signature
├── Include audit metadata
├── Export scope default
└── Async export for large report
```

## 20. Security & Access Settings

```text
Security & Access Settings
├── Payroll access roles
├── Who can create payroll run
├── Who can calculate payroll
├── Who can approve payroll
├── Who can lock payroll
├── Who can generate Brick VA
├── Who can send disbursement
├── Who can mark manual paid
├── Who can edit employee salary
├── Who can edit bank account
├── Who can export reports
└── Sensitive data masking
```

## 21. Audit Log Settings

```text
Audit Log Settings
├── Track salary changes
├── Track bank changes
├── Track tax profile changes
├── Track BPJS profile changes
├── Track payroll calculation
├── Track approval action
├── Track payment action
├── Track manual paid action
├── Track export action
├── Track setting changes
└── Audit retention period
```


---

# 10 — Notion Ready Final Backend Tasks

## Phase 1 — Foundation

```text
- [ ] Confirm final payroll menu structure.
- [ ] Confirm Supabase vs Laravel ownership.
- [ ] Create payroll_periods table.
- [ ] Create payroll_runs table.
- [ ] Create payroll_run_employees table.
- [ ] Create payroll_run_steps table.
- [ ] Create payroll_settings table.
- [ ] Create payroll_audit_logs table.
- [ ] Add tenant_id to all payroll tables.
- [ ] Add RLS policy for tenant isolation.
- [ ] Add indexes for payroll run, employee, status, period.
```

## Phase 2 — Employee Payroll Data

```text
- [ ] Create employee_payroll_profiles table.
- [ ] Create employee_bank_accounts table with primary/secondary slot.
- [ ] Create employee_tax_profiles table.
- [ ] Create employee_bpjs_profiles table.
- [ ] Create employee_salary_components table.
- [ ] Create employee_profile_submission_requests table.
- [ ] Create employee_profile_submissions table.
- [ ] Build EmployeePayrollService.
- [ ] Build BankAccountValidationService or add to PayrollValidationService.
- [ ] Build PayrollReminderService.
- [ ] Add employee self-service payroll submission endpoints.
```

## Phase 3 — Salary Components

```text
- [ ] Create salary_components table.
- [ ] Add component type: earning, deduction, benefit, reimbursement.
- [ ] Add calculation type: fixed, percentage, formula, attendance_based, overtime_based.
- [ ] Add taxable flag.
- [ ] Add BPJS base flag.
- [ ] Add visible on payslip flag.
- [ ] Add effective start/end date.
- [ ] Build SalaryComponentService.
- [ ] Add deactivate instead of delete logic.
- [ ] Add formula validation.
```

## Phase 4 — Payroll Run Flow

```text
- [ ] Build PayrollRunService.
- [ ] Build create payroll run.
- [ ] Apply payroll type default.
- [ ] Initialize payroll run steps.
- [ ] Build select employee flow.
- [ ] Build eligible employees query.
- [ ] Build sync attendance flow.
- [ ] Build calculation progress.
- [ ] Build review payroll data.
- [ ] Build lock payroll.
- [ ] Add right sheet response for payroll run detail.
```

## Phase 5 — Calculation Engine

```text
- [ ] Create payroll_calculations table.
- [ ] Create payroll_calculation_items table.
- [ ] Build PayrollCalculationService.
- [ ] Calculate base salary.
- [ ] Calculate prorated salary.
- [ ] Calculate fixed earnings.
- [ ] Calculate variable earnings.
- [ ] Calculate attendance deduction.
- [ ] Calculate overtime.
- [ ] Calculate BPJS.
- [ ] Calculate PPh21.
- [ ] Calculate net salary.
- [ ] Save calculation snapshot.
- [ ] Create issue if calculation fails.
```

## Phase 6 — BPJS

```text
- [ ] Create bpjs_rate_settings table.
- [ ] Create bpjs_employee_calculations table.
- [ ] Create bpjs_company_calculations table if needed.
- [ ] Build BPJSCalculationService.
- [ ] Add system default vs company override.
- [ ] Add effective date.
- [ ] Add salary cap.
- [ ] Add employee contribution.
- [ ] Add employer contribution.
- [ ] Add BPJS calculation right sheet response.
- [ ] Add BPJS report export.
```

## Phase 7 — PPh21

```text
- [ ] Create tax_ptkp_settings table.
- [ ] Create tax_ter_settings table.
- [ ] Create tax_pph21_calculations table.
- [ ] Create tax_yearly_summaries table.
- [ ] Build Pph21CalculationService.
- [ ] Add government default indicator.
- [ ] Add effective date.
- [ ] Add gross/nett/gross-up method.
- [ ] Add final month adjustment.
- [ ] Add PPh21 calculation right sheet response.
- [ ] Add PPh21 report export.
```

## Phase 8 — Issues and Resolution

```text
- [ ] Create payroll_issues table.
- [ ] Create payroll_issue_resolutions table.
- [ ] Build PayrollIssueService.
- [ ] Build PayrollIssueResolutionService.
- [ ] Add missing bank issue.
- [ ] Add invalid bank issue.
- [ ] Add tax missing issue.
- [ ] Add BPJS missing issue.
- [ ] Add calculation failed issue.
- [ ] Add payment failed issue.
- [ ] Add Brick funding expired issue.
- [ ] Add resolve by edit bank.
- [ ] Add resolve by switch bank.
- [ ] Add resolve by request employee update.
- [ ] Add resolve by mark manual paid.
- [ ] Add resolve by exclude employee.
- [ ] Add resolve by retry payment.
```

## Phase 9 — Approval

```text
- [ ] Create payroll_approval_flows table.
- [ ] Create payroll_approval_steps table.
- [ ] Create payroll_approval_histories table.
- [ ] Build PayrollApprovalService.
- [ ] Add approval flow builder.
- [ ] Add add/edit/delete approval step.
- [ ] Add specific approver person.
- [ ] Add role approver.
- [ ] Add conditional approval by payroll type.
- [ ] Add conditional approval by amount threshold.
- [ ] Add checkbox confirmation.
- [ ] Add drag-to-confirm validation.
- [ ] Save approver role snapshot.
- [ ] Save amount snapshot.
- [ ] Save IP and user agent.
- [ ] Auto lock after final approval.
- [ ] Auto create payment batch after lock if enabled.
```

## Phase 10 — Payment and Brick

```text
- [ ] Create payroll_payment_batches table.
- [ ] Create payroll_payment_items table.
- [ ] Create payroll_payment_attempts table.
- [ ] Create payroll_payment_webhooks table.
- [ ] Build PayrollPaymentService.
- [ ] Build DisbursementProviderInterface.
- [ ] Build ManualPaymentProvider.
- [ ] Build BankFileExportProvider.
- [ ] Build BrickFundingVirtualAccountService.
- [ ] Build BrickDisbursementProvider.
- [ ] Build BrickWebhookService.
- [ ] Generate Brick VA.
- [ ] Show VA detail.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.
- [ ] Send Brick disbursement after funding paid.
- [ ] Process payment success webhook.
- [ ] Process payment failed webhook.
- [ ] Retry failed transfer.
- [ ] Switch employee bank account.
- [ ] Mark manual paid with note/reference.
- [ ] Generate payment receipt.
- [ ] Export transfer detail.
```

## Phase 11 — Payslip

```text
- [ ] Create payslips table.
- [ ] Create payslip_items table.
- [ ] Create payslip_delivery_logs table.
- [ ] Build PayslipService.
- [ ] Generate payslip snapshot.
- [ ] Generate PDF.
- [ ] Upload PDF to Supabase Storage.
- [ ] Add payslip right sheet detail.
- [ ] Add earnings/deductions/BPJS/PPh21/payment/send history tabs.
- [ ] Build PayslipDeliveryService.
- [ ] Send payslip email.
- [ ] Send payslip WhatsApp.
- [ ] Send employee app notification.
- [ ] Add recipient scope.
- [ ] Add delivery log.
```

## Phase 12 — Reports

```text
- [ ] Create payroll_report_exports table.
- [ ] Build PayrollReportService.
- [ ] Build PayrollExportService.
- [ ] Add payroll summary report.
- [ ] Add employee payroll report.
- [ ] Add department payroll cost report.
- [ ] Add branch payroll cost report.
- [ ] Add BPJS report.
- [ ] Add PPh21 report.
- [ ] Add payslip report.
- [ ] Add bank transfer report.
- [ ] Add failed payment report.
- [ ] Add overtime cost report.
- [ ] Add attendance deduction report.
- [ ] Add payroll journal report.
- [ ] Add PDF export.
- [ ] Add Excel export.
- [ ] Add CSV export.
- [ ] Add payslip ZIP export.
- [ ] Add export history.
```

## Phase 13 — Payroll Settings

```text
- [ ] Build PayrollSettingService.
- [ ] Add General Payroll Settings.
- [ ] Add Payroll Period & Cut-off.
- [ ] Add Payroll Type Defaults.
- [ ] Add Employee Selection Rules.
- [ ] Add Salary Calculation Rules.
- [ ] Add Salary Component Rules.
- [ ] Add Attendance Impact Rules.
- [ ] Add Overtime Rules.
- [ ] Add Proration Rules.
- [ ] Add BPJS Settings.
- [ ] Add PPh21 / Tax Settings.
- [ ] Add Payslip Settings.
- [ ] Add Payslip Delivery Settings.
- [ ] Add Payment / Disbursement Settings.
- [ ] Add Brick Funding VA Settings.
- [ ] Add Bank Account Validation Settings.
- [ ] Add Approval Flow Settings.
- [ ] Add Reminder & Employee Completion Settings.
- [ ] Add Report Export Settings.
- [ ] Add Security & Access Settings.
- [ ] Add Audit Log Settings.
```

## Phase 14 — Security, Queue, Audit

```text
- [ ] Add JWT auth to all payroll APIs.
- [ ] Validate tenant_id on every request.
- [ ] Add role permission validation.
- [ ] Mask bank account number.
- [ ] Mask NPWP/NIK.
- [ ] Mask Brick credential.
- [ ] Store Brick secret in Laravel env/secret manager.
- [ ] Validate webhook signature.
- [ ] Add idempotency key for payment request.
- [ ] Add queue for calculation.
- [ ] Add queue for payslip generation.
- [ ] Add queue for Brick disbursement.
- [ ] Add queue for export report.
- [ ] Add audit log for all sensitive actions.
```
