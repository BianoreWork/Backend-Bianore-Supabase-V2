# 03 — Final Backend Architecture

## Final Architecture

```text
Frontend React / Next.js
        ↓
Laravel API
        ↓
Payroll Domain Services
        ↓
Supabase PostgreSQL
        ↓
Supabase Storage
        ↓
External Providers
        ├── Brick Funding VA
        ├── Brick Disbursement
        ├── Email Provider
        ├── WhatsApp Provider
        └── Export Generator
```

---

## Main Backend Responsibilities

## Supabase

```text
- Database utama payroll
- Tenant isolation
- Payroll period/run data
- Payroll employee data
- Salary components
- Employee payroll profile
- Bank/tax/BPJS profile
- Payroll calculation result
- Payslip metadata
- Payment batch and item status
- Brick VA metadata
- Approval history
- Audit logs
- Report export records
- RPC/view for dashboard and reports
```

## Laravel

```text
- API layer for frontend
- JWT auth and permission validation
- Payroll process orchestration
- Payroll calculation engine
- Attendance sync trigger
- BPJS engine
- PPh21 engine
- Approval workflow
- Approval confirmation validation
- Issue resolution
- Payslip PDF generator
- Payslip delivery
- Brick Funding VA service
- Brick Disbursement service
- Brick webhook handler
- Report export generation
- Queue jobs
- Audit log writing
```

---

## Final Payroll Flow

```text
Create Payroll Period
→ Create Payroll Run
→ Select Payroll Type
→ Apply Payroll Type Defaults
→ Select Employees
→ Validate Employee Payroll Data
→ Sync Attendance
→ Calculate Salary
→ Calculate Allowance & Deduction
→ Calculate BPJS
→ Calculate PPh21
→ Review Payroll
→ Resolve Issues
→ Submit Approval
→ Approval Confirmation
→ Final Approval
→ Lock Payroll
→ Create Payment Batch
→ Generate Brick Funding VA
→ Company Pays VA
→ Brick Confirms Funding Paid
→ Send Brick Disbursement
→ Receive Webhook Status
→ Retry / Resolve Failed Payment
→ Generate Payslip
→ Send Payslip
→ Export Reports
```

---

## Final Status Lifecycle

## Payroll Run Status

```text
draft
employee_selection
attendance_synced
calculating
calculated
needs_attention
pending_approval
approved
locked
payment_batch_created
waiting_va_payment
funding_paid
disbursement_processing
paid
partially_paid
failed
cancelled
```

## Payment Batch Status

```text
draft
ready_for_funding
waiting_va_payment
funding_paid
funding_expired
funding_failed
ready_for_disbursement
disbursement_processing
paid
partially_paid
failed
cancelled
```

## Payment Item Status

```text
pending
validating
processing
success
failed
retried
manual_paid
reversed
```

## Approval Status

```text
draft
submitted
approved
rejected
need_revision
locked
```

## Issue Status

```text
open
in_progress
resolved
ignored
excluded
```

---

## Final Role Access

```text
super_admin
admin
hr
finance
manager
employee
```

## Sensitive Actions

```text
- edit salary
- approve payroll
- lock payroll
- generate Brick VA
- send disbursement
- mark manual paid
- switch employee bank
- export payroll report
- change payroll settings
```
