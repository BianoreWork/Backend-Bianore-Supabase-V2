# 06 — Final API Routes

## Payroll Overview

```text
GET /api/payroll/overview
GET /api/payroll/overview/widgets/{widgetKey}/actions
GET /api/payroll/overview/department-cost-detail
GET /api/payroll/issues/summary
```

## Payroll Run

```text
GET /api/payroll/runs
POST /api/payroll/runs
GET /api/payroll/runs/{id}
PUT /api/payroll/runs/{id}
DELETE /api/payroll/runs/{id}
GET /api/payroll/runs/{id}/steps
GET /api/payroll/runs/{id}/steps/{stepCode}
GET /api/payroll/runs/{id}/employees
GET /api/payroll/runs/{id}/eligible-employees
POST /api/payroll/runs/{id}/select-employees
POST /api/payroll/runs/{id}/sync-attendance
POST /api/payroll/runs/{id}/calculate
GET /api/payroll/runs/{id}/calculation-progress
POST /api/payroll/runs/{id}/recalculate
POST /api/payroll/runs/{id}/employees/{employeeId}/recalculate
POST /api/payroll/runs/{id}/submit-approval
POST /api/payroll/runs/{id}/approve
POST /api/payroll/runs/{id}/reject
POST /api/payroll/runs/{id}/request-revision
POST /api/payroll/runs/{id}/lock
POST /api/payroll/runs/{id}/payment-batch
POST /api/payroll/runs/{id}/cancel
```

## Salary Components

```text
GET /api/payroll/salary-components
POST /api/payroll/salary-components
GET /api/payroll/salary-components/{id}
PUT /api/payroll/salary-components/{id}
DELETE /api/payroll/salary-components/{id}
POST /api/payroll/salary-components/{id}/activate
POST /api/payroll/salary-components/{id}/deactivate
```

## Employee Payroll Info

```text
GET /api/payroll/employees
GET /api/payroll/employees/{employeeId}
PUT /api/payroll/employees/{employeeId}/profile
GET /api/payroll/employees/{employeeId}/salary-history
POST /api/payroll/employees/{employeeId}/salary-components
DELETE /api/payroll/employees/{employeeId}/salary-components/{componentId}
GET /api/payroll/employees/{employeeId}/bank-accounts
POST /api/payroll/employees/{employeeId}/bank-accounts
PUT /api/payroll/employees/{employeeId}/bank-accounts/{bankId}
DELETE /api/payroll/employees/{employeeId}/bank-accounts/{bankId}
POST /api/payroll/employees/{employeeId}/bank-accounts/{bankId}/validate
POST /api/payroll/employees/{employeeId}/bank-accounts/{bankId}/set-primary
PUT /api/payroll/employees/{employeeId}/tax-profile
PUT /api/payroll/employees/{employeeId}/bpjs-profile
POST /api/payroll/employees/{employeeId}/send-reminder
```

## Employee Self-Service Payroll Data

```text
GET /api/employee/payroll/profile
POST /api/employee/payroll/bank-accounts
POST /api/employee/payroll/tax-profile
POST /api/employee/payroll/bpjs-profile
GET /api/employee/payroll/submission-requests
POST /api/employee/payroll/submission-requests/{requestId}/complete
```

## Payslip

```text
GET /api/payroll/payslips
GET /api/payroll/payslips/{id}
GET /api/payroll/payslips/{id}/detail
POST /api/payroll/runs/{id}/generate-payslips
POST /api/payroll/payslips/{id}/regenerate
POST /api/payroll/payslips/send
GET /api/payroll/payslips/{id}/delivery-logs
GET /api/payroll/payslips/{id}/download
GET /api/employee/payslips
GET /api/employee/payslips/{id}
GET /api/employee/payslips/{id}/download
```

## BPJS

```text
GET /api/payroll/bpjs/settings
POST /api/payroll/bpjs/settings
PUT /api/payroll/bpjs/settings/{id}
GET /api/payroll/bpjs/calculations
GET /api/payroll/bpjs/calculations/{employeeId}
POST /api/payroll/bpjs/recalculate/{employeeId}
GET /api/payroll/bpjs/reports
POST /api/payroll/bpjs/reports/export
```

## Tax / PPh21

```text
GET /api/payroll/tax/settings/ptkp
POST /api/payroll/tax/settings/ptkp
GET /api/payroll/tax/settings/ter
POST /api/payroll/tax/settings/ter
GET /api/payroll/tax/calculations
GET /api/payroll/tax/calculations/{employeeId}
POST /api/payroll/tax/recalculate/{employeeId}
GET /api/payroll/tax/reports
POST /api/payroll/tax/reports/export
```

## Payroll Reports

```text
GET /api/payroll/reports/summary
GET /api/payroll/reports/employee
GET /api/payroll/reports/department
GET /api/payroll/reports/branch
GET /api/payroll/reports/bpjs
GET /api/payroll/reports/pph21
GET /api/payroll/reports/bank-transfer
GET /api/payroll/reports/failed-payment
GET /api/payroll/reports/overtime-cost
GET /api/payroll/reports/attendance-deduction
GET /api/payroll/reports/journal
POST /api/payroll/reports/export
GET /api/payroll/reports/exports/{exportId}
GET /api/payroll/reports/exports/{exportId}/download
```

## Payment / Disbursement / Brick

```text
GET /api/payroll/payments/batches
POST /api/payroll/runs/{id}/payment-batch
GET /api/payroll/payments/batches/{batchId}
POST /api/payroll/payments/batches/{batchId}/validate
POST /api/payroll/runs/{id}/brick/funding-va
GET /api/payroll/runs/{id}/brick/funding-status
POST /api/payroll/payments/batches/{batchId}/brick/send-disbursement
GET /api/payroll/payments/batches/{batchId}/brick/status
POST /api/payroll/payments/items/{itemId}/brick/retry
POST /api/payroll/payments/items/{itemId}/retry
POST /api/payroll/payments/items/{itemId}/switch-bank
POST /api/payroll/payments/items/{itemId}/manual-paid
POST /api/payroll/payments/items/{itemId}/request-bank-update
GET /api/payroll/payments/batches/{batchId}/receipt
GET /api/payroll/payments/batches/{batchId}/export-detail
GET /api/payroll/payments/batches/{batchId}/payslip-zip
POST /api/webhooks/payroll/payments/brick
POST /api/webhooks/payroll/payments/{provider}
```

## Payroll Issues

```text
GET /api/payroll/runs/{id}/issues
GET /api/payroll/issues/{issueId}
POST /api/payroll/issues/{issueId}/resolve
POST /api/payroll/issues/{issueId}/request-employee-update
POST /api/payroll/issues/bulk-resolve
```

## Payroll Settings

```text
GET /api/payroll/settings
PUT /api/payroll/settings
GET /api/payroll/settings/general
PUT /api/payroll/settings/general
GET /api/payroll/settings/cutoff
PUT /api/payroll/settings/cutoff
GET /api/payroll/settings/payroll-type-defaults
PUT /api/payroll/settings/payroll-type-defaults
GET /api/payroll/settings/employee-selection-rules
PUT /api/payroll/settings/employee-selection-rules
GET /api/payroll/settings/salary-calculation-rules
PUT /api/payroll/settings/salary-calculation-rules
GET /api/payroll/settings/attendance-impact-rules
PUT /api/payroll/settings/attendance-impact-rules
GET /api/payroll/settings/overtime-rules
PUT /api/payroll/settings/overtime-rules
GET /api/payroll/settings/proration-rules
PUT /api/payroll/settings/proration-rules
GET /api/payroll/settings/payslip
PUT /api/payroll/settings/payslip
GET /api/payroll/settings/payslip-delivery
PUT /api/payroll/settings/payslip-delivery
GET /api/payroll/settings/payment-provider
PUT /api/payroll/settings/payment-provider
POST /api/payroll/settings/payment-provider/test-connection
GET /api/payroll/settings/brick
PUT /api/payroll/settings/brick
POST /api/payroll/settings/brick/test-connection
GET /api/payroll/settings/approval-flows
POST /api/payroll/settings/approval-flows
PUT /api/payroll/settings/approval-flows/{id}
DELETE /api/payroll/settings/approval-flows/{id}
POST /api/payroll/settings/approval-flows/{id}/steps
PUT /api/payroll/settings/approval-flows/{id}/steps/{stepId}
DELETE /api/payroll/settings/approval-flows/{id}/steps/{stepId}
GET /api/payroll/settings/reminders
PUT /api/payroll/settings/reminders
GET /api/payroll/settings/report-export
PUT /api/payroll/settings/report-export
GET /api/payroll/settings/security-access
PUT /api/payroll/settings/security-access
GET /api/payroll/settings/audit-log
PUT /api/payroll/settings/audit-log
```
