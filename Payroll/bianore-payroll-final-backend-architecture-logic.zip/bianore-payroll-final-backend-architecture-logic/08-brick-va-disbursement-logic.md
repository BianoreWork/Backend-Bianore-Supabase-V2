# 08 — Brick VA and Disbursement Logic

## Correct Brick Flow

```text
Payroll Approved
→ Payroll Locked
→ Payment Batch Created
→ Generate Brick Funding VA
→ Company pays VA
→ Brick confirms funding via webhook
→ Bianore sends disbursement batch
→ Brick transfers salary to employee bank accounts
→ Brick sends payment status webhook
→ Bianore updates statuses
→ Failed payments can be retried/resolved
→ Payslip is sent
```

---

## Funding vs Disbursement

```text
Funding VA = company pays total payroll amount into Brick funding VA.
Disbursement = Brick sends salary to each employee bank account.
```

---

## Funding Status

```text
not_created
waiting_va_payment
funding_paid
funding_expired
funding_failed
```

## Disbursement Status

```text
not_started
pending
processing
success
partially_paid
failed
```

---

## Brick Funding VA Right Sheet

When status = waiting_va_payment:

```text
Brick Virtual Account Payment
├── VA Bank
├── VA Number
├── VA Name
├── Amount
├── Expired At
├── Copy VA Number
├── Download Payment Instruction
├── Check Funding Status
└── Regenerate VA if expired
```

---

## Success Payment Detail

When status = success:

```text
Payment Batch Success Detail
├── Payroll Type
├── Period
├── Total Employees
├── Total Amount
├── Provider: Brick
├── Funding Paid At
├── Disbursement Completed At
├── Success Count
├── Failed Count
├── Payment Reference
├── Download Payment Receipt
├── Download Employee Transfer Report
└── Download Payslip Batch
```

---

## Failed Transfer Resolution

When some transfers fail:

```text
Failed Transfers
├── Employee Name
├── Bank
├── Account Number Masked
├── Amount
├── Failure Reason
├── Retry Selected
├── Retry All Failed
├── Switch Bank Account
├── Request Employee Update Bank
└── Mark as Manual Paid
```

---

## Brick Service Tasks

- [ ] Generate Brick Funding VA.
- [ ] Save VA detail to payroll_payment_batches.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.
- [ ] Send disbursement batch after funding paid.
- [ ] Save Brick batch ID.
- [ ] Save Brick transaction IDs.
- [ ] Process transfer success webhook.
- [ ] Process transfer failed webhook.
- [ ] Retry failed transfer.
- [ ] Switch bank and retry.
- [ ] Mark as manual paid.
- [ ] Generate payment receipt.
- [ ] Export transfer detail.

---

## Brick Webhook Handler

```text
POST /api/webhooks/payroll/payments/brick
```

- [ ] Validate webhook signature.
- [ ] Save raw webhook payload.
- [ ] Identify event type.
- [ ] Identify funding reference or transaction reference.
- [ ] Update funding status if funding event.
- [ ] Update payment item status if transfer event.
- [ ] Update batch summary counts.
- [ ] Update payroll run status.
- [ ] Trigger payslip delivery if payment success.
- [ ] Mark webhook as processed.
- [ ] Add audit log.
