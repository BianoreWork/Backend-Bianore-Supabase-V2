# 05 — Final Laravel Structure, Services, Jobs

## Laravel Controllers

```text
app/Http/Controllers/Payroll/
├── PayrollOverviewController.php
├── PayrollRunController.php
├── SalaryComponentController.php
├── EmployeePayrollController.php
├── PayslipController.php
├── BPJSController.php
├── TaxPph21Controller.php
├── PayrollReportController.php
├── PayrollSettingController.php
├── PayrollPaymentController.php
├── PayrollIssueController.php
├── PayrollRunStepController.php
└── PayrollReminderController.php

app/Http/Controllers/Webhook/
├── PayrollPaymentWebhookController.php
└── BrickPaymentWebhookController.php
```

---

## Laravel Requests

```text
app/Http/Requests/Payroll/
├── CreatePayrollRunRequest.php
├── UpdatePayrollRunRequest.php
├── SelectPayrollEmployeesRequest.php
├── CalculatePayrollRequest.php
├── SubmitPayrollApprovalRequest.php
├── ApprovePayrollRequest.php
├── RejectPayrollRequest.php
├── ResolvePayrollIssueRequest.php
├── CreateSalaryComponentRequest.php
├── UpdateEmployeePayrollInfoRequest.php
├── UpdateEmployeeBankAccountRequest.php
├── ValidateEmployeeBankAccountRequest.php
├── GeneratePayslipRequest.php
├── SendPayslipRequest.php
├── CreatePaymentBatchRequest.php
├── SendPayrollPaymentRequest.php
├── MarkManualPaidRequest.php
├── SwitchBankAccountRequest.php
├── ExportPayrollReportRequest.php
└── UpdatePayrollSettingsRequest.php
```

---

## Laravel Resources

```text
app/Http/Resources/Payroll/
├── PayrollOverviewResource.php
├── PayrollRunResource.php
├── PayrollRunStepResource.php
├── PayrollEmployeeResource.php
├── SalaryComponentResource.php
├── EmployeePayrollProfileResource.php
├── EmployeeBankAccountResource.php
├── PayslipResource.php
├── BPJSCalculationResource.php
├── Pph21CalculationResource.php
├── PayrollPaymentBatchResource.php
├── PayrollPaymentItemResource.php
├── PayrollIssueResource.php
└── PayrollReportExportResource.php
```

---

## Laravel Payroll Services

```text
app/Services/Payroll/
├── PayrollOverviewService.php
├── PayrollRunService.php
├── PayrollCalculationService.php
├── SalaryComponentService.php
├── AttendancePayrollSyncService.php
├── BPJSCalculationService.php
├── Pph21CalculationService.php
├── PayrollApprovalService.php
├── PayslipService.php
├── PayrollReportService.php
├── PayrollPaymentService.php
├── PayrollValidationService.php
├── PayrollAuditService.php
├── PayrollIssueService.php
├── PayrollIssueResolutionService.php
├── PayrollRunStepService.php
├── PayrollReminderService.php
├── PayslipDeliveryService.php
├── PayrollExportService.php
└── EmployeePayrollProfileService.php
```

---

## Laravel Payment Services

```text
app/Services/Payment/
├── DisbursementProviderInterface.php
├── ManualPaymentProvider.php
├── BankFileExportProvider.php
├── DokuDisbursementProvider.php
├── OyDisbursementProvider.php
├── BrickDisbursementProvider.php
├── BrickFundingVirtualAccountService.php
├── BrickWebhookService.php
└── PaymentWebhookService.php
```

---

## Laravel Supabase Services

```text
app/Services/Supabase/
├── SupabasePayrollRepository.php
├── SupabaseRpcService.php
├── SupabaseStorageService.php
└── SupabaseReportRepository.php
```

---

## Laravel Jobs

```text
app/Jobs/Payroll/
├── CalculatePayrollJob.php
├── CalculateEmployeePayrollJob.php
├── SyncPayrollAttendanceJob.php
├── GeneratePayslipPdfJob.php
├── SendPayslipDeliveryJob.php
├── CreatePaymentBatchJob.php
├── CreateBrickFundingVaJob.php
├── CheckBrickFundingStatusJob.php
├── SendBrickDisbursementBatchJob.php
├── RetryBrickFailedDisbursementJob.php
├── ExportPayrollReportJob.php
└── SendEmployeePayrollReminderJob.php
```

---

## Laravel Enums

```text
app/Enums/
├── PayrollStatus.php
├── PayrollType.php
├── PayrollRunStepStatus.php
├── PayrollPaymentStatus.php
├── PayrollFundingStatus.php
├── SalaryComponentType.php
├── ApprovalStatus.php
├── TaxMethod.php
├── BpjsProgram.php
├── PayrollIssueStatus.php
├── PayrollIssueSeverity.php
└── PayslipDeliveryChannel.php
```

---

# Service Logic Tasks

## PayrollOverviewService

- [ ] Build getOverview method.
- [ ] Build getWidgetActions method.
- [ ] Build getDepartmentCostDetail method.
- [ ] Build getPayrollAlerts method.
- [ ] Build getPayrollProcessSteps method.
- [ ] Build getStepDetail method.
- [ ] Validate tenant access.
- [ ] Validate user role permission.

## PayrollRunService

- [ ] Build createPayrollRun method.
- [ ] Apply payroll type defaults.
- [ ] Initialize payroll run steps.
- [ ] Select default employees if monthly payroll.
- [ ] Pull failed payment employees if correction payroll.
- [ ] Update payroll status lifecycle.
- [ ] Lock payroll after final approval.
- [ ] Create payment batch after lock if setting enabled.

## PayrollRunStepService

- [ ] Initialize default steps.
- [ ] Update step status.
- [ ] Update progress percentage.
- [ ] Save step metadata.
- [ ] Return step detail for popup/right sheet.
- [ ] Track warnings and errors.

## PayrollCalculationService

- [ ] Calculate base salary.
- [ ] Calculate prorated salary.
- [ ] Apply salary components.
- [ ] Calculate attendance impact.
- [ ] Calculate overtime.
- [ ] Calculate BPJS.
- [ ] Calculate PPh21.
- [ ] Calculate gross salary.
- [ ] Calculate total deduction.
- [ ] Calculate net salary.
- [ ] Save calculation snapshot.
- [ ] Create issues if calculation fails.

## PayrollApprovalService

- [ ] Submit approval.
- [ ] Load approval flow.
- [ ] Validate current approver.
- [ ] Validate approval step order.
- [ ] Require checkbox confirmation.
- [ ] Require drag-to-confirm if setting enabled.
- [ ] Save approval metadata.
- [ ] Allow reject with reason.
- [ ] Allow request revision.
- [ ] Lock payroll after final approval.
- [ ] Trigger payment batch creation after final approval.

## PayrollIssueService

- [ ] Create payroll issue.
- [ ] Group issue by payroll run.
- [ ] Group issue by employee.
- [ ] Return suggested actions.
- [ ] Support missing bank account.
- [ ] Support invalid bank account.
- [ ] Support tax/BPJS missing.
- [ ] Support calculation failed.
- [ ] Support payment failed.
- [ ] Support Brick funding expired.

## PayrollIssueResolutionService

- [ ] Resolve issue by edit bank.
- [ ] Resolve issue by switch bank.
- [ ] Resolve issue by request employee update.
- [ ] Resolve issue by mark manual paid.
- [ ] Resolve issue by exclude employee.
- [ ] Resolve issue by retry payment.
- [ ] Resolve issue by recalculate.
- [ ] Save resolution note.
- [ ] Save audit log.

## PayslipService

- [ ] Generate payslip record.
- [ ] Generate payslip items snapshot.
- [ ] Generate PDF.
- [ ] Upload PDF to Supabase Storage.
- [ ] Regenerate payslip with reason.
- [ ] Return payslip right sheet detail.

## PayslipDeliveryService

- [ ] Send payslip to email.
- [ ] Send payslip to WhatsApp.
- [ ] Send employee app notification.
- [ ] Support recipient scope.
- [ ] Save delivery logs.
- [ ] Retry failed delivery.

## PayrollPaymentService

- [ ] Create payment batch.
- [ ] Validate employee bank accounts.
- [ ] Create payment items.
- [ ] Mark manual paid.
- [ ] Retry failed payment.
- [ ] Switch employee bank account.
- [ ] Generate receipt.
- [ ] Export transfer detail.

## BrickFundingVirtualAccountService

- [ ] Generate Brick Funding VA.
- [ ] Save VA number.
- [ ] Save VA bank.
- [ ] Save VA name.
- [ ] Save funding amount.
- [ ] Save expiry time.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.

## BrickDisbursementProvider

- [ ] Prepare disbursement batch payload.
- [ ] Send disbursement to Brick.
- [ ] Save Brick batch ID.
- [ ] Save Brick transaction IDs.
- [ ] Query transaction status.
- [ ] Retry failed transaction.

## BrickWebhookService

- [ ] Validate webhook signature.
- [ ] Save raw payload.
- [ ] Process funding event.
- [ ] Process disbursement event.
- [ ] Update payment item.
- [ ] Update payment batch.
- [ ] Update payroll run status.
- [ ] Trigger payslip delivery if payment success.

## PayrollExportService

- [ ] Generate PDF report.
- [ ] Generate Excel report.
- [ ] Generate CSV report.
- [ ] Generate ZIP payslip.
- [ ] Upload export file.
- [ ] Save export history.
- [ ] Support async export for large data.

## PayrollReminderService

- [ ] Send missing bank reminder.
- [ ] Send missing tax reminder.
- [ ] Send missing BPJS reminder.
- [ ] Create employee submission request.
- [ ] Track reminder completion.
- [ ] Notify admin after employee submission.
