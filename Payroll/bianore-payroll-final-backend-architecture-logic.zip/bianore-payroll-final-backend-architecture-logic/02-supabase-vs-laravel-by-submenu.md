# 02 — Supabase vs Laravel by Payroll Submenu

## Prinsip Utama

```text
Supabase = database utama, tenant isolation, payroll data, view/RPC query, calculation result, report data, payslip/payment metadata.

Laravel = business service layer, payroll logic, approval workflow, payslip PDF, Brick VA/disbursement, webhook, BPJS/PPh21 engine, export, queue, audit, security validation.
```

---

# 1. Payroll Overview

## Supabase

- [ ] payroll_runs.
- [ ] payroll_run_employees.
- [ ] payroll_calculations.
- [ ] payroll_payment_batches.
- [ ] payroll_payment_items.
- [ ] payroll_issues.
- [ ] payroll_run_steps.
- [ ] report views/RPC.
- [ ] admin_payroll_overview RPC.

## Laravel

- [ ] PayrollOverviewService.
- [ ] Widget action resolver.
- [ ] Payroll step detail resolver.
- [ ] Issue summary resolver.
- [ ] Department cost detail resolver.
- [ ] Permission validation.
- [ ] Export summary trigger.

## Kesimpulan

```text
Supabase dominan untuk data summary.
Laravel untuk action, permission, dan response orchestration.
```

---

# 2. Payroll Run

## Supabase

- [ ] payroll_periods.
- [ ] payroll_runs.
- [ ] payroll_run_employees.
- [ ] payroll_run_steps.
- [ ] payroll_calculations.
- [ ] payroll_calculation_items.
- [ ] payroll_issues.
- [ ] payroll_issue_resolutions.
- [ ] payroll_approval_histories.
- [ ] payroll_audit_logs.

## Laravel

- [ ] PayrollRunService.
- [ ] PayrollRunStepService.
- [ ] PayrollCalculationService.
- [ ] AttendancePayrollSyncService.
- [ ] PayrollApprovalService.
- [ ] PayrollIssueService.
- [ ] PayrollIssueResolutionService.
- [ ] PayrollAuditService.
- [ ] PayrollValidationService.

## Kesimpulan

```text
Laravel dominan untuk proses.
Supabase dominan untuk penyimpanan, status, dan query.
```

---

# 3. Salary Components

## Supabase

- [ ] salary_components.
- [ ] employee_salary_components.
- [ ] component effective date.
- [ ] taxable/BPJS/payslip flags.

## Laravel

- [ ] SalaryComponentService.
- [ ] Formula validation.
- [ ] Apply component saat payroll calculation.
- [ ] Prevent hard delete if component already used.
- [ ] Deactivate component.

## Kesimpulan

```text
Supabase untuk master data.
Laravel untuk validation dan apply logic.
```

---

# 4. Employee Payroll Info

## Supabase

- [ ] employee_payroll_profiles.
- [ ] employee_bank_accounts.
- [ ] employee_tax_profiles.
- [ ] employee_bpjs_profiles.
- [ ] employee_salary_components.
- [ ] employee_profile_submission_requests.
- [ ] employee_profile_submissions.

## Laravel

- [ ] EmployeePayrollService.
- [ ] BankAccountValidationService / PayrollValidationService.
- [ ] PayrollReminderService.
- [ ] Employee submission approval logic.
- [ ] Salary override logic.
- [ ] Bank primary/secondary switch logic.

## Kesimpulan

```text
Supabase untuk profil dan histori.
Laravel untuk validation, approval, reminder, dan sensitive action.
```

---

# 5. Payslip

## Supabase

- [ ] payslips.
- [ ] payslip_items.
- [ ] payslip_delivery_logs.
- [ ] Supabase Storage for PDF.

## Laravel

- [ ] PayslipService.
- [ ] PayslipDeliveryService.
- [ ] PDF generator.
- [ ] Email/WhatsApp/employee app delivery.
- [ ] Regenerate validation.
- [ ] Delivery logs.
- [ ] Secure download link.

## Kesimpulan

```text
Laravel dominan untuk PDF dan delivery.
Supabase untuk metadata, item snapshot, dan file path.
```

---

# 6. BPJS

## Supabase

- [ ] bpjs_rate_settings.
- [ ] employee_bpjs_profiles.
- [ ] bpjs_employee_calculations.
- [ ] bpjs_company_calculations.
- [ ] BPJS report source.

## Laravel

- [ ] BPJSCalculationService.
- [ ] Rate effective date validation.
- [ ] System default vs company override resolver.
- [ ] BPJS report export.
- [ ] Recalculate employee BPJS.

## Kesimpulan

```text
Supabase untuk rate/profile/result.
Laravel untuk calculation engine dan export.
```

---

# 7. Tax / PPh21

## Supabase

- [ ] tax_ptkp_settings.
- [ ] tax_ter_settings.
- [ ] employee_tax_profiles.
- [ ] tax_pph21_calculations.
- [ ] tax_yearly_summaries.

## Laravel

- [ ] Pph21CalculationService.
- [ ] TER/PTKP effective date resolver.
- [ ] Gross/nett/gross-up logic.
- [ ] Final month adjustment.
- [ ] Tax report export.

## Kesimpulan

```text
Supabase untuk settings/profile/result.
Laravel untuk tax engine dan export.
```

---

# 8. Payroll Reports

## Supabase

- [ ] report views.
- [ ] payroll_report_exports.
- [ ] payroll source data.
- [ ] BPJS/tax/payment report source data.

## Laravel

- [ ] PayrollReportService.
- [ ] PayrollExportService.
- [ ] PDF generator.
- [ ] Excel generator.
- [ ] CSV generator.
- [ ] ZIP payslip generator.
- [ ] Async export job.

## Kesimpulan

```text
Supabase untuk query/report source.
Laravel untuk generation/download workflow.
```

---

# 9. Payroll Settings

## Supabase

- [ ] payroll_settings.
- [ ] payroll_provider_settings.
- [ ] payroll_approval_flows.
- [ ] payroll_approval_steps.
- [ ] bpjs_rate_settings.
- [ ] tax_ptkp_settings.
- [ ] tax_ter_settings.

## Laravel

- [ ] PayrollSettingService.
- [ ] Approval flow validation.
- [ ] Brick credential handling.
- [ ] Secret management.
- [ ] Setting permission validation.
- [ ] Test provider connection.
- [ ] Audit log for setting changes.

## Kesimpulan

```text
Supabase untuk setting non-secret.
Laravel untuk validation, secret, provider connection, dan sensitive permission.
```
