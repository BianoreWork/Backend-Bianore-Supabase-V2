# 01 — Final Payroll Menu Structure

## Struktur Utama Payroll — Jangan Diubah

```text
Payroll
├── Payroll Overview
├── Payroll Run
├── Salary Components
├── Employee Payroll Info
├── Payslip
├── BPJS
├── Tax / PPh 21
├── Payroll Reports
└── Payroll Settings
```

---

# 1. Payroll Overview

```text
Payroll Overview
├── Payroll Monthly Summary
│   ├── Total gross salary
│   ├── Total deduction
│   ├── Total net salary
│   ├── Total employees
│   ├── Total BPJS
│   ├── Total PPh21
│   └── Three-dot action menu
│       ├── View payroll detail
│       ├── Continue payroll process
│       ├── View approval status
│       ├── View disbursement status
│       ├── Export summary
│       └── View audit log
│
├── Department Cost Widget
│   ├── Department payroll cost
│   ├── Overtime cost
│   ├── Allowance cost
│   ├── Deduction cost
│   └── Three-dot action menu
│       ├── View department breakdown
│       ├── Compare with last month
│       ├── Export department cost
│       ├── View employees in department
│       └── View overtime cost
│
├── Payroll Process Step Widget
│   ├── Step 1: Setup Payroll
│   ├── Step 2: Sync Attendance
│   ├── Step 3: Calculate Salary
│   ├── Step 4: Approval
│   └── Step 5: Disbursement
│
├── Step Detail Popup / Right Sheet
│   ├── Setup Payroll Detail
│   ├── Attendance Sync Detail
│   ├── Salary Calculation Detail
│   ├── Approval Detail
│   └── Disbursement Detail
│
├── Payroll Alerts
│   ├── Missing bank account
│   ├── Invalid bank account
│   ├── Missing tax profile
│   ├── Missing BPJS profile
│   ├── Pending approval
│   ├── Waiting Brick VA payment
│   └── Failed disbursement
│
└── Quick Actions
    ├── Create payroll run
    ├── Continue current payroll
    ├── Review issues
    ├── Export report
    └── Open disbursement detail
```

---

# 2. Payroll Run

```text
Payroll Run
├── Payroll Run List
│   ├── Payroll code
│   ├── Payroll name
│   ├── Payroll type
│   ├── Period
│   ├── Total employees
│   ├── Total net salary
│   ├── Status
│   ├── Issue count
│   └── Export action
│       ├── Export PDF
│       ├── Export Excel
│       ├── Export CSV
│       ├── Export payslip ZIP
│       └── Export audit log
│
├── Create Payroll Run CTA
│   ├── Payroll type selection
│   │   ├── Monthly Payroll
│   │   ├── Correction Payroll
│   │   ├── THR Payroll
│   │   ├── Bonus Payroll
│   │   ├── Final Payroll
│   │   └── Failed Payment Retry Payroll
│   │
│   ├── Monthly Payroll Default
│   │   ├── Auto include active monthly employees
│   │   ├── Use default cut-off
│   │   ├── Require attendance sync
│   │   ├── Require BPJS
│   │   ├── Require PPh21
│   │   └── Require approval and disbursement
│   │
│   ├── Correction Payroll Default
│   │   ├── Manual employee selection
│   │   ├── Pull failed transfer employees from Disbursement
│   │   ├── Allow manual adjustment
│   │   └── Allow correction payslip
│   │
│   └── THR Payroll Default
│       ├── Include eligible employees
│       ├── Use THR formula
│       ├── Attendance optional
│       └── Tax calculation required
│
├── Payroll Run Right Sheet
│   ├── Summary Tab
│   ├── Employees Tab
│   ├── Calculation Tab
│   ├── Approval Tab
│   ├── Payment Tab
│   └── Audit Log Tab
│
├── Employees Tab
│   ├── Employee list
│   ├── Base salary
│   ├── Gross salary
│   ├── Deduction
│   ├── BPJS
│   ├── PPh21
│   ├── Net salary
│   ├── Payment status
│   ├── Issue badge
│   └── Resolve action
│       ├── Edit bank
│       ├── Switch bank
│       ├── Request employee update
│       ├── Mark as manual paid
│       ├── Exclude employee
│       └── Recalculate employee
│
├── Draft Status Actions
│   ├── Select employees
│   ├── Add employee
│   ├── Remove employee
│   ├── Include department
│   ├── Exclude employee
│   └── Fix missing payroll data
│
├── Calculate Salary Action
│   └── Calculation Progress Modal
│       ├── Load employee payroll profile
│       ├── Apply salary components
│       ├── Sync attendance deduction
│       ├── Calculate BPJS
│       ├── Calculate PPh21
│       └── Finalize net salary
│
├── Approval Action
│   ├── Submit approval
│   ├── Approve
│   ├── Reject
│   ├── Request revision
│   └── Approval Confirmation Modal
│       ├── Show approver role
│       ├── Show payroll amount
│       ├── Show employee count
│       ├── Required checkbox
│       └── Drag to confirm approval
│
└── Payment Action
    ├── Lock payroll
    ├── Create payment batch
    ├── Generate Brick VA
    └── Open disbursement detail
```

---

# 3. Salary Components

```text
Salary Components
├── Earnings
│   ├── Basic salary
│   ├── Fixed allowance
│   ├── Position allowance
│   ├── Transport allowance
│   ├── Meal allowance
│   ├── Attendance allowance
│   ├── Overtime pay
│   ├── Bonus
│   ├── Commission
│   └── THR
│
├── Deductions
│   ├── Late deduction
│   ├── Absent deduction
│   ├── Unpaid leave deduction
│   ├── Loan deduction
│   ├── Cash advance
│   ├── BPJS employee contribution
│   ├── PPh21
│   └── Other deduction
│
├── Benefits
│   ├── BPJS employer contribution
│   ├── Insurance
│   └── Company benefit
│
├── Component Settings
│   ├── Fixed amount
│   ├── Percentage
│   ├── Formula based
│   ├── Taxable / non-taxable
│   ├── BPJS base / not BPJS base
│   ├── Recurring / one-time
│   ├── Prorated / non-prorated
│   └── Visible on payslip
│
└── Small Addition
    ├── Effective start date
    ├── Effective end date
    ├── Used by employee count
    └── Deactivate instead of delete
```

---

# 4. Employee Payroll Info

```text
Employee Payroll Info
├── Employee Payroll List
│   ├── Employee name
│   ├── Department
│   ├── Position
│   ├── Salary type
│   ├── Base salary
│   ├── Bank status
│   ├── Tax status
│   ├── BPJS status
│   ├── Payroll eligibility
│   └── Reminder action
│
├── Employee Payroll Right Sheet
│   ├── Tab 1: Profil Payroll
│   ├── Tab 2: Rekening Bank
│   ├── Tab 3: Profil Pajak
│   └── Tab 4: Profil BPJS
│
├── Profil Payroll Tab
│   ├── Salary type
│   ├── Base salary
│   ├── Daily rate
│   ├── Hourly rate
│   ├── Payroll status
│   ├── Effective date
│   ├── Overtime eligible
│   ├── Attendance deduction enabled
│   ├── Salary components
│   ├── Fixed allowance
│   ├── Benefits
│   ├── Deductions
│   ├── BPJS included
│   ├── Tax method
│   └── Actions
│       ├── Edit salary
│       ├── Override salary
│       ├── Add salary component
│       ├── Set effective date
│       └── View salary history
│
├── Rekening Bank Tab
│   ├── Primary Bank Account
│   ├── Secondary Bank Account
│   └── Actions
│       ├── Add bank
│       ├── Edit bank
│       ├── Set as primary
│       ├── Validate bank account
│       └── Request employee update
│
├── Profil Pajak Tab
│   ├── NIK
│   ├── NPWP
│   ├── PTKP status
│   ├── Tax method
│   ├── TER category
│   ├── Tax enabled
│   ├── Employee submitted data
│   └── HR approval status
│
├── Profil BPJS Tab
│   ├── BPJS Kesehatan number
│   ├── BPJS Ketenagakerjaan number
│   ├── BPJS Kesehatan active
│   ├── JHT active
│   ├── JP active
│   ├── JKK active
│   ├── JKM active
│   ├── JKP active
│   ├── BPJS base salary
│   ├── Employee submitted data
│   └── HR approval status
│
└── Reminder Action
    ├── Missing bank reminder
    ├── Missing tax reminder
    ├── Missing BPJS reminder
    ├── Invalid bank reminder
    ├── Send to employee app
    ├── Send to email
    └── Send to WhatsApp
```

---

# 5. Payslip

```text
Payslip
├── Payslip List
│   ├── Employee name
│   ├── Period
│   ├── Gross salary
│   ├── Deduction
│   ├── Net salary
│   ├── Payment status
│   ├── Payslip status
│   └── Delivery status
│
├── Payslip Right Sheet
│   ├── Summary Tab
│   ├── Earnings Tab
│   ├── Deductions Tab
│   ├── BPJS Tab
│   ├── PPh21 Tab
│   ├── Payment Status Tab
│   ├── Send History Tab
│   └── Download History Tab
│
├── Actions
│   ├── Preview payslip
│   ├── Download PDF
│   ├── Regenerate payslip
│   ├── Send to email
│   ├── Send to WhatsApp
│   └── Send employee app notification
│
├── Send Payslip Form
│   ├── Period
│   ├── Recipient scope
│   │   ├── All paid employees
│   │   ├── Selected department
│   │   ├── Selected employees
│   │   └── Not sent yet
│   │
│   ├── Channels
│   │   ├── Email
│   │   ├── WhatsApp
│   │   └── Employee app notification
│   │
│   ├── Options
│   │   ├── Attach PDF
│   │   ├── Include payment status
│   │   ├── Send only if paid
│   │   └── Skip missing contact
│   │
│   └── Actions
│       ├── Preview message
│       └── Send payslip
│
└── Delivery Logs
    ├── Channel
    ├── Recipient
    ├── Status
    ├── Sent at
    └── Failed reason
```

---

# 6. BPJS

```text
BPJS
├── BPJS Settings
├── BPJS Rate
├── Employee BPJS Profile
├── BPJS Calculation
└── BPJS Reports
```

Updated detail:

```text
BPJS
├── Tarif BPJS
├── Kalkulasi BPJS
├── BPJS Calculation Right Sheet
└── Laporan BPJS
```

---

# 7. Tax / PPh 21

```text
Tax / PPh 21
├── Tax Settings
├── PTKP Settings
├── TER Settings
├── Employee Tax Profile
├── PPh21 Calculation
└── Tax Reports
```

Updated detail:

```text
Tax / PPh 21
├── PTKP
├── TER
├── Kalkulasi PPh21
├── PPh21 Calculation Right Sheet
└── Laporan PPh21
```

---

# 8. Payroll Reports

```text
Payroll Reports
├── Payroll Summary Report
├── Employee Payroll Report
├── Department Payroll Cost Report
├── Branch Payroll Cost Report
├── BPJS Report
├── PPh21 Report
├── Payslip Report
├── Bank Transfer Report
├── Failed Payment Report
├── Overtime Cost Report
├── Attendance Deduction Report
├── Payroll Journal Report
└── Export History
```

---

# 9. Payroll Settings

```text
Payroll Settings
├── General Payroll Settings
├── Payroll Period & Cut-off
├── Payroll Type Defaults
├── Employee Selection Rules
├── Salary Calculation Rules
├── Salary Component Rules
├── Attendance Impact Rules
├── Overtime Rules
├── Proration Rules
├── BPJS Settings
├── PPh21 / Tax Settings
├── Payslip Settings
├── Payslip Delivery Settings
├── Payment / Disbursement Settings
├── Brick Funding VA Settings
├── Bank Account Validation Settings
├── Approval Flow Settings
├── Reminder & Employee Completion Settings
├── Report Export Settings
├── Security & Access Settings
└── Audit Log Settings
```
