# 10 — Notion Ready Final Backend Tasks

## Phase 1 — Foundation

```text
- [ ] Confirm final payroll menu structure.
- [ ] Confirm Supabase vs Laravel ownership.
- [ ] Create payroll_periods table.
- [ ] Create payroll_runs table.
- [ ] Create payroll_run_employees table.
- [ ] Create payroll_run_steps table.
- [ ] Create payroll_settings table.
- [ ] Create payroll_audit_logs table.
- [ ] Add tenant_id to all payroll tables.
- [ ] Add RLS policy for tenant isolation.
- [ ] Add indexes for payroll run, employee, status, period.
```

## Phase 2 — Employee Payroll Data

```text
- [ ] Create employee_payroll_profiles table.
- [ ] Create employee_bank_accounts table with primary/secondary slot.
- [ ] Create employee_tax_profiles table.
- [ ] Create employee_bpjs_profiles table.
- [ ] Create employee_salary_components table.
- [ ] Create employee_profile_submission_requests table.
- [ ] Create employee_profile_submissions table.
- [ ] Build EmployeePayrollService.
- [ ] Build BankAccountValidationService or add to PayrollValidationService.
- [ ] Build PayrollReminderService.
- [ ] Add employee self-service payroll submission endpoints.
```

## Phase 3 — Salary Components

```text
- [ ] Create salary_components table.
- [ ] Add component type: earning, deduction, benefit, reimbursement.
- [ ] Add calculation type: fixed, percentage, formula, attendance_based, overtime_based.
- [ ] Add taxable flag.
- [ ] Add BPJS base flag.
- [ ] Add visible on payslip flag.
- [ ] Add effective start/end date.
- [ ] Build SalaryComponentService.
- [ ] Add deactivate instead of delete logic.
- [ ] Add formula validation.
```

## Phase 4 — Payroll Run Flow

```text
- [ ] Build PayrollRunService.
- [ ] Build create payroll run.
- [ ] Apply payroll type default.
- [ ] Initialize payroll run steps.
- [ ] Build select employee flow.
- [ ] Build eligible employees query.
- [ ] Build sync attendance flow.
- [ ] Build calculation progress.
- [ ] Build review payroll data.
- [ ] Build lock payroll.
- [ ] Add right sheet response for payroll run detail.
```

## Phase 5 — Calculation Engine

```text
- [ ] Create payroll_calculations table.
- [ ] Create payroll_calculation_items table.
- [ ] Build PayrollCalculationService.
- [ ] Calculate base salary.
- [ ] Calculate prorated salary.
- [ ] Calculate fixed earnings.
- [ ] Calculate variable earnings.
- [ ] Calculate attendance deduction.
- [ ] Calculate overtime.
- [ ] Calculate BPJS.
- [ ] Calculate PPh21.
- [ ] Calculate net salary.
- [ ] Save calculation snapshot.
- [ ] Create issue if calculation fails.
```

## Phase 6 — BPJS

```text
- [ ] Create bpjs_rate_settings table.
- [ ] Create bpjs_employee_calculations table.
- [ ] Create bpjs_company_calculations table if needed.
- [ ] Build BPJSCalculationService.
- [ ] Add system default vs company override.
- [ ] Add effective date.
- [ ] Add salary cap.
- [ ] Add employee contribution.
- [ ] Add employer contribution.
- [ ] Add BPJS calculation right sheet response.
- [ ] Add BPJS report export.
```

## Phase 7 — PPh21

```text
- [ ] Create tax_ptkp_settings table.
- [ ] Create tax_ter_settings table.
- [ ] Create tax_pph21_calculations table.
- [ ] Create tax_yearly_summaries table.
- [ ] Build Pph21CalculationService.
- [ ] Add government default indicator.
- [ ] Add effective date.
- [ ] Add gross/nett/gross-up method.
- [ ] Add final month adjustment.
- [ ] Add PPh21 calculation right sheet response.
- [ ] Add PPh21 report export.
```

## Phase 8 — Issues and Resolution

```text
- [ ] Create payroll_issues table.
- [ ] Create payroll_issue_resolutions table.
- [ ] Build PayrollIssueService.
- [ ] Build PayrollIssueResolutionService.
- [ ] Add missing bank issue.
- [ ] Add invalid bank issue.
- [ ] Add tax missing issue.
- [ ] Add BPJS missing issue.
- [ ] Add calculation failed issue.
- [ ] Add payment failed issue.
- [ ] Add Brick funding expired issue.
- [ ] Add resolve by edit bank.
- [ ] Add resolve by switch bank.
- [ ] Add resolve by request employee update.
- [ ] Add resolve by mark manual paid.
- [ ] Add resolve by exclude employee.
- [ ] Add resolve by retry payment.
```

## Phase 9 — Approval

```text
- [ ] Create payroll_approval_flows table.
- [ ] Create payroll_approval_steps table.
- [ ] Create payroll_approval_histories table.
- [ ] Build PayrollApprovalService.
- [ ] Add approval flow builder.
- [ ] Add add/edit/delete approval step.
- [ ] Add specific approver person.
- [ ] Add role approver.
- [ ] Add conditional approval by payroll type.
- [ ] Add conditional approval by amount threshold.
- [ ] Add checkbox confirmation.
- [ ] Add drag-to-confirm validation.
- [ ] Save approver role snapshot.
- [ ] Save amount snapshot.
- [ ] Save IP and user agent.
- [ ] Auto lock after final approval.
- [ ] Auto create payment batch after lock if enabled.
```

## Phase 10 — Payment and Brick

```text
- [ ] Create payroll_payment_batches table.
- [ ] Create payroll_payment_items table.
- [ ] Create payroll_payment_attempts table.
- [ ] Create payroll_payment_webhooks table.
- [ ] Build PayrollPaymentService.
- [ ] Build DisbursementProviderInterface.
- [ ] Build ManualPaymentProvider.
- [ ] Build BankFileExportProvider.
- [ ] Build BrickFundingVirtualAccountService.
- [ ] Build BrickDisbursementProvider.
- [ ] Build BrickWebhookService.
- [ ] Generate Brick VA.
- [ ] Show VA detail.
- [ ] Check funding status.
- [ ] Process funding paid webhook.
- [ ] Process funding expired webhook.
- [ ] Send Brick disbursement after funding paid.
- [ ] Process payment success webhook.
- [ ] Process payment failed webhook.
- [ ] Retry failed transfer.
- [ ] Switch employee bank account.
- [ ] Mark manual paid with note/reference.
- [ ] Generate payment receipt.
- [ ] Export transfer detail.
```

## Phase 11 — Payslip

```text
- [ ] Create payslips table.
- [ ] Create payslip_items table.
- [ ] Create payslip_delivery_logs table.
- [ ] Build PayslipService.
- [ ] Generate payslip snapshot.
- [ ] Generate PDF.
- [ ] Upload PDF to Supabase Storage.
- [ ] Add payslip right sheet detail.
- [ ] Add earnings/deductions/BPJS/PPh21/payment/send history tabs.
- [ ] Build PayslipDeliveryService.
- [ ] Send payslip email.
- [ ] Send payslip WhatsApp.
- [ ] Send employee app notification.
- [ ] Add recipient scope.
- [ ] Add delivery log.
```

## Phase 12 — Reports

```text
- [ ] Create payroll_report_exports table.
- [ ] Build PayrollReportService.
- [ ] Build PayrollExportService.
- [ ] Add payroll summary report.
- [ ] Add employee payroll report.
- [ ] Add department payroll cost report.
- [ ] Add branch payroll cost report.
- [ ] Add BPJS report.
- [ ] Add PPh21 report.
- [ ] Add payslip report.
- [ ] Add bank transfer report.
- [ ] Add failed payment report.
- [ ] Add overtime cost report.
- [ ] Add attendance deduction report.
- [ ] Add payroll journal report.
- [ ] Add PDF export.
- [ ] Add Excel export.
- [ ] Add CSV export.
- [ ] Add payslip ZIP export.
- [ ] Add export history.
```

## Phase 13 — Payroll Settings

```text
- [ ] Build PayrollSettingService.
- [ ] Add General Payroll Settings.
- [ ] Add Payroll Period & Cut-off.
- [ ] Add Payroll Type Defaults.
- [ ] Add Employee Selection Rules.
- [ ] Add Salary Calculation Rules.
- [ ] Add Salary Component Rules.
- [ ] Add Attendance Impact Rules.
- [ ] Add Overtime Rules.
- [ ] Add Proration Rules.
- [ ] Add BPJS Settings.
- [ ] Add PPh21 / Tax Settings.
- [ ] Add Payslip Settings.
- [ ] Add Payslip Delivery Settings.
- [ ] Add Payment / Disbursement Settings.
- [ ] Add Brick Funding VA Settings.
- [ ] Add Bank Account Validation Settings.
- [ ] Add Approval Flow Settings.
- [ ] Add Reminder & Employee Completion Settings.
- [ ] Add Report Export Settings.
- [ ] Add Security & Access Settings.
- [ ] Add Audit Log Settings.
```

## Phase 14 — Security, Queue, Audit

```text
- [ ] Add JWT auth to all payroll APIs.
- [ ] Validate tenant_id on every request.
- [ ] Add role permission validation.
- [ ] Mask bank account number.
- [ ] Mask NPWP/NIK.
- [ ] Mask Brick credential.
- [ ] Store Brick secret in Laravel env/secret manager.
- [ ] Validate webhook signature.
- [ ] Add idempotency key for payment request.
- [ ] Add queue for calculation.
- [ ] Add queue for payslip generation.
- [ ] Add queue for Brick disbursement.
- [ ] Add queue for export report.
- [ ] Add audit log for all sensitive actions.
```
