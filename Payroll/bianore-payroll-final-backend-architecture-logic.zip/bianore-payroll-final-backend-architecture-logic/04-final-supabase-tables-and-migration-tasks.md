# 04 — Final Supabase Tables and Migration Tasks

## Final Supabase Tables

```text
payroll_periods
payroll_runs
payroll_run_employees
payroll_run_steps
payroll_calculations
payroll_calculation_items
salary_components
employee_salary_components
employee_payroll_profiles
employee_bank_accounts
employee_tax_profiles
employee_bpjs_profiles
bpjs_rate_settings
bpjs_employee_calculations
bpjs_company_calculations
tax_ptkp_settings
tax_ter_settings
tax_pph21_calculations
tax_yearly_summaries
payslips
payslip_items
payslip_delivery_logs
payroll_payment_batches
payroll_payment_items
payroll_payment_webhooks
payroll_payment_attempts
payroll_approval_flows
payroll_approval_steps
payroll_approval_histories
payroll_audit_logs
payroll_settings
payroll_report_exports
payroll_provider_settings
payroll_issues
payroll_issue_resolutions
employee_profile_submission_requests
employee_profile_submissions
```

---

# A. Core Payroll Tables

## payroll_periods

- [ ] Create payroll_periods table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add period_name varchar.
- [ ] Add month integer.
- [ ] Add year integer.
- [ ] Add cutoff_start_date date.
- [ ] Add cutoff_end_date date.
- [ ] Add payment_date date.
- [ ] Add status varchar default 'open'.
- [ ] Add is_locked boolean default false.
- [ ] Add locked_at timestamp nullable.
- [ ] Add locked_by UUID/bigint nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + month + year.
- [ ] Add index tenant_id + year + month.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_runs

- [ ] Create payroll_runs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_period_id UUID references payroll_periods(id).
- [ ] Add run_code varchar unique per tenant.
- [ ] Add run_name varchar.
- [ ] Add payroll_type varchar: monthly, correction, thr, bonus, final, failed_retry.
- [ ] Add month integer.
- [ ] Add year integer.
- [ ] Add cutoff_start_date date.
- [ ] Add cutoff_end_date date.
- [ ] Add payment_date date.
- [ ] Add status varchar default 'draft'.
- [ ] Add total_employees integer default 0.
- [ ] Add total_gross_salary numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add total_bpjs_employee numeric default 0.
- [ ] Add total_bpjs_employer numeric default 0.
- [ ] Add total_pph21 numeric default 0.
- [ ] Add total_net_salary numeric default 0.
- [ ] Add total_paid numeric default 0.
- [ ] Add total_failed_payment numeric default 0.
- [ ] Add submitted_at timestamp nullable.
- [ ] Add submitted_by UUID/bigint nullable.
- [ ] Add approved_at timestamp nullable.
- [ ] Add approved_by UUID/bigint nullable.
- [ ] Add locked_at timestamp nullable.
- [ ] Add locked_by UUID/bigint nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + month + year.
- [ ] Add index tenant_id + payment_date.
- [ ] Add RLS policy for tenant isolation.

## payroll_run_employees

- [ ] Create payroll_run_employees table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add employment_type varchar.
- [ ] Add department_id UUID/bigint nullable.
- [ ] Add branch_id UUID/bigint nullable.
- [ ] Add position_id UUID/bigint nullable.
- [ ] Add base_salary numeric default 0.
- [ ] Add prorated_salary numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add total_bpjs_employee numeric default 0.
- [ ] Add total_bpjs_employer numeric default 0.
- [ ] Add total_pph21 numeric default 0.
- [ ] Add gross_salary numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add payment_status varchar default 'pending'.
- [ ] Add calculation_status varchar default 'pending'.
- [ ] Add issue_status varchar default 'none'.
- [ ] Add issue_count integer default 0.
- [ ] Add is_excluded boolean default false.
- [ ] Add exclusion_reason text nullable.
- [ ] Add reviewed_at timestamp nullable.
- [ ] Add reviewed_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint payroll_run_id + employee_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + payment_status.
- [ ] Add index tenant_id + calculation_status.
- [ ] Add RLS policy for tenant isolation.

## payroll_run_steps

- [ ] Create payroll_run_steps table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add step_code varchar.
- [ ] Add step_name varchar.
- [ ] Add status varchar default 'pending'.
- [ ] Add progress_percentage integer default 0.
- [ ] Add started_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add error_count integer default 0.
- [ ] Add warning_count integer default 0.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint payroll_run_id + step_code.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + step_code.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

---

# B. Salary and Employee Payroll Tables

## salary_components

- [ ] Create salary_components table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add component_code varchar.
- [ ] Add component_name varchar.
- [ ] Add component_type varchar: earning, deduction, benefit, reimbursement.
- [ ] Add calculation_type varchar: fixed, percentage, formula, attendance_based, overtime_based.
- [ ] Add default_amount numeric default 0.
- [ ] Add default_percentage numeric default 0.
- [ ] Add formula text nullable.
- [ ] Add is_taxable boolean default true.
- [ ] Add is_bpjs_base boolean default false.
- [ ] Add is_recurring boolean default true.
- [ ] Add is_prorated boolean default false.
- [ ] Add is_visible_on_payslip boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add sort_order integer default 0.
- [ ] Add effective_start_date date nullable.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + component_code.
- [ ] Add index tenant_id + component_type.
- [ ] Add index tenant_id + is_active.
- [ ] Add RLS policy for tenant isolation.

## employee_salary_components

- [ ] Create employee_salary_components table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add salary_component_id UUID references salary_components(id).
- [ ] Add amount numeric default 0.
- [ ] Add percentage numeric default 0.
- [ ] Add formula_override text nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + salary_component_id.
- [ ] Add index tenant_id + effective_start_date + effective_end_date.
- [ ] Add RLS policy for tenant isolation.

## employee_payroll_profiles

- [ ] Create employee_payroll_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add payroll_status varchar default 'active'.
- [ ] Add salary_type varchar: monthly, daily, hourly, commission.
- [ ] Add base_salary numeric default 0.
- [ ] Add daily_rate numeric default 0.
- [ ] Add hourly_rate numeric default 0.
- [ ] Add prorate_method varchar default 'calendar_days'.
- [ ] Add overtime_eligible boolean default true.
- [ ] Add attendance_deduction_enabled boolean default true.
- [ ] Add tax_enabled boolean default true.
- [ ] Add bpjs_enabled boolean default true.
- [ ] Add payment_method varchar default 'bank_transfer'.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add override_reason text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + payroll_status.
- [ ] Add index tenant_id + salary_type.
- [ ] Add RLS policy for tenant isolation.

## employee_bank_accounts

- [ ] Create employee_bank_accounts table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bank_name varchar.
- [ ] Add bank_code varchar.
- [ ] Add account_number varchar.
- [ ] Add account_holder_name varchar.
- [ ] Add slot_type varchar: primary, secondary.
- [ ] Add is_primary boolean default false.
- [ ] Add validation_status varchar default 'unvalidated'.
- [ ] Add validation_provider varchar nullable.
- [ ] Add validated_at timestamp nullable.
- [ ] Add validation_response jsonb nullable.
- [ ] Add submission_source varchar: admin, employee.
- [ ] Add approval_status varchar: pending_review, approved, rejected.
- [ ] Add approved_by UUID/bigint nullable.
- [ ] Add approved_at timestamp nullable.
- [ ] Add name_match_status varchar nullable.
- [ ] Add name_match_score numeric nullable.
- [ ] Add last_used_for_payment_at timestamp nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + bank_code.
- [ ] Add index tenant_id + validation_status.
- [ ] Add index tenant_id + approval_status.
- [ ] Add RLS policy for tenant isolation.
- [ ] Add masking strategy for account_number in frontend response.

## employee_tax_profiles

- [ ] Create employee_tax_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add nik varchar nullable.
- [ ] Add npwp varchar nullable.
- [ ] Add ptkp_status varchar.
- [ ] Add tax_method varchar: gross, nett, gross_up.
- [ ] Add tax_enabled boolean default true.
- [ ] Add ter_category varchar nullable.
- [ ] Add submission_source varchar nullable.
- [ ] Add approval_status varchar nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + ptkp_status.
- [ ] Add index tenant_id + tax_method.
- [ ] Add RLS policy for tenant isolation.

## employee_bpjs_profiles

- [ ] Create employee_bpjs_profiles table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bpjs_kesehatan_number varchar nullable.
- [ ] Add bpjs_ketenagakerjaan_number varchar nullable.
- [ ] Add bpjs_kesehatan_active boolean default false.
- [ ] Add jht_active boolean default false.
- [ ] Add jp_active boolean default false.
- [ ] Add jkk_active boolean default false.
- [ ] Add jkm_active boolean default false.
- [ ] Add jkp_active boolean default false.
- [ ] Add jkk_risk_level varchar nullable.
- [ ] Add bpjs_base_salary numeric default 0.
- [ ] Add submission_source varchar nullable.
- [ ] Add approval_status varchar nullable.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + employee_id.
- [ ] Add index tenant_id + bpjs_kesehatan_active.
- [ ] Add index tenant_id + jht_active.
- [ ] Add RLS policy for tenant isolation.

---

# C. Calculation Tables

## payroll_calculations

- [ ] Create payroll_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add attendance_summary jsonb.
- [ ] Add base_salary numeric default 0.
- [ ] Add prorated_salary numeric default 0.
- [ ] Add gross_salary numeric default 0.
- [ ] Add taxable_income numeric default 0.
- [ ] Add non_taxable_income numeric default 0.
- [ ] Add total_earning numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add bpjs_employee_total numeric default 0.
- [ ] Add bpjs_employer_total numeric default 0.
- [ ] Add pph21_amount numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add calculation_status varchar default 'success'.
- [ ] Add calculation_note text nullable.
- [ ] Add calculation_snapshot jsonb nullable.
- [ ] Add calculated_at timestamp nullable.
- [ ] Add calculated_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_calculation_items

- [ ] Create payroll_calculation_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_calculation_id UUID references payroll_calculations(id).
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add salary_component_id UUID nullable.
- [ ] Add item_code varchar.
- [ ] Add item_name varchar.
- [ ] Add item_type varchar: earning, deduction, benefit, tax, bpjs.
- [ ] Add amount numeric default 0.
- [ ] Add quantity numeric default 1.
- [ ] Add rate numeric default 0.
- [ ] Add calculation_source varchar.
- [ ] Add is_taxable boolean default true.
- [ ] Add is_visible_on_payslip boolean default true.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_calculation_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

---

# D. BPJS and Tax Tables

## bpjs_rate_settings

- [ ] Create bpjs_rate_settings table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID nullable for tenant override or null for system default.
- [ ] Add program_code varchar.
- [ ] Add program_name varchar.
- [ ] Add employee_rate numeric default 0.
- [ ] Add employer_rate numeric default 0.
- [ ] Add salary_cap numeric nullable.
- [ ] Add risk_level varchar nullable for JKK.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_company_override boolean default false.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index program_code + effective_start_date.
- [ ] Add index tenant_id + program_code.

## bpjs_employee_calculations

- [ ] Create bpjs_employee_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add program_code varchar.
- [ ] Add base_salary numeric default 0.
- [ ] Add employee_rate numeric default 0.
- [ ] Add employer_rate numeric default 0.
- [ ] Add employee_amount numeric default 0.
- [ ] Add employer_amount numeric default 0.
- [ ] Add total_amount numeric default 0.
- [ ] Add calculation_note text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + program_code.
- [ ] Add RLS policy for tenant isolation.

## tax_ptkp_settings

- [ ] Create tax_ptkp_settings table.
- [ ] Add id UUID primary key.
- [ ] Add ptkp_code varchar.
- [ ] Add ptkp_name varchar.
- [ ] Add amount numeric.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().

## tax_ter_settings

- [ ] Create tax_ter_settings table.
- [ ] Add id UUID primary key.
- [ ] Add ter_category varchar.
- [ ] Add income_min numeric.
- [ ] Add income_max numeric nullable.
- [ ] Add rate numeric.
- [ ] Add effective_start_date date.
- [ ] Add effective_end_date date nullable.
- [ ] Add is_system_default boolean default true.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index ter_category + income_min + income_max.

## tax_pph21_calculations

- [ ] Create tax_pph21_calculations table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add ptkp_status varchar.
- [ ] Add tax_method varchar.
- [ ] Add ter_category varchar nullable.
- [ ] Add gross_income numeric default 0.
- [ ] Add taxable_income numeric default 0.
- [ ] Add tax_rate numeric default 0.
- [ ] Add pph21_amount numeric default 0.
- [ ] Add gross_up_allowance numeric default 0.
- [ ] Add final_tax_adjustment numeric default 0.
- [ ] Add calculation_detail jsonb nullable.
- [ ] Add calculated_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

---

# E. Payslip Tables

## payslips

- [ ] Create payslips table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add payslip_number varchar.
- [ ] Add period_month integer.
- [ ] Add period_year integer.
- [ ] Add gross_salary numeric default 0.
- [ ] Add total_deduction numeric default 0.
- [ ] Add net_salary numeric default 0.
- [ ] Add file_path text nullable.
- [ ] Add file_url text nullable.
- [ ] Add status varchar default 'draft'.
- [ ] Add generated_at timestamp nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add downloaded_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + payslip_number.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add RLS policy for tenant isolation.

## payslip_items

- [ ] Create payslip_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payslip_id UUID references payslips(id).
- [ ] Add item_code varchar.
- [ ] Add item_name varchar.
- [ ] Add item_type varchar.
- [ ] Add amount numeric default 0.
- [ ] Add sort_order integer default 0.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payslip_id.
- [ ] Add RLS policy for tenant isolation.

## payslip_delivery_logs

- [ ] Create payslip_delivery_logs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payslip_id UUID references payslips(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add channel varchar: email, whatsapp, employee_app.
- [ ] Add recipient varchar.
- [ ] Add status varchar: pending, sent, failed.
- [ ] Add message_template text nullable.
- [ ] Add provider varchar nullable.
- [ ] Add provider_message_id varchar nullable.
- [ ] Add failed_reason text nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payslip_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + channel + status.
- [ ] Add RLS policy for tenant isolation.

---

# F. Payment and Brick Tables

## payroll_payment_batches

- [ ] Create payroll_payment_batches table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add batch_code varchar.
- [ ] Add provider varchar: manual, bank_file, doku, oy, xendit, bank_api, brick.
- [ ] Add source_bank_account_id UUID/bigint nullable.
- [ ] Add total_amount numeric default 0.
- [ ] Add total_employees integer default 0.
- [ ] Add success_count integer default 0.
- [ ] Add failed_count integer default 0.
- [ ] Add pending_count integer default 0.
- [ ] Add status varchar default 'pending'.
- [ ] Add provider_batch_id varchar nullable.
- [ ] Add provider_response jsonb nullable.
- [ ] Add funding_status varchar default 'not_created'.
- [ ] Add funding_method varchar nullable.
- [ ] Add funding_va_bank varchar nullable.
- [ ] Add funding_va_bank_code varchar nullable.
- [ ] Add funding_va_number varchar nullable.
- [ ] Add funding_va_name varchar nullable.
- [ ] Add funding_amount numeric default 0.
- [ ] Add funding_expired_at timestamp nullable.
- [ ] Add funding_paid_at timestamp nullable.
- [ ] Add disbursement_status varchar default 'not_started'.
- [ ] Add brick_batch_id varchar nullable.
- [ ] Add brick_reference_id varchar nullable.
- [ ] Add brick_status varchar nullable.
- [ ] Add brick_response jsonb nullable.
- [ ] Add submitted_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + batch_code.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + funding_status.
- [ ] Add index tenant_id + disbursement_status.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_items

- [ ] Create payroll_payment_items table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payment_batch_id UUID references payroll_payment_batches(id).
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint references employees(id).
- [ ] Add bank_name varchar.
- [ ] Add bank_code varchar.
- [ ] Add account_number varchar.
- [ ] Add account_holder_name varchar.
- [ ] Add amount numeric default 0.
- [ ] Add transfer_note text nullable.
- [ ] Add status varchar default 'pending'.
- [ ] Add provider_transaction_id varchar nullable.
- [ ] Add provider_reference varchar nullable.
- [ ] Add brick_transaction_id varchar nullable.
- [ ] Add brick_reference_id varchar nullable.
- [ ] Add brick_status varchar nullable.
- [ ] Add failure_code varchar nullable.
- [ ] Add failure_reason text nullable.
- [ ] Add manual_paid boolean default false.
- [ ] Add manual_paid_at timestamp nullable.
- [ ] Add manual_paid_by UUID/bigint nullable.
- [ ] Add manual_paid_reference varchar nullable.
- [ ] Add manual_paid_note text nullable.
- [ ] Add resolution_status varchar nullable.
- [ ] Add resolution_note text nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add resolved_at timestamp nullable.
- [ ] Add switched_bank_account_id UUID nullable.
- [ ] Add retry_count integer default 0.
- [ ] Add last_retry_at timestamp nullable.
- [ ] Add paid_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + payment_batch_id.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + status.
- [ ] Add index tenant_id + resolution_status.
- [ ] Add index tenant_id + manual_paid.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_attempts

- [ ] Create payroll_payment_attempts table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payment_item_id UUID references payroll_payment_items(id).
- [ ] Add attempt_number integer default 1.
- [ ] Add provider varchar.
- [ ] Add request_payload jsonb nullable.
- [ ] Add response_payload jsonb nullable.
- [ ] Add status varchar.
- [ ] Add error_code varchar nullable.
- [ ] Add error_message text nullable.
- [ ] Add attempted_at timestamp default now().
- [ ] Add index tenant_id + payment_item_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_payment_webhooks

- [ ] Create payroll_payment_webhooks table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID nullable.
- [ ] Add provider varchar.
- [ ] Add event_type varchar.
- [ ] Add provider_transaction_id varchar nullable.
- [ ] Add provider_batch_id varchar nullable.
- [ ] Add raw_payload jsonb not null.
- [ ] Add signature_valid boolean default false.
- [ ] Add processed boolean default false.
- [ ] Add processed_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index provider + provider_transaction_id.
- [ ] Add index provider + provider_batch_id.
- [ ] Add index processed.

---

# G. Approval, Audit, Issues, Settings

## payroll_approval_flows

- [ ] Create payroll_approval_flows table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add flow_name varchar.
- [ ] Add applies_to_payroll_type varchar nullable.
- [ ] Add amount_threshold numeric nullable.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add index tenant_id + is_active.
- [ ] Add RLS policy for tenant isolation.

## payroll_approval_steps

- [ ] Create payroll_approval_steps table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add approval_flow_id UUID references payroll_approval_flows(id).
- [ ] Add step_order integer.
- [ ] Add role_required varchar.
- [ ] Add specific_approver_id UUID/bigint nullable.
- [ ] Add approval_type varchar default 'single'.
- [ ] Add is_required boolean default true.
- [ ] Add can_request_revision boolean default true.
- [ ] Add can_approve_payment boolean default false.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + approval_flow_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_approval_histories

- [ ] Create payroll_approval_histories table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID references payroll_runs(id).
- [ ] Add approval_step_id UUID nullable.
- [ ] Add action varchar: submitted, approved, rejected, revision_requested.
- [ ] Add note text nullable.
- [ ] Add acted_by UUID/bigint nullable.
- [ ] Add acted_at timestamp default now().
- [ ] Add approver_role_snapshot varchar nullable.
- [ ] Add payroll_amount_snapshot numeric nullable.
- [ ] Add total_employee_snapshot integer nullable.
- [ ] Add checkbox_confirmed boolean default false.
- [ ] Add drag_confirmed boolean default false.
- [ ] Add confirmation_text text nullable.
- [ ] Add ip_address varchar nullable.
- [ ] Add user_agent text nullable.
- [ ] Add approval_device jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add RLS policy for tenant isolation.

## payroll_issues

- [ ] Create payroll_issues table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID nullable references payroll_runs(id).
- [ ] Add payroll_run_employee_id UUID nullable references payroll_run_employees(id).
- [ ] Add employee_id UUID/bigint nullable.
- [ ] Add issue_code varchar.
- [ ] Add issue_title varchar.
- [ ] Add issue_description text nullable.
- [ ] Add severity varchar: info, warning, blocking.
- [ ] Add status varchar default 'open'.
- [ ] Add source varchar.
- [ ] Add suggested_actions jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add resolved_at timestamp nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + issue_code.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_issue_resolutions

- [ ] Create payroll_issue_resolutions table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_issue_id UUID references payroll_issues(id).
- [ ] Add resolution_action varchar.
- [ ] Add resolution_note text nullable.
- [ ] Add resolved_by UUID/bigint nullable.
- [ ] Add resolved_at timestamp default now().
- [ ] Add old_values jsonb nullable.
- [ ] Add new_values jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add index tenant_id + payroll_issue_id.
- [ ] Add RLS policy for tenant isolation.

## employee_profile_submission_requests

- [ ] Create employee_profile_submission_requests table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint not null.
- [ ] Add request_type varchar: bank, tax, bpjs, payroll_profile.
- [ ] Add title varchar.
- [ ] Add message text.
- [ ] Add status varchar default 'pending'.
- [ ] Add due_date date nullable.
- [ ] Add sent_by UUID/bigint nullable.
- [ ] Add sent_at timestamp nullable.
- [ ] Add completed_at timestamp nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + request_type + status.
- [ ] Add RLS policy for tenant isolation.

## employee_profile_submissions

- [ ] Create employee_profile_submissions table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add employee_id UUID/bigint not null.
- [ ] Add request_id UUID nullable references employee_profile_submission_requests(id).
- [ ] Add submission_type varchar: bank, tax, bpjs.
- [ ] Add payload jsonb not null.
- [ ] Add status varchar default 'pending_review'.
- [ ] Add reviewed_by UUID/bigint nullable.
- [ ] Add reviewed_at timestamp nullable.
- [ ] Add rejection_reason text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + submission_type + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_settings

- [ ] Create payroll_settings table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add setting_group varchar.
- [ ] Add setting_key varchar.
- [ ] Add setting_value jsonb.
- [ ] Add is_active boolean default true.
- [ ] Add created_at timestamp default now().
- [ ] Add updated_at timestamp default now().
- [ ] Add unique constraint tenant_id + setting_group + setting_key.
- [ ] Add index tenant_id + setting_group.
- [ ] Add RLS policy for tenant isolation.

## payroll_report_exports

- [ ] Create payroll_report_exports table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add report_type varchar.
- [ ] Add period_type varchar: monthly, yearly, custom.
- [ ] Add month integer nullable.
- [ ] Add year integer nullable.
- [ ] Add start_date date nullable.
- [ ] Add end_date date nullable.
- [ ] Add scope_type varchar: all, department, branch, selected_employees, single_employee.
- [ ] Add scope_payload jsonb nullable.
- [ ] Add format varchar: pdf, excel, csv, zip.
- [ ] Add status varchar default 'pending'.
- [ ] Add file_path text nullable.
- [ ] Add file_url text nullable.
- [ ] Add created_by UUID/bigint nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add completed_at timestamp nullable.
- [ ] Add failed_reason text nullable.
- [ ] Add index tenant_id + report_type.
- [ ] Add index tenant_id + status.
- [ ] Add RLS policy for tenant isolation.

## payroll_audit_logs

- [ ] Create payroll_audit_logs table.
- [ ] Add id UUID primary key.
- [ ] Add tenant_id UUID not null.
- [ ] Add payroll_run_id UUID nullable.
- [ ] Add employee_id UUID/bigint nullable.
- [ ] Add actor_id UUID/bigint nullable.
- [ ] Add event_type varchar.
- [ ] Add description text.
- [ ] Add old_values jsonb nullable.
- [ ] Add new_values jsonb nullable.
- [ ] Add metadata jsonb nullable.
- [ ] Add ip_address varchar nullable.
- [ ] Add user_agent text nullable.
- [ ] Add created_at timestamp default now().
- [ ] Add index tenant_id + payroll_run_id.
- [ ] Add index tenant_id + employee_id.
- [ ] Add index tenant_id + event_type.
- [ ] Add RLS policy for tenant isolation.
