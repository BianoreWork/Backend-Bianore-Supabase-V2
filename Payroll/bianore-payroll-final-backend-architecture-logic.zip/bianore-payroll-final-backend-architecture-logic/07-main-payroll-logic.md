# 07 — Main Payroll Logic

## Final End-to-End Logic

```text
Create Payroll Period
→ Create Payroll Run
→ Select Payroll Type
→ Apply Payroll Type Defaults
→ Select Employees
→ Validate Employee Payroll Data
→ Sync Attendance
→ Calculate Salary
→ Calculate Allowance & Deduction
→ Calculate BPJS
→ Calculate PPh21
→ Review Payroll
→ Resolve Issues
→ Submit Approval
→ Approval Confirmation
→ Final Approval
→ Lock Payroll
→ Create Payment Batch
→ Generate Brick Funding VA
→ Company Pays VA
→ Brick Confirms Funding Paid
→ Send Brick Disbursement
→ Receive Webhook Status
→ Retry / Resolve Failed Payment
→ Generate Payslip
→ Send Payslip
→ Export Reports
```

---

## Payroll Type Logic

## Monthly Payroll

```text
- Auto include active monthly employees.
- Use default cut-off.
- Require attendance sync.
- Require BPJS if enabled.
- Require PPh21 if enabled.
- Require approval.
- Require payment batch.
- Require disbursement.
```

## Correction Payroll

```text
- Flexible employee selection.
- Can pull failed transfer employees from payment items.
- Can add manual earning/deduction adjustment.
- Can regenerate correction payslip.
- Can use approval based on settings.
```

## THR Payroll

```text
- Include eligible employees.
- Use THR formula.
- Attendance sync optional.
- Tax calculation required.
- Approval required.
- Disbursement enabled if setting active.
```

## Failed Payment Retry Payroll

```text
- Pull failed payment items.
- Does not recalculate salary unless correction needed.
- Allows switch bank account.
- Allows retry transfer.
- Allows mark manual paid.
```

---

## Payroll Run Step Logic

## Step 1 — Setup Payroll

```text
- Create period/run.
- Apply payroll type defaults.
- Initialize run steps.
- Validate cut-off and payment date.
```

## Step 2 — Select Employees

```text
- Auto select employees if monthly payroll.
- Manual select if correction/bonus.
- Pull failed payment employees if failed retry/correction.
- Validate payroll profile, bank, tax, BPJS.
- Create issues for missing data.
```

## Step 3 — Sync Attendance

```text
- Pull attendance between cut-off dates.
- Count present/late/absent/leave/sick/unpaid leave.
- Count overtime/no checkout/attendance flags.
- Save attendance_summary snapshot.
```

## Step 4 — Calculate Salary

```text
- Load payroll profile.
- Load salary components.
- Calculate base salary.
- Calculate prorated salary.
- Calculate earnings.
- Calculate deductions.
- Calculate overtime.
- Calculate attendance deduction.
- Calculate BPJS.
- Calculate PPh21.
- Save calculation result and items.
```

## Step 5 — Review and Resolve Issues

```text
- Show employee list.
- Show calculation result.
- Show issue badges.
- Allow resolve: edit bank, switch bank, request update, exclude, recalculate.
```

## Step 6 — Approval

```text
- Submit approval.
- Load approval flow.
- Approver confirms with checkbox and drag-to-confirm.
- Save role, amount, employee count, IP, user agent.
- Final approval locks payroll.
```

## Step 7 — Payment Batch

```text
- Create payment batch after lock.
- Create payment item per employee.
- Validate bank account.
- Mark invalid payments as issue.
```

## Step 8 — Brick Funding VA

```text
- Generate VA.
- Company pays VA.
- Brick webhook confirms funding.
```

## Step 9 — Brick Disbursement

```text
- Send disbursement after funding paid.
- Track status per employee.
- Retry/switch/manual paid if failed.
```

## Step 10 — Payslip

```text
- Generate payslip snapshot.
- Generate PDF.
- Send by email/WhatsApp/app.
- Save delivery logs.
```

---

## Calculation Formula

```text
Gross Salary
= Base Salary
+ Fixed Earnings
+ Variable Earnings
+ Overtime
+ Bonus
+ Reimbursement
+ THR/Commission if applicable
```

```text
Total Deduction
= Attendance Deduction
+ Unpaid Leave Deduction
+ Loan Deduction
+ BPJS Employee Contribution
+ PPh21
+ Other Deduction
```

```text
Net Salary
= Gross Salary - Total Deduction
```

---

## Snapshot Rule

Every payroll calculation must save snapshot:

```text
- employee payroll profile
- salary components
- attendance summary
- BPJS rate
- tax rate
- calculation result
```

Reason:

```text
Changes in future salary/profile/settings must not change old payroll result.
```
